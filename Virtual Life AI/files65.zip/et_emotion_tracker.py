#!/usr/bin/env python3
"""
ET Emotion Lattice Tower v3.0 — Batch Processing & Tracking Tool
=================================================================
The exact framework used to derive and verify 853 emotions across 71 batches.

Usage:
    1. Define emotions with their 6 ET-derived inputs
    2. Run through the EmotionLattice system
    3. Get full output: Lövheim cube (DA/NE/5HT), PAD, primary emotion, 
       intensity, blend weights
    4. Run PAD sanity checks

All inputs are derived using the three ET analytical tools:
    - Identification Principle: Understand(X) ⟺ Identified(P_X) ∧ D_X ∧ T_X
    - Descriptor Gap Principle: Any gap is itself a descriptor
    - Subsumption Law: Completeness and irreducibility

Constants: S=12, K=2/3, V=1/12 (all ET-native, zero tuning)

Author: Mike Muller (Aevum Defluo) / Exception Theory
"""

import sys
import os

# Add path to ET Conscious AI modules
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from et_conscious_ai_identity import (
    EgoInvariant, EmotionLattice
)


# ═══════════════════════════════════════════════════════════════════════
# CORE PROCESSING FUNCTION
# ═══════════════════════════════════════════════════════════════════════

def derive_emotion(name, definition, derivation_notes, 
                   novelty, variance, ego_resonance,
                   pdt_completeness, gap_awareness, normative_significance,
                   ego=None):
    """
    Process a single emotion through the ET Emotion Lattice Tower.
    
    All 6 inputs must be derived using the three ET analytical tools:
    
    FROM P (Point) - substrate/ground:
        variance        [0.0-0.3]  Instability of the experiential substrate
        
    FROM D (Descriptor) - what is being described:
        novelty         [0.0-1.0]  How unexpected/new the descriptor is
        normative_significance [-1.0 to +1.0]  Values alignment 
                                               (positive=aligned, negative=violated)
        
    FROM T (Traverser) - the experiencing agent:
        ego_resonance   [0.0-1.0]  How strongly T is engaged/activated
        pdt_completeness [0.0-1.0] T's capacity to handle the situation
        
    FROM GAP (Descriptor Gap Principle):
        gap_awareness   [0.0-1.0]  Size of the identified gap in the D-set
    
    Returns dict with all computed values.
    """
    if ego is None:
        ego = EgoInvariant(name='EmotionTracker')
    
    el = EmotionLattice(ego)
    state = el.appraise(
        novelty=novelty,
        variance=variance,
        ego_resonance=ego_resonance,
        pdt_completeness=pdt_completeness,
        gap_awareness=gap_awareness,
        normative_significance=normative_significance
    )
    
    coord = state.coord
    lv = coord.lovheim
    weights = lv.blend_weights()
    top3 = sorted(weights.items(), key=lambda x: -x[1])[:3]
    blend_str = ', '.join(f'{p.name}={v:.2f}' for p, v in top3)
    
    return {
        'name': name,
        'definition': definition,
        'derivation': derivation_notes,
        # Lövheim Cube coordinates
        'da': lv.da,
        'ne': lv.ne,
        'sht': lv.sht,
        # PAD coordinates
        'P': coord.pad.pleasure,
        'A': coord.pad.arousal,
        'D': coord.pad.dominance,
        # Emotion classification
        'emotion_name': coord.emotion_name,
        'primary': coord.primary.name,
        'intensity_level': coord.intensity_level,
        'blend': blend_str,
        # Lattice metadata
        'k': coord.k,
        'd': coord.d,
        'manifold_state': coord.manifold_state,
        # Raw inputs (for audit)
        'inputs': {
            'novelty': novelty,
            'variance': variance,
            'ego_resonance': ego_resonance,
            'pdt_completeness': pdt_completeness,
            'gap_awareness': gap_awareness,
            'normative_significance': normative_significance,
        }
    }


# ═══════════════════════════════════════════════════════════════════════
# BATCH PROCESSING
# ═══════════════════════════════════════════════════════════════════════

def process_batch(batch_name, emotions, sanity_checks=None):
    """
    Process a batch of emotions and run sanity checks.
    
    emotions: list of dicts, each with keys:
        name, definition, derivation,
        novelty, variance, ego_resonance, 
        pdt_completeness, gap_awareness, normative_significance
        
    sanity_checks: list of tuples:
        (emotion_name, check_description, lambda_fn, reason_string)
    
    Returns list of result dicts.
    """
    ego = EgoInvariant(name=batch_name)
    results = []
    
    print("=" * 120)
    print(f"ET EMOTION LATTICE TOWER — {batch_name}")
    print("ALL inputs derived: Identification Principle + Descriptor Gap + Subsumption Law")
    print("=" * 120)
    
    for em in emotions:
        r = derive_emotion(
            name=em['name'],
            definition=em['definition'],
            derivation_notes=em['derivation'],
            novelty=em['novelty'],
            variance=em['variance'],
            ego_resonance=em['ego_resonance'],
            pdt_completeness=em['pdt_completeness'],
            gap_awareness=em['gap_awareness'],
            normative_significance=em['normative_significance'],
            ego=ego
        )
        results.append(r)
        
        print(f"\n{'─'*120}")
        print(f"  {r['name']:20s} — {r['definition']}")
        print(f"  Derivation: {r['derivation']}")
        print(f"  Cube:   DA={r['da']:.3f}  NE={r['ne']:.3f}  5HT={r['sht']:.3f}")
        print(f"  PAD:    P={r['P']:+.3f}  A={r['A']:.3f}  D={r['D']:.3f}")
        print(f"  Result: {r['emotion_name']:20s}  primary={r['primary']:12s}  intensity={r['intensity_level']}")
        print(f"  Blend:  {r['blend']}")
    
    # Summary table
    print(f"\n{'='*120}")
    print("SUMMARY")
    print(f"{'='*120}")
    hdr = f"  {'#':>2s} {'Emotion':20s} {'Output':15s} {'Primary':12s} {'I':>1s} {'DA':>6s} {'NE':>6s} {'5HT':>6s} {'P':>7s} {'A':>5s} {'D':>5s}"
    div = f"  {'─'*2} {'─'*20} {'─'*15} {'─'*12} {'─'*1} {'─'*6} {'─'*6} {'─'*6} {'─'*7} {'─'*5} {'─'*5}"
    print(hdr)
    print(div)
    for i, r in enumerate(results, 1):
        print(f"  {i:2d} {r['name']:20s} {r['emotion_name']:15s} {r['primary']:12s} "
              f"{r['intensity_level']:1d} {r['da']:6.3f} {r['ne']:6.3f} {r['sht']:6.3f} "
              f"{r['P']:+7.3f} {r['A']:5.3f} {r['D']:5.3f}")
    
    # Unique counts
    ue = sorted(set(r['emotion_name'] for r in results))
    up = sorted(set(r['primary'] for r in results))
    print(f"\n  Unique emotions:  {len(ue)}/{len(results)}: {ue}")
    print(f"  Unique primaries: {len(up)}/8:  {up}")
    
    # Sanity checks
    if sanity_checks:
        print(f"\n  PAD SANITY:")
        passed = 0
        total = len(sanity_checks)
        for (em_name, desc, check_fn, reason) in sanity_checks:
            r = next((x for x in results if x['name'] == em_name), None)
            if r is None:
                print(f"    ? {em_name:20s} {desc:15s} (NOT FOUND)")
                continue
            ok = check_fn(r)
            passed += ok
            print(f"    {'✓' if ok else '✗'} {em_name:20s} {desc:15s} ({reason})")
        print(f"  {passed}/{total} pass")
    
    return results


# ═══════════════════════════════════════════════════════════════════════
# EXPORT FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════

def results_to_csv(all_results, filepath):
    """Export all results to CSV for analysis."""
    import csv
    
    fieldnames = [
        'name', 'definition', 'derivation',
        'da', 'ne', 'sht',
        'P', 'A', 'D',
        'emotion_name', 'primary', 'intensity_level', 'blend',
        'k', 'd', 'manifold_state',
        'novelty', 'variance', 'ego_resonance',
        'pdt_completeness', 'gap_awareness', 'normative_significance'
    ]
    
    with open(filepath, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for r in all_results:
            row = {k: r.get(k, '') for k in fieldnames if k not in r.get('inputs', {})}
            row.update(r.get('inputs', {}))
            # Flatten
            flat = {}
            for k in fieldnames:
                if k in r:
                    flat[k] = r[k]
                elif k in r.get('inputs', {}):
                    flat[k] = r['inputs'][k]
                else:
                    flat[k] = ''
            writer.writerow(flat)
    
    print(f"Exported {len(all_results)} emotions to {filepath}")


def results_to_markdown(all_results, filepath, title="ET Emotion Derivations"):
    """Export all results to a markdown table."""
    with open(filepath, 'w') as f:
        f.write(f"# {title}\n\n")
        f.write(f"Total: {len(all_results)} emotions derived via ET Identification Principle, "
                f"Descriptor Gap Principle, and Subsumption Law.\n\n")
        f.write(f"Constants: S=12, K=2/3, V=1/12. Zero tuned coefficients.\n\n")
        
        f.write("| # | Emotion | Output | Primary | IL | DA | NE | 5HT | P | A | D |\n")
        f.write("|---|---------|--------|---------|----|----|----|----|---|---|---|\n")
        
        for i, r in enumerate(all_results, 1):
            f.write(f"| {i} | {r['name']} | {r['emotion_name']} | {r['primary']} | "
                    f"{r['intensity_level']} | {r['da']:.3f} | {r['ne']:.3f} | {r['sht']:.3f} | "
                    f"{r['P']:+.3f} | {r['A']:.3f} | {r['D']:.3f} |\n")
        
        f.write(f"\n---\n\n")
        
        # Detailed derivations
        f.write("## Detailed Derivations\n\n")
        for i, r in enumerate(all_results, 1):
            f.write(f"### {i}. {r['name']}\n\n")
            f.write(f"**Definition:** {r['definition']}\n\n")
            f.write(f"**ET Derivation:** {r['derivation']}\n\n")
            f.write(f"**Cube:** DA={r['da']:.3f}, NE={r['ne']:.3f}, 5HT={r['sht']:.3f}\n\n")
            f.write(f"**PAD:** P={r['P']:+.3f}, A={r['A']:.3f}, D={r['D']:.3f}\n\n")
            f.write(f"**Result:** {r['emotion_name']} (primary={r['primary']}, "
                    f"intensity={r['intensity_level']})\n\n")
            f.write(f"**Blend:** {r['blend']}\n\n")
    
    print(f"Exported {len(all_results)} emotions to {filepath}")


# ═══════════════════════════════════════════════════════════════════════
# EXAMPLE USAGE / DEMO
# ═══════════════════════════════════════════════════════════════════════

if __name__ == '__main__':
    
    # ─── Define emotions with ET-derived inputs ───
    # Each emotion is decomposed using the three ET tools:
    #   P (Point):     → variance (substrate instability)
    #   D (Descriptor): → novelty (how new), normative_significance (values alignment)  
    #   T (Traverser):  → ego_resonance (engagement), pdt_completeness (capacity)
    #   Gap:            → gap_awareness (size of identified gap in D-set)
    
    demo_emotions = [
        {
            'name': 'JOY',
            'definition': 'A feeling of great pleasure and happiness',
            'derivation': 'P:warm(0.04) D:pleasant(nov=0.15,norm=0.6) T:engaged(ego=0.75,pdt=0.8) Gap:clear(0.1)',
            'novelty': 0.15, 'variance': 0.04, 'ego_resonance': 0.75,
            'pdt_completeness': 0.8, 'gap_awareness': 0.1, 'normative_significance': 0.6,
        },
        {
            'name': 'FEAR',
            'definition': 'An unpleasant emotion caused by threat of danger or harm',
            'derivation': 'P:trembling(0.20) D:threat(nov=0.3,norm=-0.3) T:flight(ego=0.75,pdt=0.15) Gap:danger(0.35)',
            'novelty': 0.3, 'variance': 0.20, 'ego_resonance': 0.75,
            'pdt_completeness': 0.15, 'gap_awareness': 0.35, 'normative_significance': -0.3,
        },
        {
            'name': 'RAGE',
            'definition': 'Violent uncontrollable anger',
            'derivation': 'P:volcanic(0.08) D:fury(nov=0.1,norm=-0.95) T:maximum(ego=0.95,pdt=0.85) Gap:clear(0.05)',
            'novelty': 0.1, 'variance': 0.08, 'ego_resonance': 0.95,
            'pdt_completeness': 0.85, 'gap_awareness': 0.05, 'normative_significance': -0.95,
        },
        {
            'name': 'SAUDADE',
            'definition': 'Deep melancholic longing for an absent beloved',
            'derivation': 'P:aching(0.12) D:absence(nov=0.1,norm=-0.5) T:consumed(ego=0.65,pdt=0.2) Gap:beloved_absent(0.45)',
            'novelty': 0.1, 'variance': 0.12, 'ego_resonance': 0.65,
            'pdt_completeness': 0.2, 'gap_awareness': 0.45, 'normative_significance': -0.5,
        },
        {
            'name': 'NIRVANA',
            'definition': 'Ultimate happiness; total liberation from suffering',
            'derivation': 'P:infinite(0.01) D:liberation(nov=0.05,norm=0.95) T:transcendent(ego=0.7,pdt=0.95) Gap:zero(0.0)',
            'novelty': 0.05, 'variance': 0.01, 'ego_resonance': 0.7,
            'pdt_completeness': 0.95, 'gap_awareness': 0.0, 'normative_significance': 0.95,
        },
    ]
    
    # ─── Define sanity checks ───
    demo_checks = [
        ('JOY',     'P>0.3',   lambda r: r['P'] > 0.3,   'happiness=pleasant'),
        ('FEAR',    'FEAR',     lambda r: r['primary'] == 'FEAR', 'threat=fear'),
        ('FEAR',    'A>0.5',   lambda r: r['A'] > 0.5,   'danger=activated'),
        ('RAGE',    'ANGER',    lambda r: r['primary'] == 'ANGER', 'rage=anger'),
        ('RAGE',    'il=2',    lambda r: r['intensity_level'] == 2, 'violent=high intensity'),
        ('SAUDADE', 'P<-0.3',  lambda r: r['P'] < -0.3,  'longing=unpleasant'),
        ('NIRVANA', 'P>0.5',   lambda r: r['P'] > 0.5,   'liberation=very pleasant'),
    ]
    
    # ─── Process ───
    results = process_batch("DEMO BATCH", demo_emotions, demo_checks)
    
    print(f"\n{'='*120}")
    print("DERIVATION GUIDE — How to use the three ET tools:")
    print(f"{'='*120}")
    print("""
    For each emotion definition, apply:
    
    1. IDENTIFICATION PRINCIPLE — Understand(X) ⟺ Identified(P_X) ∧ D_X ∧ T_X
       
       P (Point): What is the experiential SUBSTRATE?
         → variance: How unstable/turbulent is the ground? [0.0 = still, 0.3 = volcanic]
       
       D (Descriptor): What is BEING DESCRIBED?
         → novelty: How new/unexpected is this? [0.0 = familiar, 1.0 = unprecedented]
         → normative_significance: How do VALUES align? [-1.0 = maximally violated, +1.0 = maximally fulfilled]
       
       T (Traverser): WHO is experiencing, and HOW?
         → ego_resonance: How strongly is T engaged? [0.0 = absent, 1.0 = maximally present]
         → pdt_completeness: Can T HANDLE this? [0.0 = utterly overwhelmed, 1.0 = total mastery]
    
    2. DESCRIPTOR GAP PRINCIPLE — Any gap is itself a descriptor
       
       → gap_awareness: What is MISSING in the D-set? [0.0 = nothing missing, 1.0 = everything missing]
         The gap between what IS and what SHOULD BE, or between what's KNOWN and UNKNOWN.
    
    3. SUBSUMPTION LAW — Verify completeness and irreducibility
       
       Check: Are all 6 inputs accounted for? Is anything redundant?
       The 6 inputs (2 from D, 2 from T, 1 from P, 1 from Gap) are the minimal 
       complete description of any emotional appraisal.
    
    STRUCTURAL PATTERNS discovered across 853 emotions:
    
    • P≈0 for high-novelty positive emotions (DAZZLED, WONDER, YUGEN):
      Overwhelm-tension from high novelty creates slight negative even when positive.
      
    • P≈0 for mild irritation with high capability (IRKED, PEEVED, MIFFED):
      Person CAN handle it (high pdt) nearly cancels the annoyance.
      
    • JOY primary for aggressive-approach emotions (QUARRELSOME, SCORN):
      The person who ENJOYS fighting experiences it as approach energy.
      
    • Stubborn family clusters (OBSTINATE, MULISH, PIG-HEADED, etc.):
      All: high ego, high pdt, low novelty, negative norm → D>0.7 consistently.
      
    • Exhaustion family clusters (TIRED, POOPED, WIPED OUT, etc.):
      All: low ego, low pdt, low novelty → A<0.2, P<0 consistently.
    """)
