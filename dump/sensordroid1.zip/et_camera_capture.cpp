/*
 * ET LOSSLESS SENSOR CAPTURE — CAMERA CAPTURE IMPLEMENTATION
 * ============================================================
 * Camera2 NDK: ACameraDevice + AImageReader + RAW_SENSOR format.
 * Captures unprocessed Bayer-mosaic data at the sensor's native bit depth.
 *
 * REQUIRES: Camera2 NDK (API 24+)
 *   Link: -lcamera2ndk -lmediandk
 *
 * Author: Michael James Muller — Aevum Defluo (Exception Theory)
 * License: CC-BY-4.0
 */

#include "et_camera_capture.hpp"
#include <cstring>
#include <cstdio>

#ifdef __ANDROID__
#include <camera/NdkCameraManager.h>
#include <camera/NdkCameraDevice.h>
#include <camera/NdkCameraCaptureSession.h>
#include <camera/NdkCaptureRequest.h>
#include <media/NdkImageReader.h>
#include <media/NdkImage.h>
#include <android/log.h>

#define LOG_TAG "EtCameraCapture"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

/* ═══════════════════════════════════════════════════════════════════
 * IMAGE AVAILABLE CALLBACK — receives RAW frames from Camera2
 * ═══════════════════════════════════════════════════════════════════ */
static void on_image_available(void *context, AImageReader *reader) {
    auto *cap = static_cast<et_camera_capture_t *>(context);
    if (!cap || !cap->callback) return;

    AImage *image = nullptr;
    media_status_t status = AImageReader_acquireLatestImage(reader, &image);
    if (status != AMEDIA_OK || !image) return;

    /* Get image properties */
    int32_t width, height, format;
    AImage_getWidth(image, &width);
    AImage_getHeight(image, &height);
    AImage_getFormat(image, &format);

    int64_t timestamp;
    AImage_getTimestamp(image, &timestamp);

    /* Get raw pixel data */
    uint8_t *data = nullptr;
    int data_len = 0;
    AImage_getPlaneData(image, 0, &data, &data_len);

    int row_stride = 0;
    AImage_getPlaneRowStride(image, 0, &row_stride);

    if (data && data_len > 0) {
        /* RAW_SENSOR is RAW16: uint16_t per pixel, Bayer-mosaic */
        const uint16_t *raw16 = reinterpret_cast<const uint16_t *>(data);

        cap->callback(cap->callback_data, raw16, width, height,
                       row_stride, cap->hw_info.actual_bit_depth,
                       timestamp, cap->total_frames);

        cap->total_frames++;
    }

    AImage_delete(image);
}

/* Camera device state callbacks */
static void on_camera_disconnected(void *context, ACameraDevice *device) {
    (void)context; (void)device;
    LOGW("Camera disconnected");
}

static void on_camera_error(void *context, ACameraDevice *device, int error) {
    (void)context; (void)device;
    LOGE("Camera error: %d", error);
}

static ACameraDevice_StateCallbacks g_device_callbacks = {
    .context = nullptr,
    .onDisconnected = on_camera_disconnected,
    .onError = on_camera_error,
};

/* Capture session state callbacks */
static void on_session_ready(void *context, ACameraCaptureSession *session) {
    (void)context; (void)session;
    LOGI("Capture session ready");
}

static void on_session_active(void *context, ACameraCaptureSession *session) {
    (void)context; (void)session;
    LOGI("Capture session active");
}

static void on_session_closed(void *context, ACameraCaptureSession *session) {
    (void)context; (void)session;
    LOGI("Capture session closed");
}

static ACameraCaptureSession_stateCallbacks g_session_callbacks = {
    .context = nullptr,
    .onClosed = on_session_closed,
    .onReady = on_session_ready,
    .onActive = on_session_active,
};

#else
#define LOGI(...)
#define LOGW(...)
#define LOGE(...)
#endif

/* ═══════════════════════════════════════════════════════════════════
 * DEFAULT CONFIG
 * ═══════════════════════════════════════════════════════════════════ */
et_camera_config_t et_camera_default_config(void) {
    et_camera_config_t config;
    std::memset(&config, 0, sizeof(config));
    config.camera_id = -1;     /* Auto-select rear camera */
    config.width = 0;          /* Maximum RAW resolution */
    config.height = 0;
    config.fps = 0;            /* Default frame rate */
    config.raw_format = 1;     /* Request RAW_SENSOR */
    return config;
}

/* ═══════════════════════════════════════════════════════════════════
 * CHECK RAW SUPPORT
 * ═══════════════════════════════════════════════════════════════════ */
int et_camera_has_raw_support(void) {
#ifdef __ANDROID__
    ACameraManager *manager = ACameraManager_create();
    if (!manager) return 0;

    ACameraIdList *id_list = nullptr;
    ACameraManager_getCameraIdList(manager, &id_list);
    if (!id_list) { ACameraManager_delete(manager); return 0; }

    int has_raw = 0;
    for (int i = 0; i < id_list->numCameras; i++) {
        ACameraMetadata *chars = nullptr;
        ACameraManager_getCameraCharacteristics(manager, id_list->cameraIds[i], &chars);
        if (!chars) continue;

        ACameraMetadata_const_entry entry;
        camera_status_t cs = ACameraMetadata_getConstEntry(
            chars, ACAMERA_REQUEST_AVAILABLE_CAPABILITIES, &entry);

        if (cs == ACAMERA_OK) {
            for (uint32_t j = 0; j < entry.count; j++) {
                if (entry.data.u8[j] == ACAMERA_REQUEST_AVAILABLE_CAPABILITIES_RAW) {
                    has_raw = 1;
                    break;
                }
            }
        }
        ACameraMetadata_free(chars);
        if (has_raw) break;
    }

    ACameraManager_deleteCameraIdList(id_list);
    ACameraManager_delete(manager);
    return has_raw;
#else
    return 0;
#endif
}

/* ═══════════════════════════════════════════════════════════════════
 * INIT
 * ═══════════════════════════════════════════════════════════════════ */
et_error_t et_camera_init(et_camera_capture_t *cap, const et_camera_config_t *config,
                           et_camera_callback_t callback, void *user_data) {
    if (!cap || !config) return ET_ERR_NULL_INPUT;
    std::memset(cap, 0, sizeof(*cap));
    cap->config = *config;
    cap->callback = callback;
    cap->callback_data = user_data;
    return ET_OK;
}

/* ═══════════════════════════════════════════════════════════════════
 * OPEN — configure Camera2 for RAW_SENSOR output
 * ═══════════════════════════════════════════════════════════════════ */
et_error_t et_camera_open(et_camera_capture_t *cap) {
    if (!cap) return ET_ERR_NULL_INPUT;

#ifdef __ANDROID__
    ACameraManager *manager = ACameraManager_create();
    if (!manager) return ET_ERR_SENSOR;

    /* Find camera with RAW support */
    ACameraIdList *id_list = nullptr;
    ACameraManager_getCameraIdList(manager, &id_list);
    if (!id_list || id_list->numCameras == 0) {
        ACameraManager_delete(manager);
        return ET_ERR_SENSOR;
    }

    const char *selected_id = nullptr;
    int raw_width = 0, raw_height = 0, raw_bits = 10;

    for (int i = 0; i < id_list->numCameras; i++) {
        ACameraMetadata *chars = nullptr;
        ACameraManager_getCameraCharacteristics(manager, id_list->cameraIds[i], &chars);
        if (!chars) continue;

        /* Check for RAW capability */
        ACameraMetadata_const_entry cap_entry;
        camera_status_t cs = ACameraMetadata_getConstEntry(
            chars, ACAMERA_REQUEST_AVAILABLE_CAPABILITIES, &cap_entry);
        int has_raw_cap = 0;
        if (cs == ACAMERA_OK) {
            for (uint32_t j = 0; j < cap_entry.count; j++) {
                if (cap_entry.data.u8[j] == ACAMERA_REQUEST_AVAILABLE_CAPABILITIES_RAW) {
                    has_raw_cap = 1;
                    break;
                }
            }
        }

        if (has_raw_cap || !cap->config.raw_format) {
            /* Find largest RAW_SENSOR output size */
            ACameraMetadata_const_entry scaler_entry;
            cs = ACameraMetadata_getConstEntry(
                chars, ACAMERA_SCALER_AVAILABLE_STREAM_CONFIGURATIONS, &scaler_entry);

            if (cs == ACAMERA_OK) {
                /* Format: [format, width, height, input] tuples */
                for (uint32_t j = 0; j + 3 < scaler_entry.count; j += 4) {
                    int32_t fmt = scaler_entry.data.i32[j];
                    int32_t w = scaler_entry.data.i32[j + 1];
                    int32_t h = scaler_entry.data.i32[j + 2];
                    int32_t input = scaler_entry.data.i32[j + 3];
                    /* AIMAGE_FORMAT_RAW_SENSOR = 0x20 */
                    if (fmt == 0x20 && input == 0 && w * h > raw_width * raw_height) {
                        raw_width = w;
                        raw_height = h;
                        selected_id = id_list->cameraIds[i];
                    }
                }
            }

            /* Get sensor bit depth */
            ACameraMetadata_const_entry bw_entry;
            cs = ACameraMetadata_getConstEntry(
                chars, ACAMERA_SENSOR_INFO_WHITE_LEVEL, &bw_entry);
            if (cs == ACAMERA_OK && bw_entry.count > 0) {
                int32_t white_level = bw_entry.data.i32[0];
                raw_bits = 1;
                int wl = white_level;
                while (wl > 1) { wl >>= 1; raw_bits++; }
            }
        }
        ACameraMetadata_free(chars);
        if (selected_id) break;
    }

    if (!selected_id) {
        LOGE("No camera with RAW support found");
        ACameraManager_deleteCameraIdList(id_list);
        ACameraManager_delete(manager);
        return ET_ERR_SENSOR;
    }

    LOGI("Selected camera %s: %dx%d @ %d-bit RAW", selected_id, raw_width, raw_height, raw_bits);

    /* Store hardware info */
    cap->hw_info.actual_width = raw_width;
    cap->hw_info.actual_height = raw_height;
    cap->hw_info.actual_bit_depth = raw_bits;
    cap->hw_info.has_raw_capability = 1;
    std::snprintf(cap->hw_info.camera_name, sizeof(cap->hw_info.camera_name),
                  "Camera %s", selected_id);

    /* Open camera device */
    ACameraDevice *device = nullptr;
    g_device_callbacks.context = cap;
    camera_status_t cs = ACameraManager_openCamera(
        manager, selected_id, &g_device_callbacks, &device);

    if (cs != ACAMERA_OK || !device) {
        LOGE("Failed to open camera: %d", cs);
        ACameraManager_deleteCameraIdList(id_list);
        ACameraManager_delete(manager);
        return ET_ERR_SENSOR;
    }
    cap->camera_device = device;

    /* Create AImageReader for RAW_SENSOR (RAW16) format */
    AImageReader *reader = nullptr;
    /* AIMAGE_FORMAT_RAW_SENSOR = 0x20 */
    media_status_t ms = AImageReader_new(raw_width, raw_height, 0x20, 4, &reader);
    if (ms != AMEDIA_OK || !reader) {
        LOGE("Failed to create RAW image reader: %d", ms);
        ACameraDevice_close(device);
        ACameraManager_deleteCameraIdList(id_list);
        ACameraManager_delete(manager);
        return ET_ERR_SENSOR;
    }
    cap->image_reader = reader;

    /* Set image available listener */
    AImageReader_ImageListener listener = {
        .context = cap,
        .onImageAvailable = on_image_available,
    };
    AImageReader_setImageListener(reader, &listener);

    /* Create capture session */
    ANativeWindow *window = nullptr;
    AImageReader_getWindow(reader, &window);

    ACaptureSessionOutputContainer *container = nullptr;
    ACaptureSessionOutputContainer_create(&container);
    cap->output_container = container;

    ACaptureSessionOutput *output = nullptr;
    ACaptureSessionOutput_create(window, &output);
    ACaptureSessionOutputContainer_add(container, output);
    cap->session_output = output;

    ACameraCaptureSession *session = nullptr;
    g_session_callbacks.context = cap;
    cs = ACameraDevice_createCaptureSession(device, container, &g_session_callbacks, &session);
    if (cs != ACAMERA_OK || !session) {
        LOGE("Failed to create capture session: %d", cs);
        /* Clean up on failure */
        ACaptureSessionOutputContainer_remove(container, output);
        ACaptureSessionOutput_free(output);
        ACaptureSessionOutputContainer_free(container);
        AImageReader_delete(reader);
        ACameraDevice_close(device);
        ACameraManager_deleteCameraIdList(id_list);
        ACameraManager_delete(manager);
        return ET_ERR_SENSOR;
    }
    cap->capture_session = session;

    /* Create capture request */
    ACaptureRequest *request = nullptr;
    ACameraDevice_createCaptureRequest(device, TEMPLATE_STILL_CAPTURE, &request);
    ACameraOutputTarget *target = nullptr;
    ACameraOutputTarget_create(window, &target);
    ACaptureRequest_addTarget(request, target);
    cap->capture_request = request;

    cap->is_open = 1;
    LOGI("Camera opened: %dx%d @ %d-bit RAW", raw_width, raw_height, raw_bits);

    ACameraManager_deleteCameraIdList(id_list);
    ACameraManager_delete(manager);
    return ET_OK;

#else
    (void)cap;
    return ET_ERR_SENSOR;
#endif
}

/* ═══════════════════════════════════════════════════════════════════
 * START / STOP / CLOSE
 * ═══════════════════════════════════════════════════════════════════ */
et_error_t et_camera_start(et_camera_capture_t *cap) {
    if (!cap || !cap->is_open) return ET_ERR_NULL_INPUT;
#ifdef __ANDROID__
    auto *session = static_cast<ACameraCaptureSession *>(cap->capture_session);
    auto *request = static_cast<ACaptureRequest *>(cap->capture_request);
    camera_status_t cs = ACameraCaptureSession_setRepeatingRequest(
        session, nullptr, 1, &request, nullptr);
    if (cs != ACAMERA_OK) return ET_ERR_SENSOR;
    cap->is_capturing = 1;
    LOGI("Camera capture started");
    return ET_OK;
#else
    return ET_ERR_SENSOR;
#endif
}

et_error_t et_camera_stop(et_camera_capture_t *cap) {
    if (!cap || !cap->is_capturing) return ET_ERR_NULL_INPUT;
#ifdef __ANDROID__
    auto *session = static_cast<ACameraCaptureSession *>(cap->capture_session);
    ACameraCaptureSession_stopRepeating(session);
    cap->is_capturing = 0;
    LOGI("Camera capture stopped: %lld frames", (long long)cap->total_frames);
    return ET_OK;
#else
    return ET_ERR_SENSOR;
#endif
}

void et_camera_close(et_camera_capture_t *cap) {
    if (!cap) return;
#ifdef __ANDROID__
    if (cap->is_capturing) et_camera_stop(cap);
    if (cap->capture_session) {
        ACameraCaptureSession_close(static_cast<ACameraCaptureSession *>(cap->capture_session));
    }
    if (cap->capture_request) {
        ACaptureRequest_free(static_cast<ACaptureRequest *>(cap->capture_request));
    }
    if (cap->session_output) {
        ACaptureSessionOutput_free(static_cast<ACaptureSessionOutput *>(cap->session_output));
    }
    if (cap->output_container) {
        ACaptureSessionOutputContainer_free(
            static_cast<ACaptureSessionOutputContainer *>(cap->output_container));
    }
    if (cap->image_reader) {
        AImageReader_delete(static_cast<AImageReader *>(cap->image_reader));
    }
    if (cap->camera_device) {
        ACameraDevice_close(static_cast<ACameraDevice *>(cap->camera_device));
    }
    cap->is_open = 0;
#endif
}

void et_camera_print_report(const et_camera_capture_t *cap) {
    if (!cap) return;
    LOGI("╔══════════════════════════════════════════════════════════════╗");
    LOGI("║   ET CAMERA CAPTURE — HARDWARE REPORT                      ║");
    LOGI("╚══════════════════════════════════════════════════════════════╝");
    LOGI("  Resolution: %dx%d", cap->hw_info.actual_width, cap->hw_info.actual_height);
    LOGI("  Bit depth: %d (RAW sensor)", cap->hw_info.actual_bit_depth);
    LOGI("  RAW support: %s", cap->hw_info.has_raw_capability ? "YES" : "NO");
    LOGI("  Camera: %s", cap->hw_info.camera_name);
    LOGI("  R₀ = 1 photoelectron (quantum of detection)");
    LOGI("  Total pixels per frame: %d",
         cap->hw_info.actual_width * cap->hw_info.actual_height);
}
