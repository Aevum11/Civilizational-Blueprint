/* ============================================================================
 * et_med_projection.c — Projection primitives
 * ----------------------------------------------------------------------------
 *  Identification: a measurement r is the ratio of two like-dimensioned
 *  quantities (current/baseline). The projection (k, d, eps) is its address
 *  on the N-fold lattice.
 *
 *  Descriptor Gap: eps_cents = (N*log2(r) - k) * 1200/N. Positive eps means
 *  the measurement is sharp of its lattice attractor; negative means flat.
 *
 *  Subsumption: this same formula handles a musical ratio, a heart-rate
 *  ratio, a hormone-concentration ratio, an oscillation-frequency ratio.
 *  Only the meaning of r and the choice of N change.
 *
 *  Verification baselines (Projection Guide §51-54):
 *      r = 1     → (k=0,  d=1,  eps=0)         unison        [Exception]
 *      r = 2     → (k=12, d=1,  eps=0)         octave        [d=1 doubling]
 *      r = 3/2   → (k=7,  d=12, eps=+1.955¢)   perfect 5th   [d=12 EM-class]
 *      r = 2/3   → (k=-7, d=12, eps=-1.955¢)   Koide K=2/3
 *      r = sqrt2 → (k=6,  d=2,  eps=0)         tritone       [d=2 bimodal]
 * ========================================================================= */
#include "libet_med.h"
#include "et_med_internal.h"

#include <math.h>
#include <stddef.h>
#include <string.h>

/* Definition of the canonical landmark tower (declared in et_med_internal.h) */
const int ET_LCM_LANDMARKS[ET_LCM_TOWER_COUNT] = {
    12,        /* base manifold                                           */
    60,        /* LCM(1..6) ; extends to senary qualia                    */
    84,        /* LCM(1..7) integrated with 12 — septic + base            */
    420,       /* LCM(1..7) ; biological floor (5,7) co-binding           */
    2520,      /* LCM(1..10)                                              */
    27720      /* LCM(1..11) ; cortical floor (Blue Brain 11D cliques)    */
};

LIBET_MED_API int et_lcm_tower(int* out, int max_count) {
    /* Identification: this is the public enumerator for the canonical tower.
     * Wrappers (Android/Windows/Browser) use this to populate UI dropdowns. */
    if (out == NULL || max_count <= 0) {
        _et_error(ET_ERR_INVALID_ARG, "et_lcm_tower needs non-null buffer");
        return 0;
    }
    int n = ET_LCM_TOWER_COUNT;
    if (n > max_count) n = max_count;
    for (int i = 0; i < n; ++i) out[i] = ET_LCM_LANDMARKS[i];
    return n;
}

/* ----------------------------------------------------------------------------
 * Real-axis projection
 * ------------------------------------------------------------------------- */
LIBET_MED_API et_error_t et_project_real(double r, int N, et_projection_t* out) {
    /* Identification: r is the dimensionless ratio of two like quantities. */
    if (out == NULL) {
        _et_error(ET_ERR_INVALID_ARG, "et_project_real needs non-null out");
        return ET_ERR_INVALID_ARG;
    }
    /* Initialize to a safe state in case of early return. */
    memset(out, 0, sizeof(*out));

    if (!et_is_finite(r) || r <= 0.0) {
        _et_error(ET_ERR_INVALID_RATIO, "r must be > 0 and finite");
        return ET_ERR_INVALID_RATIO;
    }
    et_error_t e = et_validate_N(N);
    if (e == ET_ERR_INVALID_N) return e;

    /* Descriptor Gap calculation. */
    double l2  = log2(r);
    double pos = (double)N * l2;
    int    k   = et_round_int(pos);
    double eps = (pos - (double)k) * 1200.0 / (double)N;

    /* Sublattice family. By convention gcd(0, N) = N → d = 1 (the
     * Identity/Exception class). */
    int absk = k < 0 ? -k : k;
    int g    = (absk == 0) ? N : et_gcd(absk, N);
    int d    = N / g;

    /* Numerical sanity check. */
    if (!et_is_finite(eps) || !et_is_finite(l2) || !et_is_finite(pos)) {
        _et_error(ET_ERR_NUMERIC, "non-finite produced in projection");
        return ET_ERR_NUMERIC;
    }

    out->r          = r;
    out->log2_r     = l2;
    out->exact_pos  = pos;
    out->k          = k;
    out->g          = g;
    out->d          = d;
    out->eps_cents  = eps;
    out->N          = N;
    return ET_OK;
}

/* ----------------------------------------------------------------------------
 * Imaginary-axis (D-T phase) projection
 *  theta in radians ; mapped to a positive ratio via 2^(theta/(2*pi)) so that
 *  one full revolution (2*pi rad) corresponds to one octave on the imag axis.
 * ------------------------------------------------------------------------- */
LIBET_MED_API et_error_t et_project_imag(double theta, int N, et_projection_t* out) {
    /* Identification: imag axis is the D-T phase rotation; one full turn is
     * one octave of bilateral D-folding. */
    if (out == NULL) {
        _et_error(ET_ERR_INVALID_ARG, "et_project_imag needs non-null out");
        return ET_ERR_INVALID_ARG;
    }
    if (!et_is_finite(theta)) {
        _et_error(ET_ERR_INVALID_ARG, "theta must be finite");
        return ET_ERR_INVALID_ARG;
    }
    /* Reduce theta to [0, 2*pi) for stable log2 evaluation. We choose this
     * half-open window (rather than (-pi, pi]) so that an ascending phase of
     * 7/12 of an octave maps to k=+7 on the lattice, not k=-5 (its enharmonic
     * inversion). The two are mathematically equivalent modulo an octave, but
     * the ascending convention is the natural medical reading of a positive
     * phase accumulation. */
    static const double TWO_PI = 6.283185307179586476925286766559;
    double t = fmod(theta, TWO_PI);
    if (t < 0.0) t += TWO_PI;       /* map (-2*pi, 0) -> (0, 2*pi)          */

    double r = pow(2.0, t / TWO_PI);
    return et_project_real(r, N, out);
}

/* ----------------------------------------------------------------------------
 * Complex projection — both axes + combined cell family
 * ------------------------------------------------------------------------- */
LIBET_MED_API et_error_t et_project_complex(double r, double theta, int N,
                                            et_complex_projection_t* out) {
    /* Identification: a complete observation has both magnitude (real axis,
     * D-binding strength) and phase (imag axis, D-T orientation).
     * The combined cell family is LCM(d_r, d_theta) — the FQG cell. */
    if (out == NULL) {
        _et_error(ET_ERR_INVALID_ARG, "et_project_complex needs non-null out");
        return ET_ERR_INVALID_ARG;
    }
    memset(out, 0, sizeof(*out));

    et_error_t e1 = et_project_real(r, N, &out->real);
    if (e1 != ET_OK) return e1;
    et_error_t e2 = et_project_imag(theta, N, &out->imag);
    if (e2 != ET_OK) return e2;

    out->k_r       = out->real.k;
    out->k_theta   = out->imag.k;
    out->d_r       = out->real.d;
    out->d_theta   = out->imag.d;

    long long combined = et_lcm(out->d_r, out->d_theta);
    /* Cap at INT_MAX/2 for safety; the canonical tower never exceeds 27720. */
    if (combined > 1000000LL) {
        _et_error(ET_ERR_FALLBACK_USED,
                  "combined cell family huge — clipped for storage");
        combined = 1000000LL;
    }
    out->d_combined = (int)combined;

    /* Magnitude / phase decomposition into D and T fractions.
     * Identification: alpha = atan2(|theta_pos|, |r_pos|) gives the D-T
     * gradient angle; D_fraction = cos^2(alpha), T_fraction = sin^2(alpha)
     * are the squared cosines (= power split) per Projection Guide §27. */
    double abs_r_pos     = fabs(out->real.exact_pos);
    double abs_theta_pos = fabs(out->imag.exact_pos);
    double alpha         = atan2(abs_theta_pos, abs_r_pos);
    out->alpha           = alpha;
    out->D_fraction      = cos(alpha) * cos(alpha);
    out->T_fraction      = sin(alpha) * sin(alpha);
    out->N               = N;

    return ET_OK;
}

/* ----------------------------------------------------------------------------
 * Multi-resolution projection — across the canonical landmark tower
 * ------------------------------------------------------------------------- */
LIBET_MED_API et_error_t et_project_multi(double r,
                                          et_projection_t* out,
                                          int max_lattices,
                                          int* count_out) {
    if (out == NULL || count_out == NULL) {
        _et_error(ET_ERR_INVALID_ARG, "et_project_multi needs non-null buffers");
        return ET_ERR_INVALID_ARG;
    }
    *count_out = 0;
    int filled = 0;
    for (int i = 0; i < ET_LCM_TOWER_COUNT && filled < max_lattices; ++i) {
        et_error_t e = et_project_real(r, ET_LCM_LANDMARKS[i], &out[filled]);
        if (e == ET_OK) {
            ++filled;
        } else {
            /* If the first call fails (bad r), all will — bail out. */
            return e;
        }
    }
    *count_out = filled;
    return ET_OK;
}
