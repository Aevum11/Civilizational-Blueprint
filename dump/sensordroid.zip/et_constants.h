/*
 * ET LOSSLESS SENSOR CAPTURE — FUNDAMENTAL CONSTANTS
 * ==================================================
 * All constants forward-derived from P∘D∘T = E.
 * Zero free parameters. Zero tuning. Zero ad hoc.
 *
 * String literals for MPFR initialization — zero IEEE 754 float
 * anywhere in the constant definition chain.
 *
 * Author: Michael James Muller — Aevum Defluo (Exception Theory)
 * License: CC-BY-4.0
 */

#ifndef ET_CONSTANTS_H
#define ET_CONSTANTS_H

/* ═══════════════════════════════════════════════════════════════════
 * PRECISION PARAMETERS — structurally derived, not chosen
 *
 * 1200 cents/octave → 1200 binary digits = 361 decimal places minimum
 * Plus 39 digits guard → WORK_DPS = 400
 * Plus 100 digits for transcendental function chains → COMPUTE_DPS = 500
 * MPFR precision in bits: ceil(COMPUTE_DPS × log₂(10)) = ceil(500 × 3.3219) = 1661
 * ═══════════════════════════════════════════════════════════════════ */
#define ET_WORK_DPS         400
#define ET_COMPUTE_DPS      500
#define ET_COMPUTE_GUARD    100
#define ET_MPFR_BITS        1661   /* ceil(500 × log₂(10)) */

/* ═══════════════════════════════════════════════════════════════════
 * FUNDAMENTAL ET CONSTANTS
 * |Π| = 3 (three primitives), S = 4 (logic states), N = |Π| × S = 12
 * ═══════════════════════════════════════════════════════════════════ */
#define ET_N_BASE           12     /* N = 12 — base manifold symmetry */
#define ET_PI_CARD          3      /* |Π| = 3 — three primitives */
#define ET_S_LOGIC          4      /* S = 4 — logic states */

/* Base variance: V = 1/N = 1/12 */
#define ET_V_BASE_STR       "0.08333333333333333333333333333333333333333333333333"

/* σ_audio = √V = 1/√12 — the structural cell scale */
#define ET_SIGMA_AUDIO_STR  "0.28867513459481288225457439025097872782380089394244"

/* Koide ratio: K = 2/3 — stability threshold */
#define ET_KOIDE_STR        "0.66666666666666666666666666666666666666666666666667"

/* K_EM = 8 — electromagnetic constant */
#define ET_K_EM             8

/* A₀ = 137 — fine structure inverse */
#define ET_A0               137

/* Cents per octave: 1200 = N × 100 */
#define ET_CENTS_PER_OCTAVE 1200
#define ET_CENTS_STR        "1200"

/* ln(2) as high-precision string */
#define ET_LN2_STR \
    "0.693147180559945309417232121458176568075500134360255254120680009493393" \
    "621969694715605863326996418687542001481020570685733685520235758130557032" \
    "670751635075961930727570828371435190307038623891673471123350115364497955" \
    "239120475172681574932065155524734139525882950453007095326366642654104239" \
    "157814952043740430385500801953446023295806975610498643452734974426070814" \
    "55017530138628773069649245073953704358220838272672299698460168506"

/* Manifold Conversion Constant: Λ = 1200/ln(2) ≈ 1731.234... */
/* Bridges D-face (discrete, 1200 cents/octave) and P-face (continuous, ln2 nats/octave) */
#define ET_LAMBDA_STR \
    "1731.23404906675624522617167714962540416938952117803295927998901710068989" \
    "14410991791935599"

/* Phase conversion constant: Λ_θ = 600/π ≈ 190.986... */
#define ET_LAMBDA_THETA_STR \
    "190.98593171027440292266051604702281236372326551080259012418983080760051" \
    "86887005553780218"

/* ═══════════════════════════════════════════════════════════════════
 * LCM TOWER — the canonical resolution sequence
 * Each level = LCM of consecutive integers
 * ═══════════════════════════════════════════════════════════════════ */
static const int ET_LCM_TOWER[] = {12, 60, 420, 840, 2520, 27720};
#define ET_LCM_TOWER_SIZE   6

/* Extended tower (non-LCM intermediate levels from the report data) */
static const int ET_EXTENDED_TOWER[] = {
    12, 24, 36, 60, 84, 120, 132, 168, 180, 252, 360, 420, 840, 2520, 27720
};
#define ET_EXTENDED_TOWER_SIZE 15

/* ═══════════════════════════════════════════════════════════════════
 * SENSOR R₀ VALUES — substrate-derived, not chosen
 * Each is the smallest closed T-traversal loop of the sensor's P-substrate
 * ═══════════════════════════════════════════════════════════════════ */

/* Audio: R₀ = σ_audio = 1/√12 = √(1/12) */
#define ET_R0_AUDIO_STR     ET_SIGMA_AUDIO_STR

/* Accelerometer: R₀ = g = 9.80665 m/s² (standard gravity) */
#define ET_R0_ACCEL_STR     "9.80665"

/* Gyroscope: R₀ = ω_Earth = 7.2921150e-5 rad/s (Earth rotation rate) */
#define ET_R0_GYRO_STR      "0.000072921150"

/* Magnetometer: R₀ = B_Earth ≈ 50 μT (local geomagnetic field) */
#define ET_R0_MAG_STR       "0.000050"

/* Barometer: R₀ = P_atm = 101325 Pa (standard atmosphere) */
#define ET_R0_BARO_STR      "101325"

/* Light sensor: R₀ = 1 lux (scotopic threshold) */
#define ET_R0_LIGHT_STR     "1"

/* Temperature: R₀ = T_body = 310.15 K (core body temperature) */
#define ET_R0_TEMP_STR      "310.15"

/* Camera: R₀ = 1 photoelectron (quantum of detection) */
#define ET_R0_CAMERA_STR    "1"

/* GPS position: R₀ = R_Earth = 6.371e6 m (mean Earth radius) */
#define ET_R0_GPS_POS_STR   "6371000"

/* Humidity: R₀ = 1.0 (already dimensionless ratio) */
#define ET_R0_HUMIDITY_STR  "1"

/* Proximity: R₀ = λ_IR = 940 nm = 9.4e-7 m (IR LED wavelength) */
#define ET_R0_PROX_STR      "0.00000094"

/* Heart rate / PPG: R₀ = τ_rest (set dynamically from resting heart rate) */
/* Default: 60/72 = 0.8333... seconds (72 bpm resting) */
#define ET_R0_HR_DEFAULT_STR "0.83333333333333333333333333333333333333"

/* Step counter: R₀ = 1 step */
#define ET_R0_STEP_STR      "1"

/* ═══════════════════════════════════════════════════════════════════
 * SENSOR TYPE ENUMERATION
 * ═══════════════════════════════════════════════════════════════════ */
typedef enum {
    ET_SENSOR_AUDIO         = 0,
    ET_SENSOR_ACCEL         = 1,
    ET_SENSOR_GYRO          = 2,
    ET_SENSOR_MAG           = 3,
    ET_SENSOR_BARO          = 4,
    ET_SENSOR_LIGHT         = 5,
    ET_SENSOR_TEMP          = 6,
    ET_SENSOR_CAMERA        = 7,
    ET_SENSOR_GPS_POS       = 8,
    ET_SENSOR_GPS_TIME      = 9,
    ET_SENSOR_HUMIDITY       = 10,
    ET_SENSOR_PROXIMITY     = 11,
    ET_SENSOR_HEART_RATE    = 12,
    ET_SENSOR_STEP          = 13,
    ET_SENSOR_TYPE_COUNT    = 14
} et_sensor_type_t;

/* Sensor type names (for display and .etsf header) */
static const char* ET_SENSOR_TYPE_NAMES[] = {
    "AUDIO", "ACCEL", "GYRO", "MAG", "BARO", "LIGHT", "TEMP",
    "CAMERA", "GPS_POS", "GPS_TIME", "HUMIDITY", "PROXIMITY",
    "HEART_RATE", "STEP"
};

/* Default R₀ for each sensor type (index by et_sensor_type_t) */
static const char* ET_SENSOR_R0_DEFAULTS[] = {
    ET_R0_AUDIO_STR, ET_R0_ACCEL_STR, ET_R0_GYRO_STR, ET_R0_MAG_STR,
    ET_R0_BARO_STR, ET_R0_LIGHT_STR, ET_R0_TEMP_STR, ET_R0_CAMERA_STR,
    ET_R0_GPS_POS_STR, "1", ET_R0_HUMIDITY_STR, ET_R0_PROX_STR,
    ET_R0_HR_DEFAULT_STR, ET_R0_STEP_STR
};

/* ═══════════════════════════════════════════════════════════════════
 * MANIFOLD STATE ENUMERATION (from P∘D∘T power set)
 * ═══════════════════════════════════════════════════════════════════ */
typedef enum {
    ET_STATE_EXCEPTION      = 0,   /* {P,D,T} — fully substantiated */
    ET_STATE_MEDIATION      = 1,   /* {D,T}   — bridge without substrate */
    ET_STATE_INCOHERENCE    = 2,   /* {P,T}   — self-defeating */
    ET_STATE_UNSUBSTANTIATED = 3   /* {P,D}   — frozen potential */
} et_manifold_state_t;

/* ═══════════════════════════════════════════════════════════════════
 * ERROR CODES
 * ═══════════════════════════════════════════════════════════════════ */
typedef enum {
    ET_OK                   = 0,
    ET_ERR_NULL_INPUT       = 1,
    ET_ERR_INVALID_N        = 2,
    ET_ERR_ZERO_R0          = 3,
    ET_ERR_NEGATIVE_R       = 4,
    ET_ERR_ZERO_R           = 5,
    ET_ERR_PRECISION        = 6,
    ET_ERR_ALLOC            = 7,
    ET_ERR_FORMAT           = 8,
    ET_ERR_SENSOR           = 9,
    ET_ERR_BOUNDARY         = 10,
    ET_ERR_TRANSITION       = 11,
    ET_ERR_DIVISION_BY_ZERO = 12
} et_error_t;

/* ═══════════════════════════════════════════════════════════════════
 * .etsf FILE FORMAT CONSTANTS
 * ═══════════════════════════════════════════════════════════════════ */
#define ETSF_MAGIC          "ETSF"
#define ETSF_MAGIC_SIZE     4
#define ETSF_VERSION        1

/* Sign encoding */
#define ET_SIGN_POSITIVE    0
#define ET_SIGN_NEGATIVE    1
#define ET_SIGN_ZERO        2

/* ∂I boundary constants (Identity F) */
/* Twilight Zone entry: |ε| > 33¢ at N=12 */
#define ET_TWILIGHT_ENTRY_CENTS_N12  33

#endif /* ET_CONSTANTS_H */
