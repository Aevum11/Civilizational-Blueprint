/*
 * ET LOSSLESS SENSOR CAPTURE — ANDROID DIRECT CHANNEL ACCESS
 * ============================================================
 * Bypasses the Android SensorService to read raw hardware sensor data
 * through shared memory (Direct Channel API, available since API 26).
 *
 * ACCESS PRIORITY (mirrors lossless microphone HOST_API_PRIORITY):
 *   Priority 0: Direct Channel + HardwareBuffer → raw shared memory
 *   Priority 1: ASensorEventQueue at SENSOR_DELAY_FASTEST
 *   Priority 2: Java SensorManager fallback
 *
 * Direct Channel writes sensor events into a shared memory region
 * that the native code reads via atomic counters — no SensorService
 * in the path. Supports up to ASENSOR_DIRECT_RATE_VERY_FAST (~800 Hz).
 *
 * This is the Android equivalent of WASAPI Exclusive for sensors:
 * the hardware writes directly to a buffer the app reads.
 *
 * Author: Michael James Muller — Aevum Defluo (Exception Theory)
 * License: CC-BY-4.0
 */

#ifndef ET_DIRECT_CHANNEL_H
#define ET_DIRECT_CHANNEL_H

#include "et_constants.h"

#ifdef __ANDROID__
#include <android/sensor.h>
#include <android/hardware_buffer.h>
#include <android/looper.h>
#endif

/* ═══════════════════════════════════════════════════════════════════
 * SENSOR DIRECT CHANNEL CONTEXT
 * One per active hardware sensor using direct channel mode.
 * ═══════════════════════════════════════════════════════════════════ */
typedef struct {
    int                 sensor_id;      /* App-assigned ID */
    et_sensor_type_t    sensor_type;    /* ET sensor classification */
    int                 active;         /* 1 if currently recording */

#ifdef __ANDROID__
    ASensorManager     *manager;        /* NDK sensor manager */
    const ASensor      *sensor;         /* Hardware sensor handle */
    int                 channel_id;     /* Direct channel ID (-1 if not supported) */
    int                 using_direct;   /* 1 if direct channel active */
    int                 direct_rate;    /* ASENSOR_DIRECT_RATE_xxx */
    ASensorEventQueue  *event_queue;    /* Fallback event queue */
    ALooper            *looper;         /* Event loop for queue mode */

    /* Shared memory for direct channel */
    AHardwareBuffer    *hw_buffer;      /* Hardware buffer (direct channel) */
    void               *shared_mem;     /* Mapped memory pointer */
    size_t              shared_mem_size;/* Buffer size in bytes */

    /* Sensor characteristics */
    float               resolution;     /* LSB value (smallest measurable change) */
    float               max_range;      /* Maximum measurement value */
    int                 min_delay_us;   /* Minimum sampling period (max rate) */
    int                 fifo_max;       /* Hardware FIFO size */
    int                 direct_support; /* Highest direct rate level supported */
#endif

    /* Metadata */
    char                name[128];
    char                vendor[64];
    int                 axes;           /* 1=scalar, 3=vector */
    int                 is_bipolar;     /* 1 if values can be negative */
    int                 sample_rate_hz; /* Actual configured rate */
    int                 bit_depth;      /* Effective ADC bit depth */
    char                access_mode[64];/* "direct_channel" or "event_queue" */
} et_direct_sensor_t;

/* ═══════════════════════════════════════════════════════════════════
 * SENSOR EVENT (from direct channel or event queue)
 * ═══════════════════════════════════════════════════════════════════ */
typedef struct {
    int                 sensor_id;
    long long           timestamp_ns;   /* Monotonic nanoseconds */
    float               values[16];     /* Up to 16 float values (Android max) */
    int                 value_count;    /* Number of valid values */
    int                 from_direct;    /* 1 if from direct channel */
    long long           sequence;       /* Atomic counter (direct channel only) */
} et_sensor_event_t;

/* ═══════════════════════════════════════════════════════════════════
 * SENSOR MANAGER — manages all hardware sensors
 * ═══════════════════════════════════════════════════════════════════ */
typedef struct {
    et_direct_sensor_t  sensors[ET_MAX_SENSORS];
    int                 sensor_count;
    int                 initialized;

#ifdef __ANDROID__
    ASensorManager     *asensor_manager;
    ALooper            *main_looper;
#endif
} et_sensor_manager_t;

/* ═══════════════════════════════════════════════════════════════════
 * LIFECYCLE
 * ═══════════════════════════════════════════════════════════════════ */

/*
 * Initialize the sensor manager: enumerate all hardware sensors,
 * probe direct channel support, determine optimal access mode per sensor.
 *
 * Mirrors ETLiveCapture._auto_detect_direct():
 *   1. Enumerate all sensors via ASensorManager_getSensorList()
 *   2. For each: probe capabilities, direct channel support, max rate
 *   3. Skip virtual/composite sensors (record ONLY hardware sensors)
 *   4. Prefer direct channel over event queue
 *   5. Prefer highest rate over lowest latency
 */
et_error_t et_sensor_manager_init(et_sensor_manager_t *mgr);

/*
 * Free all resources, close all channels.
 */
void et_sensor_manager_cleanup(et_sensor_manager_t *mgr);

/*
 * Print detected hardware report (mirrors ETLiveCapture.print_hardware_report).
 */
void et_sensor_manager_print_report(const et_sensor_manager_t *mgr);

/* ═══════════════════════════════════════════════════════════════════
 * SENSOR ACTIVATION
 * ═══════════════════════════════════════════════════════════════════ */

/*
 * Start recording from a specific sensor.
 * Uses direct channel if supported, falls back to event queue.
 *
 * Parameters:
 *   mgr       — initialized sensor manager
 *   sensor_id — ID from the sensor list
 *   rate_hz   — desired sample rate (0 = maximum supported)
 */
et_error_t et_sensor_start(et_sensor_manager_t *mgr, int sensor_id, int rate_hz);

/*
 * Stop recording from a specific sensor.
 */
et_error_t et_sensor_stop(et_sensor_manager_t *mgr, int sensor_id);

/*
 * Start ALL available hardware sensors simultaneously.
 */
et_error_t et_sensor_start_all(et_sensor_manager_t *mgr);

/*
 * Stop ALL sensors.
 */
et_error_t et_sensor_stop_all(et_sensor_manager_t *mgr);

/* ═══════════════════════════════════════════════════════════════════
 * EVENT READING
 * ═══════════════════════════════════════════════════════════════════ */

/*
 * Poll for sensor events (non-blocking).
 *
 * For direct channel: reads shared memory via atomic counter.
 * For event queue: polls ASensorEventQueue_getEvents().
 *
 * Parameters:
 *   mgr       — initialized sensor manager
 *   sensor_id — which sensor to poll (-1 = poll all)
 *   events    — output buffer for events
 *   max_events — buffer capacity
 *   count_out — number of events actually read
 */
et_error_t et_sensor_poll(et_sensor_manager_t *mgr, int sensor_id,
                           et_sensor_event_t *events, int max_events,
                           int *count_out);

/*
 * Get the raw ADC integer for a sensor event.
 *
 * The Android API reports sensor values as float32. To maintain
 * the zero-float64 chain, we need the raw ADC integer. This is
 * obtained from the sensor's resolution and the float value:
 *   adc_int = round(event_value / sensor_resolution)
 *
 * For direct channel sensors, the shared memory contains the
 * raw sensor_event_t which may include the integer value directly
 * via additional_info events.
 *
 * Parameters:
 *   sensor    — the sensor context
 *   value     — float32 value from the event
 *   adc_out   — output: raw ADC integer
 *   max_out   — output: maximum ADC value for this sensor
 */
et_error_t et_sensor_to_adc(const et_direct_sensor_t *sensor,
                              float value, long *adc_out, long *max_out);

/* ═══════════════════════════════════════════════════════════════════
 * SENSOR TYPE MAPPING
 *
 * Maps Android sensor types (ASENSOR_TYPE_xxx) to ET sensor types.
 * Only HARDWARE sensors are mapped — virtual/composite are skipped.
 * ═══════════════════════════════════════════════════════════════════ */
et_sensor_type_t et_android_sensor_to_et_type(int android_type);

/*
 * Check if an Android sensor type is a hardware sensor (not composite).
 * Virtual sensors (rotation vector, gravity, linear acceleration) are
 * OS-computed from hardware sensors — we record the hardware directly.
 */
int et_is_hardware_sensor(int android_type);

#endif /* ET_DIRECT_CHANNEL_H */
