/*
 * ET LOSSLESS SENSOR CAPTURE — .etsf FORMAT IMPLEMENTATION
 * =========================================================
 * Streaming encoder/decoder for multi-sensor ET lattice data.
 *
 * Key design decisions:
 *   - ε stored as UTF-8 string (zero float64 in storage chain)
 *   - d NOT stored (derived from k and N — Kolmogorov Principle)
 *   - k stored as zigzag-encoded varint (compact for typical values)
 *   - Samples timestamp-ordered (interleaved across sensors)
 *   - Per-sensor headers include R₀ at full precision
 *
 * Author: Michael James Muller — Aevum Defluo (Exception Theory)
 * License: CC-BY-4.0
 */

#include "et_format.h"
#include <stdlib.h>
#include <string.h>

/* ═══════════════════════════════════════════════════════════════════
 * VARINT ENCODING (zigzag for signed integers)
 *
 * Zigzag encoding maps signed integers to unsigned:
 *   0 → 0, -1 → 1, 1 → 2, -2 → 3, 2 → 4, ...
 *   encode(n) = (n << 1) ^ (n >> 63)   (for 64-bit)
 *
 * Then stores as variable-length bytes (7 bits per byte, MSB = continuation).
 * ═══════════════════════════════════════════════════════════════════ */
static size_t write_varint(FILE *fp, long value) {
    /* Zigzag encode */
    unsigned long uval = (unsigned long)((value << 1) ^ (value >> 63));
    size_t written = 0;
    do {
        unsigned char byte = (unsigned char)(uval & 0x7F);
        uval >>= 7;
        if (uval > 0) byte |= 0x80; /* continuation bit */
        fwrite(&byte, 1, 1, fp);
        written++;
    } while (uval > 0);
    return written;
}

static long read_varint(FILE *fp, int *ok) {
    unsigned long uval = 0;
    int shift = 0;
    *ok = 1;
    while (1) {
        unsigned char byte;
        if (fread(&byte, 1, 1, fp) != 1) { *ok = 0; return 0; }
        uval |= ((unsigned long)(byte & 0x7F)) << shift;
        if (!(byte & 0x80)) break;
        shift += 7;
        if (shift > 63) { *ok = 0; return 0; } /* overflow protection */
    }
    /* Zigzag decode */
    return (long)((uval >> 1) ^ -(long)(uval & 1));
}

/* ═══════════════════════════════════════════════════════════════════
 * HELPER: write fixed-length string with padding
 * ═══════════════════════════════════════════════════════════════════ */
static void write_fixed_string(FILE *fp, const char *str, size_t field_len) {
    size_t len = strlen(str);
    if (len > field_len) len = field_len;
    fwrite(str, 1, len, fp);
    /* Pad with zeros */
    for (size_t i = len; i < field_len; i++) {
        char zero = '\0';
        fwrite(&zero, 1, 1, fp);
    }
}

static void read_fixed_string(FILE *fp, char *buf, size_t field_len) {
    if (fread(buf, 1, field_len, fp) != field_len) {
        buf[0] = '\0';
    }
    buf[field_len - 1] = '\0'; /* Ensure null termination */
}

/* ═══════════════════════════════════════════════════════════════════
 * WRITER
 * ═══════════════════════════════════════════════════════════════════ */

et_error_t et_etsf_writer_open(et_etsf_writer_t *writer, const char *path,
                                int global_N, int precision_dps,
                                const char *device_model) {
    if (!writer || !path) return ET_ERR_NULL_INPUT;

    memset(writer, 0, sizeof(*writer));
    writer->fp = fopen(path, "wb");
    if (!writer->fp) return ET_ERR_FORMAT;

    writer->sample_counts = (uint64_t *)calloc(ET_MAX_SENSORS, sizeof(uint64_t));
    if (!writer->sample_counts) {
        fclose(writer->fp);
        return ET_ERR_ALLOC;
    }

    /* Write global header */
    fwrite(ETSF_MAGIC, 1, ETSF_MAGIC_SIZE, writer->fp);

    uint16_t version = ETSF_VERSION;
    fwrite(&version, sizeof(uint16_t), 1, writer->fp);

    uint16_t sensor_count = 0; /* Will be patched at close */
    long sensor_count_offset = ftell(writer->fp);
    fwrite(&sensor_count, sizeof(uint16_t), 1, writer->fp);

    uint16_t gN = (uint16_t)global_N;
    fwrite(&gN, sizeof(uint16_t), 1, writer->fp);

    int64_t ts = 0; /* Creation timestamp — set by caller or at close */
    fwrite(&ts, sizeof(int64_t), 1, writer->fp);

    uint16_t pdps = (uint16_t)precision_dps;
    fwrite(&pdps, sizeof(uint16_t), 1, writer->fp);

    write_fixed_string(writer->fp, device_model ? device_model : "unknown", 64);

    return ET_OK;
}

et_error_t et_etsf_writer_add_sensor(et_etsf_writer_t *writer,
                                      et_sensor_type_t type,
                                      const char *name, int axes,
                                      const char *R0_str,
                                      int sample_rate, int bit_depth,
                                      const char *access_mode, int N,
                                      int *sensor_id_out) {
    if (!writer || !writer->fp) return ET_ERR_NULL_INPUT;
    if (writer->sensor_count >= ET_MAX_SENSORS) return ET_ERR_SENSOR;

    int sid = writer->sensor_count;

    /* Record offset for patching total_samples later */
    writer->sensor_header_offsets[sid] = ftell(writer->fp);

    /* Write per-sensor header */
    uint16_t sid16 = (uint16_t)sid;
    fwrite(&sid16, sizeof(uint16_t), 1, writer->fp);

    uint16_t st = (uint16_t)type;
    fwrite(&st, sizeof(uint16_t), 1, writer->fp);

    write_fixed_string(writer->fp, name ? name : "unknown", 128);

    uint8_t ax = (uint8_t)axes;
    fwrite(&ax, 1, 1, writer->fp);

    write_fixed_string(writer->fp, R0_str ? R0_str : "1", 512);

    uint32_t sr = (uint32_t)sample_rate;
    fwrite(&sr, sizeof(uint32_t), 1, writer->fp);

    uint8_t bd = (uint8_t)bit_depth;
    fwrite(&bd, 1, 1, writer->fp);

    write_fixed_string(writer->fp, access_mode ? access_mode : "unknown", 64);

    uint16_t nval = (uint16_t)N;
    fwrite(&nval, sizeof(uint16_t), 1, writer->fp);

    uint64_t total = 0; /* Patched at close */
    fwrite(&total, sizeof(uint64_t), 1, writer->fp);

    writer->sensor_count++;
    if (sensor_id_out) *sensor_id_out = sid;

    return ET_OK;
}

et_error_t et_etsf_writer_write_sample(et_etsf_writer_t *writer,
                                        int sensor_id,
                                        long long timestamp_ns,
                                        int axis, int sign,
                                        long k, const mpfr_t eps,
                                        int eps_dps) {
    if (!writer || !writer->fp) return ET_ERR_NULL_INPUT;
    if (sensor_id < 0 || sensor_id >= writer->sensor_count) return ET_ERR_SENSOR;

    /* Timestamp (8 bytes) */
    int64_t ts = (int64_t)timestamp_ns;
    fwrite(&ts, sizeof(int64_t), 1, writer->fp);

    /* Sensor ID (2 bytes) */
    uint16_t sid = (uint16_t)sensor_id;
    fwrite(&sid, sizeof(uint16_t), 1, writer->fp);

    /* Axis (1 byte) */
    uint8_t ax = (uint8_t)axis;
    fwrite(&ax, 1, 1, writer->fp);

    /* Sign (1 byte) */
    uint8_t sg = (uint8_t)sign;
    fwrite(&sg, 1, 1, writer->fp);

    /* k as varint (variable length) */
    write_varint(writer->fp, k);

    /* ε as length-prefixed string — the zero-float64 output path */
    char eps_buf[ET_WORK_DPS + 64];
    int eps_len = et_eps_to_string(eps, eps_dps, eps_buf, sizeof(eps_buf));
    if (eps_len < 0) eps_len = 0;

    uint16_t elen = (uint16_t)eps_len;
    fwrite(&elen, sizeof(uint16_t), 1, writer->fp);
    if (eps_len > 0) {
        fwrite(eps_buf, 1, (size_t)eps_len, writer->fp);
    }

    writer->sample_counts[sensor_id]++;
    return ET_OK;
}

et_error_t et_etsf_writer_close(et_etsf_writer_t *writer) {
    if (!writer || !writer->fp || writer->closed) return ET_ERR_NULL_INPUT;

    /* Patch sensor_count in global header */
    /* Global header layout: magic(4) + version(2) + sensor_count(2) + ... */
    fseek(writer->fp, ETSF_MAGIC_SIZE + sizeof(uint16_t), SEEK_SET);
    uint16_t sc = (uint16_t)writer->sensor_count;
    fwrite(&sc, sizeof(uint16_t), 1, writer->fp);

    /* Patch total_samples in each sensor header */
    for (int i = 0; i < writer->sensor_count; i++) {
        /* Per-sensor header layout:
         * sid(2) + type(2) + name(128) + axes(1) + R0(512) + sr(4) + bd(1) + mode(64) + N(2) + total(8)
         * Offset to total_samples from header start: 2+2+128+1+512+4+1+64+2 = 716
         */
        long total_offset = writer->sensor_header_offsets[i] + 716;
        fseek(writer->fp, total_offset, SEEK_SET);
        fwrite(&writer->sample_counts[i], sizeof(uint64_t), 1, writer->fp);
    }

    fclose(writer->fp);
    writer->fp = NULL;
    writer->closed = 1;
    free(writer->sample_counts);
    writer->sample_counts = NULL;

    return ET_OK;
}

/* ═══════════════════════════════════════════════════════════════════
 * READER
 * ═══════════════════════════════════════════════════════════════════ */

et_error_t et_etsf_reader_open(et_etsf_reader_t *reader, const char *path) {
    if (!reader || !path) return ET_ERR_NULL_INPUT;

    memset(reader, 0, sizeof(*reader));
    reader->fp = fopen(path, "rb");
    if (!reader->fp) return ET_ERR_FORMAT;

    /* Read global header */
    char magic[4];
    if (fread(magic, 1, 4, reader->fp) != 4 ||
        memcmp(magic, ETSF_MAGIC, 4) != 0) {
        fclose(reader->fp);
        return ET_ERR_FORMAT;
    }
    memcpy(reader->global_header.magic, magic, 4);

    fread(&reader->global_header.version, sizeof(uint16_t), 1, reader->fp);
    fread(&reader->global_header.sensor_count, sizeof(uint16_t), 1, reader->fp);
    fread(&reader->global_header.global_N, sizeof(uint16_t), 1, reader->fp);
    fread(&reader->global_header.creation_timestamp, sizeof(int64_t), 1, reader->fp);
    fread(&reader->global_header.precision_dps, sizeof(uint16_t), 1, reader->fp);
    read_fixed_string(reader->fp, reader->global_header.device_model, 64);

    reader->sensor_count = reader->global_header.sensor_count;

    /* Allocate and read sensor headers */
    reader->sensor_headers = (et_etsf_sensor_header_t *)calloc(
        (size_t)reader->sensor_count, sizeof(et_etsf_sensor_header_t));
    if (!reader->sensor_headers) {
        fclose(reader->fp);
        return ET_ERR_ALLOC;
    }

    for (int i = 0; i < reader->sensor_count; i++) {
        et_etsf_sensor_header_t *sh = &reader->sensor_headers[i];
        fread(&sh->sensor_id, sizeof(uint16_t), 1, reader->fp);
        fread(&sh->sensor_type, sizeof(uint16_t), 1, reader->fp);
        read_fixed_string(reader->fp, sh->sensor_name, 128);
        fread(&sh->axes, 1, 1, reader->fp);
        read_fixed_string(reader->fp, sh->R0_str, 512);
        fread(&sh->sample_rate_hz, sizeof(uint32_t), 1, reader->fp);
        fread(&sh->bit_depth, 1, 1, reader->fp);
        read_fixed_string(reader->fp, sh->access_mode, 64);
        fread(&sh->N, sizeof(uint16_t), 1, reader->fp);
        fread(&sh->total_samples, sizeof(uint64_t), 1, reader->fp);
    }

    return ET_OK;
}

et_error_t et_etsf_reader_next(et_etsf_reader_t *reader,
                                et_etsf_sample_record_t *record) {
    if (!reader || !reader->fp || !record) return ET_ERR_NULL_INPUT;

    memset(record, 0, sizeof(*record));

    /* Timestamp */
    int64_t ts;
    if (fread(&ts, sizeof(int64_t), 1, reader->fp) != 1) {
        record->eof = 1;
        return ET_OK;
    }
    record->timestamp_ns = (long long)ts;

    /* Sensor ID */
    uint16_t sid;
    if (fread(&sid, sizeof(uint16_t), 1, reader->fp) != 1) {
        record->eof = 1;
        return ET_OK;
    }
    record->sensor_id = (int)sid;

    /* Axis */
    uint8_t ax;
    fread(&ax, 1, 1, reader->fp);
    record->axis = (int)ax;

    /* Sign */
    uint8_t sg;
    fread(&sg, 1, 1, reader->fp);
    record->sign = (int)sg;

    /* k (varint) */
    int ok;
    record->k = read_varint(reader->fp, &ok);
    if (!ok) { record->eof = 1; return ET_OK; }

    /* ε string (length-prefixed) */
    uint16_t elen;
    if (fread(&elen, sizeof(uint16_t), 1, reader->fp) != 1) {
        record->eof = 1;
        return ET_OK;
    }
    if (elen > 0) {
        size_t to_read = (size_t)elen;
        if (to_read >= sizeof(record->eps_str)) to_read = sizeof(record->eps_str) - 1;
        if (fread(record->eps_str, 1, to_read, reader->fp) != to_read) {
            record->eof = 1;
            return ET_OK;
        }
        record->eps_str[to_read] = '\0';
        /* Skip any remaining bytes if elen > buffer */
        if ((size_t)elen > to_read) {
            fseek(reader->fp, (long)((size_t)elen - to_read), SEEK_CUR);
        }
    }

    record->eof = 0;
    return ET_OK;
}

void et_etsf_reader_close(et_etsf_reader_t *reader) {
    if (!reader) return;
    if (reader->fp) fclose(reader->fp);
    free(reader->sensor_headers);
    reader->fp = NULL;
    reader->sensor_headers = NULL;
}
