/*
 * ET LOSSLESS SENSOR CAPTURE — .etsf FORMAT
 * ==========================================
 * The lossless storage container for multi-sensor ET data.
 * Generalized from the .etlm format (lossless microphone).
 *
 * Each sample stores: (sensor_id, timestamp, axis, sign, k, ε_string)
 * d is NOT stored — derived from k and N (Kolmogorov Principle).
 * ε is stored as a string at WORK_DPS — zero IEEE 754 float.
 *
 * File structure:
 *   [Global Header]
 *   [Per-Sensor Header] × sensor_count
 *   [Sample Stream] (timestamp-ordered)
 *
 * Author: Michael James Muller — Aevum Defluo (Exception Theory)
 * License: CC-BY-4.0
 */

#ifndef ET_FORMAT_H
#define ET_FORMAT_H

#include "et_constants.h"
#include "et_bijection.h"
#include <stdio.h>

/* ═══════════════════════════════════════════════════════════════════
 * GLOBAL HEADER (written once at file start)
 * ═══════════════════════════════════════════════════════════════════ */
typedef struct {
    char        magic[4];           /* "ETSF" */
    uint16_t    version;            /* Format version (currently 1) */
    uint16_t    sensor_count;       /* Number of active sensors */
    uint16_t    global_N;           /* Base lattice resolution */
    int64_t     creation_timestamp; /* Nanoseconds since epoch */
    uint16_t    precision_dps;      /* Working precision (decimal places) */
    char        device_model[64];   /* Device model string */
} et_etsf_global_header_t;

/* ═══════════════════════════════════════════════════════════════════
 * PER-SENSOR HEADER (one per active sensor)
 * ═══════════════════════════════════════════════════════════════════ */
typedef struct {
    uint16_t    sensor_id;          /* Unique sensor identifier */
    uint16_t    sensor_type;        /* et_sensor_type_t value */
    char        sensor_name[128];   /* Human-readable name */
    uint8_t     axes;               /* 1=scalar, 3=vector */
    char        R0_str[512];        /* Substrate-derived R₀ (full precision) */
    uint32_t    sample_rate_hz;     /* Sensor sample rate */
    uint8_t     bit_depth;          /* Native ADC bit depth */
    char        access_mode[64];    /* "direct_channel", "event_queue", etc. */
    uint16_t    N;                  /* Resolution for this sensor */
    uint64_t    total_samples;      /* Total samples in stream (set at close) */
} et_etsf_sensor_header_t;

/* ═══════════════════════════════════════════════════════════════════
 * SAMPLE RECORD (one per measurement)
 *
 * Variable-length due to ε string encoding.
 * Wire format:
 *   [timestamp_ns: int64]
 *   [sensor_id:    uint16]
 *   [axis:         uint8]
 *   [sign:         uint8]   (0=positive, 1=negative, 2=zero)
 *   [k:            varint]  (zigzag-encoded variable-length integer)
 *   [eps_len:      uint16]  (length of ε string)
 *   [eps_str:      char[]]  (ε at WORK_DPS, UTF-8, NOT null-terminated)
 * ═══════════════════════════════════════════════════════════════════ */

/* ═══════════════════════════════════════════════════════════════════
 * WRITER — streaming encoder
 * ═══════════════════════════════════════════════════════════════════ */
typedef struct {
    FILE       *fp;                 /* Output file handle */
    int         sensor_count;       /* Number of sensors registered */
    uint64_t   *sample_counts;      /* Per-sensor sample count */
    long        sensor_header_offsets[ET_MAX_SENSORS]; /* For patching total_samples */
    int         closed;             /* 1 if finalized */
} et_etsf_writer_t;

/*
 * Open a new .etsf file for writing.
 * Writes the global header immediately.
 */
et_error_t et_etsf_writer_open(et_etsf_writer_t *writer, const char *path,
                                int global_N, int precision_dps,
                                const char *device_model);

/*
 * Register a sensor (writes its per-sensor header).
 * Must be called before any samples for that sensor.
 * Returns the sensor_id assigned.
 */
et_error_t et_etsf_writer_add_sensor(et_etsf_writer_t *writer,
                                      et_sensor_type_t type,
                                      const char *name, int axes,
                                      const char *R0_str,
                                      int sample_rate, int bit_depth,
                                      const char *access_mode, int N,
                                      int *sensor_id_out);

/*
 * Write a single sample to the stream.
 * The ε is written as a string at the specified precision.
 */
et_error_t et_etsf_writer_write_sample(et_etsf_writer_t *writer,
                                        int sensor_id,
                                        long long timestamp_ns,
                                        int axis, int sign,
                                        long k, const mpfr_t eps,
                                        int eps_dps);

/*
 * Finalize and close the file.
 * Patches total_samples in each sensor header.
 */
et_error_t et_etsf_writer_close(et_etsf_writer_t *writer);

/* ═══════════════════════════════════════════════════════════════════
 * READER — streaming decoder
 * ═══════════════════════════════════════════════════════════════════ */
typedef struct {
    FILE       *fp;
    et_etsf_global_header_t     global_header;
    et_etsf_sensor_header_t    *sensor_headers;
    int                         sensor_count;
} et_etsf_reader_t;

typedef struct {
    long long   timestamp_ns;
    int         sensor_id;
    int         axis;
    int         sign;
    long        k;
    char        eps_str[ET_WORK_DPS + 64]; /* ε as string */
    int         eof;                        /* 1 if end of stream */
} et_etsf_sample_record_t;

/*
 * Open an .etsf file for reading.
 * Reads global header and all sensor headers.
 */
et_error_t et_etsf_reader_open(et_etsf_reader_t *reader, const char *path);

/*
 * Read the next sample from the stream.
 * Returns ET_OK and sets record->eof = 1 when stream is exhausted.
 */
et_error_t et_etsf_reader_next(et_etsf_reader_t *reader,
                                et_etsf_sample_record_t *record);

/*
 * Close the reader.
 */
void et_etsf_reader_close(et_etsf_reader_t *reader);

#endif /* ET_FORMAT_H */
