/*
 * ET LOSSLESS SENSOR CAPTURE — CAMERA CAPTURE (Camera2 NDK RAW)
 * ===============================================================
 * Direct camera hardware access via the Camera2 NDK API with
 * RAW_SENSOR format — unprocessed Bayer-mosaic data at the
 * sensor's native bit depth (10/12/16 bits per pixel).
 *
 * This bypasses the ISP (Image Signal Processor) pipeline:
 *   - No demosaicing (Bayer → RGB conversion)
 *   - No white balance
 *   - No noise reduction
 *   - No sharpening
 *   - No tone mapping
 *   - No gamma correction
 *
 * The raw photoelectron counts go directly to the ET bijection:
 *   R₀ = 1 photoelectron (quantum of detection)
 *   r = raw_DN (digital number from ADC) / 1 = raw_DN (dimensionless count)
 *   Π_N(raw_DN) = (k, d, ε) per pixel per Bayer channel
 *
 * REQUIRES: Camera2 NDK (libcamera2ndk, libmediandk)
 *   cmake: find_library(camera2ndk), find_library(mediandk)
 *
 * Author: Michael James Muller — Aevum Defluo (Exception Theory)
 * License: CC-BY-4.0
 */

#ifndef ET_CAMERA_CAPTURE_HPP
#define ET_CAMERA_CAPTURE_HPP

#include "et_constants.h"
#include "et_bijection.hpp"
#include <cstdint>

/* ═══════════════════════════════════════════════════════════════════
 * CAMERA CONFIGURATION
 * ═══════════════════════════════════════════════════════════════════ */
typedef struct {
    int     camera_id;            /* 0 = rear, 1 = front, -1 = auto */
    int     width;                /* Requested width (0 = maximum RAW) */
    int     height;               /* Requested height (0 = maximum RAW) */
    int     fps;                  /* Requested frame rate (0 = default) */
    int     raw_format;           /* 1 = RAW_SENSOR (16-bit Bayer), 0 = JPEG fallback */
} et_camera_config_t;

/* ═══════════════════════════════════════════════════════════════════
 * CAMERA HARDWARE INFO
 * ═══════════════════════════════════════════════════════════════════ */
typedef struct {
    int     actual_width;
    int     actual_height;
    int     actual_bit_depth;     /* 10, 12, or 16 for RAW */
    int     has_raw_capability;   /* 1 if RAW_SENSOR is supported */
    int     active_array_w;       /* Full sensor active area width */
    int     active_array_h;       /* Full sensor active area height */
    int     bayer_pattern;        /* 0=RGGB, 1=GRBG, 2=GBRG, 3=BGGR */
    float   pixel_pitch_um;       /* Physical pixel size in micrometers */
    int     iso_range_min;        /* Minimum ISO sensitivity */
    int     iso_range_max;        /* Maximum ISO sensitivity */
    long long exposure_range_min_ns; /* Minimum exposure time */
    long long exposure_range_max_ns; /* Maximum exposure time */
    char    camera_name[128];
} et_camera_hw_info_t;

/* ═══════════════════════════════════════════════════════════════════
 * RAW FRAME CALLBACK
 *
 * Called for each captured RAW frame. Provides access to the
 * unprocessed Bayer-mosaic data at the sensor's native bit depth.
 *
 * Parameters:
 *   user_data   — user-provided context
 *   raw_data    — pointer to RAW16 pixel data (uint16_t per pixel)
 *   width       — frame width in pixels
 *   height      — frame height in pixels
 *   row_stride  — bytes per row (may include padding)
 *   bit_depth   — effective bit depth (10, 12, or 16)
 *   timestamp_ns — frame timestamp from the camera
 *   frame_number — sequential frame number
 * ═══════════════════════════════════════════════════════════════════ */
typedef void (*et_camera_callback_t)(void *user_data,
                                      const uint16_t *raw_data,
                                      int width, int height,
                                      int row_stride, int bit_depth,
                                      long long timestamp_ns,
                                      long long frame_number);

/* ═══════════════════════════════════════════════════════════════════
 * CAMERA CAPTURE CONTEXT
 * ═══════════════════════════════════════════════════════════════════ */
typedef struct {
    et_camera_config_t    config;
    et_camera_hw_info_t   hw_info;
    et_camera_callback_t  callback;
    void                 *callback_data;
    int                   is_open;
    int                   is_capturing;
    long long             total_frames;

    /* Camera2 NDK handles (opaque) */
    void                 *camera_device;     /* ACameraDevice* */
    void                 *capture_session;   /* ACameraCaptureSession* */
    void                 *image_reader;      /* AImageReader* */
    void                 *output_container;  /* ACaptureSessionOutputContainer* */
    void                 *session_output;    /* ACaptureSessionOutput* */
    void                 *capture_request;   /* ACaptureRequest* */
} et_camera_capture_t;

/* ═══════════════════════════════════════════════════════════════════
 * LIFECYCLE
 * ═══════════════════════════════════════════════════════════════════ */

/** Get default camera config: rear camera, max RAW resolution. */
et_camera_config_t et_camera_default_config(void);

/** Initialize camera capture. */
et_error_t et_camera_init(et_camera_capture_t *cap, const et_camera_config_t *config,
                           et_camera_callback_t callback, void *user_data);

/** Open camera device and configure RAW_SENSOR output. */
et_error_t et_camera_open(et_camera_capture_t *cap);

/** Start capturing RAW frames. */
et_error_t et_camera_start(et_camera_capture_t *cap);

/** Stop capturing. */
et_error_t et_camera_stop(et_camera_capture_t *cap);

/** Close camera and free resources. */
void et_camera_close(et_camera_capture_t *cap);

/** Print camera hardware report. */
void et_camera_print_report(const et_camera_capture_t *cap);

/** Check if any camera supports RAW_SENSOR format. */
int et_camera_has_raw_support(void);

#endif /* ET_CAMERA_CAPTURE_HPP */
