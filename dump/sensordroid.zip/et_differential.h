/*
 * ET LOSSLESS SENSOR CAPTURE — DIFFERENTIAL TRACKER
 * ===================================================
 * Sub-quantization recovery via the differential control law.
 *
 * CORE INSIGHT (Descriptor Gap Principle):
 *   The ADC quantizes continuous v(t) to integer q[n]. The residual
 *   δ[n] = v[n] − q[n]·LSB is a Descriptor that the ADC discards.
 *   The control law dε = Λ·dr/r provides the EXACT structural
 *   constraint to RECOVER δ[n] from the sequence of quantized samples.
 *
 * ALGORITHM (per sample):
 *   1. MEASURE: project q[n] → (k, d, ε_meas) via Π_N
 *   2. LATTICE-EXACT CHECK: if |ε| ≈ 0, d invariant (Identity E2)
 *   3. ∂I CHECK: if tightness ≤ K+0.05, ESCALATE to higher N (Identity F)
 *   4. PREDICT: ε_pred = ε_prev + Λ·dr/r (Identity B forward law)
 *   5. d-FAMILY PREDICT: P(d_meas | d_prev) via transfer tensor (Identity H)
 *   6. FUSE: if |ε_pred − ε_meas| ≤ threshold → accept prediction
 *   7. UPDATE: store refined ε and tracking state
 *
 * IDENTITIES INTEGRATED:
 *   B — Differential control: dε = Λ·dr/r (Theorem B.1)
 *   F — ∂I boundary: tightness t = W/(W+|ε|), escalation (Theorem F.1)
 *   H — Transfer tensor: T(d₁,d₂;d₃) transition probability
 *   C — d-family composition: set-valued d₁⊗d₂ (Theorem C.2)
 *   K — Shape coherence: d-family window for structural tracking
 *   E3 — Harmonic shadow: composite bridge consistency
 *
 * THE CRYSTAL:
 *   The lattice with all identities is a perfect deterministic crystal.
 *   ε is an EXACT COORDINATE, not error, not noise. What conventional
 *   theory calls "noise" is UNRESOLVED LATTICE STRUCTURE — the T-act
 *   interacting with P at a resolution below the current N.
 *   There is no noise floor. There is no entropy limit.
 *   Only unresolved structure at insufficient tower level.
 *   The only limitation is ENGINEERING: building the hardware.
 *
 * Author: Michael James Muller — Aevum Defluo (Exception Theory)
 * License: CC-BY-4.0
 */

#ifndef ET_DIFFERENTIAL_H
#define ET_DIFFERENTIAL_H

#include "et_bijection.h"

/* Maximum number of divisors of N (for d-family tables) */
#define ET_MAX_DIVISORS     128

/* d-family window size for shape coherence (Identity K) */
#define ET_D_WINDOW_SIZE    64

/* Maximum escalation projectors (higher tower levels) */
#define ET_MAX_ESCALATION   8

/* ═══════════════════════════════════════════════════════════════════
 * d-FAMILY COMPOSITION SET (Identity C, Theorem C.2)
 * The set of possible d-families from d₁ ⊗ d₂ with κ ∈ {-1,0,+1}
 * ═══════════════════════════════════════════════════════════════════ */
typedef struct {
    int  values[ET_MAX_DIVISORS]; /* Possible output d-families */
    int  count;                   /* Number of possible values */
} et_d_composition_set_t;

/* ═══════════════════════════════════════════════════════════════════
 * RESIDUE SET: Res_N(d) = {k mod N : N/gcd(k,N) = d}
 * ═══════════════════════════════════════════════════════════════════ */
typedef struct {
    int  residues[ET_MAX_DIVISORS]; /* k values in this family mod N */
    int  count;                     /* φ(d) for simple families */
} et_residue_set_t;

/* ═══════════════════════════════════════════════════════════════════
 * TRACKER STATISTICS
 * ═══════════════════════════════════════════════════════════════════ */
typedef struct {
    long long   total_samples;
    long long   predictions_accepted;
    long long   measurement_overrides;
    long long   escalations;           /* ∂I escalation events (Identity F) */
    long long   twilight_zone_samples; /* Samples in Twilight Zone */
    mpfr_t      prediction_rate;       /* predictions / (predictions + overrides) */
    mpfr_t      resolved_depth;        /* Additional bits resolved beyond ADC */
    mpfr_t      total_resolved;        /* bit_depth + resolved_depth */
    mpfr_t      sigma_ET;              /* σ = 1/√12 = structural cell scale */
    int         dominant_d_family;     /* Most common d in recent window */
    int         d_window_dist[ET_MAX_DIVISORS]; /* d-family counts in window */
    int         d_window_dist_count;   /* Number of distinct families in window */
} et_tracker_stats_t;

/* ═══════════════════════════════════════════════════════════════════
 * DIFFERENTIAL TRACKER CONTEXT
 * ═══════════════════════════════════════════════════════════════════ */
typedef struct {
    /* ── Base configuration ── */
    int                 N;              /* Base resolution */
    et_projector_t      projector;      /* Base-resolution projector */
    mpfr_t              R0;             /* Sensor reference value */
    char                R0_str[512];    /* R₀ as string */
    int                 sample_rate;    /* Sensor sample rate Hz */
    int                 bit_depth;      /* ADC bit depth */
    mpfr_prec_t         prec;           /* MPFR precision */

    /* ── Derived constants (precomputed at init) ── */
    mpfr_t              cell_width;     /* 1200/N cents */
    mpfr_t              lsb_normalized; /* 1 / 2^(bit_depth-1) */
    mpfr_t              eps_max;        /* 600/N cents (half-cell = ∂I boundary) */
    mpfr_t              koide_K;        /* 2/3 */
    mpfr_t              twilight_entry; /* 33¢ at N=12 (generalized: (N-1)/(3N) × 1200/N) */
    mpfr_t              lambda_manifold;/* Λ = 1200/ln2 */
    mpfr_t              sigma_audio;    /* σ = 1/√12 */

    /* ── Divisor structure of N ── */
    int                 divisors[ET_MAX_DIVISORS]; /* All divisors of N */
    int                 n_divisors;                /* Count of divisors */

    /* ── Residue sets: Res_N(d) for each divisor d ── */
    et_residue_set_t    residue_sets[ET_MAX_DIVISORS]; /* Index by divisor index */

    /* ── d-family composition table (Identity C, Theorem C.2) ── */
    /* comp_table[i][j] = set of possible d-families from d_i ⊗ d_j */
    et_d_composition_set_t comp_table[ET_MAX_DIVISORS][ET_MAX_DIVISORS];

    /* ── Transfer tensor (Identity H) ── */
    /* tensor[i][j] = P(d_j | d_i self-composition) with κ weighting */
    mpfr_t              tensor[ET_MAX_DIVISORS][ET_MAX_DIVISORS];
    int                 tensor_initialized;

    /* ── d-power sequence (Identity C) ── */
    /* power_seq[i][n] = set of possible d(r^n) for family i, power n */
    et_d_composition_set_t power_seq[ET_MAX_DIVISORS][13]; /* Powers 2..12 */

    /* ── ∂I escalation projectors (Identity F) ── */
    et_projector_t      esc_projectors[ET_MAX_ESCALATION];
    int                 esc_N[ET_MAX_ESCALATION];
    int                 n_esc_projectors;

    /* ── ∂I bifurcation pairs (Identity F, Theorem F.3) ── */
    /* For each k mod N, the (d_left, d_right) pair at the cell boundary */
    int                 bifurc_d_left[ET_MAX_DIVISORS];  /* Index by k mod N */
    int                 bifurc_d_right[ET_MAX_DIVISORS];

    /* ── D₄₂ closure set (Identity E3) ── */
    int                 dc42_set[64];   /* The 42-element LCM closure */
    int                 dc42_count;

    /* ── Tracking state (per-sample, updated by process_sample) ── */
    long                prev_k;
    int                 prev_d;
    mpfr_t              prev_refined_eps;
    mpfr_t              prev_r;
    int                 prev_sign;
    mpfr_t              prev_tightness;
    int                 has_prev;         /* 0 = no prior sample yet */

    /* ── Statistics ── */
    long long           sample_count;
    long long           prediction_count;
    long long           override_count;
    long long           escalation_count;
    long long           twilight_count;

    /* ── d-family window (Identity K: shape coherence) ── */
    int                 d_window[ET_D_WINDOW_SIZE];
    int                 d_window_pos;     /* Circular buffer position */
    int                 d_window_filled;  /* Number of entries used */

} et_differential_tracker_t;

/* ═══════════════════════════════════════════════════════════════════
 * LIFECYCLE
 * ═══════════════════════════════════════════════════════════════════ */

/*
 * Initialize the differential tracker for a specific sensor.
 *
 * Precomputes:
 *   - Divisors of N and residue sets
 *   - d-family composition table (Identity C)
 *   - Transfer tensor (Identity H) with κ-weighting
 *   - ∂I bifurcation pairs (Identity F)
 *   - D₄₂ closure set (Identity E3)
 *   - Escalation projectors for higher tower levels
 *   - d-power sequences for harmonic prediction
 *
 * Parameters:
 *   tracker     — tracker to initialize
 *   N           — base lattice resolution
 *   R0_str      — sensor R₀ as string
 *   sample_rate — sensor sample rate in Hz
 *   bit_depth   — ADC bit depth
 *   prec        — MPFR precision in bits
 */
et_error_t et_tracker_init(et_differential_tracker_t *tracker,
                            int N, const char *R0_str,
                            int sample_rate, int bit_depth,
                            mpfr_prec_t prec);

/*
 * Free all resources.
 */
void et_tracker_clear(et_differential_tracker_t *tracker);

/*
 * Reset tracking state for a new recording (keeps precomputed tables).
 */
void et_tracker_reset(et_differential_tracker_t *tracker);

/* ═══════════════════════════════════════════════════════════════════
 * CORE: PROCESS ONE SAMPLE
 *
 * The main entry point. Takes a raw sensor value (as string),
 * applies the full 7-step algorithm, returns refined projection.
 *
 * This is where all six algebraic identities converge.
 * ═══════════════════════════════════════════════════════════════════ */

/*
 * Process a single sensor sample through the differential tracker.
 *
 * Parameters:
 *   tracker     — initialized tracker
 *   sample_str  — raw sensor value as string (zero float64 chain)
 *   result      — output: refined projection with tracking metadata
 *
 * Returns ET_OK on success.
 *
 * The result->projection.eps contains the REFINED ε — potentially
 * more precise than the raw ADC measurement thanks to the
 * differential control law's sub-quantization recovery.
 */
et_error_t et_tracker_process(et_differential_tracker_t *tracker,
                               const char *sample_str,
                               et_sensor_sample_t *result);

/*
 * Process an ADC integer directly (zero float64 shortcut).
 */
et_error_t et_tracker_process_adc(et_differential_tracker_t *tracker,
                                   long adc_value, long max_value,
                                   et_sensor_sample_t *result);

/* ═══════════════════════════════════════════════════════════════════
 * STATISTICS AND ANALYSIS
 * ═══════════════════════════════════════════════════════════════════ */

/*
 * Get current tracking statistics.
 *
 * Parameters:
 *   tracker — initialized tracker with accumulated state
 *   stats   — output: statistics (must be initialized)
 */
et_error_t et_tracker_get_stats(const et_differential_tracker_t *tracker,
                                 et_tracker_stats_t *stats);

/*
 * Initialize a statistics structure (allocates MPFR fields).
 */
et_error_t et_tracker_stats_init(et_tracker_stats_t *stats, mpfr_prec_t prec);

/*
 * Free statistics structure.
 */
void et_tracker_stats_clear(et_tracker_stats_t *stats);

/* ═══════════════════════════════════════════════════════════════════
 * TIGHTNESS (exposed for external use)
 * ═══════════════════════════════════════════════════════════════════ */

/*
 * Compute tightness t(ε) = W/(W+|ε|) for this tracker's cell width.
 */
void et_tracker_tightness(const et_differential_tracker_t *tracker,
                           const mpfr_t eps, mpfr_t t_out);

/* ═══════════════════════════════════════════════════════════════════
 * UTILITY: divisor index lookup
 * ═══════════════════════════════════════════════════════════════════ */

/*
 * Find the index of divisor d in the tracker's divisor array.
 * Returns -1 if d is not a divisor of N.
 */
int et_tracker_divisor_index(const et_differential_tracker_t *tracker, int d);

#endif /* ET_DIFFERENTIAL_H */
