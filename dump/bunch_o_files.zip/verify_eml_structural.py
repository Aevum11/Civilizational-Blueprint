"""
Check structural correspondences between the paper's three EML variants
and ET's triadic structure, plus the ternary Sheffer's self-closure.
"""
import math
import cmath
from math import gcd, log2

N_ET = 12
def project_real(r, N=N_ET):
    if r <= 0: return None
    exact = N * log2(r)
    k = int(round(exact))
    g = gcd(abs(k), N) if k != 0 else N
    d = N // g
    eps_cents = (exact - k) * (1200.0 / N)
    return dict(k=k, d=d, eps_cents=eps_cents)

# The three paper-identified Sheffer variants (eqs 4a, 4b, 4c)
print("=" * 70)
print("THE THREE EML SHEFFER VARIANTS vs their distinguished constants")
print("=" * 70)
print("Variant  Formula                     Constant     Constant class")
print("-" * 70)

# 4a: eml(x,y) = exp(x) - ln(y),          constant = 1
# 4b: edl(x,y) = exp(x) / ln(y),          constant = e
# 4c: -eml(y,x) = ln(x) - exp(y),         constant = -∞

variants = [
    ("EML (4a)",  "exp(x) - ln(y)",          1.0,        "1"),
    ("EDL (4b)",  "exp(x) / ln(y)",          math.e,     "e"),
    ("-EML (4c)", "ln(x) - exp(y)",          None,       "-∞"),
]
for name, form, const, const_str in variants:
    if const is None:
        print(f"{name:<10}  {form:<26}  {const_str:<11}  off-lattice (annihilation boundary §3.4)")
        continue
    p = project_real(const)
    print(f"{name:<10}  {form:<26}  {const_str:<11}  k={p['k']:>+3}  d={p['d']:>2}  ε={p['eps_cents']:+.2f}¢")

# Check: is there a PDT-style categorization?
#   1 is the multiplicative identity → Exception unison of (ℝ⁺,×) — the D-ground
#   e is the Euler base — the natural-log fixed point — the T-fixed point of exp/ln
#   -∞ is the log-annihilation boundary of (ℝ⁺,×) → the P-edge
# I.e. the three constants are one-each from each of three ET-structural roles:
#   constant 1  = D-identity (unison, k=0, d=1)
#   constant e  = T-fixed (e^1 = e, ln e = 1; the exp/ln loop closure)
#   constant -∞ = P-edge (the annihilation boundary of the multiplicative manifold)

print()
print("=" * 70)
print("STRUCTURAL CLAIM: The three variant constants {1, e, -∞} map 1-to-1")
print("onto ET's {D-identity, T-fixed-point, P-edge} roles")
print("=" * 70)
print("  constant 1   -> (ℝ⁺,×) identity: r=1 → k=0, d=1, ε=0 UNISON (D-ground)")
print("  constant e   -> exp/ln loop closure: ln(e)=1, exp(1)=e (T-closure)")
print("  constant -∞  -> log-annihilation: ln(0)=-∞ → r=0 OFF-LATTICE (P-edge)")

# Verify: projection of e does NOT sit at a deep attractor (it's at d=12, ε~+31¢)
# while 1 is the unison. The asymmetry matches: 1 is D-trivial (exactly on the lattice),
# e is a transcendental (hits d=12 with substantial gap), and -∞ is outside the lattice.
# This is the ET (PDT)-role asymmetry expressed in constant choice.

# The ternary operator T(x,y,z) = e^(x/ln x) · ln(z)/e^y  (paper §5, Ref. [47])
# Paper claim: T(x,x,x) = 1 WITHOUT a distinguished constant
print()
print("=" * 70)
print("The ternary Sheffer T(x,y,z) = e^(x/ln x) · ln(z) / e^y ")
print("Paper's claim: T(x,x,x) = 1  (no distinguished constant needed)")
print("=" * 70)

def T_ternary(x, y, z):
    return cmath.exp(x / cmath.log(x)) * cmath.log(z) / cmath.exp(y)

for xval in [2.0, 3.0, math.e, math.pi, 7.3, 1000.0]:
    v = T_ternary(xval, xval, xval)
    print(f"  T({xval}, {xval}, {xval})  =  {v}")
# Should all be 1 + 0j

# Structural parallel: the paper's ternary operator achieves the SAME property
# as ET's three-primitive closure: three inputs, unit output, no external axiom.
# This mirrors the ET structural claim |Π| = 3 uniquely necessary (§5.5).

# 3) Project the transcendental residuals e and π.
#    EML must generate these from scratch — so their lattice positions should
#    reflect how "hard" they are to reach.
print()
print("=" * 70)
print("EML COMPLEXITY vs ET LATTICE ELEGANCE for the two core transcendentals")
print("=" * 70)
# RPN K from paper Table 4: e -> K=3 (direct),  π -> K>53 (direct, unfinished)
#                           e -> K=3 (EML-compiler), π -> K=193 (compiler)
# So π is ~18x to 65x harder than e in EML depth.

# Lattice projections
for const, val, K_direct in [("e", math.e, 3), ("π", math.pi, 53)]:
    p = project_real(val)
    print(f"{const}: K_direct_search={K_direct}, lattice=(k={p['k']}, d={p['d']}, ε={p['eps_cents']:+.2f}¢)")

print()
print("Both hit d=12-family-adjacent structure, but e is tightly bound (ε~+31¢")
print("inside d=12) while π falls in d=3 (cubic). EML effort ratio (K π / K e)")
print("≈ 53/3 ≈ 18 at direct-search; for compiler output 193/3 ≈ 64.")
print("Compare to ET magical impedance: ξ(d=3)/ξ(d=12) = 6.85/1.00 = 6.85×")
print("per-step coupling strength (Part VIII §43). The EML K-ratio is not")
print("equal to the ET ξ ratio — EML measures tree-depth, ET ξ measures")
print("coupling-strength; they are NOT the same invariant.")

# 4) The palindromic cascade of ET is PALINDROME=[12,6,4,3,12,2,12,3,4,6,12,1].
#    Does the paper's discovery order (Fig 1, spiral) have any relationship?
#    Look at the phylogenetic tree: starts at EML/1, reaches e first (K=3),
#    then -1, 2, π, etc. The ET palindrome starts at 12 (the full resolution),
#    goes 12 → 6 → 4 → 3 → 12 → 2 → 12 → 3 → 4 → 6 → 12 → 1.
#    Let's see if there's a relationship by projecting the discovery order.

print()
print("=" * 70)
print("ET palindrome positions of the 'easy' EML-recoverable constants")
print("(paper Table 4 shows simplest RPN K values first to compile)")
print("=" * 70)
# Paper reports the constants that EML generates earliest (from Fig 1 order):
discovery_order = [
    ("e",    math.e,              3),
    ("-1",   1.0,                 17),  # 17 in K
    ("2",    2.0,                 19),
    ("-2",   2.0,                 27),  # structural note: -2 is also at |r|=2
    ("1/2",  0.5,                 29),
    ("√2",   math.sqrt(2),        35),
    ("π",    math.pi,             53),
    ("i",    1.0,                 55),  # |i|=1 — pure phase
]
print(f"{'const':<6}  {'RPN K':>6}  {'|r| proj':>16}")
for name, r, K in discovery_order:
    p = project_real(r)
    if p:
        print(f"{name:<6}  {K:>6}  k={p['k']:>+3}, d={p['d']:>2}, ε={p['eps_cents']:+.2f}¢")

