# -*- mode: python ; coding: utf-8 -*-
#
# et32_bridge.spec
# ET32 Bridge — PyInstaller Build Specification (64-bit Broker)
#
# Derived from P ∘ D ∘ T = E.
#
# PDT of this build:
#   P = the Python source tree (all et_bridge modules + entry point)
#   D = PyInstaller spec (the Descriptor set of the distribution)
#   T = PyInstaller itself (the Traverser that compiles P into a binary)
#   E = ET32_Bridge.exe — a fully self-contained 64-bit broker executable
#
# ET constants reflected in the build:
#   S = 12 → 12+ et_*.py modules collected from flat directory
#   IPC_BUFFER_SIZE = 49152 → runtime constant embedded via Analysis
#
# Usage:
#   pyinstaller et32_bridge.spec
#
# Prerequisites (64-bit Python ≥ 3.9):
#   pip install pyinstaller pystray pillow pywin32
#
# The output is placed in dist/ET32_Bridge/ (one-folder mode for easier
# distribution alongside et_bridge32.dll and config_template.json).
#
# SPDX-License-Identifier: MIT
# Copyright (c) 2026 Michael James Muller (Aevum Defluo) — Exception Theory

import sys
import os
from pathlib import Path

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
HERE        = Path(SPECPATH)          # directory containing this .spec file
SRC_MAIN    = str(HERE / "et32_bridge_main.py")
SRC_DIR     = str(HERE)              # all modules live flat alongside the entry point
DIST_NAME   = "ET32_Bridge"

# ---------------------------------------------------------------------------
# Analysis — collect all source modules
# ---------------------------------------------------------------------------
a = Analysis(
    [SRC_MAIN],
    pathex=[str(HERE)],
    binaries=[],
    datas=[
        # Ship the default config template alongside the executable
        (str(HERE / "config_template.json"), "."),
        # Ship the 32-bit DLL (compiled separately by build.bat)
        (str(HERE / "et_bridge32.dll"),      "."),
    ],
    hiddenimports=[
        # All ET bridge modules — flat layout (S = 12 core + 2 extended)
        "et_math",
        "et_handle",
        "et_config",
        "et_logger",
        "et_monitor",
        "et_heaven",
        "et_injector",
        "et_ipc",
        "et_host64",
        "et_api",
        "et_awe",
        "et_wow64",
        "et_errors",
        # Win32 extensions used by the bridge
        "win32api",
        "win32con",
        "win32process",
        "win32security",
        "pywintypes",
        # System tray (optional — present if installed)
        "pystray",
        "PIL",
        "PIL.Image",
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        # Exclude heavy packages not used by the bridge
        "numpy",
        "scipy",
        "matplotlib",
        "pandas",
        "tkinter",
        "unittest",
        "email",
        "html",
        "http",
        "xmlrpc",
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=None,
    noarchive=False,
)

# ---------------------------------------------------------------------------
# PYZ — compressed Python bytecode archive
# ---------------------------------------------------------------------------
pyz = PYZ(a.pure, a.zipped_data, cipher=None)

# ---------------------------------------------------------------------------
# EXE — the broker executable (64-bit, Windows subsystem = console for log output)
# ---------------------------------------------------------------------------
exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,         # one-folder mode: binaries stay in dist/
    name=DIST_NAME,
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=True,                  # console mode: log output visible in terminal
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,              # inherits host arch (must be x64)
    codesign_identity=None,
    entitlements_file=None,
    icon=None,
    version=None,
)

# ---------------------------------------------------------------------------
# COLLECT — assemble the one-folder distribution
# ---------------------------------------------------------------------------
coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[
        # Do not UPX-compress the 32-bit DLL — it breaks the PE structure
        "et_bridge32.dll",
    ],
    name=DIST_NAME,
)
