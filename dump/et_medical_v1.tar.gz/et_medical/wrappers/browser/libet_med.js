// ============================================================================
// libet_med.js — JavaScript facade over the Emscripten-built libet_med WASM
// ----------------------------------------------------------------------------
//  Identification: this is the Browser projection of the libet_med C ABI —
//  the same ABI the Windows C# and Android Kotlin wrappers bind to. All
//  function names mirror the corresponding methods on those platforms.
//
//  Subsumption: the underlying WASM is literally the same C code compiled
//  via Emscripten; this file only adapts the `ccall`/`cwrap` conventions
//  plus a small amount of HEAP marshalling for the struct-returning
//  functions.
//
//  Build: see README.md and build_wasm.sh in this directory.
//  Usage:
//      <script src="et_med.js"></script>      <!-- Emscripten glue -->
//      <script src="libet_med.js"></script>   <!-- this facade -->
//      <script>
//        createLibEtMed().then(async Module => {
//          const api = new EtMed(Module);
//          await api.ready;
//          const patient = api.patientBaseline({ hrRestBpm: 60, ... });
//          const sig = api.computeMultifoldSignature(patient);
//        });
//      </script>
// ============================================================================

// Enums — mirror the C ABI integer codes one-for-one.
const EtError = Object.freeze({
    Ok: 0, InvalidRatio: 1, InvalidN: 2, InvalidArg: 3,
    OutOfMemory: 4, UnknownTower: 5, IncompleteBaseline: 6,
    FallbackUsed: 7, CascadeStabilityExceeded: 8,
    OffLattice: 9, Numeric: 10, Last: 11
});

const Tower = Object.freeze({
    Cardiac: 0, Respiratory: 1, Neural: 2, Endocrine: 3, Immune: 4,
    Digestive: 5, Renal: 6, Musculoskeletal: 7, Reproductive: 8,
    Developmental: 9, Count: 10
});

const Sex = Object.freeze({ Female: 0, Male: 1, Unspecified: 2 });

const ManifoldState = Object.freeze({
    Exception: 0, Unsubstantiated: 1, Mediation: 2, Incoherence: 3
});
const ManifoldStateName = Object.freeze({
    0: "Exception", 1: "Unsubstantiated", 2: "Mediation", 3: "Incoherence"
});

const IncoherenceLevel = Object.freeze({
    None: 0, L1Categorical: 1, L2Binding: 2, L3Cascade: 3,
    L4Stability: 4, L5Coherence: 5
});
const IncoherenceLevelName = Object.freeze({
    0: "None", 1: "L1 Categorical", 2: "L2 Binding",
    3: "L3 Cascade", 4: "L4 Stability", 5: "L5 Coherence"
});

const TowerName = Object.freeze({
    0: "Cardiac", 1: "Respiratory", 2: "Neural", 3: "Endocrine", 4: "Immune",
    5: "Digestive", 6: "Renal", 7: "Musculoskeletal", 8: "Reproductive",
    9: "Developmental"
});

// Struct layouts (bytes) — computed from the C struct definitions. These
// are DERIVED from the canonical ABI sizes (int=4, double=8, C11 struct
// alignment — the largest member is double so 8-byte aligned overall).
//
// et_projection_t: 8*3 + 4*3 + 8 + 4 = 56 bytes, padded to 56 on boundary
//   r(8) log2_r(8) exact_pos(8) k(4) g(4) d(4) eps_cents(8) N(4) -> with
//   natural alignment: r@0 log2_r@8 exact_pos@16 k@24 g@28 d@32 eps@40
//   N@48 total 56 (pad 4 at end so struct size = 56)... actually final
//   size must be multiple of largest alignment (8) so 56 is OK.
const SIZEOF_PROJECTION = 56;
const PROJ_OFFSETS = {
    r: 0, log2_r: 8, exact_pos: 16, k: 24, g: 28, d: 32,
    eps_cents: 40, N: 48
};

// et_patient_baseline_t: 9 doubles + 1 int + pad to multiple of 8
//   hr(0) rr(8) temp(16) sbp(24) dbp(32) spo2(40) gait(48) cycle(56)
//   age(64) sex(72,int) pad(76) = 80 bytes
const SIZEOF_PATIENT_BASELINE = 80;
const PB_OFFSETS = {
    hrRestBpm: 0, rrRestPerMin: 8, temperatureC: 16, sbpRestMmHg: 24,
    dbpRestMmHg: 32, spo2Pct: 40, gaitCycleS: 48, menstrualCycleD: 56,
    ageYears: 64, sex: 72
};

// et_finding_t verified layout (from abi_probe at build time):
//   sizeof = 704
//   name@0 (96)  description@96 (256)  state@352  incoh@356  tower@360
//   lattice_res@364  projection@368 (56)  severity_raw@424  severity_pct@432
//   urgency_rank@440  icd11@444  icf@476  snomed@508  laterality@540
//   severity_text@572  specific_anatomy@604  histopathology@636
//   temporal_pattern@668
const SIZEOF_FINDING = 704;
const FN_OFFSETS = {
    name: 0, description: 96, state: 352, incoh: 356, tower: 360,
    latticeRes: 364, projection: 368, severityRaw: 424, severityPct: 432,
    urgencyRank: 440, icd11: 444, icf: 476, snomed: 508, laterality: 540,
    severityText: 572, specificAnatomy: 604, histopathology: 636,
    temporalPattern: 668
};
const FN_SIZES = {
    name: 96, description: 256,
    icd11: 32, icf: 32, snomed: 32, laterality: 32,
    severityText: 32, specificAnatomy: 32, histopathology: 32,
    temporalPattern: 32
};

// ============================================================================
//  EtMed class — the public facade
// ============================================================================
class EtMed {
    constructor(Module) {
        this.M = Module;
        this.ready = Promise.resolve();

        // cwrap every exported function.
        const c = (name, ret, args) => Module.cwrap(name, ret, args);
        this._errorString          = c('et_error_string', 'string', ['number']);
        this._fallbackCount        = c('et_fallback_count', 'number', []);
        this._resetFallbackCount   = c('et_reset_fallback_count', null, []);
        this._projectRealRaw       = c('et_project_real', 'number',
                                       ['number', 'number', 'number']);
        this._projectImagRaw       = c('et_project_imag', 'number',
                                       ['number', 'number', 'number']);
        this._projectMultiRaw      = c('et_project_multi', 'number',
                                       ['number', 'number', 'number', 'number']);
        this._lcmTower             = c('et_lcm_tower', 'number', ['number', 'number']);
        this._eleganceScoreRaw     = c('et_elegance_score', 'number',
                                       ['number', 'number', 'number', 'number']);
        this._magicalImpedance     = c('et_magical_impedance', 'number',
                                       ['number', 'number', 'number']);
        this._bestRationalRaw      = c('et_best_rational', 'number',
                                       ['number', 'number', 'number', 'number']);
        this._palindromeD          = c('et_palindrome_d', 'number', ['number']);
        this._shimmer              = c('et_shimmer', 'number', ['number']);
        this._towerName            = c('et_tower_name', 'string', ['number']);
        this._towerDefaultR0       = c('et_tower_default_R0', 'number', ['number']);
        this._towerResolution      = c('et_tower_resolution', 'number', ['number']);
        this._towerReferenceBaseline = c('et_tower_reference_baseline_value',
                                         'number', ['number']);
        this._patientBaselineInit  = c('et_patient_baseline_init', null, ['number']);
        this._derivePersonalR0Raw  = c('et_derive_personal_R0', 'number',
                                       ['number', 'number', 'number', 'number']);
        this._computeMultifoldRaw  = c('et_compute_multifold_signature', 'number',
                                       ['number', 'number', 'number']);
        this._manifoldStateName    = c('et_manifold_state_name', 'string', ['number']);
        this._incoherenceLevelName = c('et_incoherence_level_name', 'string', ['number']);
        this._measurementInit      = c('et_measurement_init', null, ['number']);
        this._findingInit          = c('et_finding_init', null, ['number']);
        this._classifyMeasurementRaw = c('et_classify_measurement', 'number',
                                         ['number', 'number', 'number', 'number']);
        this._generateFindingsRaw  = c('et_generate_findings', 'number',
                                       ['number', 'number', 'number',
                                        'number', 'number', 'number']);
        this._freeFindings         = c('et_free_findings', null, ['number', 'number']);
        this._severityScoreRaw     = c('et_severity_score_raw', 'number',
                                       ['number', 'number', 'number', 'number',
                                        'number', 'number']);
        this._severityScorePct     = c('et_severity_score_pct', 'number', ['number']);
        this._severityScoreMaxRaw  = c('et_severity_score_max_raw', 'number', []);
        this._classifyState        = c('et_classify_state', 'number',
                                       ['number', 'number', 'number']);
        this._classifyIncoherence  = c('et_classify_incoherence_level', 'number',
                                       ['number', 'number', 'number',
                                        'number', 'number']);

        // Constants: mirrored from the C header.
        this.ET_V_BASE           = 1.0 / 12.0;
        this.ET_K_KOIDE          = 2.0 / 3.0;
        this.ET_A0_LOCAL_EM      = 137;
        this.ET_BIOLOGICAL_FLOOR = 420;
        this.ET_CORTICAL_FLOOR   = 27720;
    }

    // ---------- Memory helpers (wrap _malloc/_free) ------------------------
    _malloc(bytes) {
        const ptr = this.M._malloc(bytes);
        if (ptr === 0) throw new Error("libet_med: out of WASM memory");
        return ptr;
    }
    _zalloc(bytes) {
        const ptr = this._malloc(bytes);
        this.M.HEAP8.fill(0, ptr, ptr + bytes);
        return ptr;
    }
    _free(ptr) { if (ptr) this.M._free(ptr); }

    _readProjection(ptr) {
        const H = this.M;
        return {
            r:         H.HEAPF64[(ptr + PROJ_OFFSETS.r)        >> 3],
            log2R:     H.HEAPF64[(ptr + PROJ_OFFSETS.log2_r)   >> 3],
            exactPos:  H.HEAPF64[(ptr + PROJ_OFFSETS.exact_pos)>> 3],
            k:         H.HEAP32 [(ptr + PROJ_OFFSETS.k)        >> 2],
            g:         H.HEAP32 [(ptr + PROJ_OFFSETS.g)        >> 2],
            d:         H.HEAP32 [(ptr + PROJ_OFFSETS.d)        >> 2],
            epsCents:  H.HEAPF64[(ptr + PROJ_OFFSETS.eps_cents)>> 3],
            n:         H.HEAP32 [(ptr + PROJ_OFFSETS.N)        >> 2]
        };
    }

    _writePatientBaseline(ptr, b) {
        const H = this.M;
        this._patientBaselineInit(ptr);  // sets all NaN / unspecified
        const write = (key) => {
            if (b[key] !== undefined && Number.isFinite(b[key])) {
                H.HEAPF64[(ptr + PB_OFFSETS[key]) >> 3] = b[key];
            }
        };
        ['hrRestBpm','rrRestPerMin','temperatureC','sbpRestMmHg',
         'dbpRestMmHg','spo2Pct','gaitCycleS','menstrualCycleD',
         'ageYears'].forEach(write);
        if (b.sex !== undefined) H.HEAP32[(ptr + PB_OFFSETS.sex) >> 2] = b.sex|0;
    }

    _readCString(ptr, maxLen) {
        return this.M.UTF8ToString(ptr, maxLen);
    }

    _readFinding(ptr) {
        const H = this.M;
        return {
            name:             this._readCString(ptr + FN_OFFSETS.name,           FN_SIZES.name),
            description:      this._readCString(ptr + FN_OFFSETS.description,    FN_SIZES.description),
            state:            H.HEAP32[(ptr + FN_OFFSETS.state)        >> 2],
            incoherenceLevel: H.HEAP32[(ptr + FN_OFFSETS.incoh)        >> 2],
            tower:            H.HEAP32[(ptr + FN_OFFSETS.tower)        >> 2],
            latticeResolution: H.HEAP32[(ptr + FN_OFFSETS.latticeRes)  >> 2],
            projection:       this._readProjection(ptr + FN_OFFSETS.projection),
            severityRaw:      H.HEAPF64[(ptr + FN_OFFSETS.severityRaw) >> 3],
            severityPct:      H.HEAPF64[(ptr + FN_OFFSETS.severityPct) >> 3],
            urgencyRank:      H.HEAP32[(ptr + FN_OFFSETS.urgencyRank)  >> 2],
            icd11Code:        this._readCString(ptr + FN_OFFSETS.icd11,          FN_SIZES.icd11),
            icfCode:          this._readCString(ptr + FN_OFFSETS.icf,            FN_SIZES.icf),
            snomedCode:       this._readCString(ptr + FN_OFFSETS.snomed,         FN_SIZES.snomed),
            laterality:       this._readCString(ptr + FN_OFFSETS.laterality,     FN_SIZES.laterality),
            severityText:     this._readCString(ptr + FN_OFFSETS.severityText,   FN_SIZES.severityText),
            specificAnatomy:  this._readCString(ptr + FN_OFFSETS.specificAnatomy, FN_SIZES.specificAnatomy),
            histopathology:   this._readCString(ptr + FN_OFFSETS.histopathology, FN_SIZES.histopathology),
            temporalPattern:  this._readCString(ptr + FN_OFFSETS.temporalPattern, FN_SIZES.temporalPattern)
        };
    }

    // ---------- Public API ------------------------------------------------

    errorString(code)          { return this._errorString(code); }
    fallbackCount()            { return this._fallbackCount(); }
    resetFallbackCount()       { this._resetFallbackCount(); }

    magicalImpedance(d, s = 4, a0 = 137) {
        return this._magicalImpedance(d, s, a0);
    }

    palindromeD(nMod12)        { return this._palindromeD(nMod12); }
    shimmer(n)                 { return this._shimmer(n); }

    towerName(t)               { return this._towerName(t); }
    towerDefaultR0(t)          { return this._towerDefaultR0(t); }
    towerResolution(t)         { return this._towerResolution(t); }
    towerReferenceBaseline(t)  { return this._towerReferenceBaseline(t); }

    projectReal(r, n = 12) {
        const ptr = this._zalloc(SIZEOF_PROJECTION);
        try {
            const code = this._projectRealRaw(r, n, ptr);
            if (code !== 0) throw new EtMedError(code, this.errorString(code));
            return this._readProjection(ptr);
        } finally { this._free(ptr); }
    }

    projectImag(theta, n = 12) {
        const ptr = this._zalloc(SIZEOF_PROJECTION);
        try {
            const code = this._projectImagRaw(theta, n, ptr);
            if (code !== 0) throw new EtMedError(code, this.errorString(code));
            return this._readProjection(ptr);
        } finally { this._free(ptr); }
    }

    computeMultifoldSignature(baseline, allowFallback = true) {
        // The C struct is 4*TowerCount + 8*TowerCount + 45*sizeof(elegance)
        // + 3 doubles + 1 int. We allocate enough to cover the whole struct
        // and only read the scalars we need (R0 array at offset 0, present
        // array after it, then pairwise, then the 3 scalars + pair count).
        //
        // Layout computed from libet_med.h:
        //   R0_seconds[10]    @ 0   (80 bytes)
        //   R0_present[10]    @ 80  (40 bytes)  [int * 10 = 40]
        //   pairwise[45]      @ 120
        //   et_elegance_t = 10*8 + 4*4 = 96... actually:
        //     r(8)+p(4)+q(4)+p_plus_q(4)+d(4)+pad(4)+eps(8)+sym(8)
        //     +tight(8)+simp(8)+eleg(8) = 64 bytes per elegance
        //   Let's verify: r(8) p(4) q(4) p_plus_q(4) d(4) eps_cents(8)
        //     symmetry(8) tightness(8) simplicity(8) elegance(8)
        //     = 8+4+4+4+4+8+8+8+8+8 = 64 bytes (doubles 8-aligned)
        //   pairwise = 45 * 64 = 2880 bytes  @ 120..3000
        //   multifold_scalar      @ 3000 (8)
        //   multifold_log_scalar  @ 3008 (8)
        //   multifold_normalized  @ 3016 (8)
        //   pair_count_valid      @ 3024 (4)
        //   end                    @ 3032, rounded to 3032 (8-aligned)
        const SIZE = 3032;
        const OFFSET_SCALAR     = 3000;
        const OFFSET_LOG_SCALAR = 3008;
        const OFFSET_NORMALIZED = 3016;
        const OFFSET_PAIRCOUNT  = 3024;

        const blPtr = this._zalloc(SIZEOF_PATIENT_BASELINE);
        const sigPtr = this._zalloc(SIZE);
        try {
            this._writePatientBaseline(blPtr, baseline);
            const code = this._computeMultifoldRaw(blPtr,
                                                   allowFallback ? 1 : 0,
                                                   sigPtr);
            if (code !== 0) throw new EtMedError(code, this.errorString(code));
            const H = this.M;
            const r0 = [];
            const pres = [];
            for (let i = 0; i < Tower.Count; ++i) {
                r0.push  (H.HEAPF64[(sigPtr + i * 8) >> 3]);
                pres.push(H.HEAP32 [(sigPtr + 80 + i * 4) >> 2] !== 0);
            }
            return {
                scalar:              H.HEAPF64[(sigPtr + OFFSET_SCALAR)     >> 3],
                logScalar:           H.HEAPF64[(sigPtr + OFFSET_LOG_SCALAR) >> 3],
                normalizedVsReference: H.HEAPF64[(sigPtr + OFFSET_NORMALIZED) >> 3],
                pairCountValid:      H.HEAP32 [(sigPtr + OFFSET_PAIRCOUNT) >> 2],
                R0Seconds:           r0,
                R0Present:            pres
            };
        } finally {
            this._free(sigPtr);
            this._free(blPtr);
        }
    }

    // et_measurement_t layout:
    //   name[64]             @ 0
    //   current_value(8)     @ 64
    //   baseline_value(8)    @ 72
    //   units[16]            @ 80
    //   tower(4)             @ 96
    //   resolution_override  @ 100
    //   timestamp(8)         @ 104
    //   end                  @ 112
    _writeMeasurement(ptr, m) {
        const H = this.M;
        this._measurementInit(ptr);
        if (m.name) H.stringToUTF8(m.name, ptr + 0, 64);
        H.HEAPF64[(ptr + 64) >> 3] = Number.isFinite(m.currentValue) ? m.currentValue : NaN;
        H.HEAPF64[(ptr + 72) >> 3] = Number.isFinite(m.baselineValue) ? m.baselineValue : NaN;
        if (m.units) H.stringToUTF8(m.units, ptr + 80, 16);
        H.HEAP32 [(ptr + 96) >> 2] = (m.tower|0);
        H.HEAP32 [(ptr + 100)>> 2] = (m.resolutionOverride|0);
        H.HEAPF64[(ptr + 104)>> 3] = Number.isFinite(m.timestampS) ? m.timestampS : 0;
    }

    generateFindings(measurements, baseline, allowFallback = true) {
        const SIZEOF_MEASUREMENT = 112;
        const n = measurements.length;
        const msPtr = this._zalloc(SIZEOF_MEASUREMENT * n);
        const blPtr = this._zalloc(SIZEOF_PATIENT_BASELINE);
        // out params
        const outPtrPtr = this._zalloc(4);  // pointer to int32
        const outCntPtr = this._zalloc(4);
        try {
            this._writePatientBaseline(blPtr, baseline);
            for (let i = 0; i < n; ++i) {
                this._writeMeasurement(msPtr + i * SIZEOF_MEASUREMENT, measurements[i]);
            }
            const code = this._generateFindingsRaw(
                msPtr, n, blPtr,
                allowFallback ? 1 : 0,
                outPtrPtr, outCntPtr
            );
            if (code !== 0) throw new EtMedError(code, this.errorString(code));

            const H = this.M;
            const findingsPtr = H.HEAPU32[outPtrPtr >> 2];
            const count       = H.HEAP32 [outCntPtr >> 2];
            const results = [];
            for (let i = 0; i < count; ++i) {
                results.push(this._readFinding(findingsPtr + i * SIZEOF_FINDING));
            }
            this._freeFindings(findingsPtr, count);
            return results;
        } finally {
            this._free(outCntPtr);
            this._free(outPtrPtr);
            this._free(blPtr);
            this._free(msPtr);
        }
    }

    patientBaseline(fields = {}) {
        const b = {
            hrRestBpm: NaN, rrRestPerMin: NaN, temperatureC: NaN,
            sbpRestMmHg: NaN, dbpRestMmHg: NaN, spo2Pct: NaN,
            gaitCycleS: NaN, menstrualCycleD: NaN, ageYears: NaN,
            sex: Sex.Unspecified
        };
        return Object.assign(b, fields);
    }

    measurement(fields = {}) {
        return Object.assign({
            name: "", currentValue: NaN, baselineValue: NaN,
            units: "", tower: Tower.Cardiac,
            resolutionOverride: 0, timestampS: 0
        }, fields);
    }
}

class EtMedError extends Error {
    constructor(code, msg) { super(`libet_med error ${code}: ${msg}`); this.code = code; }
}

// Expose to global / module.
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { EtMed, EtError, Tower, Sex, ManifoldState,
                       ManifoldStateName, IncoherenceLevel, IncoherenceLevelName,
                       TowerName, EtMedError };
}
if (typeof window !== 'undefined') {
    window.EtMed             = EtMed;
    window.EtMedEnums        = { EtError, Tower, Sex, ManifoldState,
                                 ManifoldStateName, IncoherenceLevel,
                                 IncoherenceLevelName, TowerName };
    window.EtMedError        = EtMedError;
}
