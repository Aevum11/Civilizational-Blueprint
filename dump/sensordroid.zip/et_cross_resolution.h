/*
 * ET LOSSLESS SENSOR CAPTURE — CROSS-RESOLUTION TRANSITION MAPS
 * ==============================================================
 * Finding 11: Exact algebraic identities for how the universal lattice
 * handles intersection boundaries where two coordinate charts meet.
 *
 * Three cases, all derived from the bijection (Theorem 19.4):
 *   Case 1: Same R₀, different N (cross-resolution): N₁ | N₂
 *   Case 2: Same N, different R₀ (cross-seed): ρ = R₀/R₀'
 *   Case 3: Both differ (full cross-tower): general transition
 *
 * Commutativity: (Seed ∘ Scale) = (Scale ∘ Seed) = Direct [VERIFIED]
 *
 * Application: When the tracker detects large |ε| at N=12 and
 * escalates to N=60, the Cross-Resolution Map computes the new
 * coordinates WITHOUT re-measuring the configuration. This
 * eliminates a measurement step from the sensor control loop.
 *
 * Author: Michael James Muller — Aevum Defluo (Exception Theory)
 * License: CC-BY-4.0
 */

#ifndef ET_CROSS_RESOLUTION_H
#define ET_CROSS_RESOLUTION_H

#include "et_bijection.h"

/*
 * Case 1: Cross-Resolution Transition (same R₀, N₁ | N₂).
 *
 * Given Π_N₁(r) = (k₁, d₁, ε₁), compute Π_N₂(r) = (k₂, d₂, ε₂)
 * without re-accessing r.
 *
 * M = N₂/N₁
 * δ₁ = ε₁·N₁/1200
 * k₂ = round(M·k₁ + M·δ₁)
 * ε₂ = (M·k₁ + M·δ₁ − k₂) · 1200/N₂
 * d₂ = N₂/gcd(|k₂|, N₂)
 */
et_error_t et_cross_resolution(long k1, int d1, const mpfr_t eps1,
                                int N1, int N2,
                                long *k2_out, int *d2_out, mpfr_t eps2_out,
                                mpfr_prec_t prec);

/*
 * Case 2: Cross-Seed Transition (same N, different R₀).
 *
 * ρ = R₀/R₀' (seed ratio).
 * Shifts the log₂ line by N·log₂(ρ).
 *
 * k₂ = round(k₁ + δ₁ + N·log₂(ρ))
 * ε₂ = (k₁ + δ₁ + N·log₂(ρ) − k₂) · 1200/N
 * d₂ = N/gcd(|k₂|, N)
 */
et_error_t et_cross_seed(long k1, int d1, const mpfr_t eps1,
                          int N, const char *rho_str,
                          long *k2_out, int *d2_out, mpfr_t eps2_out,
                          mpfr_prec_t prec);

/*
 * Case 3: Full Cross-Tower Transition (different N AND R₀).
 *
 * x = (k₁ + ε₁·N₁/1200) / N₁     (recover log₂(Q/R₀))
 * x' = x + log₂(R₀/R₀')            (shift to new seed)
 * k₂ = round(N₂ · x')
 * ε₂ = (N₂·x' − k₂) · 1200/N₂
 * d₂ = N₂/gcd(|k₂|, N₂)
 *
 * Factors as: (Seed ∘ Scale) = (Scale ∘ Seed) — commutative.
 */
et_error_t et_full_cross_tower(long k1, int d1, const mpfr_t eps1,
                                int N1, int N2, const char *rho_str,
                                long *k2_out, int *d2_out, mpfr_t eps2_out,
                                mpfr_prec_t prec);

#endif /* ET_CROSS_RESOLUTION_H */
