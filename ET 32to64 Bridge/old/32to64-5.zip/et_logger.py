"""
et_bridge/et_logger.py
ET32 Bridge — Structured Logger with ET Metrics and Error Integration

All log entries carry ET variance metadata.
V(E) = 0 in log entries means the operation completed as an Exception.

Updated to integrate with et_errors.ETErrorRegistry and ETOperationError:
  - Every error-level log also records in the global registry
  - ETLog.error_op() logs an ETOperationError with full formatting
  - ETLog.set_context() attaches persistent PID/family context to log entries
"""

import logging
import sys
import os
import time
import traceback
from typing import Optional, Any, Dict
from .et_math import V_BASE, K, S

# Custom log levels mapped to ET states:
#   DEBUG   → Mediation ({D,T}) — traversal in progress
#   INFO    → Exception ({P,D,T}) — grounded completion
#   WARNING → approaching ∂I (V approaching K=2/3)
#   ERROR   → Incoherence boundary ({P,T})
#   CRITICAL → Incoherence collapse

ET_LEVEL_MAP = {
    "DEBUG":    logging.DEBUG,
    "INFO":     logging.INFO,
    "WARNING":  logging.WARNING,
    "ERROR":    logging.ERROR,
    "CRITICAL": logging.CRITICAL,
}

_global_log_level: str  = "INFO"
_global_log_file:  Optional[str] = None


class ETLogFormatter(logging.Formatter):
    """
    Log formatter that includes ET variance, location, and ET state in each record.
    Format: [HH:MM:SS.mmm] [LEVL] [VS] [module] [file:func:line] message
    """

    def format(self, record: logging.LogRecord) -> str:
        variance = getattr(record, "et_variance", 0.0)
        state    = getattr(record, "et_state",    "")
        location = getattr(record, "et_location", "")
        pid_ctx  = getattr(record, "et_pid",      0)
        family   = getattr(record, "et_family",   0)

        # ET manifold state indicator
        if variance == 0.0:
            vs = "E"
        elif variance < V_BASE:
            vs = "M"
        elif variance < K:
            vs = "D"
        elif variance < 1.0:
            vs = "∂I"
        else:
            vs = "I"

        state_str = f"[{vs}]" if not state else f"[{vs}:{state}]"

        ts = time.strftime("%H:%M:%S", time.localtime(record.created))
        ms = int((record.created % 1) * 1000)

        # Build context suffix for ERROR+ levels
        ctx_parts = []
        if pid_ctx:
            ctx_parts.append(f"PID={pid_ctx}")
        if family:
            ctx_parts.append(f"d={family}")
        if location:
            ctx_parts.append(f"@ {location}")
        ctx = f" {{{', '.join(ctx_parts)}}}" if ctx_parts else ""

        return (
            f"[{ts}.{ms:03d}] "
            f"[{record.levelname[:4]}] "
            f"{state_str} "
            f"[{record.name}]{ctx} "
            f"{record.getMessage()}"
        )


def get_logger(name: str, level: str = "INFO",
               log_file: str = None) -> logging.Logger:
    """Create or retrieve an ET-structured logger."""
    logger = logging.getLogger(f"ET32Bridge.{name}")
    logger.setLevel(ET_LEVEL_MAP.get(level.upper(), logging.INFO))

    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(ETLogFormatter())
        logger.addHandler(handler)

        if log_file:
            fh = logging.FileHandler(log_file, encoding="utf-8")
            fh.setFormatter(ETLogFormatter())
            logger.addHandler(fh)

    return logger


class ETLog:
    """
    Convenience wrapper around the logger that:
    - Automatically attaches ET variance metadata
    - Accepts printf-style format strings (msg, *args) at all levels
    - Integrates with ETErrorRegistry for error-level entries
    - Captures exact source location for WARNING and above
    - Supports persistent context (pid, family) for structured log correlation

    Usage:
        log = ETLog.get("et_injector")
        log.info("Injecting PID %d (%s)", pid, exe_name)
        log.error("WriteProcessMemory failed", os_error=GetLastError(), et_pid=pid)
        log.error_op(some_et_operation_error)
    """

    _instances: Dict[str, "ETLog"] = {}
    _lock = __import__("threading").Lock()

    def __init__(self, name: str, level: str = None, log_file: str = None):
        lvl = level or _global_log_level
        self._logger  = get_logger(name, lvl, log_file or _global_log_file)
        self._name    = name
        # Persistent context set via set_context()
        self._pid:    int = 0
        self._family: int = 0

    @classmethod
    def get(cls, name: str) -> "ETLog":
        """Get or create a named ETLog instance (singleton per name)."""
        with cls._lock:
            if name not in cls._instances:
                cls._instances[name] = cls(name)
            return cls._instances[name]

    @classmethod
    def setup(cls, level: str = "INFO", log_file: str = None) -> None:
        """Configure global defaults for all ETLog instances."""
        global _global_log_level, _global_log_file
        _global_log_level = level
        _global_log_file  = log_file
        # Update all existing instances
        with cls._lock:
            for inst in cls._instances.values():
                inst._logger.setLevel(
                    ET_LEVEL_MAP.get(level.upper(), logging.INFO)
                )
                if log_file and not any(
                    isinstance(h, logging.FileHandler)
                    for h in inst._logger.handlers
                ):
                    fh = logging.FileHandler(log_file, encoding="utf-8")
                    fh.setFormatter(ETLogFormatter())
                    inst._logger.addHandler(fh)

    def set_context(self, pid: int = 0, family: int = 0) -> None:
        """Attach persistent PID/family context to all subsequent log entries."""
        self._pid    = pid
        self._family = family

    def _log(self, level: int, msg: str, args: tuple,
             variance: float = 0.0, state: str = "",
             location: str = "", et_pid: int = 0, et_family: int = 0) -> None:
        if args:
            try:
                msg = msg % args
            except Exception:
                msg = msg + " " + str(args)
        extra = {
            "et_variance": variance,
            "et_state":    state,
            "et_location": location,
            "et_pid":      et_pid or self._pid,
            "et_family":   et_family or self._family,
        }
        self._logger.log(level, msg, extra=extra)

    def _capture_location(self, depth: int = 3) -> str:
        """Capture caller location as 'file:func:line' string."""
        try:
            import sys
            frame = sys._getframe(depth)
            code  = frame.f_code
            short = os.path.basename(code.co_filename).replace(".py", "")
            return f"{short}.{code.co_name}:{frame.f_lineno}"
        except Exception:
            return ""

    # ----------------------------------------------------------------
    # PRIMARY LOG METHODS (all accept printf-style args)
    # ----------------------------------------------------------------

    def exception_state(self, msg: str, *args,
                        et_pid: int = 0, et_family: int = 0) -> None:
        """V=0, grounded Exception — operation completed correctly."""
        self._log(logging.INFO, msg, args, 0.0, "E",
                  et_pid=et_pid, et_family=et_family)

    def mediation(self, msg: str, *args,
                  variance: float = None,
                  et_pid: int = 0, et_family: int = 0) -> None:
        """Active traversal — V=V_BASE/2, Mediation state."""
        v = variance if variance is not None else V_BASE / 2
        self._log(logging.DEBUG, msg, args, v, "M",
                  et_pid=et_pid, et_family=et_family)

    def warning_di(self, msg: str, *args,
                   et_pid: int = 0, et_family: int = 0) -> None:
        """Approaching Incoherence boundary — V=K."""
        loc = self._capture_location()
        self._log(logging.WARNING, msg, args, K, "∂I", loc,
                  et_pid=et_pid, et_family=et_family)

    def incoherence(self, msg: str, *args,
                    et_pid: int = 0, et_family: int = 0) -> None:
        """Incoherent state — V=1.0, bridge failure."""
        loc = self._capture_location()
        self._log(logging.ERROR, msg, args, 1.0, "I", loc,
                  et_pid=et_pid, et_family=et_family)
        self._record_to_registry(msg, args, 1.0, et_pid, et_family)

    def info(self, msg: str, *args,
             variance: float = 0.0,
             et_pid: int = 0, et_family: int = 0) -> None:
        self._log(logging.INFO, msg, args, variance,
                  et_pid=et_pid, et_family=et_family)

    def debug(self, msg: str, *args,
              variance: float = 0.0,
              et_pid: int = 0, et_family: int = 0) -> None:
        self._log(logging.DEBUG, msg, args, variance,
                  et_pid=et_pid, et_family=et_family)

    def warning(self, msg: str, *args,
                et_pid: int = 0, et_family: int = 0) -> None:
        loc = self._capture_location()
        self._log(logging.WARNING, msg, args, K, "∂I", loc,
                  et_pid=et_pid, et_family=et_family)

    def error(self, msg: str, *args,
              variance: float = 1.0,
              et_pid: int = 0, et_family: int = 0,
              os_error: int = 0) -> None:
        """Log an error with location capture and registry recording."""
        loc = self._capture_location()
        full_msg = msg
        if os_error:
            try:
                import ctypes
                buf = ctypes.create_unicode_buffer(256)
                ctypes.windll.kernel32.FormatMessageW(
                    0x1000, None, os_error, 0, buf, 256, None
                )
                os_msg = buf.value.strip()
                full_msg = f"{msg} [OS: {os_msg} (0x{os_error:08X})]"
            except Exception:
                full_msg = f"{msg} [OS error: 0x{os_error:08X}]"
        self._log(logging.ERROR, full_msg, args, variance, "I", loc,
                  et_pid=et_pid, et_family=et_family)
        self._record_to_registry(full_msg, args, variance, et_pid, et_family)

    def critical(self, msg: str, *args,
                 et_pid: int = 0, et_family: int = 0) -> None:
        loc = self._capture_location()
        self._log(logging.CRITICAL, msg, args, 1.0, "COLLAPSE", loc,
                  et_pid=et_pid, et_family=et_family)
        self._record_to_registry(msg, args, 1.0, et_pid, et_family)

    def error_op(self, error: "ETOperationError") -> None:
        """
        Log a fully-formed ETOperationError.
        Includes every field: location, OS error, ET state, cause chain.
        Also records in the global error registry.
        """
        try:
            from .et_errors import ETErrorSeverity, record_error
            level = error.severity.python_log_level
            extra = {
                "et_variance": error.variance,
                "et_state":    error.severity.name,
                "et_location": str(error.location),
                "et_pid":      error.et_pid,
                "et_family":   error.et_family,
            }
            self._logger.log(level, str(error), extra=extra)
            record_error(error)
        except ImportError:
            self._log(logging.ERROR, str(error), (), 1.0, "E")

    def exc(self, msg: str, *args,
            et_pid: int = 0, et_family: int = 0) -> None:
        """
        Log the current exception with full traceback.
        Call inside an except block.
        """
        import traceback
        tb_str = traceback.format_exc()
        loc    = self._capture_location()
        full   = f"{msg} — Exception:\n{tb_str}" if not args else \
                 f"{msg % args} — Exception:\n{tb_str}"
        self._log(logging.ERROR, full, (), 1.0, "I", loc,
                  et_pid=et_pid, et_family=et_family)
        self._record_to_registry(full, (), 1.0, et_pid, et_family)

    # ----------------------------------------------------------------
    # INTERNAL
    # ----------------------------------------------------------------

    def _record_to_registry(self, msg: str, args: tuple,
                             variance: float,
                             et_pid: int, et_family: int) -> None:
        """Record error-level events in the global ETErrorRegistry."""
        try:
            from .et_errors import ETOperationError, ETErrorSeverity, record_error
            if variance >= K:
                sev = ETErrorSeverity.INCOHERENT if variance >= 1.0 else ETErrorSeverity.BOUNDARY
                err = ETOperationError(
                    msg % args if args else msg,
                    severity  = sev,
                    et_pid    = et_pid or self._pid,
                    et_family = et_family or self._family,
                    depth     = 4,
                )
                record_error(err)
        except Exception:
            pass  # registry failure must never break logging
