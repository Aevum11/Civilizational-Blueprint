"""
et32_bridge_main.py
ET32 Bridge — Main Entry Point (64-bit Broker)

Derived from P ∘ D ∘ T = E.

This is the top-level P∘D∘T instantiation of the entire bridge:
  P = this operating system process (the 64-bit broker)
  D = the loaded ETBridgeConfig (Descriptor set of all target processes)
  T = this main thread + all spawned workers (the Traverser)
  E = the running bridge (full Exception state — V(E) = 0 while operational)

Startup sequence (ET-grounded):
  1. Parse arguments — determine config path
  2. Load ETBridgeConfig — instantiate D
  3. Start ETBridgeAPI — starts IPC server (creates P-channel)
  4. Start ETProcessMonitor — T begins scanning
  5. Enter main loop — bridge is active
  6. On config change — hot-reload D without stopping T
  7. On CTRL+C / signal — graceful shutdown (Subsumption Law completion check)

Usage:
  ET32_Bridge.exe [--config path\to\config.json] [--log-level DEBUG|INFO|WARNING]
  
  Default config path: ET32_Bridge_config.json (alongside the executable).

  If --no-tray is NOT passed (default), a system tray icon is created showing
  bridge status. Pass --no-tray to run as a pure console/background process.

ET Stability reporting:
  The main loop logs bridge stability (K_eff) every S² = 144 seconds.
  If K_eff < K (2/3), a WARNING is emitted — approaching ∂I.
  If K_eff < V_BASE (1/12), an INCOHERENCE event is emitted.

Compilation to EXE:
  Use et32_bridge.spec with PyInstaller (64-bit Python required):
    pyinstaller et32_bridge.spec
"""

import argparse
import os
import sys
import time
import signal
import threading
import ctypes
import json
from pathlib import Path
from typing import Optional

# Ensure the package is importable when running as frozen EXE
if getattr(sys, "frozen", False):
    _base = sys._MEIPASS
    sys.path.insert(0, _base)
    os.chdir(os.path.dirname(sys.executable))

from et_bridge import (
    ETBridgeConfig, ETBridgeAPI, ETProcessMonitor, ETLog,
    S, K, V_BASE, QUEUE_DEPTH, CONN_TIMEOUT_MS
)

# ============================================================================
# STARTUP BANNER
# ============================================================================

_BANNER = r"""
╔══════════════════════════════════════════════════════════════════╗
║             ET32 Bridge — Exception Theory 64-bit Broker         ║
║                  P ∘ D ∘ T = E  (v1.0.0)                        ║
║          S=12  K=2/3  V=1/12  ħ_d=4096  IPC=49152B              ║
╚══════════════════════════════════════════════════════════════════╝
"""

# ============================================================================
# ARGUMENT PARSING
# ============================================================================

def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog        = "ET32_Bridge",
        description = "ET32 Bridge: 32-bit → 64-bit capability extension broker.",
        formatter_class = argparse.RawDescriptionHelpFormatter,
        epilog      = "Derived from Exception Theory (P∘D∘T=E). All constants from first principles."
    )
    parser.add_argument(
        "--config", "-c",
        default = None,
        help    = "Path to et32_bridge_config.json (default: alongside executable)"
    )
    parser.add_argument(
        "--log-level", "-l",
        default = "INFO",
        choices = ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"],
        help    = "Logging level (default: INFO)"
    )
    parser.add_argument(
        "--log-file", "-f",
        default = None,
        help    = "Path to log file (default: ET32_Bridge.log alongside executable)"
    )
    parser.add_argument(
        "--no-tray",
        action  = "store_true",
        default = False,
        help    = "Suppress system tray icon (run as background/console process)"
    )
    parser.add_argument(
        "--generate-config", "-g",
        action  = "store_true",
        default = False,
        help    = "Generate a default config file and exit"
    )
    parser.add_argument(
        "--status",
        action  = "store_true",
        default = False,
        help    = "Print current bridge status and exit (if another instance is running)"
    )
    return parser.parse_args()


# ============================================================================
# LOCATE CONFIG FILE
# ============================================================================

def _resolve_config_path(explicit: Optional[str]) -> Path:
    """
    Resolve the config file path.
    Order: explicit arg → beside executable → beside script → CWD.
    """
    if explicit:
        p = Path(explicit)
        if p.exists():
            return p
        raise FileNotFoundError(f"Config not found: {explicit}")

    candidates = [
        Path(sys.executable).parent / "et32_bridge_config.json",
        Path(__file__).parent / "et32_bridge_config.json",
        Path.cwd() / "et32_bridge_config.json",
    ]
    for c in candidates:
        if c.exists():
            return c

    # Return the first candidate as the default (will be created if --generate-config)
    return candidates[0]


# ============================================================================
# GENERATE DEFAULT CONFIG
# ============================================================================

def _generate_default_config(path: Path) -> None:
    """
    Generate a default config file with example targets.
    ET Descriptors pre-filled with all lattice positions enabled.
    """
    ETBridgeConfig.generate_default(str(path))
    print(f"Default config generated: {path}")
    print("Edit the 'targets' array to list your 32-bit executables.")
    print("Then run ET32_Bridge.exe without --generate-config to start the bridge.")


# ============================================================================
# SYSTEM TRAY (optional — requires pystray + Pillow)
# ============================================================================

def _try_start_tray(bridge_api: ETBridgeAPI, stop_callback):
    """
    Attempt to start a system tray icon showing bridge status.
    Silently skipped if pystray or PIL are not available.

    The tray icon shows:
      - Tooltip: "ET32 Bridge — K=x.xx" (Koide alignment)
      - Menu: Status | Reload Config | Stop Bridge

    ET derivation: the tray is a T-interface — it gives the user a traversal
    point into the bridge's Descriptor state without modifying P or D.
    """
    try:
        import pystray
        from PIL import Image, ImageDraw

        # Draw a simple icon: 32×32 teal circle with "ET" text
        # Colour derived from ET: RGB = (S*S, S*V*255, K*255) = (144, 21, 170) → purple
        def _make_icon_image():
            img  = Image.new("RGBA", (32, 32), (0, 0, 0, 0))
            draw = ImageDraw.Draw(img)
            draw.ellipse([2, 2, 30, 30], fill=(90, 50, 180, 255))
            draw.text((7, 10), "ET", fill=(255, 255, 255, 255))
            return img

        def _status_action(icon, item):
            report = bridge_api.status_report()
            # Show in console (tray icon is silent in most contexts)
            print(json.dumps(report, indent=2))

        def _reload_action(icon, item):
            bridge_api.reload_config()
            print("Config reloaded.")

        def _stop_action(icon, item):
            icon.stop()
            stop_callback()

        icon = pystray.Icon(
            name  = "ET32Bridge",
            icon  = _make_icon_image(),
            title = "ET32 Bridge",
            menu  = pystray.Menu(
                pystray.MenuItem("Status",        _status_action),
                pystray.MenuItem("Reload Config", _reload_action),
                pystray.MenuItem("Stop Bridge",   _stop_action),
            )
        )

        def _tray_thread():
            icon.run()

        t = threading.Thread(target=_tray_thread, name="ET_TrayIcon", daemon=True)
        t.start()
        return icon
    except ImportError:
        return None  # pystray/PIL not available — no tray


# ============================================================================
# MAIN LOOP
# ============================================================================

def _main_loop(
    bridge_api:  ETBridgeAPI,
    monitor:     ETProcessMonitor,
    config:      ETBridgeConfig,
    log:         "ETLog"
) -> None:
    """
    Main event loop for the broker process.

    Runs until bridge_api.request_stop() is called.

    Periodic tasks (ET-timed):
      Every S   = 12 s : update tray tooltip, check config hash
      Every S²  = 144 s: log stability report
      Every S×K = 8 s  : Koide-threshold health check (2/3 × 12 ≈ 8s)
    """
    last_stability_log = time.monotonic()
    last_config_check  = time.monotonic()
    last_health_check  = time.monotonic()

    STABILITY_INTERVAL = float(S * S)    # 144 s
    CONFIG_INTERVAL    = float(S)        # 12 s
    HEALTH_INTERVAL    = S * K           # 8 s

    log.info("Main loop started. Bridge is active.")
    log.info(
        "Watching for: %s",
        ", ".join(t.exe_name for t in config.targets) if config.targets else "(no targets)"
    )

    while bridge_api.is_running:
        now = time.monotonic()

        # --- Stability report every S² seconds ---
        if now - last_stability_log >= STABILITY_INTERVAL:
            k_eff = bridge_api.stability
            state = "EXCEPTION" if k_eff >= 1.0 - V_BASE else (
                    "MEDIATION" if k_eff >= K else
                    "WARNING"   if k_eff >= V_BASE else
                    "INCOHERENCE"
            )
            log.info(
                "Stability report: K_eff=%.4f [%s] | active_targets=%d",
                k_eff,
                state,
                len(monitor.active_pids())
            )
            last_stability_log = now

        # --- Config file change check every S seconds ---
        if now - last_config_check >= CONFIG_INTERVAL:
            if config.has_changed():
                log.info("Config file changed — reloading...")
                new_cfg = ETBridgeConfig.load(config.config_path)
                if new_cfg:
                    config.apply(new_cfg)
                    bridge_api.reload_config()
                    monitor.update_targets(config.targets)
            last_config_check = now

        # --- Health check every S×K ≈ 8 seconds ---
        if now - last_health_check >= HEALTH_INTERVAL:
            k_eff = bridge_api.stability
            if k_eff < V_BASE:
                log.incoherence(
                    "Bridge variance CRITICAL: K_eff=%.4f < V_BASE=%.4f",
                    k_eff, V_BASE
                )
            elif k_eff < K:
                log.warning_di(
                    "Bridge approaching ∂I: K_eff=%.4f < K=%.4f",
                    k_eff, K
                )
            last_health_check = now

        # Sleep in CONN_TIMEOUT_MS / S chunks so we can respond quickly to stop events
        bridge_api._stop_event.wait(timeout=CONN_TIMEOUT_MS / 1000.0 / S)

    log.info("Main loop exiting.")


# ============================================================================
# ENTRY POINT
# ============================================================================

def main() -> int:
    """
    Main entry point.
    Returns exit code: 0 = clean shutdown, 1 = startup error.
    """
    args = _parse_args()

    # --- Initialise logging (FIRST action — before anything that can fail) ---
    # resolve_log_path() handles exe-relative default; ETLog.setup() installs:
    #   - sys.excepthook       (unhandled Python exceptions → log file)
    #   - faulthandler         (C-level crashes / segfaults → log file)
    #   - atexit               (final flush + error registry summary on exit)
    #   - Windows SEH filter   (DLL crashes → log file)
    # The log file is open and flushed before main() proceeds further.
    from et_bridge.et_logger import resolve_log_path
    log_file = resolve_log_path(args.log_file)
    ETLog.setup(level=args.log_level, log_file=log_file)
    log = ETLog.get("et32_bridge_main")

    log.info("ET32 Bridge starting — log: %s", log_file)
    print(_BANNER)
    print(f"  Log file: {log_file}")

    # --- Generate config and exit if requested ---
    if args.generate_config:
        try:
            config_path = _resolve_config_path(args.config) if args.config else \
                          Path(sys.executable).parent / "et32_bridge_config.json" \
                          if getattr(sys, "frozen", False) else \
                          Path.cwd() / "et32_bridge_config.json"
            _generate_default_config(config_path)
            return 0
        except Exception as exc:
            print(f"Error generating config: {exc}")
            return 1

    # --- Load config ---
    try:
        config_path = _resolve_config_path(args.config)
    except FileNotFoundError as exc:
        log.error(str(exc))
        print(f"\nError: {exc}")
        print("Run with --generate-config to create a default configuration.")
        return 1

    log.info("Loading config: %s", config_path)
    config = ETBridgeConfig.load(str(config_path))
    if config is None:
        log.incoherence("Failed to load config from %s", config_path)
        print(f"\nError: Failed to load config from {config_path}")
        return 1

    log.info("Config loaded: %d target(s)", len(config.targets))
    for t in config.targets:
        log.info("  Target: %s (inject_mode=%s)", t.exe_name, t.inject_mode)

    # If config specifies a different log path, switch to it now
    if config.log_file and resolve_log_path(config.log_file) != log_file:
        new_log_path = resolve_log_path(config.log_file)
        log.info("Switching log file to config-specified path: %s", new_log_path)
        ETLog.setup(level=config.log_level, log_file=new_log_path)
        log = ETLog.get("et32_bridge_main")
        log.info("Log resumed at new path: %s", new_log_path)

    # --- Initialise bridge API ---
    bridge_api = ETBridgeAPI(config)
    if not bridge_api.start():
        log.incoherence("Bridge API failed to start")
        print("\nError: Bridge API failed to start (see log for details).")
        return 1

    # --- Register signal handlers ---
    def _signal_handler(signum, frame):
        log.info("Signal %d received — requesting shutdown", signum)
        bridge_api.request_stop()

    signal.signal(signal.SIGINT,  _signal_handler)
    signal.signal(signal.SIGTERM, _signal_handler)

    # --- Start process monitor ---
    monitor = ETProcessMonitor(
        config         = config,
        on_found       = bridge_api.on_process_found,
        on_exit        = bridge_api.on_process_exit,
    )
    monitor.start()
    log.info("Process monitor started: polling every %ds", S)

    # --- System tray (if not suppressed) ---
    tray_icon = None
    if not args.no_tray:
        tray_icon = _try_start_tray(bridge_api, bridge_api.request_stop)
        if tray_icon:
            log.info("System tray icon active")
        else:
            log.mediation("System tray not available (pystray/PIL missing) — running headless")

    log.info("ET32 Bridge is active. Press CTRL+C to stop.")

    # --- Main loop ---
    try:
        _main_loop(bridge_api, monitor, config, log)
    except KeyboardInterrupt:
        log.info("KeyboardInterrupt received")
        bridge_api.request_stop()

    # --- Shutdown sequence ---
    log.info("Shutting down ET32 Bridge...")

    if tray_icon:
        try:
            tray_icon.stop()
        except Exception:
            pass

    monitor.stop()
    bridge_api.stop()

    log.info("ET32 Bridge stopped cleanly. P∘D∘T = E → complete.")
    print("\nET32 Bridge stopped.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
