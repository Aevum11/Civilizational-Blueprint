# THE RITAIST CANON — GAPS AND ISSUES REGISTER

**Working Document III of the Ritaist Canon**
**Companion to:** *RITAISM — Volume I* and *PERATOCRACY — Volume II* (Canonical Edition 1.1)
**Status:** OPEN — items herein must be resolved and confirmed before the Canon is declared complete and the two volumes are recombined into the single founding book.
**Prepared for:** Michael James Muller — Aevum Defluo

---

## 0. METHOD

This register was produced by applying the Three Tools of Exception Theory to the complete Ritaist corpus (the unified master document, the two prior split documents, changelog v1.1, and the Eternal Memory cross-project document — all read in full).

**Identification Principle.** P = the social substrate the Canon governs (the space of possible civilizational configurations); D = the Canon's descriptor set (the Freedom Line as the single péras, plus every derived institutional constraint — layers, caps, veto, court, locks); T = the agents who navigate it (individuals, guilds, the public, and the automated System as instrumented evidence-provider). The Canon's own stated method — "converts philosophical disputes into empirical questions" — is the Descriptor Gap Principle operating in the political domain: every dispute is treated as a measurement problem awaiting the right descriptors.

**Descriptor Gap Principle.** Every entry in Sections B and C below is a D_missing: a place where the Canon's model of governance is under-described, so that either two canonical statements collide (Section B) or a required mechanism has no specification (Section C). Per the Gap Principle, each gap is itself the pointer to its own resolution; candidate resolutions are drawn from the Canon's own principles, never ad hoc.

**Subsumption Law.** The separation into two volumes was executed to zero remainder — every block of source content is accounted for (Section F, Verification Record). The Canon as an *ideology*, however, does not yet subsume its own domain without remainder: the entries below are the remainder. When every entry is closed and the Verification Principle is satisfied (no internal inconsistency remains), the Canon is complete and the single book may be assembled per the Canon Map's recombination rule.

Priority key: **P1** — load-bearing; the Canon's central claims depend on closing it. **P2** — required for implementation completeness. **P3** — required for editorial/formal completeness.

**Second sweep (this revision).** After the first register was compiled, a deeper hunt was executed: a domain × lifecycle × adversarial-actor matrix (persons from birth to death; items from creation to disposal; guilds from founding to dissolution; the system from activation to amendment; and, for each, the bad-faith actor trying to exploit it), verified against the canon by a forty-topic keyword battery over both volumes with nearest-header attribution, followed by full reads of §§6.3, 7.3, 11.3–11.5, 13.6, 14.4, 17.3, 19.1 and 22.3 so that every partial coverage is characterized from text, not memory (log: `SWEEP_VERIFICATION.txt`). Claims the sweep disproved were withdrawn before writing — notably, self-defense is canonically stated (14.1), stalking and post-rejection harassment are classified (9.2), altruism has its merit channel (17.3), and guild mediation is the named dispute path (13.6). Everything below survived verification. The additions appear as B-15 – B-20 and C-33 – C-71; existing identifiers are stable and unchanged.

---

## A. EDITORIAL AND STRUCTURAL ISSUES — FOUND AND ACTIONED

These were defects in the source corpus discovered during the full read. Each lists the action taken in the Canonical Edition 1.1 assembly. All actions are logged in the machine verification record and await confirmation.

**A-1. Chapter 30 (Conclusion) lost by the prior split. [ACTIONED]** The prior two-document split contained Parts I–IX and the partitioned Chapter 29, but Chapter 30 — the Conclusion of the entire ideology — appeared in neither document. Restored in full to Volume I, Part X. Volume II received a newly written, governance-scoped "Conclusion of the Governmental Volume" so that it also closes properly; it explicitly defers to Chapter 30 as canonical.

**A-2. Broken numbering in the prior split. [ACTIONED]** The prior Ritaism document ran Part I directly into Part IV; the prior Peratocracy document *began* at Part II. Resolved by the canonical continuous-numbering design: both volumes carry the shared Chapters 1–30 / Parts I–X structure, documented in the Canon Map (Appendix D of both volumes), which also gives the recombination rule for the single book.

**A-3. Changelog v1.1 integrated nowhere. [ACTIONED]** None of the fifteen v1.1 refinements had been integrated into either prior document. All fifteen are now integrated at their specified locations with their specified semantics: ⊕ additions (1.3.1, 2.5, 3.9, 4.7, 5.6, 6.1.2, 8.10, 13.7.1, 15.1.1, 19.6, Appendix B) and ⟳ replace/expand operations (4.4 replaced per the changelog's explicit instruction; 13.10, 21.1, 26.3 expanded with full retention — see A-4). The changelog document is hereby **superseded by integration** and should be archived, not further edited.

**A-4. Expand-semantics retention. [ACTIONED]** Rule of assembly: an "expand" never loses source content. ⟳13.10 retains **both** original blocks verbatim beneath the revised exceptions doctrine — the care-requirement block ("For those with disabilities or mental illness that may cause uncontrollable harm") and the "Possessions as Extension of Self" block; the care block's retention was mandated by the zero-loss audit (Section F), which found the revised doctrine restates it in new words only. ⟳21.1 retains the original epigraph ("It emerges just fine from the modern world…") above the elaborated argument; ⟳26.3 retains the original Option 1/Option 2 elaborations (including the transcendence pathway list) ahead of the full-spectrum framing. The one true replacement, ⟳4.4, was explicit in the changelog; the superseded passage is preserved **verbatim** in the Annex to this register, with an evidence-based map of where each of its ideas survives in canon.

**A-5. Chapter 10 mojibake. [ACTIONED]** The master document reads "taxonomic categoriesblacksmith" (lost em-dash) in §10.5.3; the prior Peratocracy split carries the corrected "categories—blacksmith". The corrected text was adopted as canonical for Chapter 10.

**A-6. Chapter 23 broken subject. [ACTIONED]** §23.1 opened "I is a phenomenological knowledge organization system…" — a residue of an earlier find-and-replace. Corrected to "Eternal Memory is a phenomenological knowledge organization system…"; the following sentence "The name of it is Eternal Memory." was retained unchanged.

**A-7. Duplicated, unscoped front matter in the prior split. [ACTIONED]** Both prior documents carried the identical Preamble verbatim — duplication, not separation. The full Preamble is now canonical to Volume I; Volume II carries a scoped Preamble to the Governmental Volume plus a new "Constitutional Foundation" section that states the Freedom Line and its empirical application so Volume II stands complete, with citation to Volume I for the derivation.

**A-8. Knowledge System stranded. [ACTIONED]** Part VI existed only in the cross-project document; neither prior volume referenced it. Part VI (Chapters 23–24) is now homed in Volume II with the "Knowledge infrastructure" bullet restored to the Integration Points appendix; both volumes' Linkage appendices carry the Eternal Memory integration summary; the standalone cross-project document remains the bridge artifact to the Eternal Memory project.

**A-9. Colophon asymmetry. [ACTIONED]** Each prior document's closing kept only its own name-line. Both volumes now close with the master's dual colophon ("RITAISM: The Philosophy of Natural Order" / "PERATOCRACY: Governance Through the Correct Limit"), the blessing, and the founding-document tagline — the shared seal of one canon.

**A-10. Missing formal apparatus. [ACTIONED]** Neither prior document had an abstract, table of contents, or conclusion. Both volumes now carry: title block with edition line, Abstract, Two-Volume Canon note, generated Table of Contents, Appendices A–D (Key Principles partition; Direct Statements — full in Vol. I, indexed in Vol. II; Companion Linkage; Canon Map), and proper closings.

**A-11. "EMP" naming. [OPEN — see C-30.]** §24.1 uses "EMP categories" while the system is named "Eternal Memory" and "The Knowledge System." Because "EMP" may be an intentional acronym (Eternal Memory Project), it was left untouched pending a canonical naming ruling.

---

## B. INTERNAL TENSIONS — TWO CANONICAL STATEMENTS IN COLLISION

Each entry is a Descriptor conflict: both statements are canon, and a missing higher Descriptor must adjudicate them. Candidate resolutions are drawn from the Canon's own principles.

**B-1. Merit permanence vs. "Merit reduced." [P1]**
*Locations:* Ch. 6.3 ("No confiscation, no forfeiture, **no reduction** as punishment… Merit once earned remains permanently") vs. Ch. 8.7 ("Poor design → **Merit reduced**"); cf. Ch. 8.3 "Oversupply penalty."
*The gap:* whether "reduced" ever touches earned holdings.
*Candidates:* (i) Canonical clarification that all "reduction" language is **forward-looking valuation only** — future units of that item earn less merit; holdings are never touched (consistent with the Loophole Philosophy's "no retroactive punishment"); (ii) restrict 8.7's consequence to reputation plus reduced *future* per-unit award, and reword 8.7 accordingly.
*Recommended:* (i)+(ii) jointly; one sentence added to 6.3 and one reword in 8.7 closes it.

**B-2. Single Certification Rule vs. cross-guild joint certification. [P1]**
*Locations:* Ch. 8.5 ("Item can only be certified by ONE guild authority at a time. No stacking.") vs. Ch. 10.12 ("Both must agree on final certification (mutual veto between guilds)") for items inhabiting multiple conceptual domains (the prosthetics case).
*The gap:* the certification cardinality for multi-domain items.
*Candidates:* (i) Define a **joint certification instrument**: for an item inhabiting N conceptual domains, the certification is a single instrument requiring the signature of one elected authority per involved guild — "one certification" with N signatories, preserving both no-stacking and mutual veto; (ii) per-domain certifications, each singular within its domain, with the item's overall status the conjunction.
*Recommended:* (i) — it preserves 8.5's accountability pairing ("both reputations on the line") extended to all signatories, and 10.12's veto.

**B-3. Handmade total liability transfer vs. criminal negligence. [P1]**
*Locations:* Ch. 8.7 ("Handmade… Buyer assumes ALL liability… No exchange for 'defects'") vs. Ch. 13.2 ("Negligent harm crossing Freedom Line is criminal negligence"). Deliberate unsafety is already fraud (8.7); the collision is *negligent-but-not-deliberate* handmade harm.
*The gap:* whether the handmade disclaimer extinguishes criminal exposure.
*Candidates:* (i) Canonical rule: the handmade transfer extinguishes all **quality claims** (variation, imperfection, fitness) but never Freedom Line exposure — where a traced causal chain shows harm from negligence a reasonable craftsman would not commit, Chapter 13 applies; the disclaimer allocates commercial risk, not the Line; (ii) tiered: disclosed-risk categories (knives are sharp) vs. latent-hazard negligence, only the latter criminal.
*Recommended:* (i), with (ii)'s disclosed-risk language as the evidentiary guide inside causal forensics.

**B-4. "Basic healthcare" vs. the bifurcated healthcare system. [P1]**
*Locations:* Ch. 6.2 (baseline includes "Basic healthcare for illness and injury") vs. Ch. 19.2 ("Lifesaving care: free… Non-lifesaving care: market-priced").
*The gap:* whether "basic" ≡ "lifesaving," and where preventive care, chronic-condition management, mental-health care, and palliative care fall.
*Candidates:* (i) Canonical set-definition: **Baseline care = lifesaving + life-preserving + capacity-restoring to baseline function**, enumerated by the Medical Guild under mutual veto, with everything else market-layer; (ii) two-term harmonization: retain "basic" as the baseline term and define 19.2's "lifesaving" as its core, with a published guild-maintained schedule.
*Recommended:* (i); the schedule mechanism reuses the resource-cap pattern (empirical inventory, dynamic adjustment).

**B-5. Death penalty vs. retrial-with-new-evidence. [P1]**
*Locations:* Ch. 13.7 ("Severe violations forfeit ultimate freedom… Death penalty supported") vs. Ch. 13.9 ("Double jeopardy abolished — can retry with new evidence").
*The gap:* retrial symmetry breaks for irreversible punishment; new exculpatory evidence after execution cannot be remedied.
*Candidates:* (i) An **irreversibility threshold**: irreversible punishments require an evidentiary standard strictly above ordinary beyond-reasonable-doubt-with-technological-verification (e.g., complete-chain verification with zero unexplained variance), plus a mandatory review interval before execution; (ii) restrict the death penalty to cases where the perpetrator's identity and act are technologically verified beyond any competing hypothesis.
*Recommended:* (i) with (ii) as its operational content; this is the Verification Principle applied to justice — irreversible action only at model-error zero.

**B-6. Founder grant conditionality vs. No Merit Loss. [P2]**
*Locations:* Ch. 22.4 ("1,000-year merit contingent on completing transfer") vs. Ch. 6.3 permanence.
*The gap:* a conditional grant superficially resembles forfeiture.
*Candidate/Recommended:* Canonical sentence: the Founder grant **vests only upon completed transfer**; before vesting nothing has been earned, so nothing is lost — conditionality of vesting, never confiscation of holdings. One sentence in 22.4 closes it.

**B-7. Non-lifesaving care "funds" lifesaving care vs. zero-merit organizations and spread destruction. [P2]**
*Locations:* Ch. 19.2 ("market-priced to fund lifesaving services") vs. Ch. 8.2–8.4 (System destroys the spread; no organization holds merit; no treasuries exist).
*The gap:* in a spread-destroying, treasury-free economy, "funding" cannot mean revenue transfer.
*Candidates:* (i) Redefine canonically: the differential pricing is a **resource-priority mechanism** — non-lifesaving demand signals allocate automation capacity, while lifesaving provision is a first-priority claim on automation surplus (consistent with 8.9 Priority Allocation); (ii) permit an earmarked System spread-differential on non-lifesaving care whose destruction is offset by increased lifesaving resource allocation.
*Recommended:* (i); it requires no new economic object and reuses Priority Allocation verbatim.

**B-8. Public shaming lists vs. "reputation is social, not legal." [P3]**
*Locations:* Ch. 13.9 vs. Ch. 9.3.
*The gap:* a state-published reputational sanction alongside the doctrine that reputation is outside law.
*Candidate/Recommended:* Clarify: 9.3 bars **civil protection of** reputation; 13.9's lists are punishment-phase transparency for adjudicated Line-crossers — the state may publish verdicts, it may not adjudicate reputations. One clarifying sentence in each chapter.

**B-9. Caps "apply equally to all individuals" vs. corporate consumption caps. [P1]**
*Locations:* Ch. 6.4 vs. Ch. 12.5 ("Resource caps apply to corporate consumption") with Ch. 8.4 (organizations hold zero merit).
*The gap:* corporations are not individuals; the object that is capped, and its size, are undefined.
*Candidates:* (i) **Operational allocations**: collective entities receive guild-granted, publicly recorded resource allocations sized by function under the mutual-veto process — distinct in kind from individual caps and fully transparent per Ch. 11; (ii) pass-through: corporate consumption is attributed pro-rata to responsible individuals' caps.
*Recommended:* (i); (ii) collapses under scale and would make employment consume personal caps.

**B-10. Cap-crossing = Line-crossing vs. dynamic cap adjustment. [P2]**
*Locations:* Ch. 6.4 ("Crossing cap = crossing Freedom Line = harsh punishment" and "Dynamic adjustment").
*The gap:* when a cap tightens below existing lawful holdings, holders become instant violators.
*Candidate/Recommended:* Prospective rule mirroring the Loophole Philosophy: cap changes bind **acquisition going forward**; over-cap legacy holdings are frozen (no further acquisition, lawful retention or divestment window), never retroactively criminal. This is 6.6's "forward-looking adaptation only" applied to caps.

**B-11. Outlet efficacy asserted vs. efficacy admitted unknown. [P2]**
*Locations:* Ch. 16.3 ("Real violence reduced through virtual outlet") vs. Ch. 16.4 ("There is no evidence that virtual violence makes real violence easier or harder. We aim to develop the technology and gather the evidence.").
*The gap:* an asserted effect and an admitted unknown.
*Candidate/Recommended:* Reword 16.3's claim as **design hypothesis under test** — "outlet plus certain punishment is designed to reduce real violence; the outlet program is itself the experiment (16.4)" — preserving the honest epistemic stance that is one of the Canon's strengths.

**B-12. Temporal boundary vs. millennium-scale commitments. [P3]**
*Locations:* Ch. 5 (obligations end beyond the overlap chain) vs. Ch. 22 (1,000-year Founder merit), Ch. 23–24 ("eternally").
*The gap:* apparent inconsistency between bounded moral obligation and unbounded institutional commitments.
*Candidate/Recommended:* State canonically: Chapter 5 bounds **moral obligations of persons**; system rules and institutional commitments are Descriptors of the architecture and may persist indefinitely — the living are always free, via the mutual-veto process, to amend them. Institutions outlive duties by design, not by contradiction.

**B-13. Merit willing vs. no direct transfer. [P3]**
*Locations:* Ch. 6.3 ("Merit can be willed to others" / "Person-to-person direct transfers: PROHIBITED").
*The gap:* formal appearance of conflict.
*Candidate/Recommended:* One sentence: wills are **executed by the System** at death (death transfer is already listed as a System function); no living person-to-person transfer exists. Precedence order to state: valid will → closest-family split → destruction if neither.

**B-14. Oversupply penalty vs. perpetual creator merit. [P2]**
*Locations:* Ch. 8.3 (flooding lowers merit per unit) vs. Ch. 8.8 ("Merit amount constant per use").
*The gap:* whether third-party flooding of a creator's item degrades the creator's constant per-use stream.
*Candidates:* (i) The constant applies to the **creator's royalty component**; the oversupply penalty applies to the seller-side valuation of units; (ii) both float under a single guild+system revaluation with the creator's proportion constant.
*Recommended:* (i) — cleanest separation of the two mechanisms.

*— Second-sweep additions —*

**B-15. "Nothing is permanently blocked" vs. the absolute Line. [P1 — constitutional]**
*Locations:* Ch. 10.7 Phase 3 ("Nothing is permanently blocked, but nothing is forced either") vs. Ch. 1.1 (the single moral absolute), Ch. 1.3.1 ("This is not negotiable"), and the entrenchment the whole Canon presumes.
*The gap:* taken literally, the voting architecture's universal-eventual-passage principle means a persistent supermajority could amend the Freedom Line itself — the one thing the Canon everywhere treats as beyond amendment. No entrenchment clause exists; nor does any amendment procedure distinguishing ordinary public matters, the global standards list (10.11), and constitutional bedrock.
*Candidates:* (i) An explicit **entrenchment hierarchy**: the Freedom Line and the trinity's existence are constitutive (not amendable by any vote — amending them is dissolving the system, which only C-28/C-63 exit can express); the 10.11 standards list amendable by the full mutual-veto process at a heightened threshold; ordinary matters per 10.7. (ii) Reword 10.7 to scope "nothing permanently blocked" to *proposals within the system*, not proposals *about the system's constitutive rules*.
*Recommended:* (i) and (ii) together; this is one of the two or three most load-bearing sentences the Canon still needs. Pairs with C-57.

**B-16. Absolute individual privacy vs. causal-forensic evidence. [P1]**
*Locations:* Ch. 11.3 ("Individual Privacy Remains Absolute… private communications remain private"), Ch. 14.5, Ch. 13.8 vs. Ch. 1.2.2 and Ch. 13 (complete-chain forensics, technological verification).
*The gap:* crimes are planned and committed inside the private sphere the Canon declares absolute. If privacy is truly unpierceable, the court cannot trace chains through it and the "beyond-reasonable-doubt with technological verification" standard starves; if it is pierceable, "absolute" is false as written. Warrants appear nowhere.
*Candidates:* (i) **Victim-side consent**: any party to a private interaction may unlock their own side of it as evidence (their privacy, their waiver) — covering most interpersonal crime; (ii) a narrow, court-ordered **warrant instrument** for the accused's private data, issued only on independently established probable cause, scope-limited, fully logged in the public audit trail after adjudication; (iii) privacy yields only at the terminal: the private sphere is inviolable for surveillance but not for post-crime forensic reconstruction from physical evidence.
*Recommended:* (i) always; (ii) as the sole pierce, defined with the same rigor as the caps; and an explicit reword of 11.3/14.5 from "absolute" to "absolute against surveillance; pierceable only by warrant under [the new section]." Encryption rights should be stated in the same breath (they follow from 11.3 and the "open-source but locked-down" pattern of 10.9).

**B-17. Corporate merit compensation vs. the transfer prohibition. [P1]**
*Locations:* Ch. 12.4 ("Merit-based compensation and incentive systems continue"), Ch. 7.3 ("human workers require compensation" — transition) vs. Ch. 6.3 ("Person-to-person direct transfers: PROHIBITED"; organizations hold no merit, Ch. 8.4).
*The gap:* employment compensation is asserted to continue, but the only lawful merit movements are System-mediated purchases and System-generated awards — and employers hold no merit to pay with.
*Candidates:* (i) **Employment as service sale through the System**: the worker is the seller, the employer the buyer, the System the mandatory intermediary exactly per 6.3 — wages are service transactions, the spread applies, and no direct transfer ever occurs (consequence to state plainly: the transaction spread falls on labor income like all trades); (ii) employment as **validated contribution**: the employer attests work performed, the System generates merit per the 8.6 valuation machinery, and the employer expends allocated resources rather than merit.
*Recommended:* (i) for market-layer work, (ii) for guild/civic service (pairs with C-38); one subsection in Chapter 8 closes it.

**B-18. Diffuse cumulative harm vs. individual-chain forensics. [P1 — method-level]**
*Locations:* Ch. 1.2.2 (the factory-pollution chain: one source, epidemiological tracing, specific victims) and Ch. 1.4 vs. the class of harms with **many small contributors and no assignable victim chain** — climate, aquifer depletion, antibiotic resistance.
*The gap:* the Canon's proudest method — replace categories with causal tracing — is built for point sources. Where a million emitters jointly injure everyone slightly, no individual chain terminates anywhere, and the method as stated returns "no violation" for what is plainly, in aggregate, a Line-crossing against the breathable-environment terminal (1.4).
*Candidates:* (i) A **collective-causation doctrine**: guilds + public set quantitative thresholds per pollutant/commons (the resource-cap pattern applied to emissions); exceeding one's allocation is itself the traced act — the chain runs to the threshold, not to a named victim; (ii) proportional-contribution liability where aggregate harm is technologically attributed by share.
*Recommended:* (i) — it converts the diffuse case back into the Canon's native form (a cap, a measurable crossing, forward-only adjustment) without inventing categorical harm. Pairs with C-70.

**B-19. Right to die vs. the acute crisis. [P2]**
*Locations:* Ch. 14.4 ("Full autonomy to end one's own life… Condition: sound mind and clear choice required") vs. the undefined status of the person in acute, transient crisis — for whom "sound mind" is precisely what is in doubt — and Ch. 13.10's guardianship, which addresses chronic incapacity only.
*The gap:* whether any temporary intervention (an emergency hold) is permissible, for how long, decided by whom; as written, either the sound-mind condition licenses indefinite paternalistic override, or it licenses none and the condition is unenforceable.
*Candidates:* (i) A **bounded intervention window**: emergency stabilization permitted only while capacity is genuinely indeterminate, with a short hard limit, immediate independent review (the C-10 adjudicator), and full restoration of the 14.4 right upon a capacity finding; (ii) advance directives recorded via Eternal Memory as dispositive evidence of settled choice.
*Recommended:* (i)+(ii); pairs with C-10 and C-65.

**B-20. The royalty stream at death. [P3 — clarification]**
*Locations:* Ch. 25.2 ("Immortal can will merit, but stream dies with them (even if immortal)") vs. Ch. 6.3 ("Merit can be willed") and Ch. 8.8 (constant per-use merit).
*The gap:* formal appearance of conflict between heritable merit and a stream that "dies."
*Candidate/Recommended:* State canonically what 25.2 implies: the **balance** is heritable (willed or family-split per 6.3); the **per-use royalty stream** is personal and terminates at death — creations continue to exist and circulate, but generate no further merit to anyone. One sentence in 6.3 and one in 8.8 close it; note the interaction for C-6's monetary model (creator death is a deflationary event).

---

## C. MISSING DESCRIPTORS — MECHANISMS THE CANON REQUIRES BUT DOES NOT YET SPECIFY

Chapter 29 already names open questions at the category level. The entries below are more precise: each is a specific D_missing whose absence either weakens a central claim (P1) or blocks implementation (P2) or formal completeness (P3). Where an entry sharpens an existing 29.x item, the mapping is given.

**C-1. The terminal taxonomy of freedom-removal. [P1 — the central gap]**
The Canon's strongest claim — "no edge cases; only empirical causal tracing" (Ch. 1.2) — requires that the *terminal states* a causal chain may land on be canonically enumerated; otherwise the philosophical categorization the Canon expels through the front door re-enters at the chain's end ("did this chain terminate in freedom-removal?" requires knowing what counts as freedom-removal). Scattered through the Canon the recognized terminals are: existence/bodily integrity (1.1), property (1.1), informed choice (1.4, 9.6), freedom from imposed presence after rejection (9.2), physical endangerment via panic (9.3), access to unmonopolized resources (1.4), and breathable environment (1.4). **Required:** a single canonical enumeration — the Freedom-Removal Terminal Classes — with the amendment procedure (mutual veto) for extending it. This one Descriptor converts the "no philosophical debate" claim from strong rhetoric into a formal property. *(Sharpens 29.4.)*

**C-2. Enforcement organs. [P1]**
Ch. 13.8 specifies who does *not* control enforcement ("no single entity controls 'the guns'") but no chapter specifies who investigates, who arrests, who holds custody, under what warrant procedure, or how enforcement personnel are selected, credentialed, and themselves policed. **Required:** the enforcement chapter — investigation authority, arrest/custody powers, warrant standard tied to technological verification, distributed command consistent with the trinity, and enforcement-of-the-enforcers. *(Sharpens 29.4.)*

**C-3. Criminal appellate process. [P1]**
Ch. 8.5 defines appeals for certification denials; Ch. 13 defines none for criminal conviction, despite double jeopardy's abolition cutting both ways (retrial on new evidence). **Required:** appeal rights, reviewing bodies, finality rules, and their interaction with B-5's irreversibility threshold.

**C-4. The public-matter trigger. [P1]**
The entire mutual-veto architecture keys on whether a matter "affects the general public in any way" (Ch. 10.3), yet no procedure determines this classification or resolves disputes over it. **Required:** algorithmic first-pass categorization (the 10.13 pattern), a challenge path, and a default rule (ambiguity → public matter, since the veto protects both sides).

**C-5. Public-side electoral mechanics. [P2]**
Ch. 10.7 gives the architecture but not: the electorate definition (age of majority per ⟳13.10's maturity threshold — itself undefined, see C-8; sapience threshold per 19.6), quorum/participation floors, proposal standing (who may bring a matter to vote), and re-vote cadence limits (Phase 3's "nothing is permanently blocked" invites proposal-spam without a cooldown Descriptor). *(Sharpens 29.1, 29.7.)*

**C-6. Merit monetary governance. [P1]**
Creation (validated contribution, Ch. 8.3) and destruction (spread, death, oversupply) must balance for price stability, but algorithms "cannot change the rules they operate under" (10.2) and no chapter assigns the tuning of creation/destruction rates to any body. **Required:** the monetary-policy loop — guild+public mutual veto over rate rules, automation executing and reporting, with published targets. *(Sharpens 29.3.)*

**C-7. Corporate/collective resource allocation mechanics. [P1]** — the mechanism chosen under B-9, fully specified: sizing, review cadence, transparency format, and enforcement classification for over-consumption by a collective (which individuals bear the karmic chain?).

**C-8. Maturity threshold and the law of children. [P1]**
⟳13.10 establishes graduated juvenile responsibility but no thresholds; Ch. 13.2 dissolves family law into "no forced obligations beyond Freedom Line violations." **Required:** (i) the maturity schedule (ages or competence tests, guild-defined under mutual veto); (ii) canonical statement that **child neglect and abandonment by a guardian are Line violations via causal chain** (a dependent's baseline access runs through the guardian until majority); (iii) baseline delivery mechanics to minors; (iv) education provision duties, harmonized with 19.1. Without (ii), the family-law dissolution leaves dependents outside the Line's protection — an unacceptable remainder.

**C-9. Guardianship liability proportion. [P2]**
Ch. 13.10: the caregiver "shares responsibility" — but the Canon's signature is the *complete* karmic chain. **Required:** the share function — full chain, proportionate-to-preventability, or duty-breach-scoped — and the standard of care that triggers it.

**C-10. Sound-mind adjudication for the right to die. [P2]**
Ch. 14.4 conditions assisted death on "sound mind and clear choice" with no adjudicator, standard, or waiting protocol — and no reconciliation with the no-paternalism principle. **Required:** the assessment mechanism (medical-guild certification under transparency), its evidentiary standard, and its appeal path.

**C-11. Fraud, elements of the offense. [P1]**
Ch. 9.6 protects misinformation but criminalizes "lying to gain something." The boundary between protected false persuasion and criminal fraud needs elements: falsity + intent + inducement + gain/detriment + reliance, expressed in causal-forensic terms. Same requirement for **contract breach as fraud** (13.6): which breaches are criminal (fraudulent inducement, harm-causing) versus non-justiciable (pure reliance loss)? *(Sharpens 29.4.)*

**C-12. Monopoly threshold. [P2]**
Monopolization crosses the Line (1.4) and guilds "prevent monopolistic behavior" (12.5), but no test defines monopoly (market-share, essential-facility denial, or access-blocking as traced harm). **Required:** the empirical monopoly test, in the 10.13 convert-to-empirics style.

**C-13. Privacy-publication boundary (doxxing). [P1]**
Individual privacy is a protected freedom (14.5); indirect speech is protected save panic and fraud (9.3). Publishing another's private facts *removes* their privacy — the causal chain suggests a violation; the speech doctrine suggests protection. **Required:** the canonical rule (candidate: publication of information obtainable only by violating the private sphere is a Line violation — the violation is the acquisition-and-exposure chain, not the speech; lawfully public information remains protected speech). *(Sharpens 29.5.)*

**C-14. Reckless-true panic. [P3]**
The panic exception requires falsity (9.3). A true statement delivered so as to knowingly cause deadly stampede is unhandled; candidate: the endangerment terminal class (C-1) covers manner-of-delivery recklessness regardless of truth value.

**C-15. Interference adjudication. [P2]**
Ch. 7.4 defines interference with automation but not its classification (Line violation vs. administrative exclusion), its detector, or its due process. Recommended default: administrative exclusion with graduated response; Line exposure only where a traced chain reaches others' baseline provision.

**C-16. Military command architecture. [P1]**
Chs. 16.2/18.4 maintain and advance strategic capability; no chapter places it under command. **Required:** command authority under the trinity (candidate: standing capability under cross-guild + public mutual veto; use-of-force authorization thresholds; regional-force integration), squared with "no single entity controls the guns."

**C-17. Space governance regime. [P2]**
No caps in space (6.4) but the Line applies everywhere. **Required:** claim-establishment rules (first-development? registration through the System?), off-Earth jurisdiction and courts, and the boundary where Earth caps end. *(Sharpens 29.2.)*

**C-18. Movement between regional guilds. [P2]**
Ch. 18.3 answers immigration for the current world; under integration (10.10) inter-regional movement mechanics — identification, security screening consistent with the surveillance limits, regional autonomy over residency — are unspecified. *(Sharpens 29.7.)*

**C-19. Sapient-nonhuman participation mechanics. [P2]**
The sapience standard (19.6) grants full rights on reliable demonstration; unspecified: the verification protocol and its guild owner, guild membership and public-vote enrollment for sapient AI, baseline provision in nonbiological form, and duplication/forking effects on one-being-one-vote. *(Extends 25.5.)*

**C-20. "Exact copy" boundary. [P2]**
"Everything gets merit… unless it is an exact copy" (6.3) needs the near-copy rule: the trivial-variation floor below which a submission is treated as the copy it is, detection via Eternal Memory's verification substrate, and the interaction with sequential innovation's decreasing chain. *(Sharpens 29.3.)*

**C-21. Founder grant quantification. [P2]**
"Merit sufficient for their family for 1,000 years" (22.2) needs its formula: the reference consumption basket, family-growth assumptions, and the general dilution form. The illustrative arithmetic (M/3 per child, M/9 per grandchild) is verified exact for uniform three-child branching — share at generation g is M·3⁻ᵍ — but the canonical form for arbitrary branching is M/∏ᵢkᵢ along each descent line, and should be stated as such.

**C-22. Guild founder thresholds. [P2]**
Layer 2 of guild constraint (10.13.4) references minimum member counts and initial governance for activation; no values or value-setting procedure exist. *(Sharpens 29.1.)*

**C-23. Transition authority. [P2]**
Ch. 20.5's "central coordination establishes conversion rates" names a body that cannot yet exist under the not-yet-activated trinity. **Required:** the transition-governance bridge — who coordinates conversion, under what accountability, and how it dissolves into the trinity at activation. *(Sharpens 29.7.)*

**C-24. Surveillance thresholds. [P2]**
"Near-perfect accuracy + human oversight" (14.5, 19.4) needs numbers and a certifying owner (candidate: statistical accuracy floor set by the relevant guilds under mutual veto, published error rates, oversight staffing rules).

**C-25. Criminal-court composition. [P2]**
"Judge + jury/populace consensus" (13.9): selection method, size, the meaning of "populace consensus" (unanimity? supermajority?), disqualification procedure beyond "no personal connections," and juror competence requirements consistent with competency-based participation.

**C-26. Corruption's outlet. [P3]**
Ch. 3.2 promises corruption "an appropriate outlet"; none is named. Candidate: the domination/power-structure outlets of 16.1 explicitly extended to influence-and-graft simulation; one sentence links them.

**C-27. Baseline information-access floor. [P3]**
"Computer and information access" (6.2) needs its floor Descriptor (device class, bandwidth, accessibility accommodations for disability per ⟳13.10's "accommodations available") — defined by the relevant guilds under the resource-cap pattern.

**C-28. Right of exit. [P2]**
"Everything under a global banner" (10.11) plus voluntary non-participation (10.6) leaves undefined whether a person or community may exit the system's *jurisdiction* entirely (not merely its economy). The Freedom Line's own logic suggests exit must exist for consent to be meaningful; the counterpoint is that the Line's protection of others cannot be exited. **Required:** the canonical position — candidate: economic and participatory exit absolute; jurisdictional exit recognized for those who physically leave the system's domain; the Line follows interactions, not membership.

**C-29. Escalation-monitoring limits. [P2]**
Outlet monitoring (16.4) sits adjacent to the individual-privacy absolute (11.3, 13.8). **Required:** the boundary — what outlet telemetry is collected, whether outlet use is "collective context" (transparent) or private consumption (protected), retention limits, and the intervention trigger's due process. *(Sharpens 29.6.)*

**C-30. Knowledge-system naming. [P3]**
Rule on "EMP" (see A-11): either expand once as "the Eternal Memory Project (EMP)" or normalize all references to "Eternal Memory."

**C-31. No-waste-of-animal-products enforcement class. [P3]**
Ch. 19.3's "no waste" rule needs its classification (Line violation? administrative rule?) and its detector; candidate: administrative within the circular-economy diversion machinery (8.9), Line exposure only via cruelty chains.

**C-32. Baseline conduct in custody. [P3]**
Harsh punishment coexists with the universal baseline; the Canon should state whether Line-crossers in custody retain baseline provision (candidate: yes — the baseline is unconditional by definition; punishment removes freedom, not food), preempting an obvious critique.

*— Second-sweep additions —*

**Persons and identity**

**C-33. Personal identity and vital-records infrastructure. [P1]**
One-being-one-vote, merit accounts, individual caps, karmic chains, and death transfers all presuppose a unique, verified personal identity — and no chapter establishes it. **Required:** birth registration and identity issuance; the death-determination standard and its certifier (the trigger for 6.3's death transfer); missing-persons presumption rules; identity theft and impersonation as a crime class; the pseudonymity boundary (private life pseudonymous per 11.3, system identity singular); and Sybil resistance for the public vote. This is the substrate Descriptor beneath C-5, C-60, and half the economy; candidate owner: the Eternal Memory verification layer (23.x) under the surveillance limits of C-24.

**C-34. Family definition and estate mechanics. [P1]**
Ch. 6.3 sends unwilled merit to "closest family" and permits designated beneficiaries — but "family" is never defined (blood, declared kinship, partnership?), and the **physical** estate has no mechanism at all: distribution of items and housing, heirs whose inheritance would exceed their caps (interacts B-10 — candidate: the frozen-legacy rule), will validity and contest forum (no civil court; candidate: guild mediation per 13.6 with the System as executor of record), and household/partnership cap treatment for cohabiting adults. **Required:** the succession section.

**C-35. Parentage assignment and the care institution. [P2]**
Ch. 15.2 already commits to "System-funded care for externally gestated children" and "adoption or care systems" — an institution asserted but never constituted. **Required:** parentage assignment rules (birth, surrogacy, external gestation, disputed cases), the constitution and oversight of the care institution (candidate: a care guild under mutual veto), adoption procedure, and the interface with C-8's guardianship duties.

**C-36. Suspended persons. [P3]**
Cryonic or otherwise suspended individuals (Ch. 25's horizon makes this live): dead or alive for the purposes of the 6.3 death transfer, the royalty stream (B-20), caps, and the vote? Candidate: a canonical **suspended status** — rights held in abeyance, estate not triggered, no vote, revival restores everything — with the death determination of C-33 as the exit.

**Economy**

**C-37. The services economy. [P1]**
Ch. 8.3 contains the Canon's entire treatment of services: "Service provision valued by system." The marketplace machinery (certification, System possession, replacement, oversupply) is item-shaped; a haircut, a surgery, a performance cannot be warehoused by the System. **Required:** service transaction mechanics through the System intermediary (B-17's sale model); practitioner certification as the service analog of item certification under 8.5's hierarchy; the professional-discipline and decertification procedure (the malpractice path, given no civil suits — criminal negligence per 13.2 plus guild discipline); and per-rendering merit under the 8.6 valuation split.

**C-38. Employment rails and civic compensation. [P1]**
The mechanism chosen under B-17, fully specified — plus the case the sweep exposed: **compensation for governance service itself.** Guild leaders, jurors, mediators, and audit-organ members are load-bearing and currently unpaid, an open corruption vector the Canon's own 3.2 realism forbids ignoring. Candidate: civic service is validated contribution (17.3's channel — the System generates merit for adjudicated service, valuation 50/50 per 8.6), keeping it off any employer's books entirely.

**C-39. Gifts, zero-price trades, and item transfers between persons. [P2]**
Ch. 17.3 covers altruism of *effort*; giving *things* remains unbound. Handing a neighbor bread is, formally, an untracked resource transfer. **Required:** whether inter-vivos item transfers route through the System at zero price (keeping caps and provenance true), the de-minimis threshold below which the System does not care, and the vote-buying interaction (a "gift" channel is the classic bribe channel — pairs C-60). Candidate: all title transfers via System, price zero permitted, spread zero at zero price, cap accounting always.

**C-40. Credit, debt, and risk pooling. [P2]**
Ch. 20.2/20.4 convert *pre-existing* debts at transition; the steady state is silent. Merit lending is a person-to-person transfer (prohibited, 6.3) — so the Canon appears to be, by architecture, a **debtless economy**, which is a profound feature that should be stated rather than implied. **Required:** the canonical statement (no private merit debt; large purchases by saving or System installment against future validated contribution); and the insurance question — with no pooling contracts, catastrophe recovery is either the baseline (survival) plus nothing, or a System restoration function (candidate: automation-surplus catastrophe restoration as an 8.9 priority-allocation class).

**C-41. Consumer price formation and spread policy. [P1]**
Ch. 8.2 fixes the form (creator price X, buyer price Y, Y>X, spread destroyed) and 8.6 fixes X's valuation; **Y and the spread have no author.** Who or what sets consumer prices and the spread schedule — flat, progressive by luxury class, essential-goods-zero? This is where B-7's healthcare differential and C-6's monetary policy actually live. Candidate: spread schedule as a public matter under mutual veto, executed algorithmically, published; essentials at minimal spread by rule.

**C-42. Land, housing, and the commons. [P1]**
Ch. 6.4 lists land among capped finites and 1.4 names land-locking; allocation itself is absent. **Required:** baseline housing assignment (location scarcity — who gets the coast?), the land registry (candidate: Eternal Memory title layer), transfer of land through the System, commons designation (parks, waters, heritage sites — held by no one, administered by designated guilds), extraction rights for capped materials, and eviction doctrine (candidate: baseline housing irrevocable save custody; market housing per contract).

**C-43. System-bypass trade. [P2]**
Barter, black markets, and off-ledger dealing appear nowhere, yet mandatory System intermediation (6.3) makes them the system's native crime of evasion. **Required:** classification (candidate: per the prevention-first pattern — design incentives so the System channel is cheaper and safer than evasion; criminal exposure only where the bypass conceals a Line-crossing such as theft, fraud, or cap evasion, since consensual off-ledger exchange harms no chain directly and over-criminalizing it recreates prohibition dynamics the Canon rejects in 14.1–14.2). This is a deliberate design decision the Canon must make explicitly either way.

**C-44. Gambling and wagers. [P2]**
Absent entirely. A wager is a conditional person-to-person transfer — prohibited as written. Candidate: gambling as a System-mediated product class (the house is the System; stakes are purchases; winnings are System generations), which preserves the vice-freedom stance of Chapter 14 while keeping transfers lawful; or classify private wagers under C-43's de-minimis tolerance.

**C-45. Collaborative creation and derivative works. [P1]**
"First inventor gets merit" (6.3) presumes one inventor. **Required:** merit-share attribution for teams (candidate: declared split at registration, disputes to guild mediation; default equal); employer-context creation (interacts C-38 — candidate: creators are always the natural persons; employers buy usage like anyone else); derivative and licensed works along the sequential-innovation chain; and the creator's right to waive or zero-price their stream (open-source publishing — candidate: waiver permitted, registration still required so provenance and C-20's copy detection survive).

**C-46. External-trade interface. [P2]**
During the long coexistence with non-Peratocratic economies (Chs. 18, 20–21): exchange between merit and external currencies (who sets the rate after transition's 20.5 moment), import/export through the System, sanctions and embargo policy as instruments short of 18.1's justified force, and foreign ownership under caps. Pairs C-23.

**Justice**

**C-47. The punishment-form taxonomy and the carceral institution. [P1]**
The Canon commits to harsh punishment, freedom removal, and the death penalty — and specifies **no punishment forms at all**: no custody design, no sentencing scale, no parole doctrine, nothing between warning and death. B-1 forbids merit fines, which makes freedom the only punishment currency; that makes this taxonomy the entire penal system. **Required:** the ladder (restriction of movement/association → custody grades → permanent removal → death per B-5's threshold), sentencing bound to 13.7's severity-of-chain principle, custody conditions (C-32's baseline answer), duration review, and whether release restores full standing (candidate: yes — punishment complete means complete, per the second-chances philosophy of Ch. 16).

**C-48. Justification and capacity doctrine. [P1]**
Ch. 14.1 states "Self-defense always justified" — one sentence carrying an entire doctrine. **Required:** scope (defense of others; defense of property — presumably bounded, since possessions are not equivalent to bodily autonomy per 13.10's retained block), proportionality and necessity limits, duress and necessity as defenses, voluntary intoxication (candidate: full responsibility — the chain includes the choice to ingest, consistent with 14.2's freedom-with-responsibility), involuntary intoxication (chain runs to the one who dosed), and the insanity interface with 13.10's guardianship (incapacity known and uncared-for pulls in the guardian per C-9).

**C-49. Inchoate offenses. [P1]**
Attempts appear nowhere; conspiracy only as a word in 9.5. A failed murder terminates no chain in harm — as written, it is unpunishable, which no reader of Chapter 13 would accept. **Required:** the attempt doctrine (candidate: the chain standard applied to *initiated* chains — punishable when action moves from preparation to execution against a target, severity scaled to the harm risked), solicitation (9.5's direct-order logic generalized beyond authority relationships), and conspiracy elements.

**C-50. Coercion, threats, extortion, and blackmail. [P1]**
Stalking and post-rejection harassment are classified (9.2); threats and extortion are not. A direct threat ("do X or I harm you") is direct speech compelling through fear; blackmail weaponizes *protected* speech (exposing true information) into a demand for gain. **Required:** the coercion doctrine — candidate: the threat itself is the act, a Line-crossing against informed free choice (1.4's terminal), regardless of the legality of the threatened disclosure; distinguish from lawful hard bargaining by the demanded-gain element, mirroring C-11's fraud elements.

**C-51. Criminal temporal doctrine. [P1]**
The Canon's forward-only principle exists for economics (6.6, 20.5) but was never stated for criminal law. **Required:** nulla poena sine lege (no act punishable that was not classified when committed — the Loophole Philosophy's criminal twin); prospective-only effect of new terminal classes under C-1's amendment path; limitations policy (candidate: none for Line-crossings — the chain is the chain — but state it deliberately); and **transitional justice**: which pre-activation acts are prosecutable after activation (candidate: only those criminal under the law of their time and place; the system does not retro-legislate history, consistent with Ch. 5's overlap boundary).

**C-52. Victim restoration. [P1]**
Ch. 13.7 counts victim trauma in sentencing; nothing restores the victim. Transfers are banned, so perpetrator-pays restitution is architecturally impossible (and B-1 forbids merit seizure anyway). The Canon itself leaves the question standing — 13.10's retained block asks "Can property damage be compensated for?" **Required:** the System restoration function — candidate: automation-surplus restoration of victims (property replaced via 8.9 priority allocation; care via the free layer of 19.2), decoupled from the perpetrator entirely, which is exactly the baseline philosophy applied to victimhood. Answer the retained block's question canonically.

**C-53. Collective criminal liability. [P2]**
When a corporate act crosses the Line, who stands in court? Organizations hold no merit and cannot be caged. **Required:** the allocation rule — candidate: the karmic chain runs to the natural persons who decided, executed, and culpably failed to prevent (the transparency records of 11.5 make this tractable by design); no corporate veil exists because no corporate person exists. Pairs C-7.

**C-54. Clemency. [P3]**
Pardons appear nowhere. Given no-retroactivity, harsh-certainty deterrence (16.5), and B-5's irreversibility threshold, the coherent candidate is: **no pardon power exists** — mercy enters only as new exculpatory evidence (retrial per 13.9) — but this should be decided and stated, not left to inference.

**C-55. Autonomous-system harm allocation. [P1]**
A non-sapient vehicle or robot injures someone: the chain must land on a person, and the Canon does not say which. **Required:** the allocation rule across owner/operator, manufacturer, and certifier — candidate: operator negligence per ordinary chain analysis; manufacturing defect chains to the maker per 8.7's fraud-and-defect logic; certified-design failure engages the certifier's staked reputation (8.5) and, where negligent, the certifier's chain; pure unforeseeable malfunction is the accident case of C-48's doctrine. Tool status per 19.4 means the machine is never the terminus.

**C-56. Obligations of sapient-creators. [P1]**
The sapience standard (19.6) grants rights on demonstration; it says nothing to the **creator** of a new sapient. **Required:** whether a created sapient enters as juvenile-analog (creator as guardian under 13.10's graduated framework until the C-8 maturity standard is met) or as instant adult; the ethics gate on creating suffering-capable beings (candidate: creation that foreseeably dooms a sapient to incapacity or suffering chains to the creator — the germline logic of C-64 applied to artificial minds); and duplication/forking under C-33's one-identity rule. Pairs C-19.

**Governance**

**C-57. Constitutional procedure. [P1]**
The resolution machinery for B-15, fully specified: the entrenchment hierarchy (Line and trinity constitutive; 10.11 standards list at heightened mutual-veto threshold; ordinary matters per 10.7); the amendment procedure's mechanics (proposal standing, deliberation period, thresholds, promulgation via Eternal Memory); and the **interpretation authority** — algorithms are canonically bad at interpreting (10.13.2), so a human organ must construe the canon in hard cases (candidate: the judicial branch interprets in cases; a cross-guild jurisprudence council maintains the authoritative gloss under full transparency; the canon text itself amendable only per this section).

**C-58. Emergency doctrine. [P1]**
Ch. 10.9 grants "Emergency intervention possible when needed" in nine words and defines nothing. **Required:** trigger classes (disaster, epidemic, infrastructure failure, attack), the empowered organ and its scope, hard sunset and mandatory review, and the epidemic case in full — quarantine authority against 14.x bodily freedom (candidates: knowing spread is already a violation per 1.4; negligent-exposure standard for the known-infectious; preemptive restriction of the *not-yet-sick* only under the emergency instrument with compensation-in-kind and sunset; no vaccination mandates, consistent with bodily autonomy, with access universal via the free layer). The one-line grant as written is the largest unguarded power in the Canon.

**C-59. Officeholder and guild lifecycle. [P2]**
Elections exist; nothing else does. **Required:** term lengths and limits, staggering, mid-term removal for cause (recall by the electing body; automatic removal on Line conviction), succession on vacancy; guild membership joining standards and expulsion due process; and guild merger, schism, and dissolution (extends C-22's founding-only coverage) with disposition of records and certifications.

**C-60. The integrity organ. [P1]**
Audit *trails* exist everywhere (11.8); an audit *organ* exists nowhere. Ch. 10.8's capture heuristic detects but no one is charged with acting. **Required:** an independent integrity body — randomly sampling the trails, auditing valuations and elections, investigating collusion, prosecutable referrals to the court — itself fully transparent and term-limited; plus the offense set it enforces: vote-buying (via C-39's gift channel), collusion between guild and public blocs, valuation manipulation, and Sybil identity fraud (C-33). Candidate composition: cross-guild + sortition from the public, mirroring the trinity in miniature.

**C-61. System security and continuity. [P1]**
Attacks on the automation, the merit ledger, or Eternal Memory are attacks on the civilization's substrate, and the Canon has no word for them. **Required:** the sabotage/system-attack crime class (chain analysis: corrupting the ledger removes the freedoms of everyone whose claims it carries); resilience requirements — redundancy, distributed backup, and recovery procedure for the ledger and archives (extending 10.9's "open-source but locked-down" into an availability doctrine); and the reconciliation procedure after any corruption event (whose record stands). Pairs C-2's enforcement and C-58's emergencies.

**C-62. Activation certification. [P2]**
Ch. 7.3 defines the threshold structurally ("self-sustaining operation across all essential functions"); no one is empowered to *find* that it has been reached — and the Founder's transfer, the tax-to-surplus switch, and the trinity's activation all hang on that finding. **Required:** the measurement standard (essential-function inventory, sustained-operation duration, redundancy margin) and the certifying act (candidate: the 20.5 transition authority of C-23 makes the finding under published criteria; the mutual-veto process ratifies it).

**C-63. Regional secession and admission. [P2]**
C-28 answers the individual; the collective case is open. May a regional guild leave the global architecture, and how does a new region join? **Required:** the admission standard (adopting the Line and the standards list of 10.11); the secession question answered deliberately (candidate: exit is real — consent at the collective scale, per the same logic as C-28 — with the Line continuing to govern all cross-boundary interactions; permanent members' individual right of relocation protected during any exit). Pairs C-18.

**Body, mind, and society**

**C-64. Genetic law for offspring. [P1]**
Adult enhancement is free (26.3–26.4); engineering a **child** — who cannot consent — is unaddressed, and 15.2's artificial-gestation commitment makes it imminent. **Required:** the germline doctrine — candidates: therapy/harm-prevention permitted (restoring the child toward baseline function, the B-4 set logic); enhancement selection bounded by a no-foreseeable-harm standard (a choice that predictably closes the child's future capabilities chains to the chooser, per C-56's creation logic); a designated guild certifies interventions under mutual veto. This is the hardest consent problem in the Canon and must be decided on paper, not discovered in court.

**C-65. The acute-crisis window. [P2]**
The mechanism chosen under B-19, specified: hold duration limit, the reviewing adjudicator (C-10's), evidentiary standard for "capacity indeterminate," advance-directive precedence via Eternal Memory, and the bright line against any indefinite or repeat-cycling hold.

**C-66. Bodily commerce. [P2]**
Organs, tissue, gametes, and blood appear nowhere. Bodily autonomy plus the market suggests sale is lawful; the free lifesaving layer needs allocation rules for donated organs; and irreversibility demands safeguards. **Required:** System-mediated bodily commerce with heightened consent verification (the C-10 capacity machinery), allocation of lifesaving transplants inside the free layer by medical criteria (never by merit — state it, or the bifurcation of 19.2 will be read as organs-to-the-rich), and prohibition of any third-party harvesting interest in another's death (the chain writes itself).

**C-67. Education law. [P1]**
Ch. 19.1 gives the philosophy (phenomenological organization, evidence-based content, self-direction, universal access, competence credentials); it does not bind anyone. **Required:** whether education is compulsory (candidate: the child's development right — a guardian who denies a child access to the universal system commits neglect under C-8's chain, while *how* and *where* remain free per self-direction); who adjudicates "evidence-based" content disputes (candidate: the knowledge-system verification standards of 23.x under mutual veto — never a ministry); and the parental-teaching boundary (teaching anything is protected speech; *preventing* learning is the violation).

**C-68. Religious-practice boundary cases. [P1]**
Ch. 29.5 names the category; the Canon should decide the three cases that will actually arrive on day one: **infant and child body modification** for religious reasons (the bodily-integrity terminal plus a subject who cannot consent — the Canon's own principles point to prohibition until the C-8 maturity standard, with the political cost acknowledged rather than dodged); **medical neglect by faith** (guardian denial of lifesaving care to a dependent = the C-8 neglect chain — the free layer removes every excuse); and **animal sacrifice** against 19.6's unnecessary-suffering protection (candidate: bounded by the same welfare standard as any other killing of non-sapient life — no religious exemption from the Line, because the Line admits no exemptions at all; that sentence itself belongs in canon).

**C-69. The whistleblower channel. [P2]**
Everything collective is already public by right (11.5); therefore exposing concealed collective wrongdoing is not a breach but the enforcement of transparency. The Canon should say so: disclosure of what the law already deems public is protected per se; retaliation for it is itself a traceable act; and the channel routes to the C-60 integrity organ. One subsection in Chapter 11.

**C-70. Quantitative commons standards. [P1]**
The mechanism chosen under B-18, specified: per-commons thresholds (air, water, soil, spectrum, orbital space) set by the relevant guilds under mutual veto with published measurement methodology; individual and collective allocations under the cap pattern; exceedance as the traced act; and the monitoring interface bounded by C-24's surveillance limits.

**C-71. Founder lifecycle. [P2]**
Ch. 22.3 permits collaborative founding ("combine their efforts") and C-21 quantifies the grant; unspecified: the **division rule among co-founders** (candidate: declared shares at commitment, System-recorded, default proportional to certified contribution under 8.6), death **before vesting** (B-6 establishes nothing has vested — candidate: the decedent's committed contribution credits the collaboration, heirs take nothing of the unvested grant, stated plainly), and the Founder's **post-transfer standing** (candidate: none — the Bargain purchases infrastructure, not office; a founder holds power afterward only by election like anyone else — the sentence that forecloses the god-king reading of Chapter 22).

---

## D. SEPARATION DECISIONS LOG — FOR CONFIRMATION

Every discretionary decision taken in producing Canonical Edition 1.1, with rationale. Each stands unless overruled.

**D-1. Canonical continuous numbering.** Both volumes share Chapters 1–30 / Parts I–X; every citation of "Chapter N" resolves identically everywhere; the Canon Map (Appendix D, both volumes) locates each chapter and gives the recombination rule. *Rationale:* repairs A-2 without renumbering risk and makes the eventual single book a pure interleave.

**D-2. Chapter homes.** Volume I: 1–5, 14–19, 25–28, 29(§§29.5–29.6, 29.8–29.10), 30. Volume II: 6–13, 20–24, 29(§§29.1–29.4, 29.7). *Rationale:* the philosophy/mechanism criterion — Volume I carries the *why* (foundations, positions, comparisons, conclusion), Volume II the *how* (economy, governance, court, knowledge, transition). This retains the prior partition's chapter assignments (which were sound at chapter granularity) while repairing everything around them.

**D-3. Hybrid chapters bound by pointers, not duplication.** Ch. 9 (speech jurisprudence) homes in Volume II with the position summarized at 14.3 (Vol. I); Chs. 16–17 (outlets, altruism) home in Volume I with deployment referenced at 13.8/21.5 (Vol. II). Eleven companion-reference pointers were inserted at the seams (Chs. 1, 4, 6, 9, 13, 14, 16, 19, 22, 24, 26). *Rationale:* the person's requirement to "still show the links" is met by explicit apparatus — pointers in-line, plus the Companion Linkage appendices mapping every principle↔mechanism pair — rather than by the prior split's verbatim duplication.

**D-4. Changelog placements honored exactly.** All fifteen v1.1 items sit at their specified chapters, including 13.7.1 (Hammurabi) and 8.10 (Responsibility covenant) in Volume II although their content is philosophical in character. *Rationale:* the changelog is authorial instruction; minimal editorial discretion. *Flagged for decision:* whether 13.7.1 and 8.10 should relocate to Volume I's justice/equality chapters in a future edition, with Volume II citing them — the Linkage appendix already binds them both ways, so no information is lost either way.

**D-5. Preamble and constitutional apparatus.** Full Preamble → Volume I; Volume II received a scoped governmental preamble plus the Constitutional Foundation (the Line stated, causal forensics summarized, Volume I cited). *Rationale:* repairs A-7; makes Volume II standalone-complete, which the prior split was not.

**D-6. Part VI homed in Volume II.** The Knowledge System's canon functions (evidence base, merit verification, enforcement records, baseline coordination, cultural archives, funding, privacy locks) are governmental machinery; the epistemological *commitments* remain Volume I material (19.1, Preamble) and are cross-bound in both Linkage appendices. The standalone Eternal Memory cross-project document remains the bridge artifact.

**D-7. Appendix scheme.** A: Key Principles, partitioned per the prior split (verified identical to master per section), with the Knowledge-infrastructure bullet restored to Volume II's Integration Points; B: Direct Statements in full in Volume I, indexed with governance mappings in Volume II; C: Companion Linkage (both, direction-specific); D: Canon Map (both, identical). Dual-name colophon in both.

**D-8. Editorial corrections applied:** Ch. 10 em-dash (adopting the prior split's corrected text), Ch. 23 subject repair (A-6). "EMP" untouched (A-11/C-30). No other source wording was altered anywhere.

**D-9. New material added (improvement clause):** abstracts, Two-Volume Canon notes, tables of contents, Volume II preamble/constitutional foundation/conclusion, Appendices B-index/C/D, pointer lines, and the Part X wrapper notes. Everything else in both volumes is source text verbatim, machine-verified (Section F).

**D-10. Proposed and deferred — ET Foundations appendix.** An explicit Exception Theory formalization of the Canon is a natural future appendix: P = the social substrate of possible configurations (cardinality of the population's configuration space); D = the Freedom Line as the governing péras-Descriptor plus the derived institutional descriptor set (layers, caps, veto, locks — all finite, articulable constraints); T = individuals, guilds, and publics as Traversers navigating the D-constrained substrate, with the automated System as instrumented measurement; E = the realized civilizational order as the substantiated configuration. The Canon's method — converting philosophical disputes into empirical questions — is the Descriptor Gap Principle in the political domain; the Universal Logic (Public/Private/Hybrid) is a D-classification; the saturation point is the Subsumption horizon at which the descriptor set covers its domain without remainder. **Deferred pending authorial decision**, because the published Canon has to date been kept free of ET formalism and injecting it is a scope decision, not an editorial one.

---

## E. PATH TO COMPLETION

1. **Adjudicate Section B (20 items).** Each has recommended language; most close with one to three canonical sentences. The constitutional pair first — B-15 with C-57 — then B-16 (privacy/evidence), B-17 with C-38 (employment), B-18 with C-70 (commons), then B-1 through B-5 and B-9.
2. **Specify Section C (71 items).** C-1 (terminal taxonomy) remains first — it is the load-bearing Descriptor for the Canon's central claim. Then the second sweep's P1 backbone in dependency order: **C-33** (identity — substrate for votes, estates, and integrity), **C-57** (constitutional procedure), **C-47/C-48/C-49/C-50/C-51/C-52** (the completed criminal law: punishment forms, justification, inchoate acts, coercion, temporal doctrine, victim restoration), **C-41/C-37/C-45/C-42** (the completed economy: prices, services, attribution, land), **C-58/C-60/C-61** (emergency, integrity, security), **C-55/C-56/C-64** (the machine-and-mind frontier), **C-67/C-68/C-70** (education, religion, commons), then the remaining P1s of the first sweep (C-2, C-3, C-4, C-6, C-8, C-11, C-13, C-16) and all P2/P3 items. Each closed item should be drafted as a numbered subsection at its home chapter, keeping the convert-to-empirics style.
3. **Rule on flagged decisions:** D-4 (relocate 13.7.1/8.10 or keep), C-30/A-11 (EMP naming), D-10 (ET Foundations appendix), and the two deliberate design decisions the sweep surfaced — C-43 (bypass-trade stance) and C-54 (no-clemency stance).
4. **Then declare Canonical Edition complete**, re-run the verification suite, and assemble the single founding book per the Canon Map recombination rule. This register closes when its every entry carries a resolution and the Verification Principle holds: no internal inconsistency remains — for every exception an exception, except the Exception.

---

## F. VERIFICATION RECORD (MACHINE-AUDITED)

The assembly of Canonical Edition 1.1 was performed programmatically from the five source documents and audited as follows (full log: `verification_record.txt`):

- **Sources read in full:** master unified document (175,606 B), prior Ritaism split (80,356 B), prior Peratocracy split (90,941 B), changelog v1.1 (46,158 B), Eternal Memory cross-project document (6,717 B).
- **Canonical text provenance:** every chapter byte-diffed master-vs-split; all identical except Ch. 10 (split's corrected em-dash adopted). Part VI verified content-identical between master and the cross-project document after header-depth normalization. Chapter 29's ten subsections verified identical across the prior partition. Naming and Preamble identical across all three carriers.
- **Subsumption audit: PASS.** Every `###` section header from all five sources appears verbatim in the two volumes, or on the enumerated whitelist with reason (the four ⟳ retitles/restructures, the prior split's unnumbered Part X variants replaced by canonical `29.x` headers with content verified identical, the EM header-depth variants, and Appendix B subheads relevelled). Zero unaccounted remainder.
- **Changelog audit: PASS.** All fifteen v1.1 items present at their specified locations; replace/expand semantics honored with retention verified (Possessions block, 21.1 epigraph, 26.3 options).
- **Sentinel fidelity: PASS.** First and last 60 characters of every canonical block (28 chapters, 10 subsections of Ch. 29, Ch. 30, Naming, Preamble, closing) verified verbatim in the destination volume.
- **Cross-reference audit: PASS.** Every "Chapter N" reference resolves within its volume or is volume-qualified.
- **Structural checks: PASS (15/15)** — including: Volume II states the Freedom Line; Chapter 30 restored; Part VI present; Canon Map and Linkage in both; dual colophon; em-dash and Ch. 23 corrections applied; fence parity (Volume II carries exactly the master's three Chapter 8 flow diagrams; Volume I none); no doubled separators.
- **Mathematics:** the Founder-dilution illustration computed exactly (rational arithmetic): M/3 per child, M/9 per grandchild, generation-g share M·3⁻ᵍ under uniform three-child branching — confirming the source's figures and grounding C-21's request for the general form.
- **Zero-loss audit: PASS (bidirectional, line-level; full log `NO_LOSS_AUDIT.txt`).** Direction 1 — every non-blank line of all five source documents is verbatim in the volumes, or carried by an evidenced repair (the two encoding/typo corrections), or matched by exactly one verified justification rule (changelog scaffolding with its fenced payload proven 100% integrated; retitled/relevelled/partition-suffixed headers with the canonical forms verified present; the replaced §4.4 preserved verbatim in this register's Annex with each idea's canonical home verified). Direction 2 — every non-blank line of both volumes is attributed to a source document, an evidenced repair, or the enumerated new material of D-9 (fragments, generated tables of contents, the eleven pointers, scaffolding). Unresolved source lines: **0**. Unattributed volume lines: **0**. The audit itself forced one correction: the original §13.10 care-requirement block, which the revised doctrine had restated in new words only, is now retained verbatim (A-4).
- **Second-sweep gap hunt: verified (log `SWEEP_VERIFICATION.txt`).** A domain × lifecycle × adversarial-actor matrix was tested against the canon by a forty-topic keyword battery over both volumes with nearest-header attribution, followed by full section reads (§§6.3, 7.3, 11.3–11.5, 13.6, 14.4, 17.3, 19.1, 22.3). Candidate gaps disproved by the text were withdrawn before writing (self-defense 14.1; harassment/stalking 9.2; altruism channel 17.3; guild mediation 13.6; activation threshold definition 7.3); the remainder were confirmed absent or only nominally covered and entered as B-15 – B-20 and C-33 – C-71 with verified citations.

---

## ANNEX — SUPERSEDED PASSAGES PRESERVED VERBATIM

**Purpose.** The changelog's one true replacement operation (⟳4.4: "Replace existing 4.4 content") removes text from the canon by explicit authorial instruction. Under the zero-loss standard, nothing is permitted to vanish from the deliverable set: the superseded passage is therefore preserved here verbatim, together with the audited map of where each of its ideas survives in the canonical text. If any formulation below is wanted back in canon, it can be restored by a one-line instruction.

### Annex 1 — Original §4.4 "The Natural Advantages Reality" (superseded by ⟳4.4)

> ### 4.4 The Natural Advantages Reality
>
> **People will have edges. This is reality.**
>
> Some people are born smarter, more attractive, into wealthy families, with better health, in better locations, with more opportunities.
>
> **This is unfair in the cosmic sense. It is not unjust in the moral sense.**
>
> Justice concerns human actions, not natural variation. You are not entitled to outcomes equal to others simply because nature distributed advantages unequally.
>
> **Ritaism's response:**
>
> - Universal baseline ensures no one lacks necessities regardless of natural disadvantages
> - Merit system lets individuals find and leverage their own advantages
> - Resource caps prevent any advantage from translating to monopoly
> - Freedom with responsibility means your outcomes are your problem
>
> It is your own responsibility to raise yourself up. The system forces all responsibility on the individual. Freedom with responsibility. It is no one else's problem for your success or failure but you. You don't even have to participate if you do not wish to and still get the basics.

**Audited survival map (each idea → verified canonical home):**

| Original formulation | Where the idea lives in canon (verified verbatim anchors) |
|---|---|
| "People will have edges. This is reality." | Revised §4.4: "Life is unfair. This is not a bug—it is reality." |
| Born-advantages list ("…into wealthy families…") | Revised §4.4 carries the list with "into better circumstances" in place of "into wealthy families"; otherwise a superset ("smarter, stronger, more attractive… better health… better locations… more opportunities") |
| "Unfair in the cosmic sense… not unjust in the moral sense" / "Justice concerns human actions, not natural variation" | Revised §4.4: "This is **variation**, not injustice"; entitlement half carried by §1.3.1 / B.2: "No one is entitled to another." |
| Universal baseline regardless of disadvantage | Revised §4.4: "Equal in baseline provision"; Chapter 6 §6.2 (unconditional baseline) |
| Merit open to leveraging one's own advantages | Revised §4.4: "Variation in advantage = different paths to contribution"; Chapter 6 §6.3 |
| Caps prevent advantage → monopoly | Chapter 1 §1.4 (monopolization crosses the Line); Chapter 6 §6.4 (caps) |
| Freedom-with-responsibility closing paragraph | Retained in revised §4.4 in the changelog's own rewording, near-verbatim: "…It is no one else's problem for your success or failure but you. You do not even have to participate if you do not wish to and still receive the basics." (don't→do not; get→receive) |

### Annex 2 — Structural notes of record

- **"## Core Positions" (master Appendix).** Not lost: the prior split partitioned it into "## Core Positions (Philosophical)" (Volume I) and "## Core Positions (Governmental)" (Volume II); all nine bullets verified verbatim in the volumes.
- **Eternal Memory document boundaries.** The bridge document's title, "Cross-Project Documentation" label, and end-marker are document-scoping apparatus of the standalone artifact, which is retained intact; its entire content is in Volume II, Part VI, and both volumes' Linkage appendices state that Eternal Memory "is additionally maintained as a standalone cross-project document."

---

*Register prepared via the Three Tools of Exception Theory — the Identification Principle, the Descriptor Gap Principle, and the Subsumption Law — applied to the complete Ritaist corpus. Every gap above is a Descriptor awaiting identification; anything can be solved — it is just a matter of the right descriptors and the number of descriptors.*
