/*
 * ET LOSSLESS SENSOR CAPTURE — DIRECT CHANNEL IMPLEMENTATION
 * ============================================================
 * Android NDK sensor access with direct channel priority.
 *
 * Author: Michael James Muller — Aevum Defluo (Exception Theory)
 * License: CC-BY-4.0
 */

#include "et_direct_channel.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#ifdef __ANDROID__
#include <android/log.h>
#define LOG_TAG "EtSensorDirect"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGW(...) __android_log_print(ANDROID_LOG_WARN, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)
#else
#define LOGI(...)
#define LOGW(...)
#define LOGE(...)
#endif

/* ═══════════════════════════════════════════════════════════════════
 * ANDROID SENSOR TYPE → ET SENSOR TYPE MAPPING
 * Only hardware sensors are mapped.
 * ═══════════════════════════════════════════════════════════════════ */
et_sensor_type_t et_android_sensor_to_et_type(int android_type) {
#ifdef __ANDROID__
    switch (android_type) {
        case ASENSOR_TYPE_ACCELEROMETER:         return ET_SENSOR_ACCEL;
        case ASENSOR_TYPE_GYROSCOPE:             return ET_SENSOR_GYRO;
        case ASENSOR_TYPE_MAGNETIC_FIELD:        return ET_SENSOR_MAG;
        case ASENSOR_TYPE_PRESSURE:              return ET_SENSOR_BARO;
        case ASENSOR_TYPE_LIGHT:                 return ET_SENSOR_LIGHT;
        case ASENSOR_TYPE_PROXIMITY:             return ET_SENSOR_PROXIMITY;
        case ASENSOR_TYPE_AMBIENT_TEMPERATURE:   return ET_SENSOR_TEMP;
        case ASENSOR_TYPE_RELATIVE_HUMIDITY:     return ET_SENSOR_HUMIDITY;
        /* Heart rate: type 21 */
        case 21:                                 return ET_SENSOR_HEART_RATE;
        /* Step counter: type 19 */
        case 19:                                 return ET_SENSOR_STEP;
        default:                                 return ET_SENSOR_TYPE_COUNT; /* Unknown */
    }
#else
    (void)android_type;
    return ET_SENSOR_TYPE_COUNT;
#endif
}

int et_is_hardware_sensor(int android_type) {
#ifdef __ANDROID__
    /* Skip virtual/composite sensors — they are OS-computed */
    switch (android_type) {
        /* Virtual/composite — SKIP */
        case ASENSOR_TYPE_GRAVITY:
        case ASENSOR_TYPE_LINEAR_ACCELERATION:
        case ASENSOR_TYPE_ROTATION_VECTOR:
        case ASENSOR_TYPE_GAME_ROTATION_VECTOR:
        case ASENSOR_TYPE_GEOMAGNETIC_ROTATION_VECTOR:
        case ASENSOR_TYPE_SIGNIFICANT_MOTION:
            return 0;
        /* Hardware — RECORD */
        case ASENSOR_TYPE_ACCELEROMETER:
        case ASENSOR_TYPE_GYROSCOPE:
        case ASENSOR_TYPE_MAGNETIC_FIELD:
        case ASENSOR_TYPE_PRESSURE:
        case ASENSOR_TYPE_LIGHT:
        case ASENSOR_TYPE_PROXIMITY:
        case ASENSOR_TYPE_AMBIENT_TEMPERATURE:
        case ASENSOR_TYPE_RELATIVE_HUMIDITY:
        case 21: /* Heart rate */
        case 19: /* Step counter */
            return 1;
        default:
            return 0; /* Unknown — skip */
    }
#else
    (void)android_type;
    return 0;
#endif
}

/* Determine number of axes for a sensor type */
static int sensor_axes(int android_type) {
#ifdef __ANDROID__
    switch (android_type) {
        case ASENSOR_TYPE_ACCELEROMETER:
        case ASENSOR_TYPE_GYROSCOPE:
        case ASENSOR_TYPE_MAGNETIC_FIELD:
            return 3;
        default:
            return 1;
    }
#else
    (void)android_type;
    return 1;
#endif
}

/* Determine if sensor is bipolar */
static int sensor_bipolar(int android_type) {
#ifdef __ANDROID__
    switch (android_type) {
        case ASENSOR_TYPE_ACCELEROMETER:
        case ASENSOR_TYPE_GYROSCOPE:
        case ASENSOR_TYPE_MAGNETIC_FIELD:
            return 1;
        default:
            return 0;
    }
#else
    (void)android_type;
    return 0;
#endif
}

/* ═══════════════════════════════════════════════════════════════════
 * SENSOR MANAGER INIT — enumerate ALL hardware sensors
 * ═══════════════════════════════════════════════════════════════════ */
et_error_t et_sensor_manager_init(et_sensor_manager_t *mgr) {
    if (!mgr) return ET_ERR_NULL_INPUT;
    memset(mgr, 0, sizeof(*mgr));

#ifdef __ANDROID__
    mgr->asensor_manager = ASensorManager_getInstanceForPackage("com.aevumdefluo.etsensor");
    if (!mgr->asensor_manager) {
        LOGE("Failed to get ASensorManager instance");
        return ET_ERR_SENSOR;
    }

    /* Create looper for event queue mode */
    mgr->main_looper = ALooper_forThread();
    if (!mgr->main_looper) {
        mgr->main_looper = ALooper_prepare(ALOOPER_PREPARE_ALLOW_NON_CALLBACKS);
    }

    /* Enumerate all sensors */
    ASensorList sensor_list;
    int n_sensors = ASensorManager_getSensorList(mgr->asensor_manager, &sensor_list);

    LOGI("Found %d total sensors", n_sensors);

    for (int i = 0; i < n_sensors && mgr->sensor_count < ET_MAX_SENSORS; i++) {
        const ASensor *sensor = sensor_list[i];
        int type = ASensor_getType(sensor);

        /* Skip virtual/composite sensors */
        if (!et_is_hardware_sensor(type)) continue;

        et_direct_sensor_t *ds = &mgr->sensors[mgr->sensor_count];
        memset(ds, 0, sizeof(*ds));

        ds->sensor_id = mgr->sensor_count;
        ds->sensor_type = et_android_sensor_to_et_type(type);
        ds->sensor = sensor;
        ds->manager = mgr->asensor_manager;
        ds->channel_id = -1;

        /* Read sensor properties */
        const char *name = ASensor_getName(sensor);
        const char *vendor = ASensor_getVendor(sensor);
        if (name) strncpy(ds->name, name, sizeof(ds->name) - 1);
        if (vendor) strncpy(ds->vendor, vendor, sizeof(ds->vendor) - 1);

        ds->resolution = ASensor_getResolution(sensor);
        ds->max_range = ASensor_getMaxRange(sensor);
        ds->min_delay_us = ASensor_getMinDelay(sensor);
        ds->fifo_max = ASensor_getFifoMaxEventCount(sensor);
        ds->axes = sensor_axes(type);
        ds->is_bipolar = sensor_bipolar(type);

        /* Compute effective sample rate from min_delay */
        if (ds->min_delay_us > 0) {
            ds->sample_rate_hz = 1000000 / ds->min_delay_us;
        } else {
            ds->sample_rate_hz = 200; /* Default for on-change sensors */
        }

        /* Estimate ADC bit depth from resolution and range */
        if (ds->resolution > 0 && ds->max_range > 0) {
            double steps = (double)(ds->max_range * 2.0f) / (double)ds->resolution;
            ds->bit_depth = (int)ceil(log2(steps));
        } else {
            ds->bit_depth = 16; /* Default assumption */
        }

        /* Probe direct channel support */
        ds->direct_support = ASensor_getHighestDirectReportRateLevel(sensor);
        ds->using_direct = 0;

        if (ds->direct_support >= ASENSOR_DIRECT_RATE_FAST &&
            ASensor_isDirectChannelTypeSupported(sensor, ASENSOR_DIRECT_CHANNEL_TYPE_HARDWARE_BUFFER)) {
            /* Direct channel available — will set up when start() is called */
            snprintf(ds->access_mode, sizeof(ds->access_mode), "direct_channel");
            ds->direct_rate = ds->direct_support;
            LOGI("  [%d] %s: DIRECT CHANNEL (rate level %d)",
                 ds->sensor_id, ds->name, ds->direct_support);
        } else {
            snprintf(ds->access_mode, sizeof(ds->access_mode), "event_queue");
            LOGI("  [%d] %s: event queue (no direct channel)",
                 ds->sensor_id, ds->name);
        }

        mgr->sensor_count++;
    }

    mgr->initialized = 1;
    LOGI("Sensor manager initialized: %d hardware sensors", mgr->sensor_count);
    return ET_OK;

#else
    LOGW("Not on Android — sensor manager stub");
    mgr->initialized = 1;
    return ET_OK;
#endif
}

void et_sensor_manager_cleanup(et_sensor_manager_t *mgr) {
    if (!mgr || !mgr->initialized) return;

#ifdef __ANDROID__
    for (int i = 0; i < mgr->sensor_count; i++) {
        et_direct_sensor_t *ds = &mgr->sensors[i];
        if (ds->active) {
            et_sensor_stop(mgr, i);
        }
        if (ds->hw_buffer) {
            AHardwareBuffer_release(ds->hw_buffer);
            ds->hw_buffer = NULL;
        }
        if (ds->event_queue) {
            ASensorManager_destroyEventQueue(mgr->asensor_manager, ds->event_queue);
            ds->event_queue = NULL;
        }
    }
#endif

    mgr->initialized = 0;
    mgr->sensor_count = 0;
}

/* ═══════════════════════════════════════════════════════════════════
 * SENSOR START
 * ═══════════════════════════════════════════════════════════════════ */
et_error_t et_sensor_start(et_sensor_manager_t *mgr, int sensor_id, int rate_hz) {
    if (!mgr || !mgr->initialized) return ET_ERR_NULL_INPUT;
    if (sensor_id < 0 || sensor_id >= mgr->sensor_count) return ET_ERR_SENSOR;

#ifdef __ANDROID__
    et_direct_sensor_t *ds = &mgr->sensors[sensor_id];
    if (ds->active) return ET_OK; /* Already running */

    /* Try direct channel first */
    if (ds->direct_support >= ASENSOR_DIRECT_RATE_FAST) {
        /* Create hardware buffer for shared memory */
        AHardwareBuffer_Desc buf_desc = {
            .width = 4096,  /* 4KB — enough for ~39 sensor events (104 bytes each) */
            .height = 1,
            .layers = 1,
            .format = AHARDWAREBUFFER_FORMAT_BLOB,
            .usage = AHARDWAREBUFFER_USAGE_SENSOR_DIRECT_DATA |
                     AHARDWAREBUFFER_USAGE_CPU_READ_OFTEN,
        };

        int result = AHardwareBuffer_allocate(&buf_desc, &ds->hw_buffer);
        if (result == 0 && ds->hw_buffer) {
            /* Create direct channel */
            ds->channel_id = ASensorManager_createSharedMemoryDirectChannel(
                mgr->asensor_manager, ds->hw_buffer, 4096);

            if (ds->channel_id > 0) {
                /* Configure the sensor to write to the direct channel */
                int token = ASensorManager_configureDirectReport(
                    mgr->asensor_manager, ds->sensor, ds->channel_id,
                    ds->direct_rate);

                if (token > 0) {
                    ds->using_direct = 1;
                    ds->active = 1;

                    /* Map the buffer for reading */
                    AHardwareBuffer_lock(ds->hw_buffer,
                                          AHARDWAREBUFFER_USAGE_CPU_READ_OFTEN,
                                          -1, NULL, &ds->shared_mem);
                    ds->shared_mem_size = 4096;

                    LOGI("Sensor %d (%s): DIRECT CHANNEL started (token %d)",
                         sensor_id, ds->name, token);
                    return ET_OK;
                }
            }

            /* Direct channel failed — release buffer and fall through */
            AHardwareBuffer_release(ds->hw_buffer);
            ds->hw_buffer = NULL;
            ds->channel_id = -1;
        }
    }

    /* Fallback: ASensorEventQueue */
    ds->event_queue = ASensorManager_createEventQueue(
        mgr->asensor_manager, mgr->main_looper, 3 /* IDENT */, NULL, NULL);

    if (!ds->event_queue) {
        LOGE("Failed to create event queue for sensor %d", sensor_id);
        return ET_ERR_SENSOR;
    }

    /* Enable sensor at maximum rate */
    int delay_us = (rate_hz > 0) ? (1000000 / rate_hz) : ds->min_delay_us;
    if (delay_us < ds->min_delay_us) delay_us = ds->min_delay_us;

    ASensorEventQueue_enableSensor(ds->event_queue, ds->sensor);
    ASensorEventQueue_setEventRate(ds->event_queue, ds->sensor, delay_us);

    ds->using_direct = 0;
    ds->active = 1;
    snprintf(ds->access_mode, sizeof(ds->access_mode), "event_queue");

    LOGI("Sensor %d (%s): event queue started (delay %d µs)",
         sensor_id, ds->name, delay_us);
    return ET_OK;

#else
    (void)rate_hz;
    return ET_ERR_SENSOR;
#endif
}

et_error_t et_sensor_stop(et_sensor_manager_t *mgr, int sensor_id) {
    if (!mgr || !mgr->initialized) return ET_ERR_NULL_INPUT;
    if (sensor_id < 0 || sensor_id >= mgr->sensor_count) return ET_ERR_SENSOR;

#ifdef __ANDROID__
    et_direct_sensor_t *ds = &mgr->sensors[sensor_id];
    if (!ds->active) return ET_OK;

    if (ds->using_direct && ds->channel_id > 0) {
        /* Stop direct channel reporting */
        ASensorManager_configureDirectReport(
            mgr->asensor_manager, ds->sensor, ds->channel_id,
            ASENSOR_DIRECT_RATE_STOP);

        if (ds->shared_mem) {
            AHardwareBuffer_unlock(ds->hw_buffer, NULL);
            ds->shared_mem = NULL;
        }
        ASensorManager_destroyDirectChannel(mgr->asensor_manager, ds->channel_id);
        ds->channel_id = -1;
    }

    if (ds->event_queue) {
        ASensorEventQueue_disableSensor(ds->event_queue, ds->sensor);
        ASensorManager_destroyEventQueue(mgr->asensor_manager, ds->event_queue);
        ds->event_queue = NULL;
    }

    ds->active = 0;
    ds->using_direct = 0;
    LOGI("Sensor %d (%s): stopped", sensor_id, ds->name);
    return ET_OK;

#else
    return ET_ERR_SENSOR;
#endif
}

et_error_t et_sensor_start_all(et_sensor_manager_t *mgr) {
    if (!mgr) return ET_ERR_NULL_INPUT;
    for (int i = 0; i < mgr->sensor_count; i++) {
        et_sensor_start(mgr, i, 0); /* 0 = maximum rate */
    }
    return ET_OK;
}

et_error_t et_sensor_stop_all(et_sensor_manager_t *mgr) {
    if (!mgr) return ET_ERR_NULL_INPUT;
    for (int i = 0; i < mgr->sensor_count; i++) {
        et_sensor_stop(mgr, i);
    }
    return ET_OK;
}

/* ═══════════════════════════════════════════════════════════════════
 * EVENT POLLING
 * ═══════════════════════════════════════════════════════════════════ */
et_error_t et_sensor_poll(et_sensor_manager_t *mgr, int sensor_id,
                           et_sensor_event_t *events, int max_events,
                           int *count_out) {
    if (!mgr || !events || !count_out) return ET_ERR_NULL_INPUT;
    *count_out = 0;

#ifdef __ANDROID__
    /* Poll specific sensor or all */
    int start = (sensor_id >= 0) ? sensor_id : 0;
    int end = (sensor_id >= 0) ? sensor_id + 1 : mgr->sensor_count;

    for (int si = start; si < end && *count_out < max_events; si++) {
        et_direct_sensor_t *ds = &mgr->sensors[si];
        if (!ds->active) continue;

        if (ds->using_direct && ds->shared_mem) {
            /* Read from direct channel shared memory.
             *
             * Direct channel format: array of ASensorEvent structs (104 bytes each).
             * The atomic counter in each event increments for each new event.
             * We scan the buffer and read events with counter > last_seen.
             *
             * This is the RAWEST data path on Android — the sensor HAL
             * writes directly to this buffer, bypassing SensorService. */
            /* NOTE: Full direct channel parsing is hardware-specific.
             * The exact memory layout follows the sensors_event_t struct.
             * For production, read the atomic_counter field at offset 0
             * and parse the rest per the Android sensor_event_t spec. */

            /* Simplified polling: read the latest event from the buffer */
            ASensorEvent *buf = (ASensorEvent *)ds->shared_mem;
            /* Direct channel events are written sequentially.
             * The sequence number tells us which events are new. */
            /* For a production implementation, maintain a last_sequence counter
             * and read all events with sequence > last_sequence. */
        }

        if (ds->event_queue) {
            /* Poll event queue (non-blocking) */
            ASensorEvent ase;
            while (*count_out < max_events &&
                   ASensorEventQueue_getEvents(ds->event_queue, &ase, 1) > 0) {
                et_sensor_event_t *ev = &events[*count_out];
                ev->sensor_id = ds->sensor_id;
                ev->timestamp_ns = ase.timestamp;
                ev->from_direct = 0;
                ev->sequence = 0;

                /* Copy values based on sensor type */
                ev->value_count = ds->axes;
                for (int a = 0; a < ds->axes && a < 16; a++) {
                    ev->values[a] = ase.data[a];
                }

                (*count_out)++;
            }
        }
    }
    return ET_OK;

#else
    (void)sensor_id;
    (void)max_events;
    return ET_OK;
#endif
}

/* ═══════════════════════════════════════════════════════════════════
 * ADC RECOVERY — extract integer ADC value from float measurement
 *
 * Android reports sensor values as float32. To maintain zero-float64:
 *   adc_int = round(value / resolution)
 *   max_adc = round(max_range / resolution)
 *
 * This recovers the integer that the ADC actually produced,
 * undoing the float32 scaling that the HAL applied.
 * ═══════════════════════════════════════════════════════════════════ */
et_error_t et_sensor_to_adc(const et_direct_sensor_t *sensor,
                              float value, long *adc_out, long *max_out) {
    if (!sensor || !adc_out || !max_out) return ET_ERR_NULL_INPUT;

    if (sensor->resolution <= 0) {
        /* Cannot recover ADC — use the float value directly as a string.
         * This is the fallback path. The float32 has ~7 decimal digits
         * of precision, which is far less than WORK_DPS=400, but it's
         * the best we can get without direct ADC access. */
        *adc_out = (long)roundf(value * 32768.0f); /* Assume 16-bit */
        *max_out = 32768;
        return ET_OK;
    }

    /* Recover the ADC integer: adc = round(value / resolution) */
    *adc_out = (long)roundf(value / sensor->resolution);
    *max_out = (long)roundf(sensor->max_range / sensor->resolution);

    return ET_OK;
}

/* ═══════════════════════════════════════════════════════════════════
 * HARDWARE REPORT
 * ═══════════════════════════════════════════════════════════════════ */
void et_sensor_manager_print_report(const et_sensor_manager_t *mgr) {
    if (!mgr) return;

    LOGI("╔══════════════════════════════════════════════════════════════╗");
    LOGI("║   ET LOSSLESS SENSOR CAPTURE — HARDWARE REPORT             ║");
    LOGI("║   Direct access to phone hardware via NDK                  ║");
    LOGI("╚══════════════════════════════════════════════════════════════╝");
    LOGI("  Total hardware sensors: %d", mgr->sensor_count);

    for (int i = 0; i < mgr->sensor_count; i++) {
        const et_direct_sensor_t *ds = &mgr->sensors[i];
        const char *type_name = (ds->sensor_type < ET_SENSOR_TYPE_COUNT) ?
            ET_SENSOR_TYPE_NAMES[ds->sensor_type] : "UNKNOWN";

        LOGI("  [%d] %s (%s)", ds->sensor_id, ds->name, type_name);
        LOGI("      Vendor: %s", ds->vendor);
        LOGI("      Access: %s", ds->access_mode);
        LOGI("      Rate: %d Hz, Depth: ~%d bit", ds->sample_rate_hz, ds->bit_depth);
        LOGI("      Resolution: %.9f, Range: ±%.3f", ds->resolution, ds->max_range);
        LOGI("      Axes: %d, Bipolar: %s", ds->axes, ds->is_bipolar ? "yes" : "no");
    }
}
