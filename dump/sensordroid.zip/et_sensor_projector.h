/*
 * ET LOSSLESS SENSOR CAPTURE — SENSOR PROJECTOR
 * ===============================================
 * Parameterizes the universal bijection Π_N per sensor type.
 * Each sensor gets its own R₀ derived from its P-substrate.
 * The bijection itself is IDENTICAL for all sensors — only R₀ changes.
 * This is the Multifold of Lattices: one lattice, many seeds.
 *
 * Author: Michael James Muller — Aevum Defluo (Exception Theory)
 * License: CC-BY-4.0
 */

#ifndef ET_SENSOR_PROJECTOR_H
#define ET_SENSOR_PROJECTOR_H

#include "et_bijection.h"

/* ═══════════════════════════════════════════════════════════════════
 * SENSOR PROJECTOR CONTEXT
 * One instance per active sensor. Wraps et_projector_t with R₀.
 * ═══════════════════════════════════════════════════════════════════ */
typedef struct {
    et_sensor_type_t sensor_type;    /* Sensor classification */
    et_projector_t   projector;      /* The universal projector at resolution N */
    char             R0_str[512];    /* R₀ as string (full precision) */
    mpfr_t           R0;            /* R₀ as MPFR */
    int              axes;          /* Number of axes (1=scalar, 3=vector) */
    int              is_bipolar;    /* 1 if values can be negative */
    int              sample_rate;   /* Sensor sample rate in Hz */
    int              bit_depth;     /* ADC bit depth */
    char             sensor_name[128]; /* Human-readable sensor name */
    char             access_mode[64];  /* "direct_channel", "event_queue", etc. */
} et_sensor_projector_t;

/* ═══════════════════════════════════════════════════════════════════
 * SENSOR SAMPLE — the complete per-sample output
 * ═══════════════════════════════════════════════════════════════════ */
typedef struct {
    et_projection_t  projection;      /* The lattice coordinates */
    int              axis;            /* Axis index (0=x/mono, 1=y, 2=z) */
    long long        timestamp_ns;    /* Monotonic nanosecond timestamp */
    int              sensor_id;       /* Sensor identifier */
    et_sensor_type_t sensor_type;     /* Sensor type */

    /* Tracking metadata (from differential tracker) */
    int              tracking_source; /* 0=initial, 1=predicted, 2=override */
    int              escalated;       /* 1 if ∂I escalation was triggered */
    int              escalated_N;     /* Resolution after escalation */
} et_sensor_sample_t;

/* ═══════════════════════════════════════════════════════════════════
 * LIFECYCLE
 * ═══════════════════════════════════════════════════════════════════ */

/*
 * Initialize a sensor projector for a specific sensor type.
 * Uses the default R₀ for the sensor type (from et_constants.h).
 *
 * Parameters:
 *   sp          — sensor projector to initialize
 *   sensor_type — type of sensor (from et_sensor_type_t)
 *   N           — lattice resolution (default: 12)
 *   prec        — MPFR precision in bits (default: ET_MPFR_BITS)
 */
et_error_t et_sensor_projector_init(et_sensor_projector_t *sp,
                                     et_sensor_type_t sensor_type,
                                     int N, mpfr_prec_t prec);

/*
 * Initialize with a custom R₀ (for non-default reference values).
 */
et_error_t et_sensor_projector_init_custom(et_sensor_projector_t *sp,
                                            et_sensor_type_t sensor_type,
                                            const char *R0_str,
                                            int N, mpfr_prec_t prec);

/*
 * Free all resources.
 */
void et_sensor_projector_clear(et_sensor_projector_t *sp);

/* ═══════════════════════════════════════════════════════════════════
 * PROJECTION OPERATIONS
 * ═══════════════════════════════════════════════════════════════════ */

/*
 * Project a single sensor measurement.
 *
 * For scalar sensors: value_str is the single measurement.
 * For bipolar sensors: value_str may be negative (handled via sign decomposition).
 * For vector sensors: call once per axis with the appropriate axis index.
 *
 * Parameters:
 *   sp          — initialized sensor projector
 *   value_str   — string representation of the measurement (zero float64 chain)
 *   axis        — axis index (0 for scalar, 0/1/2 for x/y/z)
 *   timestamp_ns — monotonic nanosecond timestamp
 *   sample      — output sample (projection + metadata)
 */
et_error_t et_sensor_project(const et_sensor_projector_t *sp,
                              const char *value_str, int axis,
                              long long timestamp_ns,
                              et_sensor_sample_t *sample);

/*
 * Reconstruct the original measurement from a sensor sample.
 *
 * Parameters:
 *   sp      — initialized sensor projector (must match the one used for projection)
 *   sample  — the sensor sample to reconstruct
 *   value_out — output: reconstructed value (must be initialized MPFR)
 */
et_error_t et_sensor_reconstruct(const et_sensor_projector_t *sp,
                                  const et_sensor_sample_t *sample,
                                  mpfr_t value_out);

/*
 * Project an integer ADC value directly (zero float64 shortcut).
 *
 * For sensors that report integer ADC values (accelerometer, camera):
 *   value_str = "adc_int/max_int" (e.g., "1234/32768")
 *
 * This maintains the zero-float64 chain from ADC integer to lattice.
 */
et_error_t et_sensor_project_adc(const et_sensor_projector_t *sp,
                                  long adc_value, long max_value,
                                  int axis, long long timestamp_ns,
                                  et_sensor_sample_t *sample);

/* ═══════════════════════════════════════════════════════════════════
 * SENSOR DISCOVERY — enumerate available hardware
 * ═══════════════════════════════════════════════════════════════════ */

/* Maximum number of sensors the app tracks */
#define ET_MAX_SENSORS 64

typedef struct {
    int              sensor_id;
    et_sensor_type_t sensor_type;
    char             name[128];
    char             vendor[64];
    float            resolution;      /* LSB value */
    float            max_range;       /* Maximum measurement */
    int              min_delay_us;    /* Minimum delay (= max rate) */
    int              fifo_max;        /* Hardware FIFO size */
    int              direct_channel;  /* 1 if Direct Channel supported */
    int              highest_rate;    /* ASENSOR_DIRECT_RATE_xxx */
    int              axes;            /* Number of output axes */
    int              is_bipolar;      /* 1 if values can be negative */
} et_sensor_info_t;

typedef struct {
    et_sensor_info_t sensors[ET_MAX_SENSORS];
    int              count;
    int              best_accel_id;    /* ID of best accelerometer */
    int              best_gyro_id;     /* ID of best gyroscope */
    int              best_mag_id;      /* ID of best magnetometer */
    int              best_baro_id;     /* ID of best barometer */
    int              best_light_id;    /* ID of best light sensor */
    int              audio_available;  /* 1 if audio input available */
    int              camera_raw_available; /* 1 if Camera2 RAW available */
    int              gps_available;    /* 1 if GPS available */
} et_sensor_inventory_t;

#endif /* ET_SENSOR_PROJECTOR_H */
