// ═══════════════════════════════════════════════════════════════════
//  ET SITE FORGE — C++ MPFR — www.ExceptionTheory.com
// ═══════════════════════════════════════════════════════════════════
//  The AUTHORITATIVE forge. Supersedes et_site_forge.py (retained as an
//  independent cross-check). Everything on the page — every color,
//  length, duration, keyframe stop, breakpoint, and opacity — is a
//  lattice address, forward-derived from the ET constants, computed in
//  MPFR (correctly-rounded arbitrary precision, GNU MPFR/GMP), carried
//  as decimal STRINGS end to end, and re-verified by projection before
//  the build is permitted to exist.
//
//  TOTALITY RULE (Mike, 2026-07-12): Shannon, Nyquist, IEEE, float,
//  Taylor-series-grade approximation frameworks are FORBIDDEN without
//  exception, in totality. Consequently:
//    • This translation unit contains NO float and NO double. All real
//      arithmetic is mpfr_t at PREC bits derived from the digit budget.
//    • The emitted site contains NO JavaScript. The living starfield is
//      declarative text: CSS keyframes whose every stop is an exact
//      MPFR-computed decimal string. Nothing in our chain ever
//      instantiates an IEEE value; the deliverable is strings.
//    • The bijection Π_N(r) = (k, d, ε) is lossless for ANY positive
//      real — rational, irrational, transcendental — because ε is the
//      exact residue N·log₂r − k by algebraic identity (IC-1;
//      verify_lossless_bijection.py proves it symbolically and by
//      precision scaling). MPFR realizes it computationally to the
//      digit budget; the precision-scaling witness below reproduces
//      that proof in C++.
//    • Canon integrated 2026-07-12 from uploads: the lossless test is
//      string-truncation equality at WORK digits with guard digits
//      above (et_lossless_microphone.py); the field twinkle is the
//      Shimmer Identity Ψ_j = 1+√V·sin(2πj/N) weighted by the
//      impedance hierarchy w(d) = ξ(d)/ξ(1) (fractal_lattice_identity.py,
//      Identities R.2 + M/H); Λ = 1200/ln2 and Λ_θ = 600/π join the
//      constants ledger (Thms B.5, D.5). Batch-2 mining adds in-forge
//      checks for Identities A (κ lattice arithmetic), B (finite ε-shift),
//      C.4 (universal d=1 channel), B.3/F.2 (palindrome + adjacency),
//      Finding-11/E2 (ε=0 ⟹ d invariant across the tower), and the R.4
//      cascade sums — with A₀ now DERIVED as (N−1)² + S².
//    • COMPLETE ERROR HANDLING (v3.2): verify-before-write — every
//      artifact is built in memory, all checks must pass BEFORE any file
//      is created, so a failing build leaves dist/ untouched (failed
//      report → VERIFICATION_REPORT_FAILED.txt). Every MPFR parse,
//      finiteness, long-fit, projection domain, hex parse/emit,
//      directory, write (size-verified), and template substitution is
//      explicitly checked; any failure aborts loudly with context.
//      Exit codes: 0 verified+emitted · 1 checks failed, nothing
//      written · 2 fatal error, nothing written.
//
//  Canon: IC-1, IC-143 (ƛ_e), SIC-39/K.9.B (k IS chromaticity),
//  IC-117/K.8.d (D65 white = identity cell), Identity F (∂I = 600/N ¢),
//  Identity H (ξ), complex-lattice U(1) hue circle, generators {1,5,7,11}.
//  Constants: N=12, V=1/12, K=2/3, |Π|=3, S=4, A₀=137.
//  Sempaevum DOI: 10.5281/zenodo.19762311.
//
//  Build:  g++ -std=c++17 -O2 -Wall -o et_site_forge et_site_forge.cpp -lmpfr -lgmp
//  Run:    ./et_site_forge          (writes dist/, verifies, exits 1 on
//                                    any failed check)
//
//  Author: forged for Michael James Muller — Aevum Defluo
//          Exception Theory LLC — P ∘ D ∘ T = E
// ═══════════════════════════════════════════════════════════════════
#include <mpfr.h>
#include <gmp.h>
#include <string>
#include <vector>
#include <array>
#include <map>
#include <set>
#include <numeric>
#include <fstream>
#include <sstream>
#include <iostream>
#include <sys/stat.h>
#ifdef _WIN32
  #define NOMINMAX
  #define WIN32_LEAN_AND_MEAN
  #include <windows.h>
  #include <direct.h>
  #define ET_MKDIR(p) _mkdir(p)
  #define ET_RMDIR(p) _rmdir(p)
  #ifndef S_ISDIR
    #define S_ISDIR(m) (((m) & _S_IFMT) == _S_IFDIR)
  #endif
#else
  #include <unistd.h>
  #define ET_MKDIR(p) mkdir(p, 0755)
  #define ET_RMDIR(p) rmdir(p)
#endif
#include <ctime>
#include <cstdlib>
#include <cstring>
#include <cerrno>
#include <cctype>
#include <cstdio>
#include <algorithm>
#include "cie_observer_data.hpp"

// ─── precision ───────────────────────────────────────────────────────
static const long DIGITS = 250;                    // Ω standard: 200 working + 50 guard (canon)
static const long WORK_DIGITS = 200;               // string-equality comparisons at working digits
static mpfr_prec_t bits_for(long digits) {         // bits ≈ digits·log2(10)
    return (mpfr_prec_t)(digits * 3322L / 1000L + 64L);
}
static mpfr_prec_t G_PREC = bits_for(DIGITS);

// ─── console visibility: a double-clicked run must be READABLE ───────
// When launched from Explorer the process owns its console; it closes
// the instant we exit, hiding the 179-line report. Detect sole
// ownership and hold for Enter so the human sees the proof.
// ─── ALWAYS-ON RUN LOG — console visibility can never hide a run ─────
// Everything written to stdout/stderr is simultaneously appended to
// forge_run.log in the working directory. A run therefore ALWAYS
// leaves complete written evidence, even if the console window is
// swallowed, closed, or never readable. On Windows an unhandled
// native exception appends a [CRASH] line before the process dies.
class TeeBuf : public std::streambuf {
    std::streambuf* con_; std::streambuf* file_;
public:
    TeeBuf(std::streambuf* con, std::streambuf* file) : con_(con), file_(file) {}
protected:
    int overflow(int c) override {
        if (c == EOF) return !EOF;
        if (con_)  con_->sputc((char)c);
        if (file_) { file_->sputc((char)c); if (c == '\n') file_->pubsync(); }
        return c;
    }
    int sync() override {
        if (con_) con_->pubsync();
        if (file_) file_->pubsync();
        return 0;
    }
};
static std::ofstream G_LOGF;
#ifdef _WIN32
static LONG WINAPI et_crash_filter(EXCEPTION_POINTERS* ep) {
    FILE* f = std::fopen("forge_run.log", "a");
    if (f) {
        std::fprintf(f, "\n[CRASH] unhandled Windows exception 0x%08lX at %p — "
                        "process terminating before normal completion\n",
                     (unsigned long)(ep && ep->ExceptionRecord
                                     ? ep->ExceptionRecord->ExceptionCode : 0),
                     (void*)(ep && ep->ExceptionRecord
                             ? ep->ExceptionRecord->ExceptionAddress : nullptr));
        std::fflush(f); std::fclose(f);
    }
    return EXCEPTION_CONTINUE_SEARCH;
}
#endif
static void init_logging() {
#ifdef _WIN32
    // The report uses ε, ¢, π, Ψ, —. Legacy consoles decode through the
    // OEM codepage (CP437) and render them as ╬╡/┬ó/╧Ç/ΓÇö garbage.
    // Force the console to UTF-8 so the LIVE window is readable too.
    SetConsoleOutputCP(CP_UTF8);
#endif
    G_LOGF.open("forge_run.log", std::ios::binary | std::ios::trunc);
    if (G_LOGF) {
        G_LOGF << "\xEF\xBB\xBF";   // UTF-8 BOM: every editor detects encoding
        static TeeBuf tee_out(std::cout.rdbuf(), G_LOGF.rdbuf());
        static TeeBuf tee_err(std::cerr.rdbuf(), G_LOGF.rdbuf());
        std::cout.rdbuf(&tee_out);
        std::cerr.rdbuf(&tee_err);
    }
    std::time_t t = std::time(nullptr);
    char ts[32] = "unknown-time";
    if (std::tm* tv = std::localtime(&t))
        std::strftime(ts, sizeof ts, "%Y-%m-%d %H:%M:%S", tv);
    std::cout << "ET SITE FORGE run @ " << ts
              << " — this entire run is also being saved to forge_run.log\n"
              << std::flush;
#ifdef _WIN32
    SetUnhandledExceptionFilter(et_crash_filter);
#endif
}
static void hold_console_for_reader() {
#ifdef _WIN32
    unsigned long pids[2];
    if (GetConsoleProcessList(pids, 2) == 1) {
        std::cout << "\n  (Launched by double-click — the full report is above."
                     " Press Enter to close.)\n";
        std::cin.get();
    }
#endif
}

// ─── COMPLETE ERROR HANDLING — the fatal contract ────────────────────
// Exit codes: 0 = all checks passed AND all files emitted+verified;
//             1 = verification failed — dist/ untouched, failed report
//                 written to VERIFICATION_REPORT_FAILED.txt in the CWD;
//             2 = fatal environment/internal error — nothing written.
// Every failure names its exact context; no silent path exists.
[[noreturn]] static void fatal(const std::string& what) {
    int e = errno;
    std::cerr << "\n[FATAL] " << what;
    if (e) std::cerr << "  (last errno " << e << ": " << std::strerror(e) << ")";
    std::cerr << "\n[FATAL] Build aborted; no site files were written or altered.\n"
                 "[FATAL] Complete log of this run: forge_run.log\n";
    hold_console_for_reader();
    std::exit(2);
}

// ─── Mp: RAII arbitrary-precision real (strings in, strings out) ─────
struct Mp {
    mpfr_t v;
    Mp()                       { mpfr_init2(v, G_PREC); mpfr_set_zero(v, 1); }
    struct Prec { mpfr_prec_t p; };
    explicit Mp(Prec pr)       { mpfr_init2(v, pr.p);   mpfr_set_zero(v, 1); }
    Mp(const char* s)          { mpfr_init2(v, G_PREC);
        if (!s || mpfr_set_str(v, s, 10, MPFR_RNDN) != 0 || !mpfr_number_p(v))
            fatal(std::string("Mp: invalid decimal literal \"") + (s ? s : "<null>") + "\"");
    }
    Mp(const std::string& s)   { mpfr_init2(v, G_PREC);
        if (mpfr_set_str(v, s.c_str(), 10, MPFR_RNDN) != 0 || !mpfr_number_p(v))
            fatal("Mp: invalid decimal literal \"" + s + "\"");
    }
    Mp(long n)                 { mpfr_init2(v, G_PREC); mpfr_set_si(v, n, MPFR_RNDN); }
    Mp(const Mp& o)            { mpfr_init2(v, mpfr_get_prec(o.v)); mpfr_set(v, o.v, MPFR_RNDN); }
    Mp(Mp&& o) noexcept        { mpfr_init2(v, mpfr_get_prec(o.v)); mpfr_swap(v, o.v); }
    Mp& operator=(const Mp& o) { if (this != &o) mpfr_set(v, o.v, MPFR_RNDN); return *this; }
    Mp& operator=(Mp&& o) noexcept { if (this != &o) mpfr_swap(v, o.v); return *this; }
    ~Mp()                      { mpfr_clear(v); }
};
#define MPOP(name, fn) \
    static Mp name(const Mp& a, const Mp& b) { Mp r(Mp::Prec{std::max(mpfr_get_prec(a.v), mpfr_get_prec(b.v))}); fn(r.v, a.v, b.v, MPFR_RNDN); return r; }
MPOP(add, mpfr_add) MPOP(sub, mpfr_sub) MPOP(mul, mpfr_mul) MPOP(dive, mpfr_div)
static Mp operator+(const Mp& a, const Mp& b) { return add(a, b); }
static Mp operator-(const Mp& a, const Mp& b) { return sub(a, b); }
static Mp operator*(const Mp& a, const Mp& b) { return mul(a, b); }
static Mp operator/(const Mp& a, const Mp& b) { return dive(a, b); }
static Mp neg(const Mp& a) { Mp r(Mp::Prec{mpfr_get_prec(a.v)}); mpfr_neg(r.v, a.v, MPFR_RNDN); return r; }
static int cmp(const Mp& a, const Mp& b) { return mpfr_cmp(a.v, b.v); }
static bool lt (const Mp& a, const Mp& b) { return cmp(a, b) <  0; }
static bool le (const Mp& a, const Mp& b) { return cmp(a, b) <= 0; }
static Mp mabs(const Mp& a) { Mp r(Mp::Prec{mpfr_get_prec(a.v)}); mpfr_abs(r.v, a.v, MPFR_RNDN); return r; }
static Mp mmin(const Mp& a, const Mp& b) { return lt(a, b) ? a : b; }
static Mp mmax(const Mp& a, const Mp& b) { return lt(a, b) ? b : a; }
static Mp log2m(const Mp& a)  { Mp r(Mp::Prec{mpfr_get_prec(a.v)}); mpfr_log2(r.v, a.v, MPFR_RNDN); return r; }
static Mp exp2m(const Mp& a)  { Mp r(Mp::Prec{mpfr_get_prec(a.v)}); mpfr_exp2(r.v, a.v, MPFR_RNDN); return r; }
static Mp powm(const Mp& a, const Mp& b) { Mp r(Mp::Prec{std::max(mpfr_get_prec(a.v), mpfr_get_prec(b.v))}); mpfr_pow(r.v, a.v, b.v, MPFR_RNDN); return r; }
static Mp sinm(const Mp& a)   { Mp r(Mp::Prec{mpfr_get_prec(a.v)}); mpfr_sin(r.v, a.v, MPFR_RNDN); return r; }
static Mp cosm(const Mp& a)   { Mp r(Mp::Prec{mpfr_get_prec(a.v)}); mpfr_cos(r.v, a.v, MPFR_RNDN); return r; }
static Mp hypotm(const Mp& a, const Mp& b) { Mp r(Mp::Prec{std::max(mpfr_get_prec(a.v), mpfr_get_prec(b.v))}); mpfr_hypot(r.v, a.v, b.v, MPFR_RNDN); return r; }
static Mp cbrtm(const Mp& a)  { Mp r(Mp::Prec{mpfr_get_prec(a.v)}); mpfr_cbrt(r.v, a.v, MPFR_RNDN); return r; }
static Mp sqrtm(const Mp& a)  { Mp r(Mp::Prec{mpfr_get_prec(a.v)}); mpfr_sqrt(r.v, a.v, MPFR_RNDN); return r; }
static Mp pi_m(mpfr_prec_t p = 0) { Mp r(Mp::Prec{p ? p : G_PREC}); mpfr_const_pi(r.v, MPFR_RNDN); return r; }
static Mp rint_m(const Mp& a) { Mp r(Mp::Prec{mpfr_get_prec(a.v)}); mpfr_rint(r.v, a.v, MPFR_RNDN); return r; }  // ties-to-even, as canon nint
static Mp floorm(const Mp& a) { Mp r(Mp::Prec{mpfr_get_prec(a.v)}); mpfr_floor(r.v, a.v); return r; }
static long to_long(const Mp& a) {
    if (!mpfr_number_p(a.v)) fatal("to_long: non-finite value");
    if (!mpfr_fits_slong_p(a.v, MPFR_RNDN)) fatal("to_long: value exceeds long range");
    return mpfr_get_si(a.v, MPFR_RNDN);
}
static bool is_zero(const Mp& a) { return mpfr_zero_p(a.v); }

// ─── decimal string emission (plain; auto-sci for extremes) ──────────
static std::string dec(const Mp& a, int digits) {
    if (!mpfr_number_p(a.v))
        fatal("dec: non-finite value (NaN/Inf) reached emission — an upstream "
              "computation is invalid; nothing may be emitted from it");
    if (digits < 1) fatal("dec: digits must be >= 1");
    if (mpfr_zero_p(a.v)) return "0";
    mpfr_exp_t e;
    char* raw = mpfr_get_str(nullptr, &e, 10, (size_t)digits, a.v, MPFR_RNDN);
    std::string m(raw); mpfr_free_str(raw);
    bool negv = (!m.empty() && m[0] == '-');
    if (negv) m.erase(0, 1);
    // strip trailing zeros of the mantissa (keep ≥1 digit)
    size_t last = m.find_last_not_of('0');
    if (last == std::string::npos) last = 0;
    m.erase(last + 1);
    std::string out;
    long L = (long)m.size();
    if (e < -6 || e > digits + 6) {              // scientific for extremes
        out = m.substr(0, 1);
        if (L > 1) out += "." + m.substr(1);
        out += "e" + std::to_string((long)e - 1);
    } else if (e <= 0) {
        out = "0." + std::string((size_t)(-e), '0') + m;
    } else if (e >= L) {
        out = m + std::string((size_t)(e - L), '0');
    } else {
        out = m.substr(0, (size_t)e) + "." + m.substr((size_t)e);
    }
    return (negv ? "-" : "") + out;
}

// ─── string helpers ──────────────────────────────────────────────────
static void replace_all(std::string& s, const std::string& a, const std::string& b) {
    size_t p = 0;
    while ((p = s.find(a, p)) != std::string::npos) { s.replace(p, a.size(), b); p += b.size(); }
}
static std::string jstr(const std::string& s) {  // JSON string escape (our data is tame)
    std::string o = "\"";
    for (char c : s) { if (c == '"' || c == '\\') o += '\\'; o += c; }
    return o + "\"";
}

// ═════════════════════════════════════════════════════════════════════
//  ET CONSTANTS — the only inputs
// ═════════════════════════════════════════════════════════════════════
static const long N = 12, PI_COUNT = 3, S_STATES = 4;
static const long A0 = (N - 1) * (N - 1) + S_STATES * S_STATES;  // 137 — derived: A₀ = (N−1)² + S² (canon)
static const Mp V     = Mp(1L) / Mp(N);
static const Mp Kk    = Mp(2L) / Mp(3L);
static const Mp CENTS("1200");
static const Mp DI_CENTS = Mp("600") / Mp(N);        // Identity F: 50¢
static const Mp LAMBDA_E_NM("0.38615926796");        // IC-143 (fm→nm)
static std::vector<long> GENERATORS, DIVISORS;       // derived in main-init

static Mp xi_fn(long d) { Mp dd(d); return Mp(A0) / ((dd - Mp(1L)) * (dd - Mp(1L)) + Mp(S_STATES * S_STATES)); }
static Mp ln2_m() { Mp r; mpfr_const_log2(r.v, MPFR_RNDN); return r; }
static const Mp& Lambda()      { static const Mp L = CENTS / ln2_m();   return L; }  // Λ = 1200/ln2 (Thm B.5)
static const Mp& LambdaTheta() { static const Mp L = Mp("600") / pi_m(); return L; } // Λ_θ = 600/π (Thm D.5)

// ═════════════════════════════════════════════════════════════════════
//  THE BIJECTION (IC-1) — with per-call precision for the witness
// ═════════════════════════════════════════════════════════════════════
struct Proj { long k; long d; Mp eps; };
static Proj project_p(const Mp& r, mpfr_prec_t prec) {
    if (!mpfr_number_p(r.v) || mpfr_sgn(r.v) <= 0)
        fatal("project: r must be a finite positive real — r <= 0 is the "
              "annihilation boundary (§7.3), excluded from Π_N by construction");
    Mp exact(Mp::Prec{prec}); { Mp lr(Mp::Prec{prec}); mpfr_log2(lr.v, r.v, MPFR_RNDN);
                      mpfr_mul_si(exact.v, lr.v, N, MPFR_RNDN); }
    Mp kr = rint_m(exact);
    long k = to_long(kr);
    long g = (k != 0) ? std::gcd(std::labs(k), N) : N;
    long d = N / g;
    Mp eps = (exact - Mp(k)) * CENTS / Mp(N);
    return {k, d, eps};
}
static Proj project(const Mp& r) { return project_p(r, G_PREC); }
static Mp pullback(long k, const Mp& eps) {          // 2^((k+ε·N/1200)/N)
    return exp2m((Mp(k) + eps * Mp(N) / CENTS) / Mp(N));
}
static Mp lattice(long k) { return exp2m(Mp(k) / Mp(N)); }

// ═════════════════════════════════════════════════════════════════════
//  TRANSLATION LAYER (CIE observer → sRGB device) — frozen strings
// ═════════════════════════════════════════════════════════════════════
struct Tri { Mp a, b, c; };
static std::vector<std::array<Mp,4>> CMF;
static Mp D65x, D65y, Xn, Yn, Zn;
static Mp MX2R[3][3], MR2X[3][3];
static const Mp CIE_EPS = Mp("216") / Mp("24389");
static const Mp CIE_KAP = Mp("24389") / Mp("27");

static void init_translation() {
    for (int i = 0; i < CMF_N; ++i)
        CMF.push_back({Mp((long)CMF_ROWS[i].nm), Mp(CMF_ROWS[i].x),
                       Mp(CMF_ROWS[i].y), Mp(CMF_ROWS[i].z)});
    D65x = Mp(D65_X); D65y = Mp(D65_Y_);
    Xn = Mp(WPT[0]); Yn = Mp(WPT[1]); Zn = Mp(WPT[2]);
    for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) {
        MX2R[i][j] = Mp(M_X2R[i][j]); MR2X[i][j] = Mp(M_R2X[i][j]);
    }
}
static Tri cmf_at(const Mp& lam) {
    if (le(lam, CMF.front()[0])) return {CMF.front()[1], CMF.front()[2], CMF.front()[3]};
    if (le(CMF.back()[0], lam))  return {CMF.back()[1],  CMF.back()[2],  CMF.back()[3]};
    long idx = to_long(floorm((lam - CMF.front()[0]) / Mp(5L)));
    const auto& r0 = CMF[(size_t)idx]; const auto& r1 = CMF[(size_t)idx + 1];
    Mp t = (lam - r0[0]) / (r1[0] - r0[0]);
    return {r0[1] + (r1[1] - r0[1]) * t,
            r0[2] + (r1[2] - r0[2]) * t,
            r0[3] + (r1[3] - r0[3]) * t};
}
static void xyz_to_xy(const Tri& X, Mp& x, Mp& y) { Mp s = X.a + X.b + X.c; x = X.a / s; y = X.b / s; }
static Tri xy_Y_to_xyz(const Mp& x, const Mp& y, const Mp& Y) {
    return {x * Y / y, Y, (Mp(1L) - x - y) * Y / y};
}
static Mp L_to_Y(const Mp& L) {
    Mp fy = (L + Mp(16L)) / Mp(116L), f3 = fy * fy * fy;
    if (lt(CIE_EPS, f3)) return Yn * f3;
    return Yn * (Mp(116L) * fy - Mp(16L)) / CIE_KAP;
}
static Mp f_lab(const Mp& t) {
    if (lt(CIE_EPS, t)) return cbrtm(t);
    return (CIE_KAP * t + Mp(16L)) / Mp(116L);
}
static void xyz_to_lab(const Tri& X, Mp& L, Mp& a, Mp& b) {
    Mp fx = f_lab(X.a / Xn), fy = f_lab(X.b / Yn), fz = f_lab(X.c / Zn);
    L = Mp(116L) * fy - Mp(16L); a = Mp(500L) * (fx - fy); b = Mp(200L) * (fy - fz);
}
static Mp inv_f(const Mp& f) {
    Mp f3 = f * f * f;
    if (lt(CIE_EPS, f3)) return f3;
    return (Mp(116L) * f - Mp(16L)) / CIE_KAP;
}
static Tri lab_to_xyz(const Mp& L, const Mp& a, const Mp& b) {
    Mp fy = (L + Mp(16L)) / Mp(116L), fx = fy + a / Mp(500L), fz = fy - b / Mp(200L);
    return {inv_f(fx) * Xn, inv_f(fy) * Yn, inv_f(fz) * Zn};
}
static Tri xyz_to_lin(const Tri& X) {
    Tri r; Mp* o[3] = {&r.a, &r.b, &r.c};
    const Mp* in[3] = {&X.a, &X.b, &X.c};
    for (int i = 0; i < 3; ++i)
        *o[i] = MX2R[i][0] * *in[0] + MX2R[i][1] * *in[1] + MX2R[i][2] * *in[2];
    return r;
}
static Tri lin_to_xyz(const Tri& R) {
    Tri r; Mp* o[3] = {&r.a, &r.b, &r.c};
    const Mp* in[3] = {&R.a, &R.b, &R.c};
    for (int i = 0; i < 3; ++i)
        *o[i] = MR2X[i][0] * *in[0] + MR2X[i][1] * *in[1] + MR2X[i][2] * *in[2];
    return r;
}
static Mp gamma_enc(const Mp& c) {
    if (le(c, Mp("0.0031308"))) return Mp("12.92") * c;
    return Mp("1.055") * powm(c, Mp(1L) / Mp("2.4")) - Mp("0.055");
}
static Mp gamma_dec(const Mp& c) {
    if (le(c, Mp("0.04045"))) return c / Mp("12.92");
    return powm((c + Mp("0.055")) / Mp("1.055"), Mp("2.4"));
}
static bool in_gamut(const Tri& R) {
    static const Mp tol("1e-12"); static const Mp one_p = Mp(1L) + tol; static const Mp z_m = neg(tol);
    const Mp* ch[3] = {&R.a, &R.b, &R.c};
    for (int i = 0; i < 3; ++i) if (lt(*ch[i], z_m) || lt(one_p, *ch[i])) return false;
    return true;
}
static Mp clamp01(const Mp& c) { return mmin(mmax(c, Mp(0L)), Mp(1L)); }
static std::string lin_to_hex(const Tri& R) {
    char buf[8]; long o[3]; const Mp* ch[3] = {&R.a, &R.b, &R.c};
    for (int i = 0; i < 3; ++i) {
        o[i] = to_long(rint_m(gamma_enc(clamp01(*ch[i])) * Mp(255L)));
        if (o[i] < 0 || o[i] > 255)
            fatal("lin_to_hex: channel " + std::to_string(i) + " out of [0,255]: "
                  + std::to_string(o[i]));
    }
    if (std::snprintf(buf, sizeof buf, "#%02lx%02lx%02lx", o[0], o[1], o[2]) != 7)
        fatal("lin_to_hex: hex formatting failed");
    return buf;
}
static Tri hex_to_xyz(const std::string& hx) {
    if (hx.size() != 7 || hx[0] != '#')
        fatal("hex_to_xyz: malformed color \"" + hx + "\" (want #rrggbb)");
    for (int i = 1; i < 7; ++i)
        if (!std::isxdigit((unsigned char)hx[(size_t)i]))
            fatal("hex_to_xyz: non-hex digit in \"" + hx + "\"");
    auto byte_at = [&](int i) {
        char* end = nullptr;
        std::string two = hx.substr((size_t)i, 2);
        long vv = std::strtol(two.c_str(), &end, 16);
        if (!end || *end != '\0' || vv < 0 || vv > 255)
            fatal("hex_to_xyz: channel parse failed in \"" + hx + "\"");
        return vv;
    };
    long r = byte_at(1), g = byte_at(3), b = byte_at(5);
    Tri lin{gamma_dec(Mp(r) / Mp(255L)), gamma_dec(Mp(g) / Mp(255L)), gamma_dec(Mp(b) / Mp(255L))};
    return lin_to_xyz(lin);
}

// ═════════════════════════════════════════════════════════════════════
//  SPECTRAL PALETTE — visible octave k=120…130 + purple line (class 11)
// ═════════════════════════════════════════════════════════════════════
static const Mp ACCENT_L = Kk * Mp(100L);            // '-even' equiluminant law
static const long K_BASE = N * 10;                   // violet: 10 exact octaves above ƛ_e

static Mp gamut_pull(const Mp& x, const Mp& y, const Mp& L, Tri& out, int iters = 96) {
    Mp Yt = L_to_Y(L);
    auto rgb_at = [&](const Mp& t) {
        Mp xt = x + (D65x - x) * t, yt = y + (D65y - y) * t;
        return xyz_to_lin(xy_Y_to_xyz(xt, yt, Yt));
    };
    Tri z = rgb_at(Mp(0L));
    if (in_gamut(z)) { out = z; return Mp(0L); }
    Mp lo(0L), hi(1L);
    for (int i = 0; i < iters; ++i) {
        Mp mid = (lo + hi) / Mp(2L);
        if (in_gamut(rgb_at(mid))) hi = mid; else lo = mid;
    }
    out = rgb_at(hi);
    return hi;
}
static Mp boundary_chroma(const Mp& x, const Mp& y, const Mp& L) {
    Tri rgb; gamut_pull(x, y, L, rgb, 60);
    Tri X = lin_to_xyz({clamp01(rgb.a), clamp01(rgb.b), clamp01(rgb.c)});
    Mp Lo, a, b; xyz_to_lab(X, Lo, a, b);
    return hypotm(a, b);
}
// Cusp: L* = argmax in-gamut CIELAB chroma along the spectral ray — an
// extremum of the translation layer (C* vanishes at both device poles;
// unimodal). Zero free parameters. (Descriptor Gap record: the argmin-
// pull criterion collapses to the black pole and was corrected here.)
static Mp cusp_lightness(const Mp& x, const Mp& y) {
    Mp lo(1L), hi(99L);
    for (int i = 0; i < 80; ++i) {
        Mp m1 = lo + (hi - lo) / Mp(3L), m2 = hi - (hi - lo) / Mp(3L);
        if (!lt(boundary_chroma(x, y, m1), boundary_chroma(x, y, m2))) hi = m2; else lo = m1;
    }
    return (lo + hi) / Mp(2L);
}

struct SpectralClass {
    long cls; std::string kind; long k;              // k=-1 for purple line
    std::string lambda_nm;                           // "" for purple line
    long pk, pd; std::string peps;                   // spectral projection
    std::string xy_x, xy_y, cusp_L, pull_t, even_t;
    std::string hex, hex_even, hex_dim, hex_wash;
    Mp labL, labA, labB;
};
static std::vector<SpectralClass> CLASSES;

static std::string chroma_variant(const SpectralClass& c, const Mp& f) {
    Mp a2 = c.labA * f, b2 = c.labB * f;
    Tri rgb = xyz_to_lin(lab_to_xyz(c.labL, a2, b2));
    if (!in_gamut(rgb)) {
        Mp lo(0L), hi(1L);
        for (int i = 0; i < 120; ++i) {
            Mp mid = (lo + hi) / Mp(2L);
            Tri rr = xyz_to_lin(lab_to_xyz(c.labL, a2 * (Mp(1L) - mid), b2 * (Mp(1L) - mid)));
            if (in_gamut(rr)) hi = mid; else lo = mid;
        }
        rgb = xyz_to_lin(lab_to_xyz(c.labL, a2 * (Mp(1L) - hi), b2 * (Mp(1L) - hi)));
    }
    return lin_to_hex(rgb);
}
static void build_classes() {
    for (long c = 0; c <= 11; ++c) {
        SpectralClass sc; sc.cls = c;
        Tri X;
        if (c <= 10) {
            sc.kind = "spectral"; sc.k = K_BASE + c;
            Mp lam = LAMBDA_E_NM * lattice(sc.k);
            X = cmf_at(lam);
            Proj p = project(lam / LAMBDA_E_NM);
            sc.pk = p.k; sc.pd = p.d; sc.peps = dec(p.eps, 50);
            sc.lambda_nm = dec(lam, 50);
        } else {
            sc.kind = "purple-line"; sc.k = -1; sc.pk = 0; sc.pd = 0;
            Tri A = cmf_at(LAMBDA_E_NM * lattice(K_BASE));
            Tri B = cmf_at(LAMBDA_E_NM * lattice(K_BASE + 10));
            X = {A.a + B.a, A.b + B.b, A.c + B.c};
        }
        Mp x, y; xyz_to_xy(X, x, y);
        sc.xy_x = dec(x, 30); sc.xy_y = dec(y, 30);
        Mp Lc = cusp_lightness(x, y);
        Tri rc; Mp tc = gamut_pull(x, y, Lc, rc);
        Tri re; Mp te = gamut_pull(x, y, ACCENT_L, re);
        sc.cusp_L = dec(Lc, 20); sc.pull_t = dec(tc, 30); sc.even_t = dec(te, 30);
        sc.hex = lin_to_hex(rc); sc.hex_even = lin_to_hex(re);
        Tri Xv = lin_to_xyz({clamp01(rc.a), clamp01(rc.b), clamp01(rc.c)});
        xyz_to_lab(Xv, sc.labL, sc.labA, sc.labB);
        sc.hex_dim  = chroma_variant(sc, Kk);
        sc.hex_wash = chroma_variant(sc, V);
        CLASSES.push_back(std::move(sc));
    }
}

// ─── Neutral ladder: L* = j·(100·V), tint = class-1 chroma × K·V ─────
static std::map<long, std::string> NEUTRAL;
static void build_neutrals() {
    const SpectralClass& base = CLASSES[1];
    Mp scale = Kk * V;
    std::vector<long> js = {0, 1, 2, 3, 4, 8, 9, 10, 11};
    for (long j : js) {
        Mp L = Mp(j) * (Mp(100L) * V);
        Tri rgb = xyz_to_lin(lab_to_xyz(L, base.labA * scale, base.labB * scale));
        if (!in_gamut(rgb)) rgb = xyz_to_lin(lab_to_xyz(L, Mp(0L), Mp(0L)));
        NEUTRAL[j] = lin_to_hex(rgb);
    }
}

// ═════════════════════════════════════════════════════════════════════
//  UNIVERSAL COLOR ADDRESSING — all colors; DSR ≤ 0 channels sit at the
//  ANNIHILATION BOUNDARY (§7.3, RC-9): {P,D} Unsubstantiated — approached,
//  never attained; excluded from Π_N by construction; pullback 0
// ═════════════════════════════════════════════════════════════════════
struct ChanAddr { bool pole; long k, d; std::string eps; };
static std::array<ChanAddr,3> color_to_lattice(const std::string& hx) {
    Tri X = hex_to_xyz(hx);
    const Mp* val[3] = {&X.a, &X.b, &X.c};
    const Mp* ref[3] = {&Xn, &Yn, &Zn};
    std::array<ChanAddr,3> out;
    for (int i = 0; i < 3; ++i) {
        Mp dsr = *val[i] / *ref[i];
        if (!lt(Mp(0L), dsr)) { out[i] = {true, 0, 0, ""}; continue; }   // annihilation boundary
        Proj p = project(dsr);
        out[i] = {false, p.k, p.d, dec(p.eps, 50)};
    }
    return out;
}
static std::string lattice_to_color(const std::array<ChanAddr,3>& tr) {
    Mp v0 = tr[0].pole ? Mp(0L) : pullback(tr[0].k, Mp(tr[0].eps));
    Mp v1 = tr[1].pole ? Mp(0L) : pullback(tr[1].k, Mp(tr[1].eps));
    Mp v2 = tr[2].pole ? Mp(0L) : pullback(tr[2].k, Mp(tr[2].eps));
    return lin_to_hex(xyz_to_lin({v0 * Xn, v1 * Yn, v2 * Zn}));
}

// ═════════════════════════════════════════════════════════════════════
//  GEOMETRY TOKENS — every value 2^(k/12); k is named
// ═════════════════════════════════════════════════════════════════════
static std::string px_s (long k, int d = 12) { return dec(lattice(k), d) + "px"; }
static std::string rem_s(long k, int d = 12) { return dec(lattice(k), d) + "rem"; }
static std::string sec_s(long k, int d = 10) { return dec(lattice(k), d) + "s"; }
using KTable = std::vector<std::pair<std::string,long>>;
static const KTable TYPE_SCALE = {{"fs-xs",-2},{"fs-sm",-1},{"fs-base",0},{"fs-md",2},
    {"fs-lg",4},{"fs-xl",7},{"fs-2xl",12},{"fs-3xl",16},{"fs-4xl",19},{"fs-hero",24}};
static const KTable SPACE_SCALE = {{"sp-3xs",-31},{"sp-2xs",-24},{"sp-xs",-12},{"sp-sm",-5},
    {"sp-md",0},{"sp-lg",5},{"sp-xl",12},{"sp-2xl",19},{"sp-3xl",24},{"sp-4xl",31},{"sp-5xl",36}};
static const KTable RADII = {{"rad-sm",-24},{"rad-md",-12},{"rad-lg",-5},{"rad-xl",0}};
static const KTable DUR   = {{"dur-fast",-31},{"dur-base",-24},{"dur-slow",-12},{"dur-drift",24}};
static const KTable BPTS  = {{"bp-min",100},{"bp-mid",108},{"bp-grid",120},{"bp-wide",123}};

// ═════════════════════════════════════════════════════════════════════
//  THE LIVING FIELD — declarative strings, zero JavaScript
//  Star i ∈ 1…A₀: x=frac(i·log₂3), y=frac(i·log₂(3/2)); Π₁₂(i) gives
//  class=k mod 12, g=12/d, radius r=2^(g/12) px (box=2^((g+12)/12) px),
//  brightness weight w = ξ(m)/ξ(1), m = d via SVT (Identity M/H),
//  box = 2^((g+24)/12) px, twinkle period T=2^(class/12)·2 s.
//  Twinkle luminance: L_j = min(1, w·Ψ_j), Ψ_j = 1+√V·sin(2π·j/12) —
//  the Shimmer Identity (R.2) — at the 13 lattice stops j·100/12;
//  the EMITTED opacity is the device-encoded image of that luminance,
//  α_j = gamma_enc(L_j): the same frozen sRGB transfer every color
//  channel passes through. min(1,·) is the luminance ceiling, the same
//  translation-layer pull as the gamut clamp. Phase enters as a delay:
//  cycle fraction f = (ε+∂I)/(2·∂I) — ε normalized by the ∂I full step —
//  delay = −f·T. Layers L = i mod |Π|; drift T_L = bp-grid/v_L with
//  v_L = V·2^(2−L) px/s ⇒ T_L = 3072·2^L s (drift calibrated exact at
//  the k=120 reference width; declarative medium scales proportionally).
// ═════════════════════════════════════════════════════════════════════
struct Star { long i, layer, cls, d, g; std::string x_pct, y_pct, delay_s, frac; };
static std::vector<Star> STARS;
static std::map<long, std::array<std::string,13>> TWINKLE;   // per-d stops
static std::array<std::string,13> KF_PCT;                    // shared %
static std::map<long, std::string> DUR_CLS;                  // per-class T
static std::array<std::string,3> DRIFT_T;                    // per-layer s
// ── unique-capability effects (all forge-exact, zero JS) ────────────
static std::array<std::string,13> TUNNEL_PCT;    // (2^(j/12)−1)·100 %
static std::string TUNNEL_S0, TUNNEL_S1, TUNNEL_T;   // 1024px→2048px, period s
static std::vector<std::pair<std::string,std::string>> WHEEL_STAR7; // g=7 node coords
static std::string COMET_PATH, COMET_T;          // exact path d, ξ-total period
static std::array<std::string,13> COMET_TPCT;    // impedance-weighted time stops
static const long COMET_TAIL = 12;               // Koide tail: N ghosts
static std::array<std::string,12> COMET_TDELAY;  // −j·T·V² s
static std::array<std::string,12> COMET_TALPHA;  // K^j
static std::array<std::string,12> COMET_TRAD;    // 2^((30−j)/12)
static std::array<long,13> COMET_CLS;            // node classes (7j mod 12)
static std::map<long,std::string> STAR_STATIC;   // reduced-motion α = γ(w)
static std::string HTML_OUT, CSS_OUT;            // built artifacts, for gates
struct EnginePanel { std::string name, law, r_in, r60, kd, eps60, back60; long k, d; };
static std::vector<EnginePanel> ENGINE;
static std::string ENG_T, ENG_ON, ENG_OFF, ENG_SLOT;  // cycle timing strings
static std::array<std::string,13> GLOW_B1, GLOW_B2;   // Ψ-scaled blur radii (rem)

static Mp frac_m(const Mp& x) { return x - floorm(x); }
static void build_field() {
    Mp FX = log2m(Mp(3L));                    // log₂3   (|Π| rotation)
    Mp FY = log2m(Mp(3L) / Mp(2L));           // log₂K⁻¹
    Mp two_pi = Mp(2L) * pi_m();
    for (long j = 0; j <= 12; ++j)
        KF_PCT[(size_t)j] = dec(Mp(j) * Mp(100L) / Mp(12L), 18);
    // Identity M/H impedance, normalized: w = ξ(m)/ξ(1) = S²/((m−1)²+S²),
    // where harmonic family m = d via SVT (simple families, d | N — RC-5)
    // Identity R.2 Shimmer: Ψ_j = 1+√V·sin(2πj/N) — period N, mean 1, amp √V=σ
    // min(1,·): device luminance ceiling — same translation-layer pull as
    // the color gamut clamp; the d≤3 anchors breathe into the Exception cap.
    // Emitted opacity is the DEVICE-ENCODED luminance: α = γ(min(1, w·Ψ)),
    // γ = the frozen sRGB transfer (gamma_enc) — perceptual by construction.
    Mp sV = sqrtm(V);
    for (long d : DIVISORS) {
        Mp w = xi_fn(d) / xi_fn(1);
        STAR_STATIC[d] = dec(gamma_enc(mmin(Mp(1L), w)), 6);   // Ψ mean = 1
        for (long j = 0; j <= 12; ++j) {
            Mp psi = Mp(1L) + sV * sinm(two_pi * Mp(j) / Mp(12L));
            TWINKLE[d][(size_t)j] = dec(gamma_enc(mmin(Mp(1L), w * psi)), 10);
        }
    }
    for (long c = 0; c < 12; ++c)
        DUR_CLS[c] = dec(lattice(c) * Mp(2L), 12);
    for (long L = 0; L < 3; ++L)
        DRIFT_T[(size_t)L] = dec(Mp(3072L) * exp2m(Mp(L)), 8);
    for (long i = 1; i <= A0; ++i) {
        Proj p = project(Mp(i));
        Star s; s.i = i; s.layer = i % PI_COUNT;
        s.cls = ((p.k % N) + N) % N; s.d = p.d; s.g = N / p.d;
        s.x_pct = dec(frac_m(Mp(i) * FX) * Mp(100L), 15);
        s.y_pct = dec(frac_m(Mp(i) * FY) * Mp(100L), 15);
        Mp f = (p.eps + DI_CENTS) / (Mp(2L) * DI_CENTS);   // (ε+∂I)/(2∂I)
        s.frac = dec(f, 15);
        Mp T = lattice(s.cls) * Mp(2L);
        s.delay_s = dec(neg(f * T), 12);
        STARS.push_back(std::move(s));
    }
}

static void build_effects() {
    // A — OCTAVE TUNNEL: repeating-radial stops at (2^(j/12)−1)·100 %.
    // One animation period = one exact octave (box 2^(120/12) → 2^(132/12) px):
    // the loop is seamless by IC-1/RC-24 S4, not by approximation.
    for (long j = 0; j <= 12; ++j)
        TUNNEL_PCT[(size_t)j] = dec((lattice(j) - Mp(1L)) * Mp(100L), 15);
    TUNNEL_S0 = dec(lattice(132), 10); TUNNEL_S1 = dec(lattice(144), 10);
    TUNNEL_T  = dec(lattice(60), 8);                       // 2^5 = 32 s
    // B — CASCADE COMET on the g=7 star: dwell time per segment is the
    // Magical Impedance of the landing family, dt_j = ξ(m_j)·2^(−24/12) s
    // (harmonic m = d via SVT). Equal chords ⇒ distance stops j·100/12;
    // TIME stops are the impedance-weighted cumulative percents.
    {
        Mp per_xi = lattice(-24);                          // 0.25 s per ξ-unit
        std::vector<Mp> xi_seq; Mp tot(0L); long pos = 0;
        for (long i = 0; i < N; ++i) {
            pos = (pos + 7) % N;
            long g = (pos != 0) ? std::gcd(pos, N) : N;
            Mp x = xi_fn(N / g); xi_seq.push_back(x); tot = tot + x;
        }
        COMET_T = dec(tot * per_xi, 10);
        Mp acc(0L); COMET_TPCT[0] = "0";
        for (size_t j = 0; j < xi_seq.size(); ++j) {
            acc = acc + xi_seq[j];
            COMET_TPCT[j + 1] = dec(acc * Mp(100L) / tot, 12);
        }
        // node class sequence: pos = 7j mod 12 IS the spectral class —
        // the meteor's fill morphs through ALL 12 classes in fifths order
        long cpos = 0;
        for (long j = 0; j < N; ++j) { cpos = (cpos + 7) % N; COMET_CLS[(size_t)j] = cpos; }
        COMET_CLS[12] = COMET_CLS[0];                       // wrap continuity
        // Koide tail: ghost j at delay −j·T·V² (whole tail spans one mean
        // segment, T·V), opacity K^j (canonical harmonic decay, R.10.e),
        // radius one semitone smaller per ghost: 2^((30−j)/12) px.
        Mp Ttot = tot * per_xi, Kp(1L);
        for (long j = 1; j <= COMET_TAIL; ++j) {
            Kp = Kp * Kk;
            COMET_TDELAY[(size_t)(j - 1)] = dec(neg(Mp(j) * Ttot * V * V), 10);
            COMET_TALPHA[(size_t)(j - 1)] = dec(Kp, 8);
            COMET_TRAD[(size_t)(j - 1)]   = dec(lattice(30 - j), 6);
        }
    }
    // C — THE ENGINE: twelve exact projections, printed to 60 digits with
    // the pullback shown matching digit-for-digit. Zero machine error —
    // the guard digits absorb all transcendental residual (canon method).
    {
        Mp e_v(0L); mpfr_set_ui(e_v.v, 1, MPFR_RNDN); mpfr_exp(e_v.v, e_v.v, MPFR_RNDN);
        Mp phi_v = (Mp(1L) + sqrtm(Mp(5L))) / Mp(2L);
        struct In { const char* n; const char* law; Mp r; };
        std::vector<In> ins = {
            {"π",        "the half-rotation",                    pi_m()},
            {"e",        "the D-constant (EML terminal)",        e_v},
            {"φ",        "(1+√5)/2 — the golden section",        phi_v},
            {"√2",       "the tritone, k = 6 exact",             sqrtm(Mp(2L))},
            {"2^(1/12)", "the semitone — one lattice step",      lattice(1)},
            {"3/2",      "the fifth — ε IS δ_canonical",         Mp(3L) / Mp(2L)},
            {"4/3",      "the fourth = 2K (IC-149)",             Mp(4L) / Mp(3L)},
            {"Λ",        "1200/ln 2 — manifold constant (B.5)",  Lambda()},
            {"Λ_θ",      "600/π — phase constant (D.5)",         LambdaTheta()},
            {"σ_ET",     "√V = 1/√12 — structural cell scale",   sqrtm(V)},
            {"ξ(1)",     "A₀/S⁴·… = 137/16 — gravity impedance", xi_fn(1)},
            {"A₀",       "(N−1)² + S² = 137 — derived",          Mp(A0)},
        };
        for (auto& in : ins) {
            EnginePanel pn; pn.name = in.n; pn.law = in.law;
            pn.r_in = dec(in.r, (int)WORK_DIGITS);
            Proj pr = project(in.r);
            pn.k = pr.k; pn.d = pr.d;
            pn.kd = "(k = " + std::to_string(pr.k) + ", d = " + std::to_string(pr.d) + ")";
            pn.r60 = dec(in.r, 60);
            // Lattice-exact inputs have ε = 0 by identity; anything below the
            // 200-digit truncation floor (bound Λ·10⁻²⁰⁰·5 < 10⁻¹⁹⁰) IS zero.
            if (lt(mabs(pr.eps), Mp("1e-190"))) {
                pn.eps60 = "0 — lattice-exact";
                pn.back60 = dec(pullback(pr.k, Mp(0L)), 60);
            } else {
                pn.eps60 = dec(pr.eps, 60);
                pn.back60 = dec(pullback(pr.k, pr.eps), 60);
            }
            ENGINE.push_back(std::move(pn));
        }
        Mp slot = lattice(36);                             // 2^3 = 8 s per panel
        ENG_SLOT = dec(slot, 8);
        ENG_T = dec(Mp((long)ENGINE.size()) * slot, 8);    // 96 s cycle
        Mp span = Mp(100L) / Mp((long)ENGINE.size());      // 100/12 %
        ENG_ON  = dec(span * V, 12);                       // fade-in width
        ENG_OFF = dec(span - span * V, 12);                // fade-out start
    }
    // D — Ψ-GLOW: the hero equation's aura breathes on the Shimmer
    // Identity, blur_j = Ψ_j · 2^(k/12) rem at the 13 lattice stops.
    {
        Mp sV = sqrtm(V), two_pi = Mp(2L) * pi_m();
        for (long j = 0; j <= 12; ++j) {
            Mp psi = Mp(1L) + sV * sinm(two_pi * Mp(j) / Mp(12L));
            GLOW_B1[(size_t)j] = dec(psi * lattice(-5), 8);   // ×sp-sm
            GLOW_B2[(size_t)j] = dec(psi * lattice(12), 8);   // ×sp-xl
        }
    }
}

// ═════════════════════════════════════════════════════════════════════
//  CONFIG (business facts only)
// ═════════════════════════════════════════════════════════════════════
struct Config {
    std::string domain = "www.exceptiontheory.com";
    std::string title  = "Exception Theory";
    std::string tagline = "For every exception there is an exception, except the exception.";
    std::string org = "Exception Theory LLC";
    std::string org_loc = "Ellwood City, Pennsylvania";
    std::string author = "Michael James Muller — Aevum Defluo";
    std::string doi = "10.5281/zenodo.19762311";      // verified: ET_Identities.md
    std::string doi_url = "https://doi.org/10.5281/zenodo.19762311";
    // Email confirmed by Mike 2026-07-12: typo corrected ('thoery' → 'theory').
    std::string email = "exceptiontheory@gmail.com";
    std::string year;
    std::vector<std::array<std::string,4>> products;  // name, desc, url, cta — empty by directive
} CFG;

// ═════════════════════════════════════════════════════════════════════
//  TOKEN LEDGER + CSS VARS
// ═════════════════════════════════════════════════════════════════════
static std::vector<std::string> CSS_VARS;
static std::ostringstream TOKENS;                     // JSON array body
static bool tokens_first = true;
static void tok_open(const std::string& name, const std::string& value, const std::string& law) {
    if (!tokens_first) TOKENS << ",\n";
    tokens_first = false;
    TOKENS << "  {\"token\":" << jstr(name) << ",\"value\":" << jstr(value)
           << ",\"law\":" << jstr(law);
}
static void tok_kv(const std::string& k, const std::string& raw) { TOKENS << ",\"" << k << "\":" << raw; }
static void tok_close() { TOKENS << "}"; }
static std::string addr_json(const std::array<ChanAddr,3>& tr) {
    std::ostringstream o; o << "[";
    for (int i = 0; i < 3; ++i) {
        if (i) o << ",";
        if (tr[i].pole) o << "{\"boundary\":\"annihilation\"}";
        else o << "{\"k\":" << tr[i].k << ",\"d\":" << tr[i].d
               << ",\"eps_cents\":" << jstr(tr[i].eps) << "}";
    }
    o << "]"; return o.str();
}
static void add_geom(const KTable& t, const std::string& unit, const std::string& law) {
    for (auto& [name, k] : t) {
        std::string val = (unit == "rem") ? rem_s(k) : (unit == "px") ? px_s(k) : sec_s(k);
        CSS_VARS.push_back("  --" + name + ": " + val + ";");
        tok_open(name, val, law + " (k=" + std::to_string(k) + ")");
        tok_kv("k", std::to_string(k));
        tok_kv("exact", jstr(dec(lattice(k), 50)));
        tok_close();
    }
}
static const std::vector<std::pair<std::string,std::string>> SEMANTIC = {
    {"bg","var(--n1)"},{"bg-raise","var(--n2)"},{"surface","var(--n3)"},
    {"surface-2","var(--n4)"},{"line","var(--n3)"},{"text","var(--n11)"},
    {"text-2","var(--n10)"},{"text-3","var(--n9)"},
    {"advance","var(--c10)"},{"advance-2","var(--c9)"},
    {"recede","var(--c3)"},{"recede-2","var(--c1)"},
    {"arcane","var(--c11)"},{"verdant","var(--c6)"},{"gold","var(--c7)"},
    {"link","var(--c3-even)"},{"link-hot","var(--c7-even)"},
    {"gold-text","var(--c7-even)"},{"verdant-text","var(--c6-even)"},
    {"arcane-text","var(--c11-even)"},
};
static void build_tokens() {
    add_geom(TYPE_SCALE, "rem", "2^(k/12) rem — semitone type scale");
    add_geom(SPACE_SCALE, "rem", "2^(k/12) rem — semitone spacing");
    add_geom(RADII, "rem", "2^(k/12) rem — radii");
    add_geom(DUR, "s", "2^(k/12) s — durations");
    add_geom(BPTS, "px", "2^(k/12) px breakpoint");
    std::string lh = dec(lattice(7), 12);
    CSS_VARS.push_back("  --lh: " + lh + ";");
    tok_open("lh", dec(lattice(7), 50), "line-height = 2^(7/12) — the tempered fifth");
    tok_kv("k", "7"); tok_close();
    std::string meas = dec(Kk * (CENTS / Mp(N)), 10);
    CSS_VARS.push_back("  --measure: " + meas + "ch;");
    tok_open("measure", dec(Kk * (CENTS / Mp(N)), 50) + "ch",
             "reading measure = K*(1200/N) ch = 66.6ch"); tok_close();
    std::string ease = "cubic-bezier(" + dec(Mp(1L) - Kk, 8) + ", 0, " + dec(Kk, 8) + ", 1)";
    CSS_VARS.push_back("  --ease: " + ease + ";");
    tok_open("ease", ease, "cubic-bezier(1-K, 0, K, 1)"); tok_close();
    const std::vector<std::pair<std::string, Mp>> alphas = {
        {"a-v", V}, {"a-kv", Kk * V}, {"a-k2", Kk * Kk}, {"a-k", Kk},
        {"a-1v", Mp(1L) - V}, {"a-1kv", Mp(1L) - Kk * V}};
    for (auto& [n, a] : alphas) {
        CSS_VARS.push_back("  --" + n + ": " + dec(a, 10) + ";");
        tok_open(n, dec(a, 50), "opacity from {V, K} algebra"); tok_close();
    }
    for (auto& [j, hx] : NEUTRAL) {
        CSS_VARS.push_back("  --n" + std::to_string(j) + ": " + hx + ";");
        tok_open("n" + std::to_string(j), hx,
                 "neutral ladder L* = " + std::to_string(j) +
                 "*(100*V); tint = class-1 chroma * K*V");
        tok_kv("lattice_address", addr_json(color_to_lattice(hx)));
        tok_close();
    }
    for (auto& c : CLASSES) {
        std::string base_law = (c.cls <= 10)
            ? "spectral class " + std::to_string(c.cls) + ": lambda = lam_e*2^(" +
              std::to_string(c.k) + "/12) nm via CIE observer"
            : "purple line: endpoint XYZ sum via CIE observer";
        const std::array<std::array<std::string,3>,4> variants = {{
            {"",       c.hex,      " @ cusp L*=" + c.cusp_L.substr(0, 7) +
                                   " (argmax in-gamut chroma — gamut cusp, translation-layer extremum)"},
            {"-even",  c.hex_even, " @ L*=K*100 (equiluminant law)"},
            {"-dim",   c.hex_dim,  " @ cusp; chroma * K"},
            {"-wash",  c.hex_wash, " @ cusp; chroma * V"}}};
        for (auto& vv : variants) {
            std::string name = "c" + std::to_string(c.cls) + vv[0];
            CSS_VARS.push_back("  --" + name + ": " + vv[1] + ";");
            tok_open(name, vv[1], base_law + vv[2]);
            if (!c.lambda_nm.empty()) tok_kv("lambda_nm", jstr(c.lambda_nm));
            tok_kv("lattice_address", addr_json(color_to_lattice(vv[1])));
            tok_close();
        }
    }
    CSS_VARS.push_back("  --grid-n: " + std::to_string(N) + ";");
    CSS_VARS.push_back("  --di-cents: " + dec(DI_CENTS, 6) + ";");
    for (auto& [n, v] : SEMANTIC) {
        CSS_VARS.push_back("  --" + n + ": " + v + ";");
        tok_open(n, v, "semantic alias (composition)"); tok_close();
    }
}

// ═════════════════════════════════════════════════════════════════════
//  SIGIL WHEEL SVG
// ═════════════════════════════════════════════════════════════════════
static std::string build_wheel() {
    const long size = 640;
    Mp cx = Mp(size) / Mp(2L), cy = cx;
    Mp r_out = Mp(size) * (Mp(1L) - V) / Mp(2L);
    Mp r_in = r_out * Kk, r_star = r_in * Kk;
    Mp two_pi = Mp(2L) * pi_m(), half_pi = pi_m() / Mp(2L);
    auto PX = [&](const Mp& ang, const Mp& r) { return dec(cx + r * cosm(ang), 8); };
    auto PY = [&](const Mp& ang, const Mp& r) { return dec(cy + r * sinm(ang), 8); };
    std::ostringstream s;
    s << "<svg xmlns=\"http://www.w3.org/2000/svg\" viewBox=\"0 0 " << size
      << " " << size << "\" role=\"img\" aria-label=\"The visible octave of the "
      "electromagnetic spectrum projected onto the N=12 Sempaevum lattice\">"
      << "<rect width=\"" << size << "\" height=\"" << size << "\" fill=\"none\"/>";
    for (long c = 0; c < 12; ++c) {
        Mp a0 = two_pi * (Mp(c) - Mp(1L) / Mp(2L)) / Mp(12L) - half_pi;
        Mp a1 = two_pi * (Mp(c) + Mp(1L) / Mp(2L)) / Mp(12L) - half_pi;
        s << "<path d=\"M " << PX(a0, r_out) << " " << PY(a0, r_out)
          << " A " << dec(r_out, 8) << " " << dec(r_out, 8) << " 0 0 1 "
          << PX(a1, r_out) << " " << PY(a1, r_out)
          << " L " << PX(a1, r_in) << " " << PY(a1, r_in)
          << " A " << dec(r_in, 8) << " " << dec(r_in, 8) << " 0 0 0 "
          << PX(a0, r_in) << " " << PY(a0, r_in) << " Z\" fill=\""
          << CLASSES[(size_t)c].hex << "\" opacity=\"" << dec(Mp(1L) - V, 6) << "\">"
          << "<title>class " << c << " — "
          << (c <= 10 ? ("λ = " + CLASSES[(size_t)c].lambda_nm.substr(0, 6) +
                         " nm, k = " + std::to_string(CLASSES[(size_t)c].k))
                      : std::string("purple line (non-spectral)"))
          << "</title></path>";
    }
    for (long c = 0; c < 12; ++c) {
        Mp a = two_pi * (Mp(c) + Mp(1L) / Mp(2L)) / Mp(12L) - half_pi;
        Mp r2 = r_out * (Mp(1L) + V / Mp(2L));
        s << "<line x1=\"" << PX(a, r_out) << "\" y1=\"" << PY(a, r_out)
          << "\" x2=\"" << PX(a, r2) << "\" y2=\"" << PY(a, r2)
          << "\" stroke=\"" << NEUTRAL[10] << "\" stroke-width=\"1\" opacity=\""
          << dec(Kk * V, 6) << "\"/>";
    }
    for (long g : GENERATORS) {
        s << "<polyline points=\"";
        long node = 0;
        for (int j = 0; j <= 12; ++j) {
            Mp a = two_pi * Mp(node) / Mp(12L) - half_pi;
            if (g == 7) WHEEL_STAR7.push_back({PX(a, r_star), PY(a, r_star)});
            s << PX(a, r_star) << "," << PY(a, r_star) << (j < 12 ? " " : "");
            node = (node + g) % 12;
        }
        s << "\" fill=\"none\" stroke=\"" << NEUTRAL[g == 7 ? 4 : 3]
          << "\" stroke-width=\"1\" opacity=\""
          << dec(g == 7 ? Kk * Kk : Kk * V, 6) << "\"/>";
    }
    s << "<text x=\"" << dec(cx, 8) << "\" y=\"" << dec(cy, 8)
      << "\" text-anchor=\"middle\" dominant-baseline=\"central\" fill=\""
      << NEUTRAL[11] << "\" font-family=\"Georgia, serif\" font-size=\""
      << dec(lattice(60) / Mp(2L), 6) << "\" letter-spacing=\"2\">P∘D∘T = E</text>"
      << "<text x=\"" << dec(cx, 8) << "\" y=\"" << dec(cy + r_star * (Kk * Kk), 8)
      << "\" text-anchor=\"middle\" fill=\"" << NEUTRAL[9]
      << "\" font-family=\"Georgia, serif\" font-size=\"" << dec(lattice(48) / Mp(2L), 6)
      << "\" opacity=\"" << dec(Kk, 4)
      << "\">the visible octave · k = 120…130 above ƛ_e · ∂I at |ε| = 50¢</text>";
    // the cascade comet + trail — path & ξ-timing live in the page CSS
    {
        if (WHEEL_STAR7.size() != 13)
            fatal("build_wheel: g=7 star capture yielded " +
                  std::to_string(WHEEL_STAR7.size()) + " nodes (need 13)");
        std::ostringstream d;
        d << "M " << WHEEL_STAR7[0].first << " " << WHEEL_STAR7[0].second;
        for (size_t j = 1; j < WHEEL_STAR7.size(); ++j)
            d << " L " << WHEEL_STAR7[j].first << " " << WHEEL_STAR7[j].second;
        COMET_PATH = d.str();
        s << "<circle class=\"comet head\" r=\"" << dec(lattice(30), 6)
          << "\" fill=\"none\"/>";
        for (long j = 1; j <= COMET_TAIL; ++j)
            s << "<circle class=\"comet t" << j << "\" r=\""
              << COMET_TRAD[(size_t)(j - 1)] << "\" fill=\"none\"/>";
    }
    s << "</svg>";
    return s.str();
}

// ═════════════════════════════════════════════════════════════════════
//  CSS — base template + the declarative field system (no JS anywhere)
// ═════════════════════════════════════════════════════════════════════
static std::string build_css() {
    std::string tpl = R"CSS(/* www.exceptiontheory.com — forged by et_site_forge.cpp (MPFR); do not hand-edit.
   Every value is a lattice address. Authority: et_tokens.json.
   Zero JavaScript. Zero IEEE float in the forge chain. P ∘ D ∘ T = E */
:root{
@@VARS@@
}
*,*::before,*::after{box-sizing:border-box}
html{scroll-behavior:smooth}
/* ── RUNTIME DIAGNOSTICS — the page catches and NAMES degraded states.
   Healthy environment: nothing renders. Each conditional below is the
   error handler for one capability the design depends on. Zero JS. */
.sysdiag .diag{display:none;margin:0;padding:var(--sp-sm) var(--sp-md);
  background:var(--n1);border-bottom:1px solid var(--n3);
  color:var(--text-2);font-size:var(--fs-sm);line-height:var(--lh)}
.sysdiag .diag b{color:var(--text-1)}
.sysdiag .diag code{color:var(--gold-text)}
/* ── MOTION WITNESS — fail-dead traversal detector. The base
   configuration DISPLAYS the failure; the LIVE lamp exists only while
   an animation is actually EXECUTING (constant-keyframe hold). Any
   cause that stops the engine — throttling, battery saver, an
   extension, a stale stylesheet, a dead pipeline — collapses the hold
   and the page itself reports it. Detection by traversal, never by
   declaration. Beat period = 2·dur-slow = 2^0 s, lattice-exact. */
.witness{position:relative;display:block;font-size:var(--fs-sm);line-height:var(--lh)}
.witness .w-fail{display:block;padding:var(--sp-sm) var(--sp-md);
  background:var(--n1);border-bottom:1px solid var(--advance);color:var(--text-1)}
.witness .w-fail b{color:var(--advance)}
.witness .w-live{position:absolute;inset:0;display:flex;align-items:center;
  gap:var(--sp-xs);padding:0 var(--sp-md);background:var(--bg);
  color:var(--text-2);opacity:0;pointer-events:none;
  animation:w-hold calc(var(--dur-slow)*2) linear infinite}
.witness .w-live b{color:var(--verdant-text)}
.witness .w-live .beat{width:var(--sp-xs);height:var(--sp-xs);border-radius:50%;
  background:var(--verdant-text);
  animation:w-beat calc(var(--dur-slow)*2) ease-in-out infinite}
@keyframes w-hold{0%,100%{opacity:1}}
@keyframes w-beat{0%,100%{opacity:1}50%{opacity:var(--a-v)}}
@media (prefers-reduced-motion: reduce){
  .sysdiag .diag-motion{display:block}
}
@supports not (offset-path: path("M 0 0 L 1 1")){
  .sysdiag .diag-offset{display:block}
}
@supports not (color: color-mix(in srgb, red 50%, blue)){
  .sysdiag .diag-colormix{display:block}
}
@media (prefers-reduced-motion: reduce){
  html{scroll-behavior:auto}
}
body{
  margin:0;background:var(--bg);color:var(--text);
  font-family:'Palatino Linotype','Book Antiqua',Palatino,Georgia,serif;
  font-size:var(--fs-base);line-height:var(--lh);
  -webkit-font-smoothing:antialiased;
}
::selection{background:var(--advance);color:var(--n1)}
a{color:var(--link);text-decoration-color:color-mix(in srgb,var(--link) calc(var(--a-k)*100%),transparent)}
a:hover{color:var(--link-hot)}
code,kbd,.mono{font-family:ui-monospace,'Cascadia Mono',Consolas,Menlo,monospace;font-size:var(--fs-sm)}
h1,h2,h3{font-weight:600;letter-spacing:.02em}
h1{font-size:clamp(var(--fs-3xl),calc(100vw/var(--grid-n)),var(--fs-hero))}
h2{font-size:var(--fs-2xl);margin:0 0 var(--sp-md)}
h3{font-size:var(--fs-xl);margin:var(--sp-lg) 0 var(--sp-sm)}
p{margin:0 0 var(--sp-md);max-width:var(--measure)}
.small{font-size:var(--fs-sm);color:var(--text-2)}

/* ── the deep field — pure declarative animation, forge-computed ── */
.fieldwrap{position:fixed;inset:0;z-index:0;overflow:hidden;pointer-events:none}
.layer{position:absolute;top:0;bottom:0;left:0;width:200%;display:flex}
.layer .strip{position:relative;width:50%;height:100%;flex:none}
.star{position:absolute;border-radius:50%;transform:translate(-50%,-50%)}
@@STARCLASSES@@
.nebula{position:fixed;inset:0;z-index:0;pointer-events:none;
  background:
    radial-gradient(ellipse calc(100vmax*2/3) calc(100vmax/2) at calc(100%*1/12) calc(100%*1/3),
      color-mix(in srgb,var(--c1) calc(var(--a-kv)*100%),transparent),transparent 70%),
    radial-gradient(ellipse calc(100vmax/2) calc(100vmax*2/3) at calc(100%*11/12) calc(100%*2/3),
      color-mix(in srgb,var(--c0) calc(var(--a-kv)*100%),transparent),transparent 70%),
    radial-gradient(ellipse calc(100vmax/3) calc(100vmax/3) at calc(100%*2/3) calc(100%*1/12),
      color-mix(in srgb,var(--c10) calc(var(--a-v)*var(--a-v)*100%),transparent),transparent 70%);
}
.veil{position:fixed;inset:0;z-index:0;pointer-events:none;
  background:linear-gradient(180deg,transparent,color-mix(in srgb,var(--n0) calc(var(--a-k)*100%),transparent))}
/* Motion is the CONTENT of this page and runs unconditionally (owner
   directive): every animation is a verified law at gentle amplitude and
   slow lattice period. The OS reduced-motion preference is surfaced as
   an informational notice below, never as a freeze. */
@@FIELDMOTION@@
.hero::before{animation:octzoom @@TTUN@@s linear infinite}
.hero .eq{animation:eqpsi @@TGLOW@@s linear infinite}
.wheelbox .comet{animation:cometrun @@TCOMET@@s linear infinite,cometcolor @@TCOMET@@s linear infinite;opacity:1}
@@COMETTAILS@@
.engine pre{animation:panelcycle @@TENG@@s linear infinite;opacity:0}
@@ENGDELAYS@@
@keyframes octzoom{from{background-size:@@TS0@@px @@TS0@@px}to{background-size:@@TS1@@px @@TS1@@px}}
@keyframes cometrun{@@COMETSTOPS@@}
@keyframes cometcolor{@@COMETCOLOR@@}
@keyframes panelcycle{0%{opacity:0}@@EON@@%{opacity:1}@@EOFF@@%{opacity:1}@@ESPAN@@%{opacity:0}100%{opacity:0}}
@keyframes eqpsi{@@GLOWSTOPS@@}
@@KEYFRAMES@@

main,header,footer{position:relative;z-index:1}

/* ── chrome ─────────────────────────────────────────────────────── */
header.site{position:sticky;top:0;z-index:12;
  backdrop-filter:blur(var(--sp-sm));
  background:color-mix(in srgb,var(--n1) calc(var(--a-1v)*100%),transparent);
  border-bottom:1px solid color-mix(in srgb,var(--n4) calc(var(--a-k)*100%),transparent)}
.nav{max-width:var(--bp-grid);margin:0 auto;padding:var(--sp-sm) var(--sp-md);
  display:flex;align-items:center;gap:var(--sp-lg);flex-wrap:wrap}
.brand{font-size:var(--fs-md);letter-spacing:.08em;color:var(--text);text-decoration:none}
.brand b{color:var(--advance)}
.nav a.item{color:var(--text-2);text-decoration:none;font-size:var(--fs-sm);letter-spacing:.06em;text-transform:uppercase}
.nav a.item:hover{color:var(--gold-text)}
.nav .spacer{flex:1}

.wrap{max-width:var(--bp-grid);margin:0 auto;padding:var(--sp-2xl) var(--sp-md)}
.grid{display:grid;grid-template-columns:repeat(var(--grid-n),1fr);gap:var(--sp-md)}
.col-12{grid-column:span 12}.col-6{grid-column:span 6}.col-4{grid-column:span 4}.col-3{grid-column:span 3}
@media (max-width:@@BPMID@@){.col-6,.col-4,.col-3{grid-column:span 12}}

/* ── hero ───────────────────────────────────────────────────────── */
.hero{min-height:calc(100vh*2/3);display:grid;place-items:center;text-align:center;padding:var(--sp-3xl) var(--sp-md);position:relative;overflow:hidden}
.hero > div{position:relative;z-index:1}
/* THE OCTAVE TUNNEL — one animation period = one exact octave.
   13 stops at (2^(j/12)−1)·100%; box 2^(132/12)px → 2^(144/12)px.
   Seamless by IC-1 / RC-24 S4 (the octave is one U(1) winding) —
   an infinite zoom with zero drift, impossible in float animation. */
.hero::before{content:"";position:absolute;inset:0;z-index:0;pointer-events:none;
  opacity:var(--a-v);
  background:repeating-radial-gradient(circle at 50% 42%, @@TUNNELSTOPS@@);
  background-repeat:no-repeat;background-position:center;
  background-size:@@TS0@@px @@TS0@@px}
.hero .eq{font-size:clamp(var(--fs-hero),calc(100vw/12),calc(var(--fs-hero)*2));
  letter-spacing:.06em;margin:0;
  color:var(--advance);
  text-shadow:
    0 0 var(--sp-sm) color-mix(in srgb,var(--advance) calc(var(--a-k)*100%),transparent),
    0 0 var(--sp-xl) color-mix(in srgb,var(--advance) calc(var(--a-kv)*100%),transparent)}
.hero .tag{font-style:italic;color:var(--text-2);font-size:var(--fs-lg);max-width:none}
.hero .sub{color:var(--link);letter-spacing:.24em;text-transform:uppercase;font-size:var(--fs-sm)}
.cta{display:inline-block;margin-top:var(--sp-lg);padding:var(--sp-sm) var(--sp-lg);
  border:1px solid var(--recede);border-radius:var(--rad-md);color:var(--text);
  text-decoration:none;letter-spacing:.1em;font-size:var(--fs-sm);text-transform:uppercase;
  transition:all var(--dur-base) var(--ease)}
.cta:hover{border-color:var(--advance);color:var(--link-hot);
  box-shadow:0 0 var(--sp-md) color-mix(in srgb,var(--advance) calc(var(--a-kv)*100%),transparent)}
.cta.primary{border-color:var(--gold);color:var(--gold-text)}

/* ── cards / sections ───────────────────────────────────────────── */
section{padding:var(--sp-2xl) 0;border-top:1px solid color-mix(in srgb,var(--n3) calc(var(--a-k)*100%),transparent)}
.card{background:color-mix(in srgb,var(--n2) calc(var(--a-1kv)*100%),transparent);
  border:1px solid color-mix(in srgb,var(--n4) calc(var(--a-k)*100%),transparent);
  border-radius:var(--rad-lg);padding:var(--sp-lg)}
.card h3{margin-top:0}
.prim{border-top:2px solid var(--pc)}
.prim .sig{font-size:var(--fs-2xl);color:var(--pc)}
.kde{display:inline-block;padding:calc(var(--sp-3xs)) var(--sp-xs);border-radius:var(--rad-sm);
  background:color-mix(in srgb,var(--pc,var(--recede)) calc(var(--a-v)*100%),transparent);
  color:var(--text);font-family:ui-monospace,Consolas,monospace;font-size:var(--fs-xs)}
table.consts{width:100%;border-collapse:collapse;font-size:var(--fs-sm)}
table.consts th,table.consts td{padding:var(--sp-xs) var(--sp-sm);text-align:left;
  border-bottom:1px solid color-mix(in srgb,var(--n3) calc(var(--a-k)*100%),transparent)}
table.consts th{color:var(--gold-text);letter-spacing:.06em;text-transform:uppercase;font-size:var(--fs-xs)}
table.consts td.mono{color:var(--text-2)}
/* THE CASCADE COMET — traverses the g=7 star; dwell per segment is the
   Magical Impedance of the landing family: dt_j = ξ(m_j)·2^(−24/12) s,
   harmonic m = d via SVT. It lingers through gravity (ξ = 8.5625),
   flashes through EM (ξ = 1). Distance stops j·100/12; TIME stops are
   the impedance-weighted cumulative percents. */
.wheelbox .comet{offset-path:path("@@COMETPATH@@");offset-rotate:0deg;fill:var(--c7);opacity:0}
/* THE ENGINE — twelve exact projections cycling by pure CSS */
.engine .stage{position:relative;overflow:hidden;
  height:calc(8*var(--fs-xs)*var(--lh) + var(--sp-lg));
  background:color-mix(in srgb,var(--n0) calc(var(--a-k)*100%),transparent);
  border:1px solid color-mix(in srgb,var(--n4) calc(var(--a-k)*100%),transparent);
  border-radius:var(--rad-lg)}
.engine pre{position:absolute;inset:0;margin:0;padding:var(--sp-md);
  font-size:var(--fs-xs);line-height:var(--lh);opacity:0;color:var(--text-2)}
.engine pre b{color:var(--gold-text)}
.engine pre .kd{color:var(--verdant-text)}
.engine pre.p0{opacity:1}
.wheelbox{display:grid;place-items:center;padding:var(--sp-lg)}
.wheelbox svg{width:min(100%,var(--bp-mid));height:auto;
  filter:drop-shadow(0 0 var(--sp-md) color-mix(in srgb,var(--arcane) calc(var(--a-kv)*100%),transparent))}

.depth-demo{background:var(--n0);border-radius:var(--rad-lg);padding:var(--sp-xl);text-align:center}
.depth-demo .far{color:var(--recede);font-size:var(--fs-2xl);letter-spacing:.3em}
.depth-demo .near{color:var(--advance);font-size:var(--fs-2xl);letter-spacing:.3em;
  text-shadow:0 0 var(--sp-sm) color-mix(in srgb,var(--advance) calc(var(--a-k)*100%),transparent)}

.evid{border-left:2px solid var(--verdant);padding-left:var(--sp-md)}
.evid b{color:var(--verdant-text)}

.doi{display:inline-flex;gap:var(--sp-xs);align-items:center;
  border:1px solid var(--arcane);border-radius:var(--rad-md);
  padding:var(--sp-xs) var(--sp-md);color:var(--arcane-text);text-decoration:none}
.doi:hover{color:var(--gold-text);border-color:var(--gold)}

footer.site{padding:var(--sp-xl) var(--sp-md);text-align:center;color:var(--text-3);
  border-top:1px solid color-mix(in srgb,var(--n3) calc(var(--a-k)*100%),transparent)}
footer.site .eqline{letter-spacing:.2em;color:var(--text-2)}
)CSS";

    // per-class color/size classes + halo
    std::ostringstream sc;
    for (long c = 0; c < 12; ++c)
        sc << ".star.c" << c << "{background:var(--c" << c << ");color:var(--c" << c << ")}\n";
    for (long d : DIVISORS) {
        long g = N / d;
        std::string dia = dec(lattice(g + 24), 10);   // box = 2^((g+24)/12) px
        sc << ".star.g" << g << "{width:" << dia << "px;height:" << dia << "px}\n";
    }
    // reduced-motion / base state: α = γ(w) — the mean-shimmer luminance
    for (long d : DIVISORS)
        sc << ".star.d" << d << "{opacity:" << STAR_STATIC[d] << "}\n";
    // every star blooms; the stable sublattice families (d ≤ 2) halo wide
    sc << ".star{box-shadow:0 0 calc(var(--sp-2xs)) currentColor}\n"
       << ".star.d1,.star.d2{box-shadow:0 0 calc(var(--sp-2xs)) currentColor,"
          "0 0 calc(var(--sp-md)) currentColor}\n";

    // motion block (gated by prefers-reduced-motion)
    std::ostringstream fm;
    for (long L = 0; L < 3; ++L)
        fm << "  .layer.L" << L << "{animation:drift " << DRIFT_T[(size_t)L]
           << "s linear infinite}\n";
    fm << "  .star{animation-timing-function:linear;animation-iteration-count:infinite}\n";
    for (long d : DIVISORS)
        fm << "  .star.d" << d << "{animation-name:tw-d" << d << "}\n";
    for (long c = 0; c < 12; ++c)
        fm << "  .star.c" << c << "{animation-duration:" << DUR_CLS[c] << "s}\n";

    // keyframes: 3 drift + 6 twinkle sets, 13 exact stops each
    std::ostringstream kf;
    kf << "@keyframes drift{from{transform:translateX(0)}to{transform:translateX(-50%)}}\n";
    for (long d : DIVISORS) {
        kf << "@keyframes tw-d" << d << "{";
        for (long j = 0; j <= 12; ++j)
            kf << KF_PCT[(size_t)j] << "%{opacity:" << TWINKLE[d][(size_t)j] << "}";
        kf << "}\n";
    }

    // tunnel stops: class colors at the exact octave fractions
    std::ostringstream tun;
    for (long j = 0; j <= 12; ++j)
        tun << (j ? ", " : "") << "var(--c" << (j % 12) << ") "
            << TUNNEL_PCT[(size_t)j] << "%";
    // comet: TIME% → distance% (equal chords)
    std::ostringstream cm;
    for (long j = 0; j <= 12; ++j)
        cm << COMET_TPCT[(size_t)j] << "%{offset-distance:"
           << KF_PCT[(size_t)j] << "%}";
    // comet: TIME% → node class color (the meteor runs the spectrum)
    std::ostringstream cc;
    for (long j = 0; j <= 12; ++j)
        cc << COMET_TPCT[(size_t)j] << "%{fill:var(--c"
           << COMET_CLS[(size_t)j] << ")}";
    // Koide tail rules
    std::ostringstream ct;
    for (long j = 1; j <= COMET_TAIL; ++j)
        ct << "  .wheelbox .comet.t" << j << "{animation:cometrun " << COMET_T
           << "s linear infinite,cometcolor " << COMET_T
           << "s linear infinite;animation-delay:" << COMET_TDELAY[(size_t)(j-1)]
           << "s," << COMET_TDELAY[(size_t)(j-1)] << "s;opacity:"
           << COMET_TALPHA[(size_t)(j-1)] << "}\n";
    // engine per-panel delays
    std::ostringstream ed;
    for (size_t i = 0; i < ENGINE.size(); ++i)
        ed << "  .engine pre.p" << i << "{animation-delay:"
           << dec(neg(Mp((long)i) * Mp(ENG_SLOT)), 8) << "s}\n";
    // Ψ-glow stops
    std::ostringstream gl;
    for (long j = 0; j <= 12; ++j)
        gl << KF_PCT[(size_t)j] << "%{text-shadow:0 0 " << GLOW_B1[(size_t)j]
           << "rem color-mix(in srgb,var(--advance) calc(var(--a-k)*100%),transparent),"
           << "0 0 " << GLOW_B2[(size_t)j]
           << "rem color-mix(in srgb,var(--advance) calc(var(--a-kv)*100%),transparent)}";
    replace_all(tpl, "@@TUNNELSTOPS@@", tun.str());
    replace_all(tpl, "@@TS0@@", TUNNEL_S0);
    replace_all(tpl, "@@TS1@@", TUNNEL_S1);
    replace_all(tpl, "@@TTUN@@", TUNNEL_T);
    replace_all(tpl, "@@COMETPATH@@", COMET_PATH);
    replace_all(tpl, "@@COMETSTOPS@@", cm.str());
    replace_all(tpl, "@@TCOMET@@", COMET_T);
    replace_all(tpl, "@@COMETCOLOR@@", cc.str());
    replace_all(tpl, "@@COMETTAILS@@", ct.str());
    replace_all(tpl, "@@TENG@@", ENG_T);
    replace_all(tpl, "@@ENGDELAYS@@", ed.str());
    replace_all(tpl, "@@EON@@", ENG_ON);
    replace_all(tpl, "@@EOFF@@", ENG_OFF);
    replace_all(tpl, "@@ESPAN@@", dec(Mp(100L) / Mp(12L), 12));
    replace_all(tpl, "@@TGLOW@@", dec(lattice(36), 6));
    replace_all(tpl, "@@GLOWSTOPS@@", gl.str());
    std::string vars;
    for (auto& v : CSS_VARS) vars += v + "\n";
    if (!vars.empty()) vars.pop_back();
    replace_all(tpl, "@@VARS@@", vars);
    replace_all(tpl, "@@STARCLASSES@@", sc.str());
    replace_all(tpl, "@@FIELDMOTION@@", fm.str());
    replace_all(tpl, "@@KEYFRAMES@@", kf.str());
    replace_all(tpl, "@@BPMID@@", px_s(108, 10));
    return tpl;
}

// ═════════════════════════════════════════════════════════════════════
//  HTML
// ═════════════════════════════════════════════════════════════════════
static std::string field_html() {
    std::ostringstream strips[3];
    for (auto& s : STARS)
        strips[s.layer] << "<i class=\"star c" << s.cls << " d" << s.d
                        << " g" << s.g << "\" style=\"left:" << s.x_pct
                        << "%;top:" << s.y_pct << "%;animation-delay:"
                        << s.delay_s << "s\"></i>";
    std::ostringstream o;
    o << "<div class=\"fieldwrap\" aria-hidden=\"true\">";
    for (int L = 0; L < 3; ++L)
        o << "<div class=\"layer L" << L << "\"><div class=\"strip\">"
          << strips[L].str() << "</div><div class=\"strip\">"
          << strips[L].str() << "</div></div>";
    o << "</div>";
    return o.str();
}
static std::string constants_rows() {
    struct Row { const char* sym; const char* val; const char* role; const Mp* r; };
    static const Mp c12(12L), c3(3L), c4(4L), c137(137L);
    const Row rows[] = {
        {"N", "12", "manifold symmetry — |Π|·S", &c12},
        {"V", "1/12", "base variance", &V},
        {"K", "2/3", "Koide binding threshold", &Kk},
        {"|Π|", "3", "primitives {P, D, T}", &c3},
        {"S", "4", "manifold states", &c4},
        {"A₀", "137", "base fine-structure integer", &c137},
        {"ƛ_e", "386.15926796 fm", "appearance reference (IC-143)", &LAMBDA_E_NM},
        {"∂I", "50 ¢", "incoherence half-step (Identity F)", nullptr},
        {"Λ", "1200 / ln 2", "manifold conversion constant (Thm B.5)", &Lambda()},
        {"Λ_θ", "600 / π", "phase conversion constant (Thm D.5)", &LambdaTheta()},
    };
    std::ostringstream o;
    for (auto& r : rows) {
        std::string addr;
        if (r.r) {
            Proj p = project(*r.r);
            addr = "<span class=\"kde\">k=" + std::string(p.k >= 0 ? "+" : "") +
                   std::to_string(p.k) + ", d=" + std::to_string(p.d) +
                   ", ε=" + dec(p.eps, 5) + "¢</span>";
        } else addr = "<span class=\"kde\">|ε| = 600/N</span>";
        o << "<tr><td>" << r.sym << "</td><td class='mono'>" << r.val
          << "</td><td>" << r.role << "</td><td>" << addr << "</td></tr>\n";
    }
    return o.str();
}
static std::string products_block() {
    if (CFG.products.empty())
        return "<div class='card col-12'><h3>Forthcoming</h3>"
               "<p>The first product line — software and instruments built "
               "directly from the algebraic identities of the Sempaevum "
               "lattice — is in final preparation. Releases will be "
               "announced here, on this page, when the doors open.</p>"
               "<p class='small'>Every product ships with its derivation: "
               "zero free parameters, verification scripts included.</p></div>";
    std::ostringstream o;
    for (auto& p : CFG.products)
        o << "<div class='card col-4'><h3>" << p[0] << "</h3><p>" << p[1]
          << "</p><a class='cta' href='" << p[2] << "'>" << p[3] << "</a></div>";
    return o.str();
}
static std::string palette_strip() {
    std::ostringstream o;
    o << "<div style='display:flex;border-radius:var(--rad-md);overflow:hidden'>";
    for (auto& c : CLASSES) {
        std::string title = (c.cls <= 10)
            ? "class " + std::to_string(c.cls) + " · λ=" + c.lambda_nm.substr(0, 6) +
              " nm · k=" + std::to_string(c.k)
            : "class 11 · purple line";
        o << "<div title='" << title << "' style='background:var(--c" << c.cls
          << ");height:var(--sp-lg);flex:1'></div>";
    }
    o << "</div>";
    return o.str();
}
static std::string build_html(const std::string& wheel) {
    std::string t = R"HTML(<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>@@TITLE@@ — P∘D∘T = E</title>
<meta name="description" content="Exception Theory: a foundational framework built from three irreducible primitives. One equation, zero free parameters, interventional evidence. @@ORG@@.">
<meta property="og:title" content="@@TITLE@@ — P∘D∘T = E">
<meta property="og:description" content="@@TAGLINE@@">
<meta property="og:type" content="website">
<meta property="og:url" content="https://@@DOMAIN@@/">
<link rel="stylesheet" href="css/et.css">
</head>
<body>
<div class="nebula" aria-hidden="true"></div>
@@FIELD@@
<div class="veil" aria-hidden="true"></div>

<header class="site">
  <nav class="nav" aria-label="primary">
    <a class="brand" href="#top"><b>Exception</b>&nbsp;Theory</a>
    <span class="spacer"></span>
    <a class="item" href="#theory">Theory</a>
    <a class="item" href="#lattice">Lattice</a>
    <a class="item" href="#evidence">Evidence</a>
    <a class="item" href="#engine">Engine</a>
    <a class="item" href="#papers">Papers</a>
    <a class="item" href="#products">Products</a>
    <a class="item" href="#about">About</a>
  </nav>
</header>

<main id="top">
  <!-- ET runtime diagnostics layer v1: motion / offset-path / color-mix -->
  <div class="sysdiag" role="status" aria-live="polite">
    <div class="witness">
      <span class="w-fail"><b>⚠ MOTION ENGINE NOT RUNNING.</b> This page's
      animations are not executing. In order of likelihood: (1) stale
      stylesheet — hard-refresh with Ctrl+F5; (2) browser battery or
      energy saver — disable it for this page; (3) an extension or user
      style pausing animations; (4) a rendering-pipeline fault. The
      dynamics themselves are forge-verified; a healthy engine replaces
      this notice with the live lamp.</span>
      <span class="w-live">motion engine <b>LIVE</b> — witnessed by
      traversal, one-second lattice beat <i class="beat"></i></span>
    </div>
    <p class="diag diag-motion"><b>Your operating system requests reduced
    motion.</b> On this page, motion is the content: every animation is a
    verified mathematical law running at gentle amplitude and slow lattice
    period, so it remains live by design. (The Windows switch, should you
    want system animations back generally: Settings ▸ Accessibility ▸
    Visual effects ▸ Animation effects.)</p>
    <p class="diag diag-offset"><b>This browser lacks CSS
    <code>offset-path</code>.</b> The cascade meteor cannot travel its
    rail here and is parked invisible by design; everything else runs.</p>
    <p class="diag diag-colormix"><b>This browser lacks CSS
    <code>color-mix()</code>.</b> Auroras, glows and translucent washes
    render simplified here.</p>
  </div>
  <div class="hero">
    <div>
      <p class="sub">a foundational framework · three primitives · zero free parameters</p>
      <h1 class="eq">P&thinsp;∘&thinsp;D&thinsp;∘&thinsp;T&nbsp;=&nbsp;E</h1>
      <p class="tag">“@@TAGLINE@@”</p>
      <p><a class="cta primary" href="#theory">Enter the theory</a>
         <a class="cta" href="@@DOIURL@@">Read the paper</a></p>
    </div>
  </div>

  <div class="wrap">

  <section id="theory">
    <h2>The Theory</h2>
    <p>Exception Theory is built from exactly three irreducible primitives.
    Everything else — number, geometry, force, field, mind — is a
    configuration of the three. The framework stands as a complete
    foundational alternative: where the Standard Model begins from
    measured couplings and M-theory from postulated geometry, Exception
    Theory begins from the primitives and derives forward, with zero
    free parameters at every step.</p>
    <div class="grid">
      <div class="card prim col-4" style="--pc:var(--recede)">
        <div class="sig">P</div><h3>Point</h3>
        <p>The substrate — the bare, featureless container of potential.
        Infinite. Undifferentiated. Cardinality Ω. Strip away everything
        describable, and what remains is P.</p>
      </div>
      <div class="card prim col-4" style="--pc:var(--verdant)">
        <div class="sig">D</div><h3>Descriptor</h3>
        <p>The constraint — every rule, value, law, and property. Finite
        when bound. Cardinality n. All of mathematics and every physical
        law lives here.</p>
      </div>
      <div class="card prim col-4" style="--pc:var(--advance)">
        <div class="sig">T</div><h3>Traverser</h3>
        <p>The agency — the navigator that substantiates. Indeterminate,
        cardinality [0/0]. Choice, observation, becoming. Irreducible to
        rule or substrate.</p>
      </div>
    </div>
    <h3>The bijection</h3>
    <p>The lattice engine of the theory is a lossless projection. For any
    positive ratio r and resolution N,</p>
    <p class="mono">Π_N(r) = (k, d, ε)&nbsp;&nbsp;with&nbsp;&nbsp;
    k = round(N·log₂ r),&nbsp; d = N/gcd(|k|, N),&nbsp;
    ε = (N·log₂ r − k)·1200/N</p>
    <p>and the pullback 2^((k + ε·N/1200)/N) = r is an <em>algebraic
    identity</em> — not an approximation, not a fit. Zero error by
    theorem, for any positive real: rational, irrational, or
    transcendental. ε is the exact third coordinate, never noise. Every
    value on this page — every color, every length, every duration,
    every animation stop — is such an address, computed in exact
    arbitrary-precision arithmetic and carried as strings; this page
    contains no JavaScript and its forge contains no floating point.
    The build verifies itself by re-projection before it is permitted
    to exist.</p>
    <h3>The constants</h3>
    <table class="consts">
      <tr><th>Symbol</th><th>Value</th><th>Role</th><th>Lattice address</th></tr>
      @@CONSTROWS@@
    </table>
  </section>

  <section id="lattice">
    <h2>The Lattice — the visible octave</h2>
    <p>Project the visible band of the electromagnetic spectrum through
    Π₁₂ against the appearance reference ƛ_e and it lands on eleven
    consecutive lattice cells, k = 120 through 130 — violet sitting
    exactly ten octaves above ƛ_e, red at the tenth semitone. One cell
    remains to close the circle, and colorimetry supplies it: the
    non-spectral purple line. The k-axis <em>is</em> the chromaticity
    coordinate. The palette of this site is not styled — it is the
    visible octave itself, each swatch an address:</p>
    @@PALETTE@@
    <div class="wheelbox">@@WHEEL@@</div>
    <p class="small">Sector boundaries are the ∂I half-step lines
    (|ε| = 50¢, Identity F). The inscribed star polygons are the four
    generator traversals g ∈ {1, 5, 7, 11} — the cascade skeleton.
    White on this site is D65: the identity cell (0, 1, 0) in all three
    tristimulus channels — the Exception state of color. The wheel closes
    because the bijection does: the octave is one winding of U(1), the
    integer k counting windings while ε carries the phase. And the wheel's
    own proportions — like every proportion on this page — are shape
    projections: ratios, hence addresses (Identity K).</p>
    <h3>Depth without depth</h3>
    <div class="depth-demo">
      <span class="near">ADVANCE</span>&nbsp;&nbsp;&nbsp;
      <span class="far">RECEDE</span>
      <p class="small" style="margin-top:var(--sp-md);max-width:none">
      Long-wavelength red floats forward; short-wavelength blue sinks
      back — chromostereopsis, the eye's own transverse chromatic
      aberration reading wavelength as depth on a dark ground. The page
      you are looking at is running that projection on you right now.</p>
    </div>
  </section>

  <section id="evidence">
    <h2>Evidence</h2>
    <p>The standard is interventional. A framework earns its place not by
    reclassifying what is already known but by naming a knob nature has
    never been asked about — forbidden by default, zero free parameters,
    binary control — and being right when it is turned. That is the
    category Exception Theory builds for, and the derivations already on
    record set the table:</p>
    <div class="grid">
      <div class="evid col-6"><p><b>α⁻¹ derived forward.</b> The fine
      structure constant, derived from the primitives with zero free
      parameters; the CODATA 2022 measurement concurs to 0.46σ.</p></div>
      <div class="evid col-6"><p><b>The particle ledger.</b> 227 PDG
      particles and 2,324 AME2020 isotopes carry valid lattice addresses
      under one projection — one rule, no per-particle tuning.</p></div>
      <div class="evid col-6"><p><b>The vacuum reads back.</b> STAR
      Collaboration QCD vacuum data lands where the lattice says it
      lands: |ε|/cell = 0.2508 ± 0.0069 across fifteen LCM tower
      levels, and the short-range pair-polarization ceiling reads
      P_max = 1 − K at 4.4σ with long-range zero — the phase-axis
      coherence depth n_max,θ = 2, confirmed across four independent
      domains.</p></div>
      <div class="evid col-6"><p><b>Interventional bench.</b> The gravity
      channel — harmonic family m = 1, read at its d = 1 sublattice
      positions via the SVT — detects gravitational tilt through a
      lossless microphone pipeline, replicated independently across
      operators and hardware.</p></div>
      <div class="evid col-12"><p><b>Same cell, different sciences.</b>
      Kleiber's metabolic exponent 2^(3/4) and the concert interval
      A440 / C261.63 occupy one lattice address, (k = 9, d = 4); the
      Kolmogorov turbulence law 2^(5/3) shares its cell with π at
      (k = 20, d = 3). Not analogies — the same structure, read by
      different laboratories, forced by the lattice (Identity R.11).</p></div>
      <div class="evid col-12"><p><b>Shapes are addresses.</b> Any form
      decomposes into coefficient ratios, and ratios project (Identity K):
      the doubly-magic nuclei ⁴⁰Ca and ⁴⁸Ca — eight neutrons apart —
      land in one cell (k = −82, d = 6) with Δε ≈ 0.25¢, the neutron
      skin living entirely in ε; the hydrogen 1s ground state sits
      lattice-exact at (−12, 1, 0); and a Lorentzian dielectric driven
      at half its plasma frequency returns the perfect fourth, 4/3 = 2K,
      carrying the lattice's own canonical residual, |ε| = 1.955¢. Every
      proportion on this page is itself such a projection.</p></div>
    </div>
    <p class="small">Derived first; measurement concurs. Full
    derivations, identity cards, and verification scripts accompany the
    paper below.</p>
  </section>

  <section id="engine" class="engine">
    <h2>The Engine</h2>
    <p>The identities are not only laws — they are a computation engine.
    Any real number, to any depth, with zero machine error: the guard
    digits absorb every transcendental residual, and the round-trip is
    string-exact. Twelve projections, printed by the forge itself and
    re-verified on every build:</p>
    <div class="stage">
@@ENGINEPANELS@@
    </div>
    <p class="small">Each panel shows sixty digits of a two-hundred-digit
    computation. The pullback line is not an approximation of the input —
    it is the input, recovered by algebraic identity. This page cannot
    display a rounding error, because its forge cannot make one.</p>
  </section>

  <section id="papers">
    <h2>Papers</h2>
    <div class="card">
      <h3>The Sempaevum Paper</h3>
      <p>The foundational document: the primitives, the master equation,
      the lossless bijection, the tower, and the identity corpus —
      741 algebraic identity cards and counting, each derived forward
      from P∘D∘T = E and verified at 250 decimal digits.</p>
      <a class="doi" href="@@DOIURL@@">DOI&nbsp;@@DOI@@</a>
    </div>
  </section>

  <section id="products">
    <h2>Products</h2>
    <div class="grid">
      @@PRODUCTS@@
    </div>
  </section>

  <section id="about">
    <h2>About</h2>
    <p><b>@@ORG@@</b> — @@ORGLOC@@. Founded and authored by
    @@AUTHOR@@, sole creator of Exception Theory: fifteen years of
    derivation, a published formal paper, an audited identity compendium,
    verified computation at the Ω standard, and instruments in build.</p>
    <p>Correspondence: <a href="mailto:@@EMAIL@@">@@EMAIL@@</a></p>
  </section>

  </div>
</main>

<footer class="site">
  <p class="eqline">P ∘ D ∘ T = E</p>
  <p class="small">© @@YEAR@@ @@ORG@@ ·
  <a href="@@DOIURL@@">DOI @@DOI@@</a> ·
  forged losslessly from the constants — every value on this page is a
  lattice address; no JavaScript, no floating point in the chain.</p>
</footer>
</body>
</html>
)HTML";
    replace_all(t, "@@TITLE@@", CFG.title);
    replace_all(t, "@@ORG@@", CFG.org);
    replace_all(t, "@@ORGLOC@@", CFG.org_loc);
    replace_all(t, "@@AUTHOR@@", CFG.author);
    replace_all(t, "@@TAGLINE@@", CFG.tagline);
    replace_all(t, "@@DOMAIN@@", CFG.domain);
    replace_all(t, "@@DOIURL@@", CFG.doi_url);
    replace_all(t, "@@DOI@@", CFG.doi);
    replace_all(t, "@@EMAIL@@", CFG.email);
    replace_all(t, "@@YEAR@@", CFG.year);
    {
        std::ostringstream ep;
        for (size_t i = 0; i < ENGINE.size(); ++i) {
            const auto& e = ENGINE[i];
            ep << "<pre class=\"p" << i << "\"><b>" << e.name << "</b> — " << e.law
               << "\n r        = " << e.r60 << "…"
               << "\n Π₁₂(r)   = <span class=\"kd\">" << e.kd << "</span>"
               << "\n ε        = " << e.eps60 << "… ¢"
               << "\n Π⁻¹(k,ε) = " << e.back60 << "…"
               << "\n round-trip string-exact @ 200 working digits — zero machine error</pre>\n";
        }
        replace_all(t, "@@ENGINEPANELS@@", ep.str());
    }
    replace_all(t, "@@FIELD@@", field_html());
    replace_all(t, "@@CONSTROWS@@", constants_rows());
    replace_all(t, "@@PALETTE@@", palette_strip());
    replace_all(t, "@@WHEEL@@", wheel);
    replace_all(t, "@@PRODUCTS@@", products_block());
    return t;
}

// ═════════════════════════════════════════════════════════════════════
//  VERIFICATION — the build must prove itself
// ═════════════════════════════════════════════════════════════════════
struct Result { std::string name; bool ok; std::string detail; };
static std::vector<Result> RESULTS;
static void check(const std::string& n, bool ok, const std::string& d = "") {
    RESULTS.push_back({n, ok, d});
}
static Mp rel_lum(const std::string& hx) { return hex_to_xyz(hx).b / Yn; }
static Mp contrast(const std::string& fg, const std::string& bg) {
    Mp L1 = rel_lum(fg), L2 = rel_lum(bg);
    Mp hi = mmax(L1, L2), lo = mmin(L1, L2);
    return (hi + Mp("0.05")) / (lo + Mp("0.05"));
}
static void verify_all() {
    // 1 — geometry tokens lattice-exact; ε at the digit floor
    Mp floor_eps = powm(Mp(10L), Mp(-(DIGITS - 20)));
    for (auto* tab : {&TYPE_SCALE, &SPACE_SCALE, &RADII, &DUR, &BPTS})
        for (auto& [name, k] : *tab) {
            Proj p = project(lattice(k));
            bool ok = (p.k == k) && lt(mabs(p.eps), floor_eps);
            check("lattice-exact token " + name + " (k=" + std::to_string(k) + ")",
                  ok, "ε=" + dec(p.eps, 3) + "¢");
        }
    // precision-scaling witness — the losslessness proof, in C++
    Mp r7 = exp2m(Mp(7L) / Mp(12L));
    std::array<Mp,3> resid;
    long dset[3] = {60, 120, 250};
    for (int i = 0; i < 3; ++i) {
        mpfr_prec_t pp = bits_for(dset[i]);
        Mp rp(Mp::Prec{pp}); mpfr_set(rp.v, r7.v, MPFR_RNDN);
        resid[(size_t)i] = mabs(project_p(rp, pp).eps);
    }
    check("precision scaling (ε computational only, IC-1 witness)",
          (lt(resid[1], resid[0]) && lt(resid[2], resid[1])) ||
          (is_zero(resid[0]) && is_zero(resid[1]) && is_zero(resid[2])),
          dec(resid[0], 3) + " > " + dec(resid[1], 3) + " > " + dec(resid[2], 3));
    // transcendental losslessness: r = π and r = 2^(1/12)·e round-trip
    {
        // canonical lossless test (canon: nstr-truncation equality at WORK
        // digits; the 50 guard digits absorb all transcendental residual)
        Mp pi_r = pi_m();
        Proj p = project(pi_r);
        Mp back = pullback(p.k, p.eps);
        for (long wd : {50L, 100L, 200L})
            check("canonical lossless test: π string-exact at " +
                  std::to_string(wd) + " working digits",
                  dec(back, (int)wd) == dec(pi_r, (int)wd));
        Mp e_r(0L); mpfr_set_ui(e_r.v, 1, MPFR_RNDN); mpfr_exp(e_r.v, e_r.v, MPFR_RNDN);
        Mp val = lattice(1) * e_r;
        Proj q = project(val);
        Mp back2 = pullback(q.k, q.eps);
        check("transcendental round-trip r=2^(1/12)·e string-exact @ 200 digits",
              dec(back2, (int)WORK_DIGITS) == dec(val, (int)WORK_DIGITS));
        Proj pl = project(Lambda());
        check("Λ = 1200/ln2 round-trip string-exact @ 200 digits",
              dec(pullback(pl.k, pl.eps), (int)WORK_DIGITS) ==
              dec(Lambda(), (int)WORK_DIGITS), "Λ = " + dec(Lambda(), 12));
        // Identity R.2 shimmer: mean over one period = 1 exactly (Σ sin = 0)
        {
            Mp two_pi_v = Mp(2L) * pi_m(), acc(0L), sV = sqrtm(V);
            for (long n = 0; n < 12; ++n)
                acc = acc + Mp(1L) + sV * sinm(two_pi_v * Mp(n) / Mp(12L));
            check("Identity R.2 shimmer mean over period = 1 exactly",
                  dec(acc / Mp(12L), (int)WORK_DIGITS) == "1",
                  dec(acc / Mp(12L), 8));
        }
        // Identity F tightness at ∂I equals the Koide threshold exactly
        {
            Mp W = CENTS / Mp(N);
            Mp t = W / (W + DI_CENTS);
            check("tightness t(∂I) = W/(W+∂I) = K = 2/3 exactly",
                  dec(t, (int)WORK_DIGITS) == dec(Kk, (int)WORK_DIGITS),
                  dec(t, 12));
        }
        // Identity M/H impedance weights re-derived
        {
            bool wok = true;
            for (long dd : DIVISORS) {
                Mp lhs = xi_fn(dd) / xi_fn(1);
                Mp S2 = Mp(S_STATES * S_STATES);
                Mp rhs = S2 / ((Mp(dd) - Mp(1L)) * (Mp(dd) - Mp(1L)) + S2);
                if (dec(lhs, (int)WORK_DIGITS) != dec(rhs, (int)WORK_DIGITS)) wok = false;
            }
            check("field weights w = ξ(m)/ξ(1) = S²/((m−1)²+S²), m = d via SVT (Identity M/H)", wok);
        }
        // Identity R.11 cross-domain cell identifications (as shown on the site)
        {
            Proj kl = project(exp2m(Mp(3L) / Mp(4L)));
            Proj co = project(Mp("440") / Mp("261.63"));
            Proj km = project(exp2m(Mp(5L) / Mp(3L)));
            Proj pj = project(pi_m());
            check("R.11 Kleiber 2^(3/4) → (k=9, d=4) lattice-exact",
                  kl.k == 9 && kl.d == 4 && lt(mabs(kl.eps), Mp("0.001")),
                  "ε=" + dec(kl.eps, 3) + "¢");
            check("R.11 concert A440/C261.63 → same cell (k=9, d=4)",
                  co.k == 9 && co.d == 4, "ε=" + dec(co.eps, 4) + "¢");
            check("R.11 Kolmogorov 2^(5/3) → (k=20, d=3) lattice-exact",
                  km.k == 20 && km.d == 3 && lt(mabs(km.eps), Mp("0.001")),
                  "ε=" + dec(km.eps, 3) + "¢");
            check("R.11 π shares the Kolmogorov cell (k=20, d=3)",
                  pj.k == 20 && pj.d == 3, "ε=" + dec(pj.eps, 4) + "¢");
        }
    }
    // 2 — spectral classes re-projected; SIC-39 ordering
    std::vector<long> ks;
    for (auto& c : CLASSES) {
        if (c.cls > 10) continue;
        Proj p = project(Mp(c.lambda_nm) / LAMBDA_E_NM);
        bool ok = (p.k == c.pk) && (p.d == c.pd) &&
                  lt(mabs(p.eps - Mp(c.peps)), Mp("1e-40"));
        check("spectral class " + std::to_string(c.cls) + " address (k=" +
              std::to_string(p.k) + ")", ok);
        ks.push_back(c.pk);
    }
    bool mono = true;
    for (size_t i = 0; i + 1 < ks.size(); ++i) if (ks[i] >= ks[i + 1]) mono = false;
    check("SIC-39 monotone k-ordering across palette", mono,
          "k = " + std::to_string(ks.front()) + "…" + std::to_string(ks.back()));
    // 3 — IC-117 white = identity cell
    {
        auto tr = color_to_lattice("#ffffff");
        bool ok = true; std::string d;
        for (auto& ch : tr) {
            ok = ok && !ch.pole && ch.k == 0 && ch.d == 1 &&
                 lt(mabs(Mp(ch.eps)), Mp("0.2"));
            d += "(k=" + std::to_string(ch.k) + ",d=" + std::to_string(ch.d) + ") ";
        }
        check("IC-117 white = (0,1,0)^3 identity cell", ok, d);
    }
    // 4 — universal round-trips (all colors; P-pole path included)
    std::vector<std::string> tests;
    for (auto& c : CLASSES) { tests.push_back(c.hex); tests.push_back(c.hex_dim); }
    for (auto& [j, hx] : NEUTRAL) tests.push_back(hx);
    for (const char* h : {"#ff0000", "#00ff00", "#0000ff", "#ffff00",
                          "#00ffff", "#ff00ff", "#ffffff", "#123456"})
        tests.push_back(h);
    for (auto& hx : tests) {
        std::string back = lattice_to_color(color_to_lattice(hx));
        check("universal round-trip " + hx, back == hx, "→ " + back);
    }
    // 5 — derived structure
    check("generators derived = {1,5,7,11}",
          GENERATORS == std::vector<long>({1, 5, 7, 11}));
    check("divisors derived = {1,2,3,4,6,12}",
          DIVISORS == std::vector<long>({1, 2, 3, 4, 6, 12}));
    check("xi(1) = A0/16", lt(mabs(xi_fn(1) - Mp(A0) / Mp(16L)), Mp("1e-200")));
    // 6 — WCAG on the tokens as used
    const std::string bg = NEUTRAL[1];
    struct Pair { std::string n, fg, bg; const char* req; };
    std::vector<Pair> pairs = {
        {"body text n11/bg", NEUTRAL[11], bg, "7"},
        {"secondary n10/bg", NEUTRAL[10], bg, "4.5"},
        {"tertiary n9/surface", NEUTRAL[9], NEUTRAL[3], "3"},
        {"link c3-even/bg", CLASSES[3].hex_even, bg, "4.5"},
        {"gold-text c7-even/bg", CLASSES[7].hex_even, bg, "4.5"},
        {"verdant-text c6-even/bg", CLASSES[6].hex_even, bg, "4.5"},
        {"arcane-text c11-even/bg", CLASSES[11].hex_even, bg, "4.5"},
        {"brand+hero advance c10/bg", CLASSES[10].hex, bg, "4.5"},
        {"demo near c10/n0", CLASSES[10].hex, NEUTRAL[0], "3"},
        {"demo far c3/n0", CLASSES[3].hex, NEUTRAL[0], "3"},
    };
    for (auto& p : pairs) {
        Mp ratio = contrast(p.fg, p.bg);
        check("WCAG " + p.n + " >= " + p.req, !lt(ratio, Mp(p.req)),
              "ratio " + dec(ratio, 4));
    }
    // 7 — field playback strings re-derive identically
    for (size_t idx : {size_t(0), size_t(1), size_t(2), size_t(3), size_t(4),
                       size_t(5), size_t(6), size_t(7), size_t(8), size_t(9),
                       size_t(10), size_t(11), size_t(134), size_t(135), size_t(136)}) {
        const Star& s = STARS[idx];
        Proj p = project(Mp(s.i));
        Mp f = (p.eps + DI_CENTS) / (Mp(2L) * DI_CENTS);
        Mp T = lattice(s.cls) * Mp(2L);
        bool ok = (s.cls == ((p.k % N) + N) % N) && (s.d == p.d) &&
                  (s.delay_s == dec(neg(f * T), 12)) &&
                  (s.frac == dec(f, 15));
        check("star i=" + std::to_string(s.i) + " address+phase playback", ok);
    }
    check("star count = A0", (long)STARS.size() == A0, std::to_string(STARS.size()));
    check("phase fraction law f=(ε+∂I)/(2∂I) bounded [0,1]",
          [&]{ for (auto& s : STARS) { Mp f(s.frac);
                 if (lt(f, Mp(0L)) || lt(Mp(1L), f)) return false; } return true; }());
    // twinkle stops re-derived (all d, all j)
    {
        Mp two_pi = Mp(2L) * pi_m(), sV = sqrtm(V);
        bool ok = true, sk = true;
        for (long d : DIVISORS) {
            Mp w = xi_fn(d) / xi_fn(1);
            if (STAR_STATIC[d] != dec(gamma_enc(mmin(Mp(1L), w)), 6)) sk = false;
            for (long j = 0; j <= 12; ++j) {
                Mp psi = Mp(1L) + sV * sinm(two_pi * Mp(j) / Mp(12L));
                if (TWINKLE[d][(size_t)j] !=
                    dec(gamma_enc(mmin(Mp(1L), w * psi)), 10)) ok = false;
            }
        }
        check("twinkle stops re-derived: α = γ(min(1, w·Ψ)) — device-encoded luminance "
              "(6 sublattice families × 13 stops)", ok);
        check("reduced-motion base α = γ(w) re-derived (Ψ mean = 1)", sk);
        bool loop_ok = true;
        for (long d : DIVISORS)
            if (TWINKLE[d][0] != TWINKLE[d][12]) loop_ok = false;
        check("twinkle cycle closure (stop 0 = stop 12)", loop_ok);
    }
    // drift durations from the law T_L = bp-grid/(V·2^(2−L))
    for (long L = 0; L < 3; ++L) {
        Mp T = lattice(120) / (V * exp2m(Mp(2L - L)));
        check("drift T_L layer " + std::to_string(L) + " = 3072·2^L s",
              DRIFT_T[(size_t)L] == dec(T, 8), DRIFT_T[(size_t)L] + "s");
    }
    // keyframe percents are the V-ladder j·100/12
    {
        bool ok = true;
        for (long j = 0; j <= 12; ++j)
            if (KF_PCT[(size_t)j] != dec(Mp(j) * Mp(100L) / Mp(12L), 18)) ok = false;
        check("keyframe stops = j·100/12 (V-ladder percents)", ok);
    }

    // ── further canon checks mined from the identity-script uploads ──
    check("A₀ = (N−1)² + S² = 137 (derived, not hardcoded)",
          A0 == 137, std::to_string(N - 1) + "²+" + std::to_string(S_STATES) +
          "² = " + std::to_string(A0));
    {   // Thm B.3 palindrome + Thm F.2 adjacency + Identity C.4
        std::vector<long> seq;
        for (long k = 0; k < N; ++k)
            seq.push_back(N / ((k != 0) ? std::gcd(k, N) : N));
        bool pal = true, adj = true;
        for (long k = 1; k < N; ++k)
            if (seq[(size_t)k] != seq[(size_t)(N - k)]) pal = false;
        for (long k = 0; k < N; ++k)
            if (seq[(size_t)k] == seq[(size_t)((k + 1) % N)]) adj = false;
        check("sublattice d-sequence palindrome d(k)=d(N−k) (Thm B.3)", pal);
        check("adjacent cells never share a sublattice family (Thm F.2)", adj);
        bool c4 = true;
        for (long dv : DIVISORS) {
            bool found = false;
            for (long k1 = 0; k1 < N && !found; ++k1) {
                if (seq[(size_t)k1] != dv) continue;
                for (long k2 = 0; k2 < N && !found; ++k2) {
                    if (seq[(size_t)k2] != dv) continue;
                    long ssum = (k1 + k2) % N;
                    if (N / ((ssum != 0) ? std::gcd(ssum, N) : N) == 1) found = true;
                }
            }
            if (!found) c4 = false;
        }
        check("universal d=1 channel: 1 ∈ d⊗d ∀ d (Identity C.4)", c4);
    }
    {   // Identity A lattice arithmetic (κ T-act) + Identity B finite shift
        Mp e_v(0L); mpfr_set_ui(e_v.v, 1, MPFR_RNDN); mpfr_exp(e_v.v, e_v.v, MPFR_RNDN);
        Mp pi_v = pi_m();
        Proj a = project(pi_v), b = project(e_v);
        Mp da = a.eps * Mp(N) / CENTS, db = b.eps * Mp(N) / CENTS;
        long kap = to_long(rint_m(da + db));
        Mp eps_m = (da + db - Mp(kap)) * CENTS / Mp(N);
        check("Identity A lattice-multiply π·e string-exact @200 (κ=" +
              std::to_string(kap) + ")",
              dec(pullback(a.k + b.k + kap, eps_m), (int)WORK_DIGITS) ==
              dec(pi_v * e_v, (int)WORK_DIGITS));
        long kap_d = to_long(rint_m(da - db));
        Mp eps_dv = (da - db - Mp(kap_d)) * CENTS / Mp(N);
        check("Identity A lattice-divide π/e string-exact @200 (κ=" +
              std::to_string(kap_d) + ")",
              dec(pullback(a.k - b.k + kap_d, eps_dv), (int)WORK_DIGITS) ==
              dec(pi_v / e_v, (int)WORK_DIGITS));
        Mp shift("10");
        check("Identity B finite shift: π·2^(10¢/1200) = pullback(k, ε+10¢) string-exact",
              dec(pi_v * exp2m(shift / CENTS), (int)WORK_DIGITS) ==
              dec(pullback(a.k, a.eps + shift), (int)WORK_DIGITS));
    }
    {   // Finding 11 / E2: lattice-exact points preserve d across the tower
        bool inv = true; std::string detail;
        for (long kk : {7L, 12L, 120L}) {
            long d_ref = -1;
            for (long NN : {12L, 60L, 420L}) {
                Mp x = Mp(NN) * log2m(lattice(kk));
                long kN = to_long(rint_m(x));
                long dN = NN / ((kN != 0) ? std::gcd(std::labs(kN), NN) : NN);
                if (d_ref < 0) d_ref = dN; else if (dN != d_ref) inv = false;
            }
            detail += "k=" + std::to_string(kk) + "→d=" + std::to_string(d_ref) + " ";
        }
        check("ε=0 ⟹ d preserved across N∈{12,60,420} (Finding 11 / E2)", inv, detail);
    }
    {   // Identity R.4: g=7 cascade — canon sequence, SVT, sums
        std::vector<long> pal_d; long pos = 0, sum_p = 0;
        for (long i = 0; i < N; ++i) {
            pos = (pos + 7) % N;
            long g = (pos != 0) ? std::gcd(pos, N) : N;
            pal_d.push_back(N / g); sum_p += g;               // p = N/d = g
        }
        check("R.4 cascade PAL_d(g=7) = canon sequence",
              pal_d == std::vector<long>({12,6,4,3,12,2,12,3,4,6,12,1}));
        auto phi = [](long n){ long r=n,t=n;
            for (long q=2; q*q<=t; ++q) if (t%q==0){ while (t%q==0) t/=q; r-=r/q; }
            if (t>1) r-=r/t;
            return r; };
        bool svt = true;
        for (long dv : DIVISORS) {
            long cnt = 0; for (long x : pal_d) if (x == dv) ++cnt;
            if (cnt != phi(dv)) svt = false;
        }
        check("R.4 SVT: cascade visits each d with multiplicity φ(d) (P.1)", svt);
        check("R.4 Σ PAL_p = N·Σφ(d)/d = 40", sum_p == 40, "Σ = " + std::to_string(sum_p));
        check("R.4 mean(PAL_p) = |Π|+1/|Π| exactly",
              dec(Mp(sum_p) / Mp(N), (int)WORK_DIGITS) ==
              dec(Mp(PI_COUNT) + Mp(1L) / Mp(PI_COUNT), (int)WORK_DIGITS),
              dec(Mp(sum_p) / Mp(N), 10));
    }

    // ── RC-10: axis coherence depths derived from the lattice geometry ──
    {
        Mp ln2 = ln2_m();
        Mp d_th = mabs(Mp(24L) * pi_m() / ln2 - Mp(109L));   // δ_θ (Prop 13.2)
        Mp d_r  = mabs(Mp(12L) * log2m(Mp(12L)) - Mp(43L));  // δ_r (Prop 13.1)
        long n_th = to_long(floorm((Mp(1L) / Mp(2L)) / d_th));
        long n_r  = to_long(floorm((Mp(1L) / Mp(2L)) / d_r));
        check("n_max,θ = ⌊0.5/δ_θ⌋ = 2 (Prop 13.3, four-domain verified)",
              n_th == 2, "δ_θ = " + dec(d_th, 6));
        check("n_max,r = ⌊0.5/δ_r⌋ = 25 (Prop 13.1)",
              n_r == 25, "δ_r = " + dec(d_r, 6));
        check("STAR ceiling P_max = 1 − K = 1/3 exactly",
              dec(Mp(1L) - Kk, (int)WORK_DIGITS) ==
              dec(Mp(1L) / Mp(3L), (int)WORK_DIGITS));
    }
    // ── RC-12: Catalan–lattice correspondences (all derived, no lists) ──
    {
        auto catalan = [](long n) {
            long num = 1, den = 1;
            for (long i = 0; i < n; ++i) { num *= (2 * n - i); den *= (i + 1); }
            return num / den / (n + 1);                     // (2n choose n)/(n+1)
        };
        std::set<long> d42;
        for (long a = 1; a <= N; ++a)
            for (long b = 1; b <= N; ++b) d42.insert(std::lcm(a, b));
        check("Catalan C₂ = 2 = n_max,θ (G.10.a)", catalan(2) == 2);
        check("Catalan C₅ = 42 = |D₄₂| enumerated as {lcm(a,b)} (G.10.b)",
              catalan(5) == 42 && (long)d42.size() == 42,
              "|D₄₂| = " + std::to_string(d42.size()));
        check("Catalan C₆ = 132 = N(N−1) = lcm(11,12) (G.10.c)",
              catalan(6) == 132 && catalan(6) == N * (N - 1) &&
              catalan(6) == std::lcm(11L, 12L));
    }
    // ── Group K: shape projection ladder (every address re-derived) ──
    {
        auto eps_in = [](const Mp& e, const char* lo, const char* hi) {
            return lt(Mp(lo), e) && lt(e, Mp(hi));
        };
        // Legendre at the equator via exact recurrence: P_l(0) = −(l−1)/l · P_{l−2}(0)
        std::vector<Mp> P0(12);
        P0[0] = Mp(1L); P0[1] = Mp(0L);
        for (long l = 2; l < 12; ++l)
            P0[(size_t)l] = neg(Mp(l - 1) * P0[(size_t)(l - 2)]) / Mp(l);
        bool odd0 = true;
        for (long l = 1; l < 12; l += 2) if (!mpfr_zero_p(P0[(size_t)l].v)) odd0 = false;
        check("IC-142 odd-l equatorial nodes: P_l(0) = 0 exactly (parity)", odd0);
        check("even-l seeds: P₂(0)=−1/2, P₄(0)=3/8, P₆(0)=−5/16 (recurrence-exact)",
              dec(P0[2], 20) == dec(neg(Mp(1L)) / Mp(2L), 20) &&
              dec(P0[4], 20) == dec(Mp(3L) / Mp(8L), 20) &&
              dec(P0[6], 20) == dec(neg(Mp(5L)) / Mp(16L), 20));
        Proj s0 = project(Mp(1L));
        check("IC-138 s-orbital ρ₀=1 → identity cell (0, 1, 0)",
              s0.k == 0 && s0.d == 1 && mpfr_zero_p(s0.eps.v));
        Proj d2 = project(Mp(1L) / Mp(4L));
        check("IC-139 d-orbital ρ₂=1/4 → (−24, 1, 0) lattice-exact",
              d2.k == -24 && d2.d == 1 && lt(mabs(d2.eps), Mp("1e-200")));
        Proj g4 = project(Mp(9L) / Mp(64L));
        check("IC-140 g-orbital ρ₄=9/64 → (−34, 6, ≈+3.91¢)",
              g4.k == -34 && g4.d == 6 && eps_in(g4.eps, "3.86", "3.96"),
              "ε=" + dec(g4.eps, 4) + "¢");
        Proj i6 = project(Mp(25L) / Mp(256L));
        check("IC-141 i-orbital ρ₆=25/256 → (−40, 3, ≈−27.37¢)",
              i6.k == -40 && i6.d == 3 && eps_in(i6.eps, "-27.42", "-27.32"),
              "ε=" + dec(i6.eps, 4) + "¢");
        Proj h1 = project(Mp(1L) / Mp(2L));
        check("IC-147 hydrogen 1s ratio 1/2 → (−12, 1, 0) lattice-exact",
              h1.k == -12 && h1.d == 1 && lt(mabs(h1.eps), Mp("1e-200")));
        // IC-149: Lorentzian at ω/ωp = 1/2 → perfect fourth 4/3 = 2K,
        // |ε| = the canonical delta of the fifth, exactly
        Mp fourth = Mp(1L) / (Mp(1L) - (Mp(1L) / Mp(2L)) * (Mp(1L) / Mp(2L)));
        check("IC-149 Lorentzian output 1/(1−2⁻²) = 4/3 = 2K string-exact",
              dec(fourth, (int)WORK_DIGITS) ==
              dec(Mp(2L) * Kk, (int)WORK_DIGITS));
        Proj p43 = project(fourth);
        Proj p32 = project(Mp(3L) / Mp(2L));
        check("IC-149 Π(4/3) = (5, 12) and |ε(4/3)| = |ε(3/2)| = δ_canonical exactly",
              p43.k == 5 && p43.d == 12 && p32.k == 7 && p32.d == 12 &&
              dec(mabs(p43.eps), (int)WORK_DIGITS) ==
              dec(mabs(p32.eps), (int)WORK_DIGITS),
              "δ = " + dec(mabs(p32.eps), 5) + "¢");
        check("IC-144 hemisphere dipole 3/2 → (7, 12, +δ) and 4/3 · 3/2 = 2 exact",
              dec(fourth * (Mp(3L) / Mp(2L)), (int)WORK_DIGITS) == "2");
        Proj l3 = project(Mp(3L) * (sinm(Mp(1L)) - cosm(Mp(1L))));
        check("IC-145 level-set unit ball 3(sin1−cos1) → (−2, 6, ≈+24.33¢)",
              l3.k == -2 && l3.d == 6 && eps_in(l3.eps, "24.28", "24.39"),
              "ε=" + dec(l3.eps, 4) + "¢");
        Proj l4 = project(Mp(2L) / pi_m());
        check("IC-146 SDF unit sphere 2/π → (−8, 3, ≈+18.20¢)",
              l4.k == -8 && l4.d == 3 && eps_in(l4.eps, "18.15", "18.25"),
              "ε=" + dec(l4.eps, 4) + "¢");
        // IC-148 nD quadrupole, n=3 oblate (a=2, c=1): q₃ = −1/9
        Mp a2 = Mp(4L), c2 = Mp(1L);
        Mp q3 = (Mp(1L) / Mp(3L)) * (c2 - a2) / (c2 + Mp(2L) * a2);
        Proj pq = project(mabs(q3));
        check("IC-148 nD quadrupole n=3: |q₃| = 1/9 → (−38, 6, ≈−3.91¢)",
              dec(q3, 20) == dec(neg(Mp(1L)) / Mp(9L), 20) &&
              pq.k == -38 && pq.d == 6 && eps_in(pq.eps, "-3.96", "-3.86"),
              "ε=" + dec(pq.eps, 4) + "¢");
        // RC-19/20/23: nuclear shape addresses via the appearance reference
        Mp lam_fm("386.15926796");
        Proj ca40 = project(Mp("3.4776") / lam_fm);
        Proj ca48 = project(Mp("3.4771") / lam_fm);
        check("RC-19 ⁴⁰Ca charge radius → (−82, 6, ≈+46.05¢)",
              ca40.k == -82 && ca40.d == 6 && eps_in(ca40.eps, "46.00", "46.11"),
              "ε=" + dec(ca40.eps, 4) + "¢");
        Mp d_eps = mabs(ca40.eps - ca48.eps);
        check("RC-20 ⁴⁸Ca same cell as ⁴⁰Ca; Δε ≈ 0.249¢ (sub-cent)",
              ca48.k == ca40.k && ca48.d == ca40.d && eps_in(d_eps, "0.2", "0.3"),
              "Δε=" + dec(d_eps, 3) + "¢");
        Proj prot = project(Mp("0.8414") / lam_fm);
        check("RC-23 proton direct radius → (−106, 6, ≈−10.63¢)",
              prot.k == -106 && prot.d == 6 && eps_in(prot.eps, "-10.69", "-10.58"),
              "ε=" + dec(prot.eps, 4) + "¢");
    }

    // ── the four exact-law effects: every emitted string re-derived ──
    {
        bool tk = true;
        for (long j = 0; j <= 12; ++j)
            if (TUNNEL_PCT[(size_t)j] != dec((lattice(j) - Mp(1L)) * Mp(100L), 15)) tk = false;
        check("octave tunnel stops = (2^(j/12)−1)·100% re-derived; loop = one exact octave",
              tk && TUNNEL_S0 == dec(lattice(132), 10) && TUNNEL_S1 == dec(lattice(144), 10) &&
              dec(Mp(TUNNEL_S1) / Mp(TUNNEL_S0), 6) == "2",
              "box ×2 exact per period");
        // comet: recompute impedance-weighted time stops
        std::vector<Mp> xs; Mp tot(0L); long pos = 0;
        for (long i = 0; i < N; ++i) {
            pos = (pos + 7) % N;
            long g = (pos != 0) ? std::gcd(pos, N) : N;
            Mp x = xi_fn(N / g); xs.push_back(x); tot = tot + x;
        }
        bool ck = (COMET_TPCT[0] == "0");
        Mp acc(0L);
        for (size_t j = 0; j < xs.size(); ++j) {
            acc = acc + xs[j];
            if (COMET_TPCT[j + 1] != dec(acc * Mp(100L) / tot, 12)) ck = false;
        }
        check("cascade comet time stops = Σξ(m)/Σξ · 100 re-derived (12 segments)",
              ck && COMET_T == dec(tot * lattice(-24), 10),
              "T = " + COMET_T + "s, Σξ = " + dec(tot, 8));
        check("comet path = 13 g=7 star nodes (closed traversal)",
              WHEEL_STAR7.size() == 13 &&
              WHEEL_STAR7.front().first == WHEEL_STAR7.back().first &&
              WHEEL_STAR7.front().second == WHEEL_STAR7.back().second);
        // meteor: node-class color sequence, Koide tail, spans re-derived
        {
            bool cls_ok = (COMET_CLS[12] == COMET_CLS[0]);
            long cp = 0;
            for (long j = 0; j < N; ++j) {
                cp = (cp + 7) % N;
                if (COMET_CLS[(size_t)j] != cp) cls_ok = false;
            }
            check("meteor color law: fill class = 7j mod 12 — all 12 classes, "
                  "fifths order, wrap-continuous", cls_ok);
            Mp Ttot = tot * lattice(-24), Kp(1L);
            bool tail_ok = true;
            for (long j = 1; j <= COMET_TAIL; ++j) {
                Kp = Kp * Kk;
                if (COMET_TDELAY[(size_t)(j-1)] != dec(neg(Mp(j) * Ttot * V * V), 10)) tail_ok = false;
                if (COMET_TALPHA[(size_t)(j-1)] != dec(Kp, 8)) tail_ok = false;
                if (COMET_TRAD[(size_t)(j-1)]   != dec(lattice(30 - j), 6)) tail_ok = false;
            }
            check("meteor Koide tail re-derived: delay −j·T·V², α = K^j, "
                  "r = 2^((30−j)/12); tail span = T·V (one mean segment)", tail_ok,
                  "12 ghosts, α₁₂ = " + COMET_TALPHA[11]);
        }
        // engine panels: parse the printed input back, re-project, and
        // demand the printed pullback digits match a fresh pullback
        bool ek = true;
        for (auto& e : ENGINE) {
            Mp r(e.r_in);
            Proj pr = project(r);
            if (pr.k != e.k || pr.d != e.d) ek = false;
            if (dec(r, 60) != e.r60) ek = false;
            bool zero_branch = lt(mabs(pr.eps), Mp("1e-190"));
            if (zero_branch) {
                if (e.eps60 != "0 — lattice-exact") ek = false;
                if (dec(pullback(pr.k, Mp(0L)), 60) != e.back60) ek = false;
                if (dec(pullback(pr.k, Mp(0L)), (int)WORK_DIGITS) !=
                    dec(r, (int)WORK_DIGITS)) ek = false;
            } else {
                if (dec(pr.eps, 60) != e.eps60) ek = false;
                if (dec(pullback(pr.k, pr.eps), 60) != e.back60) ek = false;
                if (dec(pullback(pr.k, pr.eps), (int)WORK_DIGITS) !=
                    dec(r, (int)WORK_DIGITS)) ek = false;
            }
        }
        check("engine: all 12 panels re-projected; printed digits and pullback "
              "string-exact @ 200", ek,
              std::to_string(ENGINE.size()) + " panels");
        // glow stops re-derived from the Shimmer Identity
        bool gk = true;
        { Mp sV = sqrtm(V), two_pi = Mp(2L) * pi_m();
          for (long j = 0; j <= 12; ++j) {
              Mp psi = Mp(1L) + sV * sinm(two_pi * Mp(j) / Mp(12L));
              if (GLOW_B1[(size_t)j] != dec(psi * lattice(-5), 8)) gk = false;
              if (GLOW_B2[(size_t)j] != dec(psi * lattice(12), 8)) gk = false;
          } }
        check("Ψ-glow blur stops = Ψ_j·2^(k/12) rem re-derived (13 stops × 2 radii)", gk);
        check("engine cycle timing: slot = 2^(36/12)s, T = 12·slot, fades at V-fractions",
              ENG_SLOT == dec(lattice(36), 8) &&
              ENG_T == dec(Mp(12L) * lattice(36), 8) &&
              ENG_ON == dec((Mp(100L) / Mp(12L)) * V, 12));
    }

    // ── runtime diagnostics layer: the page's own error handling ──
    {
        check("diagnostics: all three notices present in HTML (motion, "
              "offset-path, color-mix) + version comment",
              HTML_OUT.find("diag-motion") != std::string::npos &&
              HTML_OUT.find("diag-offset") != std::string::npos &&
              HTML_OUT.find("diag-colormix") != std::string::npos &&
              HTML_OUT.find("ET runtime diagnostics layer v1") != std::string::npos);
        check("diagnostics: reduced-motion handler reveals the motion notice",
              CSS_OUT.find("@media (prefers-reduced-motion: reduce){\n"
                           "  .sysdiag .diag-motion{display:block}") != std::string::npos);
        check("diagnostics: capability handlers present "
              "(@supports not offset-path / color-mix)",
              CSS_OUT.find("@supports not (offset-path: path(") != std::string::npos &&
              CSS_OUT.find("@supports not (color: color-mix(") != std::string::npos);
        check("diagnostics: hidden in a healthy environment (base display:none)",
              CSS_OUT.find(".sysdiag .diag{display:none") != std::string::npos);
        // motion witness: fail-dead by construction
        check("witness: HTML carries fail notice + live lamp + beat",
              HTML_OUT.find("w-fail") != std::string::npos &&
              HTML_OUT.find("MOTION ENGINE NOT RUNNING") != std::string::npos &&
              HTML_OUT.find("w-live") != std::string::npos &&
              HTML_OUT.find("class=\"beat\"") != std::string::npos);
        check("witness: fail-dead law — lamp base opacity:0, held ONLY by a "
              "running constant-keyframe animation",
              CSS_OUT.find("opacity:0;pointer-events:none;\n"
                           "  animation:w-hold") != std::string::npos &&
              CSS_OUT.find("@keyframes w-hold{0%,100%{opacity:1}}") != std::string::npos);
        check("witness: beat period = 2·dur-slow = 2^0 s (lattice-exact)",
              CSS_OUT.find("animation:w-beat calc(var(--dur-slow)*2)") != std::string::npos &&
              dec(Mp(2L) * lattice(-12), 6) == "1");
        // owner directive: animations unconditional
        check("motion runs unconditionally: no no-preference gate remains; "
              "twinkle/tunnel/meteor/engine attached at base level",
              CSS_OUT.find("prefers-reduced-motion: no-preference") == std::string::npos &&
              CSS_OUT.find("\n.hero::before{animation:octzoom") != std::string::npos &&
              CSS_OUT.find("animation-name:tw-") != std::string::npos &&
              CSS_OUT.find("\n.engine pre{animation:panelcycle") != std::string::npos);
    }
}
static int report_str(std::string& out) {
    long passed = 0, failed = 0;
    std::ostringstream o;
    o << std::string(72, '=') << "\n  ET SITE FORGE (C++ MPFR) — VERIFICATION REPORT\n"
      << "  engine: MPFR " << mpfr_get_version() << " @ " << DIGITS
      << " digits (" << G_PREC << " bits) — zero float/double in the chain\n"
      << std::string(72, '=') << "\n";
    for (auto& r : RESULTS) {
        o << "  [" << (r.ok ? "PASS" : "FAIL") << "] " << r.name
          << (r.detail.empty() ? "" : "  — " + r.detail) << "\n";
        if (r.ok) ++passed; else ++failed;
    }
    o << std::string(72, '-') << "\n  PASSED: " << passed << "   FAILED: "
      << failed << "   TOTAL: " << RESULTS.size() << "\n"
      << std::string(72, '=') << "\n";
    out = o.str();
    return failed == 0 ? 0 : 1;
}
// ─── preflight: structural preconditions + template-token scans ──────
static void assert_no_tokens(const std::string& body, const char* which);
static void preflight(const std::string& wheel, const std::string& css,
                      const std::string& html, const std::string& toks) {
    if (CLASSES.size() != 12) fatal("preflight: CLASSES != 12");
    if (GENERATORS != std::vector<long>({1, 5, 7, 11}))
        fatal("preflight: generators wrong");
    if (DIVISORS.size() != 6) fatal("preflight: divisors wrong");
    for (long j : {0L, 1L, 2L, 3L, 4L, 8L, 9L, 10L, 11L})
        if (NEUTRAL.find(j) == NEUTRAL.end())
            fatal("preflight: neutral n" + std::to_string(j) + " missing");
    for (long d : DIVISORS)
        if (STAR_STATIC.find(d) == STAR_STATIC.end())
            fatal("preflight: static alpha missing for d=" + std::to_string(d));
    if (STARS.size() != (size_t)A0) fatal("preflight: star count != A0");
    if (ENGINE.size() != 12) fatal("preflight: engine panels != 12");
    if (COMET_PATH.empty() || COMET_PATH[0] != 'M')
        fatal("preflight: comet path invalid");
    assert_no_tokens(wheel, "et_wheel.svg");
    assert_no_tokens(css,   "css/et.css");
    assert_no_tokens(html,  "index.html");
    assert_no_tokens(toks,  "et_tokens.json");
    if (html.find("<script") != std::string::npos)
        fatal("preflight: a <script> element appeared in index.html — forbidden");
}

// ═════════════════════════════════════════════════════════════════════
//  TOKENS JSON + EMIT
// ═════════════════════════════════════════════════════════════════════
static std::string tokens_json() {
    std::ostringstream o;
    o << "{\n \"site\": " << jstr(CFG.domain) << ",\n \"doi\": " << jstr(CFG.doi)
      << ",\n \"engine\": \"C++ MPFR " << mpfr_get_version() << " — Omega standard: "
      << DIGITS << " digits, string->mpfr->string, zero float/double, zero JavaScript emitted\",\n"
      << " \"constants\": {\"N\": " << N << ", \"V\": " << jstr(dec(V, 50))
      << ", \"K\": " << jstr(dec(Kk, 50)) << ", \"Pi_count\": " << PI_COUNT
      << ", \"S\": " << S_STATES << ", \"A0\": " << A0
      << ", \"lambda_e_nm\": " << jstr(dec(LAMBDA_E_NM, 20))
      << ", \"lambda_manifold\": " << jstr(dec(Lambda(), 50))
      << ", \"lambda_theta\": " << jstr(dec(LambdaTheta(), 50))
      << ", \"dI_cents\": " << jstr(dec(DI_CENTS, 10));
    auto emit_vec = [&](const char* name, const std::vector<long>& v) {
        o << ", \"" << name << "\": [";
        for (size_t i = 0; i < v.size(); ++i) o << (i ? "," : "") << v[i];
        o << "]";
    };
    emit_vec("generators", GENERATORS);
    emit_vec("divisors", DIVISORS);
    {
        std::vector<long> pal_d; long pos = 0;
        for (long i = 0; i < N; ++i) {
            pos = (pos + 7) % N;
            pal_d.push_back(N / ((pos != 0) ? std::gcd(pos, N) : N));
        }
        emit_vec("cascade_PAL_d_g7", pal_d);
    }
    o << ", \"A0_derivation\": \"(N-1)^2 + S^2 = " << A0
      << "\"},\n \"spectral_classes\": [\n";
    for (size_t i = 0; i < CLASSES.size(); ++i) {
        auto& c = CLASSES[i];
        o << "  {\"class\": " << c.cls << ", \"kind\": " << jstr(c.kind);
        if (c.cls <= 10) {
            o << ", \"k\": " << c.k << ", \"lambda_nm\": " << jstr(c.lambda_nm)
              << ", \"proj\": {\"k\": " << c.pk << ", \"d\": " << c.pd
              << ", \"eps_cents\": " << jstr(c.peps) << "}";
        } else o << ", \"k\": null, \"lambda_nm\": null, \"proj\": null";
        o << ", \"xy\": [" << jstr(c.xy_x) << "," << jstr(c.xy_y) << "]"
          << ", \"cusp_L\": " << jstr(c.cusp_L)
          << ", \"gamut_pull_t\": " << jstr(c.pull_t)
          << ", \"even_pull_t\": " << jstr(c.even_t)
          << ", \"hex\": " << jstr(c.hex) << ", \"hex_even\": " << jstr(c.hex_even)
          << ", \"hex_dim\": " << jstr(c.hex_dim) << ", \"hex_wash\": " << jstr(c.hex_wash)
          << "}" << (i + 1 < CLASSES.size() ? ",\n" : "\n");
    }
    o << " ],\n \"field\": {\n"
      << "  \"laws\": \"x=frac(i*log2 3)*100%, y=frac(i*log2(3/2))*100%; class=k mod 12 of Pi12(i); "
      << "box=2^((g+24)/12)px; luminance L_j = min(1, w*Psi_j) with w=xi(m)/xi(1)=16/((m-1)^2+16) "
      << "(Identity M/H; harmonic m=d via SVT), Psi_j=1+sqrt(V)*sin(2*pi*j/12) (Shimmer, R.2); "
      << "EMITTED opacity = gamma_enc(L_j), the frozen sRGB device encode, at j*100/12%; "
      << "T=2^(class/12)*2s; delay=-f*T with f=(eps+dI)/(2*dI); layers i mod 3; drift T_L=3072*2^L s "
      << "(calibrated at the k=120 reference width)\",\n"
      << "  \"drift_T_s\": [" << jstr(DRIFT_T[0]) << "," << jstr(DRIFT_T[1]) << ","
      << jstr(DRIFT_T[2]) << "],\n  \"stars\": [\n";
    for (size_t i = 0; i < STARS.size(); ++i) {
        auto& s = STARS[i];
        o << "   {\"i\": " << s.i << ", \"L\": " << s.layer << ", \"class\": " << s.cls
          << ", \"d\": " << s.d << ", \"x_pct\": " << jstr(s.x_pct)
          << ", \"y_pct\": " << jstr(s.y_pct) << ", \"phase_frac\": " << jstr(s.frac)
          << ", \"delay_s\": " << jstr(s.delay_s) << "}"
          << (i + 1 < STARS.size() ? ",\n" : "\n");
    }
    o << "  ]\n },\n \"effects\": {\n"
      << "  \"octave_tunnel\": {\"law\": \"repeating-radial stops at (2^(j/12)-1)*100%; "
      << "box 2^(132/12)px -> 2^(144/12)px per period T=2^(60/12)s; seamless by IC-1/RC-24 S4\", "
      << "\"stops_pct\": [";
    for (long j = 0; j <= 12; ++j) o << (j ? "," : "") << jstr(TUNNEL_PCT[(size_t)j]);
    o << "], \"T_s\": " << jstr(TUNNEL_T) << "},\n"
      << "  \"cascade_comet\": {\"law\": \"meteor on the g=7 star; dt_j = xi(m_j)*2^(-24/12)s, "
      << "m=d via SVT; distance stops j*100/12, time stops impedance-weighted; fill morphs "
      << "through class(node)=7j mod 12 at the same stops; Koide tail: 12 ghosts, "
      << "delay -j*T*V^2, opacity K^j, radius 2^((30-j)/12)px\", "
      << "\"color_classes\": [";
    for (long j = 0; j <= 12; ++j) o << (j ? "," : "") << COMET_CLS[(size_t)j];
    o << "], \"time_pct\": [";
    for (long j = 0; j <= 12; ++j) o << (j ? "," : "") << jstr(COMET_TPCT[(size_t)j]);
    o << "], \"T_s\": " << jstr(COMET_T) << "},\n"
      << "  \"engine\": {\"law\": \"12 exact projections, 60 shown of 200 working digits; "
      << "slot 2^(36/12)s\", \"panels\": [";
    for (size_t i = 0; i < ENGINE.size(); ++i)
        o << (i ? "," : "") << "{\"name\": " << jstr(ENGINE[i].name)
          << ", \"k\": " << ENGINE[i].k << ", \"d\": " << ENGINE[i].d << "}";
    o << "]},\n  \"psi_glow\": {\"law\": \"blur_j = Psi_j * 2^(k/12) rem, Shimmer R.2, "
      << "13 lattice stops, T=2^(36/12)s\"},\n"
      << "  \"motion_witness\": {\"law\": \"fail-dead traversal detector: base "
      << "configuration displays failure; LIVE lamp exists only under an executing "
      << "constant-keyframe hold; beat T = 2*dur-slow = 2^0 s\"}\n },\n \"tokens\": [\n"
      << TOKENS.str() << "\n ]\n}\n";
    return o.str();
}
static void write_file(const std::string& path, const std::string& body) {
    if (body.empty()) fatal("write_file: refusing to write empty body: " + path);
    std::ofstream f(path, std::ios::binary);
    if (!f) fatal("write_file: cannot open for writing: " + path);
    f << body;
    f.flush();
    if (!f.good()) fatal("write_file: write failed: " + path);
    f.close();
    struct stat st{};
    if (stat(path.c_str(), &st) != 0)
        fatal("write_file: written file not found: " + path);
    if ((size_t)st.st_size != body.size())
        fatal("write_file: size mismatch on " + path + " (wrote " +
              std::to_string(body.size()) + ", on disk " +
              std::to_string((long)st.st_size) + ")");
    errno = 0;
}
static void ensure_dir(const char* p) {
    if (ET_MKDIR(p) != 0 && errno != EEXIST)
        fatal(std::string("ensure_dir: mkdir failed: ") + p);
    errno = 0;
    struct stat st{};
    if (stat(p, &st) != 0 || !S_ISDIR(st.st_mode))
        fatal(std::string("ensure_dir: not a directory: ") + p);
}
static void assert_no_tokens(const std::string& body, const char* which) {
    size_t pos = body.find("@@");
    if (pos != std::string::npos)
        fatal(std::string("unreplaced template token in ") + which +
              " near \"" + body.substr(pos, std::min<size_t>(24, body.size() - pos)) + "\"");
}
static int run() {
    errno = 0;
    // derived structure — never listed
    for (long g = 1; g < N; ++g) if (std::gcd(g, N) == 1) GENERATORS.push_back(g);
    for (long d = 1; d <= N; ++d) if (N % d == 0) DIVISORS.push_back(d);
    std::time_t t = std::time(nullptr);
    if (t == (std::time_t)(-1)) fatal("system clock unavailable");
    std::tm* tmv = std::localtime(&t);
    if (!tmv) fatal("localtime failed");
    char yb[8];
    if (std::strftime(yb, sizeof yb, "%Y", tmv) == 0) fatal("year format failed");
    CFG.year = yb;

    init_translation();
    build_classes();
    build_neutrals();
    build_field();
    build_effects();
    build_tokens();

    // ── PHASE 1: build every artifact IN MEMORY — nothing on disk yet ──
    std::string wheel = build_wheel();          // also fixes the comet path
    std::string css   = build_css();
    std::string html  = build_html(wheel);
    std::string toks  = tokens_json();
    HTML_OUT = html; CSS_OUT = css;               // expose to verification gates
    preflight(wheel, css, html, toks);

    // ── PHASE 2: VERIFY BEFORE WRITE — a failing build touches nothing ──
    verify_all();
    std::string rep;
    int rc = report_str(rep);
    std::cout << rep;
    if (rc != 0) {
        std::cerr << "\n[ABORT] verification failed — dist/ left untouched.\n"
                     "        Full report saved to VERIFICATION_REPORT_FAILED.txt\n";
        std::ofstream f("VERIFICATION_REPORT_FAILED.txt", std::ios::binary);
        if (f) { f << rep; f.flush(); }
        else std::cerr << "        (could not write the failure report file; "
                          "the report above is authoritative)\n";
        std::cerr << "        Complete log of this run: forge_run.log\n";
        hold_console_for_reader();
        return 1;
    }

    // ── PHASE 3: emit — every directory and write explicitly checked ──
    ensure_dir("dist"); ensure_dir("dist/css"); ensure_dir("dist/assets");
    write_file("dist/assets/et_wheel.svg", wheel);
    write_file("dist/css/et.css", css);
    write_file("dist/index.html", html);
    write_file("dist/et_tokens.json", toks);
    write_file("dist/VERIFICATION_REPORT.txt", rep);
    // a forbidden legacy artifact must not survive if present
    struct stat js{};
    if (stat("dist/js/et_field.js", &js) == 0) {
        if (std::remove("dist/js/et_field.js") != 0)
            fatal("could not remove forbidden legacy dist/js/et_field.js");
    }
    errno = 0;
    if (stat("dist/js", &js) == 0 && S_ISDIR(js.st_mode)) {
        if (ET_RMDIR("dist/js") != 0)
            fatal("could not remove legacy dist/js directory");
    }
    errno = 0;
    std::cout << "\n  dist/ written & post-write verified: index.html, css/et.css,\n"
                 "  assets/et_wheel.svg, et_tokens.json, VERIFICATION_REPORT.txt\n"
                 "  (zero JavaScript emitted; every write size-checked)\n"
                 "  Complete log of this run: forge_run.log (same folder)\n";
    hold_console_for_reader();
    return 0;
}
int main() {
    try {
        init_logging();
        return run();
    } catch (const std::exception& e) {
        fatal(std::string("unhandled exception: ") + e.what());
    } catch (...) {
        fatal("unhandled unknown exception");
    }
}
