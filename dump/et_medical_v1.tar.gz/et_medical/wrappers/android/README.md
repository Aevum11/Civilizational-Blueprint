# libet_med — Android Wrapper

JNI bridge and Kotlin facade for libet_med on Android (API 26+).

## Directory structure

```
android/
├── build.gradle                  top-level Gradle
├── settings.gradle
├── README.md                     (this file)
└── app/
    ├── build.gradle              app-module Gradle (NDK + Compose)
    └── src/main/
        ├── AndroidManifest.xml
        ├── cpp/
        │   ├── CMakeLists.txt    builds libet_med + JNI into et_med_jni.so
        │   └── et_med_jni.c      JNI marshalling layer
        └── java/com/aevumdefluo/etmed/
            ├── EtMed.kt          Kotlin facade
            └── MainActivity.kt   minimal Compose UI demo
```

## Prerequisites

- Android Studio Iguana (or newer) with:
  - Android SDK Platform 34
  - NDK 25+ (the Gradle plugin will prompt)
  - CMake 3.22+ (bundled)

## Build

1. Open `wrappers/android/` as a Gradle project in Android Studio.
2. Let Gradle sync — it will locate `../../libet_med/` via the path in
   `app/src/main/cpp/CMakeLists.txt`.
3. `Build → Make Project` (or `./gradlew assembleDebug` on the command line).
4. Install on a device / emulator: `./gradlew installDebug`.

The NDK build produces `libet_med_jni.so` for all four ABIs listed in
`build.gradle` (armeabi-v7a, arm64-v8a, x86, x86_64). The SO contains both
the libet_med C sources and the JNI bridge in one library — no separate
`libet_med.so` needs to be shipped.

## API usage (Kotlin)

```kotlin
import com.aevumdefluo.etmed.*

val patient = PatientBaseline(
    hrRestBpm    = 60.0,
    rrRestPerMin = 12.0,
    temperatureC = 36.8,
    ageYears     = 45.0,
    sex          = Sex.Male.code
)

val signature = EtMed.computeMultifoldSignature(patient)
println("multifold scalar = ${signature.scalar}")
println("normalized       = ${signature.normalizedVsReference}")

val finding = EtMed.classifyMeasurement(
    name = "HR", currentValue = 120.0,
    tower = Tower.Cardiac, baseline = patient
)
println("${finding.name}: ${finding.state} ${finding.severityPct}%")
```

## Architecture

The JNI bridge `et_med_jni.c` is intentionally thin: it only marshals
primitive types and small primitive arrays. The library's complex types
(`et_multifold_signature_t`, `et_finding_t`) are flattened into `double[]`
returns at the JNI boundary, then rebuilt in Kotlin. This keeps the JNI
surface minimal and avoids GlobalRef leaks.

## Verification

The Kotlin facade exposes exactly the same functions as the Windows
P/Invoke binding and the WebAssembly JavaScript module. Tests performed
on the C core via `test_et_med` (175+ assertions) apply equally here —
the JNI bridge is a pass-through.
