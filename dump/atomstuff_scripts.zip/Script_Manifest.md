# Sempaevum Nuclear Projection Scripts — Manifest

**All scripts: zero float64 in the computational chain. String → mpmath → string throughout.**

---

## Main Viewer Scripts

### `sempaevum_isotope_viewer.py` (111 KB)

**The mass projection viewer.** Projects 2324 measured isotopes from AME2020 onto the Sempaevum via DSR r = m_isotope × m_u/m_e. Produces a 10MB interactive 3D HTML visualization and a comprehensive markdown report.

**Contains:**
- `parse_ame2020()` — Parses AME2020 fixed-width Fortran format. Extracts atomic mass as STRING directly from file digits, never through float64. Handles estimated values.
- `parse_nist_asd()` — Parses NIST ASD ground-state data (108 elements). Extracts J values from all term symbol formats.
- `parse_nist_abundances()` — Parses NIST isotopic compositions HTML. Handles mono-isotopic elements.
- `derive_periodic_table(Z)` — Algorithmic periodic table derivation from Z alone. No lookup tables.
- `build_atomic_particles()` — Assembles the full isotope dataset by merging AME2020, NIST ASD, and NIST abundances.
- `compute_tower_projection()` — Projects through the infinite LCM tower with d-family stabilization. No maximum level.
- `compute_particle_projections()` — Full Sempaevum projection at N=12 and through the LCM tower. 120-digit mpmath precision.
- `compute_structural_ratios()` — Inter-atomic mass ratios projected onto the lattice.
- `build_fqg_grid()` — 144-cell Force Quadrant Grid construction.
- `generate_3d_html()` — Plotly.js 3D visualization with hover tooltips, stat cards, FQG grid, impedance groups.
- `generate_report()` — Comprehensive markdown report with full projection tables.
- `mp_json()` — Custom JSON serializer converting mpmath → decimal string literals in JavaScript, bypassing float64 entirely.

**Outputs:**
- `Sempaevum_isotope_viewer_AME2020.html` — Interactive 3D viewer
- `sempaevum_isotope_report.md` — Full projection report

**Data files required:**
- `/mnt/user-data/uploads/mass_1_mas20.txt` — AME2020
- `/mnt/user-data/uploads/Atomic_Weights_and_Isotopic_Compositions_for_All_Elements.html` — NIST abundances
- `nist_asd_ground_levels.txt` — NIST ASD (generated or provided)

---

### `sempaevum_nz_stability_viewer.py` (104 KB)

**The N/Z stability projection viewer.** Copied from the mass viewer and edited to project DSR r = N/Z (neutron-to-proton ratio). Reveals the valley of nuclear stability as a lattice band k_NZ ∈ [0, 7].

**Key differences from mass viewer:**
- DSR: r = N/Z (mpmath integer division) instead of r = m × m_u/m_e
- Traces colored by **stability status** (Natural/Unstable/Proton-rich/Neutron-rich) instead of periodic table category
- Stat cards show stability band counts
- CF home-finding method (§7.11 Step 3a) runs in parallel with LCM tower
- `cf_home_find()` — Continued fraction expansion of |log₂(r)|, finds convergent with maximal a_{n+1}
- Tower uses d-family stabilization with no ε-threshold (N/Z is exact)
- Skips H-1 (N=0, which gives r=0 at the ∂I boundary)

**Contains all functions from the mass viewer plus:**
- `cf_home_find(r_mp)` — CF method implementation. Computes CF expansion at 130-digit precision, finds best convergent, classifies as cf_deep_home/cf_home/cf_marginal per §7.11 thresholds.

**Outputs:**
- `Sempaevum_NZ_stability_viewer.html` — Interactive 3D viewer with stability coloring
- `sempaevum_nz_stability_report.md` — Full N/Z projection report

---

## Investigation Scripts

### `investigate_isotopes.py` (9.9 KB)

**First-pass isotope data investigation.** Examines the 2324-isotope mass projection dataset for patterns.

**Investigations:**
1. Top 25 most lattice-exact isotopes (smallest |ε| at N=12)
2. Nuclear magic numbers — do shell closures show lattice signatures?
3. Isotopes of the same element — real-axis spread across d_r families
4. Iron peak — binding energy maximum and its lattice position
5. d_r family distribution: naturally occurring vs all measured
6. Binding energy vs lattice position correlation
7. k_r density — where isotopes concentrate on the log-mass axis
8. Tower depth — do natural isotopes converge faster?
9. Isotope pairs — different nuclides at the same lattice node

**Key findings:** The ε-parabola (Section 2 of isotope findings), isotope stacking, iron peak collapse, pairing is lattice-invisible.

---

### `investigate_deep.py` (11 KB)

**Deep isotope chain analysis.** Follows up on first-pass findings with detailed chain-level investigations.

**Investigations:**
1. Even-even vs odd-odd pairing statistics on the lattice
2. Full isotope chains for C, Fe, Sn, Pb — Δk per neutron, shell closure effects
3. Isobar analysis — does the most stable isobar have the smallest |ε|? (Answer: 35.3% vs 10% random)
4. Shell closure jumps in the Tin chain (33 isotopes, magic N=50 and N=82)
5. Mass defect projection — iron peak collapses to k_defect = −81, d=4
6. β-decay chains on the lattice (A=100, 131, 192)
7. Δk per neutron — characteristic lattice step size vs element

**Key findings:** The ε-parabola traces the Bethe-Weizsäcker mass parabola, shell closures force lattice steps, Δk per neutron follows 17.3/A.

---

### `investigate_stability.py` (12 KB)

**Candidate DSR screening for stability.** Tests 5 different dimensionless seed ratios to find which one reveals nuclear stability on the lattice.

**DSRs tested:**
1. N/Z — neutron-to-proton ratio
2. Binding fraction — Δm/(Z·m_p + N·m_n)
3. β-decay Q/m_e — directly measures β-stability
4. S_2n/m_e — two-neutron separation energy
5. Composite k_mass × k_NZ — 2D stability map

**Key finding:** N/Z gives the sharpest stability boundary (98.6% of natural isotopes in 8-semitone band). Binding fraction gives the most dramatic single-point concentration (iron peak at 51% natural).

---

### `dsr_comparison.py` (6.1 KB)

**Systematic quantitative DSR comparison.** Runs all 5 candidate DSRs through the full Sempaevum projection at N=12 and computes a stability separation score (capture × purity) for each.

**DSRs compared:** N/Z, Binding fraction, BE/A over m_e, Mass defect per A over m_e, Neutron separation energy over m_e.

**Output:** Ranked comparison table with best-band identification, capture percentage, purity percentage, and composite score for each DSR.

---

### `investigate_cf.py` (7.9 KB)

**CF method results investigation.** Analyzes the continued fraction home-finding results for all 2323 N/Z projections.

**Investigations:**
1. CF quality factor vs stability — does quality distinguish natural from unstable?
2. Shared N/Z ratios — how many distinct values, how they cluster
3. CF d_home factorization — what primes appear in small d_home values?
4. Digit count distribution of d_home values
5. The 49 cf_marginal isotopes — all N/Z = powers of 2
6. CF quality vs k_NZ stability band
7. N/Z = 1 special case (the N=Z line)
8. N/Z denominator q vs CF d_home relationship

**Key findings:** N/Z = 3/2 sits at the Koide attractor, 49 marginals are ALL powers-of-2 ratios, CF quality doesn't distinguish stability, small d_home values involve only ET-relevant primes.

---

### `find_island.py` (8.2 KB)

**Island of stability search.** Examines the superheavy region (Z ≥ 100) on the N/Z lattice to find signatures of the predicted island of stability.

**Investigations:**
1. Complete lattice data for all 23 superheavy isotopes (Z ≥ 100) in AME2020
2. k_NZ = 7 and k_NZ = 8 boundary analysis — the stability band edge
3. Most lattice-exact isotopes in the boundary bands
4. Exact projections for predicted island ratios (Z=114/120/126, N=172/184)
5. ε_NZ anomaly detection — local minima in |ε| across isotope chains

**Key findings:** Predicted island nuclei split across k_NZ=7 and k_NZ=8 boundary. Z=120/126 candidates are inside the band; Z=114 with N=184 is outside. Fm-250 and No-255 sit at the Koide attractor.

---

### `island_deep.py` (11 KB)

**Deep island of stability mapping.** Projects the ENTIRE predicted island region (Z=104–130, N=150–200) onto the N/Z lattice, including isotopes not yet measured.

**Investigations:**
1. Maps all 1377 (Z, N) combinations in the island region — identifies 9 in AME2020
2. k_NZ = 7 slice of the island — 273 isotopes inside the stability band, sorted by |ε|
3. The Koide track (N/Z = 3/2) through the island — from Hg-200 to Z=130
4. Every superheavy element (Z=100–118) — full lattice comparison with d_NZ families, ε distributions
5. Lattice prediction per element — the N that minimizes |ε_NZ| at k_NZ = 7 for each Z from 104 to 130
6. d_NZ family transition mapping — where d_NZ changes for each superheavy element across all N values

**Key findings:** Island center predicted at Z=120, N=180 (Koide attractor). N=184 enters the stability band at Z=120. Z=126 with N=184 sits at the d=2→12 family transition. The stability window is 9–11 neutrons wide for superheavy elements.

---

## Data Flow

```
AME2020 (mass_1_mas20.txt)  ─┐
NIST ASD (ground levels)     ─┼─→  build_atomic_particles()  ─→  2324 isotopes
NIST Abundances (HTML)       ─┘         │
                                        ▼
                              compute_particle_projections()
                                   │           │
                                   ▼           ▼
                            Mass Projection   N/Z Projection
                            (r = m·mu/me)     (r = N/Z)
                                   │           │
                                   ▼           ▼
                            LCM Tower    LCM Tower + CF Method
                                   │           │
                                   ▼           ▼
                           isotope_viewer    nz_stability_viewer
                           (10MB HTML)       (49MB HTML)
                                   │           │
                                   ▼           ▼
                          Investigation scripts (7 total)
                                   │
                                   ▼
                           Findings documents (3 total)
```

---

*Exception Theory — P ∘ D ∘ T = E*
