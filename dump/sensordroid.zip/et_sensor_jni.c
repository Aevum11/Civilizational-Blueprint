/*
 * ET LOSSLESS SENSOR CAPTURE — JNI BRIDGE
 * =========================================
 * Marshals data between the Kotlin UI layer and the C bijection core.
 *
 * CRITICAL DESIGN: The zero-float64 chain is maintained THROUGH the
 * JNI boundary. All sensor values cross as STRINGS (JNI jstring),
 * never as jfloat or jdouble. The C core parses strings to MPFR,
 * computes in arbitrary precision, and returns strings.
 *
 * The only integers crossing are: k (long), d (int), sign (int),
 * sensor_type (int), N (int), axis (int), timestamp (long).
 * These are exact in both Java and C.
 *
 * Author: Michael James Muller — Aevum Defluo (Exception Theory)
 * License: CC-BY-4.0
 */

#include <jni.h>
#include <android/log.h>
#include <string.h>
#include <stdlib.h>

#include "et_bijection.h"
#include "et_sensor_projector.h"
#include "et_constants.h"

#define LOG_TAG "EtSensor"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

/* ═══════════════════════════════════════════════════════════════════
 * GLOBAL STATE
 * Per-sensor projectors, initialized on demand.
 * ═══════════════════════════════════════════════════════════════════ */

/* Maximum concurrent sensor projectors */
#define MAX_PROJECTORS 32

static et_sensor_projector_t g_projectors[MAX_PROJECTORS];
static int g_projector_initialized[MAX_PROJECTORS] = {0};
static int g_projector_count = 0;

/* A single base projector for standalone bijection operations */
static et_projector_t g_base_projector;
static int g_base_initialized = 0;

/* ═══════════════════════════════════════════════════════════════════
 * HELPER: ensure base projector is initialized
 * ═══════════════════════════════════════════════════════════════════ */
static et_error_t ensure_base_projector(void) {
    if (g_base_initialized) return ET_OK;
    et_error_t err = et_projector_init(&g_base_projector, ET_N_BASE, ET_MPFR_BITS);
    if (err == ET_OK) g_base_initialized = 1;
    return err;
}

/* ═══════════════════════════════════════════════════════════════════
 * JNI FUNCTION: Initialize a sensor projector
 *
 * Returns the projector index (0-based), or -1 on error.
 *
 * Java signature:
 *   native int initSensorProjector(int sensorType, String r0, int N);
 * ═══════════════════════════════════════════════════════════════════ */
JNIEXPORT jint JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_initSensorProjector(
        JNIEnv *env, jclass clazz,
        jint sensor_type, jstring jR0, jint N) {
    (void)clazz;

    if (g_projector_count >= MAX_PROJECTORS) {
        LOGE("Maximum projector count (%d) reached", MAX_PROJECTORS);
        return -1;
    }

    const char *r0_str = (*env)->GetStringUTFChars(env, jR0, NULL);
    if (!r0_str) return -1;

    int idx = g_projector_count;
    et_error_t err;

    if (r0_str[0] == '\0' || strcmp(r0_str, "default") == 0) {
        /* Use default R₀ for this sensor type */
        err = et_sensor_projector_init(&g_projectors[idx],
                                        (et_sensor_type_t)sensor_type,
                                        N, ET_MPFR_BITS);
    } else {
        /* Custom R₀ */
        err = et_sensor_projector_init_custom(&g_projectors[idx],
                                               (et_sensor_type_t)sensor_type,
                                               r0_str, N, ET_MPFR_BITS);
    }

    (*env)->ReleaseStringUTFChars(env, jR0, r0_str);

    if (err != ET_OK) {
        LOGE("Failed to init sensor projector: type=%d, error=%d",
             sensor_type, (int)err);
        return -1;
    }

    g_projector_initialized[idx] = 1;
    g_projector_count++;

    LOGI("Sensor projector %d initialized: type=%s, N=%d, R0=%s",
         idx, ET_SENSOR_TYPE_NAMES[sensor_type], N,
         g_projectors[idx].R0_str);

    return idx;
}

/* ═══════════════════════════════════════════════════════════════════
 * JNI FUNCTION: Project a sensor value
 *
 * Returns a double array: [k, d, sign, is_zero, at_boundary, N]
 * Plus ε as a separate string return (via output parameter).
 *
 * Java signature:
 *   native double[] projectSensor(int projectorIdx, String value,
 *                                  int axis, long timestampNs);
 *
 * Note: k is returned as double because JNI doesn't have jlong arrays
 * with mixed types. The caller casts back to long. k fits in double's
 * 52-bit mantissa for any realistic lattice coordinate.
 * ═══════════════════════════════════════════════════════════════════ */
JNIEXPORT jdoubleArray JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_projectSensor(
        JNIEnv *env, jclass clazz,
        jint projector_idx, jstring jValue, jint axis, jlong timestamp_ns) {
    (void)clazz;

    if (projector_idx < 0 || projector_idx >= g_projector_count ||
        !g_projector_initialized[projector_idx]) {
        LOGE("Invalid projector index: %d", projector_idx);
        return NULL;
    }

    const char *value_str = (*env)->GetStringUTFChars(env, jValue, NULL);
    if (!value_str) return NULL;

    et_sensor_sample_t sample;
    memset(&sample, 0, sizeof(sample));
    et_projection_init(&sample.projection, ET_MPFR_BITS);

    et_error_t err = et_sensor_project(&g_projectors[projector_idx],
                                        value_str, axis,
                                        (long long)timestamp_ns, &sample);

    (*env)->ReleaseStringUTFChars(env, jValue, value_str);

    if (err != ET_OK) {
        LOGE("Projection failed: error=%d", (int)err);
        et_projection_clear(&sample.projection);
        return NULL;
    }

    /* Return array: [k, d, sign, is_zero, at_boundary, N] */
    jdoubleArray result = (*env)->NewDoubleArray(env, 6);
    if (!result) {
        et_projection_clear(&sample.projection);
        return NULL;
    }

    jdouble buf[6] = {
        (jdouble)sample.projection.k,
        (jdouble)sample.projection.d,
        (jdouble)sample.projection.sign,
        (jdouble)sample.projection.is_zero,
        (jdouble)sample.projection.at_boundary,
        (jdouble)sample.projection.N
    };
    (*env)->SetDoubleArrayRegion(env, result, 0, 6, buf);

    et_projection_clear(&sample.projection);
    return result;
}

/* ═══════════════════════════════════════════════════════════════════
 * JNI FUNCTION: Get ε as string (zero float64 output path)
 *
 * Returns ε at full WORK_DPS precision as a Java String.
 * This maintains the zero-float64 chain through JNI.
 *
 * Java signature:
 *   native String getEpsilonString(int projectorIdx, String value, int axis);
 * ═══════════════════════════════════════════════════════════════════ */
JNIEXPORT jstring JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_getEpsilonString(
        JNIEnv *env, jclass clazz,
        jint projector_idx, jstring jValue, jint axis) {
    (void)clazz;

    if (projector_idx < 0 || projector_idx >= g_projector_count ||
        !g_projector_initialized[projector_idx]) {
        return (*env)->NewStringUTF(env, "ERROR");
    }

    const char *value_str = (*env)->GetStringUTFChars(env, jValue, NULL);
    if (!value_str) return (*env)->NewStringUTF(env, "ERROR");

    et_sensor_sample_t sample;
    memset(&sample, 0, sizeof(sample));
    et_projection_init(&sample.projection, ET_MPFR_BITS);

    et_error_t err = et_sensor_project(&g_projectors[projector_idx],
                                        value_str, axis, 0, &sample);

    (*env)->ReleaseStringUTFChars(env, jValue, value_str);

    if (err != ET_OK) {
        et_projection_clear(&sample.projection);
        return (*env)->NewStringUTF(env, "ERROR");
    }

    /* Convert ε to string at WORK_DPS — the zero-float64 output path */
    char eps_buf[ET_WORK_DPS + 64];
    et_eps_to_string(sample.projection.eps, ET_WORK_DPS, eps_buf, sizeof(eps_buf));

    jstring jeps = (*env)->NewStringUTF(env, eps_buf);

    et_projection_clear(&sample.projection);
    return jeps;
}

/* ═══════════════════════════════════════════════════════════════════
 * JNI FUNCTION: Project ADC integer directly
 *
 * For sensors reporting raw ADC integers (accelerometer, camera).
 * Maintains zero-float64 chain: ADC int → fraction string → MPFR.
 *
 * Java signature:
 *   native double[] projectAdc(int projectorIdx, long adcValue,
 *                               long maxValue, int axis, long timestampNs);
 * ═══════════════════════════════════════════════════════════════════ */
JNIEXPORT jdoubleArray JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_projectAdc(
        JNIEnv *env, jclass clazz,
        jint projector_idx, jlong adc_value, jlong max_value,
        jint axis, jlong timestamp_ns) {
    (void)clazz;

    if (projector_idx < 0 || projector_idx >= g_projector_count ||
        !g_projector_initialized[projector_idx]) {
        return NULL;
    }

    et_sensor_sample_t sample;
    memset(&sample, 0, sizeof(sample));
    et_projection_init(&sample.projection, ET_MPFR_BITS);

    et_error_t err = et_sensor_project_adc(&g_projectors[projector_idx],
                                            (long)adc_value, (long)max_value,
                                            axis, (long long)timestamp_ns,
                                            &sample);

    if (err != ET_OK) {
        et_projection_clear(&sample.projection);
        return NULL;
    }

    jdoubleArray result = (*env)->NewDoubleArray(env, 6);
    if (!result) {
        et_projection_clear(&sample.projection);
        return NULL;
    }

    jdouble buf[6] = {
        (jdouble)sample.projection.k,
        (jdouble)sample.projection.d,
        (jdouble)sample.projection.sign,
        (jdouble)sample.projection.is_zero,
        (jdouble)sample.projection.at_boundary,
        (jdouble)sample.projection.N
    };
    (*env)->SetDoubleArrayRegion(env, result, 0, 6, buf);

    et_projection_clear(&sample.projection);
    return result;
}

/* ═══════════════════════════════════════════════════════════════════
 * JNI FUNCTION: Verify lossless round-trip
 *
 * Projects r → (k,d,ε) → r' and verifies r = r' at WORK_DPS.
 *
 * Java signature:
 *   native boolean verifyRoundtrip(String rValue, int N);
 * ═══════════════════════════════════════════════════════════════════ */
JNIEXPORT jboolean JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_verifyRoundtrip(
        JNIEnv *env, jclass clazz,
        jstring jR, jint N) {
    (void)clazz;

    const char *r_str = (*env)->GetStringUTFChars(env, jR, NULL);
    if (!r_str) return JNI_FALSE;

    et_projector_t proj;
    et_error_t err = et_projector_init(&proj, N, ET_MPFR_BITS);
    if (err != ET_OK) {
        (*env)->ReleaseStringUTFChars(env, jR, r_str);
        return JNI_FALSE;
    }

    int is_exact = 0;
    err = et_verify_roundtrip(&proj, r_str, &is_exact);

    (*env)->ReleaseStringUTFChars(env, jR, r_str);
    et_projector_clear(&proj);

    if (err != ET_OK) return JNI_FALSE;
    return is_exact ? JNI_TRUE : JNI_FALSE;
}

/* ═══════════════════════════════════════════════════════════════════
 * JNI FUNCTION: Get sensor type name
 * ═══════════════════════════════════════════════════════════════════ */
JNIEXPORT jstring JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_getSensorTypeName(
        JNIEnv *env, jclass clazz, jint sensor_type) {
    (void)clazz;
    if (sensor_type < 0 || sensor_type >= ET_SENSOR_TYPE_COUNT) {
        return (*env)->NewStringUTF(env, "UNKNOWN");
    }
    return (*env)->NewStringUTF(env, ET_SENSOR_TYPE_NAMES[sensor_type]);
}

/* ═══════════════════════════════════════════════════════════════════
 * JNI FUNCTION: Get default R₀ for a sensor type
 * ═══════════════════════════════════════════════════════════════════ */
JNIEXPORT jstring JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_getDefaultR0(
        JNIEnv *env, jclass clazz, jint sensor_type) {
    (void)clazz;
    if (sensor_type < 0 || sensor_type >= ET_SENSOR_TYPE_COUNT) {
        return (*env)->NewStringUTF(env, "1");
    }
    return (*env)->NewStringUTF(env, ET_SENSOR_R0_DEFAULTS[sensor_type]);
}

/* ═══════════════════════════════════════════════════════════════════
 * JNI FUNCTION: Cleanup all projectors
 * ═══════════════════════════════════════════════════════════════════ */
JNIEXPORT void JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_cleanup(
        JNIEnv *env, jclass clazz) {
    (void)env;
    (void)clazz;

    for (int i = 0; i < g_projector_count; i++) {
        if (g_projector_initialized[i]) {
            et_sensor_projector_clear(&g_projectors[i]);
            g_projector_initialized[i] = 0;
        }
    }
    g_projector_count = 0;

    if (g_base_initialized) {
        et_projector_clear(&g_base_projector);
        g_base_initialized = 0;
    }

    LOGI("All projectors cleaned up");
}

/* ═══════════════════════════════════════════════════════════════════
 * JNI FUNCTION: Get ET constants for display
 * ═══════════════════════════════════════════════════════════════════ */
JNIEXPORT jstring JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_getConstantsInfo(
        JNIEnv *env, jclass clazz) {
    (void)clazz;

    char buf[2048];
    snprintf(buf, sizeof(buf),
        "N=%d | V=1/%d | K=2/3 | Λ=1200/ln2\n"
        "WORK_DPS=%d | COMPUTE_DPS=%d | MPFR_BITS=%d\n"
        "LCM Tower: 12→60→420→2520→27720\n"
        "Sensor types: %d\n"
        "P∘D∘T = E",
        ET_N_BASE, ET_N_BASE,
        ET_WORK_DPS, ET_COMPUTE_DPS, ET_MPFR_BITS,
        ET_SENSOR_TYPE_COUNT);

    return (*env)->NewStringUTF(env, buf);
}
