"""
Test Mike's idea: can EML serve as the elementary-math engine
for the lattice projection? Decompose the projection formula and
identify exactly which parts are EML-expressible.

Lattice projection at base 12ET:
    k = round(N · log₂(r))
    d = N / gcd(|k|, N)
    ε = (N log₂ r − k) · 1200/N

Decompose into atomic operations:
    1. log₂(r) = ln(r) / ln(2)        — EML can do (ln chain + ÷)
    2. N · log₂(r)                    — EML can do (×)
    3. round(...)                     — EML CANNOT do (T-act, discrete)
    4. gcd(|k|, N)                    — EML CANNOT do (Euclidean algorithm needs branching)
    5. N / gcd                        — EML can do IF gcd is given (÷)
    6. (N log₂ r − k) · 1200/N        — EML can do (− and ×)
"""

import math
import cmath
from math import gcd

# ============ EML primitives (paper §3, eq 3 + identities from Fig 1) ============
def eml(x, y):
    """The base EML operator: exp(x) - ln(y). Complex-domain internally."""
    return cmath.exp(x) - cmath.log(y)

def exp_eml(x):
    """e^x = eml(x, 1)  — paper Table 4, K=3 (depth 1)."""
    return eml(x, 1)

def ln_eml(x):
    """ln(x) = eml(1, eml(eml(1,x), 1))  — paper eq. 5, K=7 (depth 3)."""
    return eml(1, eml(eml(1, x), 1))

def mul_eml(x, y):
    """x·y = e^(ln x + ln y).  Built from exp_eml and ln_eml."""
    # ln(x*y) = ln(x) + ln(y)
    # x*y = exp(ln(x) + ln(y))
    return exp_eml(ln_eml(x) + ln_eml(y))

def div_eml(x, y):
    """x/y = e^(ln x - ln y).  Built from exp_eml and ln_eml."""
    return exp_eml(ln_eml(x) - ln_eml(y))

def sub_eml(x, y):
    """x - y = eml(ln(x), e^y).  Direct from EML definition with appropriate args:
       eml(ln(x), e^y) = exp(ln(x)) - ln(e^y) = x - y.  Verifies EML CAN subtract."""
    return eml(ln_eml(x), exp_eml(y))

# ============ Verify EML primitives ============
print("=" * 70)
print("EML PRIMITIVE VERIFICATION")
print("=" * 70)
for name, our_val, true_val in [
    ("e (constant)",      eml(1, 1),                math.e),
    ("e^2.5",             exp_eml(2.5),             math.exp(2.5)),
    ("ln(7)",             ln_eml(7),                math.log(7)),
    ("3 × 5",             mul_eml(3, 5),            15.0),
    ("3 / 5",             div_eml(3, 5),            0.6),
    ("3/2 (perfect 5th)", div_eml(3, 2),            1.5),
    ("2/3 (Koide ratio)", div_eml(2, 3),            2.0/3.0),
    ("7 - 3",             sub_eml(7, 3),            4.0),
]:
    real_val = our_val.real if hasattr(our_val, 'real') else our_val
    err = abs(real_val - true_val)
    flag = "✓" if err < 1e-12 else "✗"
    print(f"  {name:<22}  EML→ {real_val:>20.15f}   true→ {true_val:>20.15f}   {flag}")

# ============ The projection formula, decomposed ============
print()
print("=" * 70)
print("DECOMPOSITION: which parts of the lattice projection IS EML-expressible?")
print("=" * 70)

N = 12
LN2 = math.log(2)  # this is itself EML-computable: ln_eml(2)

def project_with_eml_continuous_part(r):
    """
    Use EML to compute the continuous D-content of the projection.
    This computes everything EXCEPT round() and gcd() — those are
    not EML-expressible because they are NOT pure continuous D operations.
    """
    # Step 1: log₂(r) = ln(r) / ln(2) — both via EML
    ln_r_eml  = ln_eml(r).real
    ln_2_eml  = ln_eml(2).real
    log2_r_eml = ln_r_eml / ln_2_eml      # division: EML-expressible
    
    # Step 2: N · log₂(r) — EML multiplication
    exact_eml = N * log2_r_eml             # multiplication: EML-expressible
    
    # Step 3: round() — NOT EML; this is T's act
    k = round(exact_eml)                   # T-rounding (outside EML)
    
    # Step 4: gcd() — NOT EML; this is discrete-D classification
    g = gcd(abs(k), N) if k != 0 else N    # discrete (outside EML)
    
    # Step 5: d = N/gcd — EML-expressible IF g is given as a number
    d = N // g                             # integer division (boundary case)
    
    # Step 6: ε via subtraction and multiplication — EML-expressible
    eps_cents = (exact_eml - k) * (1200.0 / N)
    
    return dict(
        r=r, ln_r=ln_r_eml, log2_r=log2_r_eml, exact=exact_eml,
        k=k, g=g, d=d, eps_cents=eps_cents,
        eml_did=['log₂(r)', 'N·log₂(r)', 'ε'],
        T_did=['round(N·log₂(r))'],
        discrete_D_did=['gcd(|k|, N)', 'N/gcd'],
    )

# ============ Demonstrate the unified pipeline ============
print()
print("THE UNIFIED PIPELINE: EML constructs the ratio, then lattice classifies it")
print("-" * 70)

# Test cases: each ratio is BUILT via EML, then projected
test_cases = [
    ("3/2 (perfect fifth)",  div_eml(3, 2).real),
    ("2/3 (Koide)",          div_eml(2, 3).real),
    ("9/8 (Pythag major 2nd)", div_eml(9, 8).real),
    ("e (transcendental)",   eml(1, 1).real),
    ("e^π",                  exp_eml(math.pi).real),  # using math.pi as input
    ("ln(2)",                ln_eml(2).real),
]

print(f"\n{'EML-built ratio':<28}  {'r':>14}  {'k':>4}  {'d':>3}  {'ε(¢)':>8}")
print("-" * 70)
for name, r in test_cases:
    if r > 0:
        proj = project_with_eml_continuous_part(r)
        print(f"{name:<28}  {r:>14.10f}  {proj['k']:>4}  {proj['d']:>3}  {proj['eps_cents']:>+8.3f}")

# ============ The structural decomposition theorem ============
print()
print("=" * 70)
print("THE STRUCTURAL DECOMPOSITION (the key finding):")
print("=" * 70)
print("""
  Lattice projection  =  (EML's continuous D-content)  +  (T's round act)  +  (discrete-D gcd)
        
  EML can implement:        log₂(r), N·log₂(r), ε computation, ratio formation
  EML CANNOT implement:     round() — this is T's act on the continuous D-position
                            gcd()   — this is discrete-D classification needing comparison
        
  Conclusion: EML covers EXACTLY the continuous D-content of the projection.
  Its inability to do round/gcd is the structural confirmation that EML is
  pure-continuous-D, with T's contribution and discrete-D classification
  living in two categorically different places (T-axis and discrete-D-axis).
""")

# ============ Verify: do EML and direct give the same lattice answer? ============
print("=" * 70)
print("CROSS-CHECK: EML-pipeline lattice projection == direct-formula projection?")
print("=" * 70)

def project_direct(r):
    """Standard ET projection — no EML."""
    log2r = math.log2(r)
    exact = N * log2r
    k = round(exact)
    g = gcd(abs(k), N) if k != 0 else N
    d = N // g
    eps_cents = (exact - k) * (1200.0 / N)
    return dict(k=k, d=d, eps_cents=eps_cents)

print(f"\n{'ratio':<24}  {'direct (k,d,ε)':>22}  {'EML-pipeline (k,d,ε)':>22}  match?")
print("-" * 90)
for name, r in test_cases:
    if r > 0:
        d_proj = project_direct(r)
        e_proj = project_with_eml_continuous_part(r)
        d_str = f"({d_proj['k']:>3}, {d_proj['d']:>2}, {d_proj['eps_cents']:>+7.3f})"
        e_str = f"({e_proj['k']:>3}, {e_proj['d']:>2}, {e_proj['eps_cents']:>+7.3f})"
        match = "✓" if (d_proj['k'] == e_proj['k'] and d_proj['d'] == e_proj['d']
                          and abs(d_proj['eps_cents'] - e_proj['eps_cents']) < 1e-9) else "✗"
        print(f"{name:<24}  {d_str:>22}  {e_str:>22}  {match}")

