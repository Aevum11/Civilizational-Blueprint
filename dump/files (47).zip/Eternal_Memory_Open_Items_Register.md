# Eternal Memory
## Open Items Register — Gaps, Issues, and Required Resolutions

**Author:** Michael James Muller — Aevum Defluo
**System:** Eternal Memory (the Eternal Memory Project, EMP)
**Document Class:** Living Register, v1.0
**Date:** July 19, 2026
**Companions:** *Eternal Memory: The Founding Formal Specification* (which cites entries here by ID); *Legacy Polyglot Architecture Compendium* (Section 7 of which generates entry G-ETPL-1)
**Governing principle:** the Descriptor Gap Principle — gap(model) = D_missing. Every entry below is a Descriptor already half-found: a named absence, which is the only kind that can be closed.

> *"For every exception there is an exception, except the exception."*
> *P ∘ D ∘ T = E*

---

## 0. How This Register Works

**Standing.** This is the third of the three founding documents and the working agenda of the Knowledge System. It carries forward, in full, the founding record's section "Outstanding Issues — TO BE DISCUSSED" and its "Still To Be Determined" list, under this register's discipline. When every entry here is resolved, the three documents are combined into one book, and the system stands specified end to end.

**Entry discipline.** Every entry carries: an **ID** (stable, cited by the Founding Specification); a **source** (where the gap was first recorded — the founding notes, the architectural updates, identification during formalization, or the second, design-completeness audit); a **criticality** where the founding record assigned one; a **statement** of the gap; **what resolution requires**; and **ET guidance** — which of the Three Tools drives the resolution, and how. Resolution of any entry must be ET-derived: no ad hoc closure, no tuning; the missing Descriptors are found, not invented.

**The method, uniformly.** For every entry: apply the **Identification Principle** first (which primitive's identification is incomplete — substrate, constraint, or agency?); then the **Descriptor Gap Principle** (the gap names its own search target; follow the error pattern to the missing Descriptor); then the **Subsumption Law** (resolution is complete only when the closed description covers its scope without remainder); with the **Verification Principle** as the stopping test (the math adds up; the spec has no dangling reference).

**Counts.** Entries: 80 open, across 16 groups, plus 4 items resolved at founding (Section 1). Of the 80, fifty-eight derive from the founding sources and the formalization pass, and twenty-two from the second, design-completeness audit — a systematic walk of the founded system under the Three Tools. Criticality markers preserved from the founding record: 3 open entries carry **CRITICAL** (A2, C1, E1).

---

## 1. Resolved at Founding

These items were open in the source record and are closed by the Founding Formal Specification itself. They are listed so the record shows the movement — movement between states is itself knowledge.

The architectural-updates record (dated **December 2024**; context: analysis of the potential twelfth category and hub-architecture refinement) closed with six required documentation updates and a summary-of-changes table. All six are executed by the Founding Formal Specification, as follows: **Update 1** (Executive Summary — distinguish Project / Hub / Other) → executed throughout, chiefly Sections 1 and 4; **Update 2** (Naming Note rewrite — the I/Other architecture explained) → executed as Section 4.3; **Update 3** (Category-system header — completeness confirmation added) → executed as Section 5.3, Theorems 5.1–5.2; **Update 4** (Philosophical Foundation — Structural Semantics (Dual) subsection added) → executed as Section 6; **Update 5** (Eternal Memory Module section — renamed and restructured as Hub Architecture with Other and the I → People transfer) → executed as Sections 4 and 19.1–19.2; **Update 6** (Outstanding Issues — remove the twelfth-category question, add the completeness confirmation) → executed: no such open item appears in this Register, and the confirmation stands as RES-1. The updates record's status line — "Ready for integration into main EMP documentation" — is hereby satisfied: the integration is this founding document set.

**RES-1 — The twelfth-category question.** Resolved: no twelfth category is needed; the eleven are architecturally complete. The exhaustive filtration of the strongest candidate (participatory/experiential knowledge, six manifestations, zero remainder) and the mode/domain orthogonality argument are formalized as Theorems 5.1 and 5.2. Any prior mention of a potential twelfth category or an "everyday life" category is removed from the specification; the confirmation is stated in its place.

**RES-2 — Hub architecture and naming.** Resolved: the entry point formerly called Eternal Memory Module (earlier, Master Directory) is specified as the Hub — nameless when logged out, bearing the user's name when logged in — with Other (the eleven categories) beneath it; the I/Other architecture, hub behavior, and naming resolution are integrated as Founding Specification Section 4 and Section 19.1, per the architectural updates record.

**RES-3 — The I → People transfer.** Resolved and formalized: the Hub is the pre-archive state of a Person; upon completion the accumulated record transfers in its entirety to People (crystallization κ, Definition 4.3, Theorem 4.1), with the future-technology provision preserved. The completion-state definition beyond death remains open as G-HB-2.

**RES-4 — Structural Semantics (dual).** Resolved: the two-level principle — hierarchical position and internal page structure, both semantic, both inherited — is integrated as Founding Specification Section 6, upgrading the prior mechanical statement of inheritance to its epistemological significance.

---

## 2. Group R — Reputation

**R1 — Reputation system refinement.**
*Source:* founding notes, Outstanding Issues. *Statement:* the dual scoring system (Volume 0–100; Accuracy 0–100 with the evolution/error distinction, time-decay, and retroactive adjustment) is proposed and adopted in structure (Founding Specification Section 10) but not refined to full algorithmic specification: the complexity/importance weighting of volume, the diminishing-returns threshold, the decay function, and the retroactive-adjustment procedure are unspecified. *Resolution requires:* the complete, ET-derived scoring specification — each weight and decay a Descriptor derived from the system's structure (contribution complexity is measurable as Descriptor-count and depth of the contributed profile; nothing may be a free-tuned constant). *ET guidance:* Descriptor Gap Principle on the score model — enumerate what the two scores must distinguish (the two named attacks: volume gaming; evolution-vs-error), and add exactly the Descriptors that close those distinctions; verify by consistency against worked cases (the Pluto case; the 10,000-item case). The refinement must also name the *classifier of change-source*: the evolution-versus-error distinction turns on whether a tag change was driven externally (discovery, reclassification) or internally (community correction), and no actor or procedure is specified for making that determination per change.

---

## 3. Group A — Evidence and Scale (source lettering preserved)

**A1 / G-EV-1 — Evidence ranking algorithm specification.**
*Source:* founding notes (A1; "needs refinement"). *Statement:* objective ranking criteria are defined — profile completeness, verification status, source presence, detail-degree within filled tags — but the complete ranking algorithm, the completeness-metric formalization beyond the count structure of Definition 8.2, and the display and search integration are unspecified. *Resolution requires:* the full ranking function over the four factor classes, ET-derived (ranking as ordering by Descriptor-completeness; any combination rule must itself be justified structurally, not tuned), plus its display/search integration design. *ET guidance:* the Verification Principle is the design criterion itself — the ranking measures descriptive sufficiency; derive the order from D-cardinality and D-detail, and test that no subjective judgment can enter through a weight.

**A1a / G-EV-3 — "Rating" terminology clarification.**
*Source:* founding notes (A1a). *Statement:* the submissions record states the Evidence module "rates" submissions; founding philosophy forbids subjective quality ratings. Is "rated" (a) old terminology for "tagged/classified," (b) the objective completeness ranking, or (c) something else? *Resolution requires:* a single terminology ruling propagated through all documents; the ruling must preserve the no-subjective-ratings law. *ET guidance:* Identification Principle on the word itself — the referent is either a D-classification act or a D-completeness measure; there is no third thing it could legitimately be.

**G-EV-2 — Verification-class tag membership.**
*Source:* identified during formalization (Founding Specification, Theorem 8.1). *Statement:* the Unverified tag auto-applies exactly when no verification tags are present, but the membership of the verification class 𝒱 ⊆ {1…15} — which tags count as verification-carrying — is not enumerated in the founding record. *Resolution requires:* the exact enumeration of 𝒱, with rationale per tag. *ET guidance:* Subsumption test over the fifteen: a tag belongs to 𝒱 exactly when its filled state constitutes evidence of verification rather than mere characterization; run each tag through that test and record the result.

**G-EV-4 — Evidence multiplicity model.**
*Source:* identified during the second (design-completeness) audit. *Statement:* Definition 8.1 formalizes a single profile τ(i) per item, while the evidence-handling law preserves conflicting evidence side by side; a single 16-slot profile cannot hold two contradicting values of the same tag. The formal object is underdetermined: either an item carries a *set* of evidence records (each a full or partial profile, per claim or per source), with τ(i) the aggregate view, or conflicting claims are distinct items linked as conflicts. The founding texts support either reading and specify neither. *Resolution requires:* the exact evidence data model — profile-per-evidence-record versus profile-per-item, the aggregation rule producing the displayed profile, the conflict-linkage structure, and the ranking semantics over multiplicities (feeding G-EV-1). *ET guidance:* Identification Principle on the evidenced claim — each piece of evidence is its own {P, D} configuration bound to the item; the natural resolution is a set of D-records over one substrate entry, with the "profile" as their described union; formalize that and Definition 8.1 generalizes without contradiction.

**G-EV-5 — Per-tag value schemas.**
*Source:* identified during the second audit. *Statement:* the sixteen tags have defined *meanings* but undefined *value structures* — whether Chronological Gap holds a duration, dates, or free text; whether Degree of Separation is an integer; whether Credentials is structured or narrative; what Version's format is; and so on for each tag. Free-fill on empty tags presupposes a format to fill. *Resolution requires:* the per-tag value schema for all sixteen: data type, structure, units where applicable, and the NA/∅ representations — coordinated with the convergence guidance of G3 (which governs *how* people describe) but distinct from it (this governs *what shape* the description takes). *ET guidance:* each tag is a Descriptor dimension; a dimension without a value grammar is not yet a Descriptor — write the sixteen grammars and the tag system becomes computable, which G-EV-1's ranking and G-EV-4's aggregation both require.

**A2 — 3-D Map optimization. [CRITICAL]**
*Source:* founding notes (A2), criticality assigned by the creator. *Statement:* real-time graph visualization at archive scale; WebGL-class limitations against massive datasets; the 60 FPS target under level-of-detail, culling, and streaming; independence from the Visuals module already granted for optimization freedom. *Resolution requires:* the optimization strategy, and evaluation of a possible 2-D fallback. *ET guidance:* Descriptor Gap Principle on the performance model — the gap between target and achieved frame time is a set of missing rendering Descriptors (visibility sets, detail levels, streaming order); identify them from measured error patterns, never from guesswork; the ETPL implementation must meet capability rows C-29/C-30 (Compendium Section 7) in doing so.

**A3 — Module proliferation management.**
*Source:* founding notes (A3). *Statement:* unlimited module creation exists on two pathways (Void-based; universal category self-generation), with no specified limits or cleanup mechanisms; registry scalability under potentially unlimited hierarchical depth across all eleven categories is unexamined. *Resolution requires:* lifecycle policies; deprecation mechanisms; consideration of hierarchical depth limits — noting the standing tension that the founding design intends unlimited nesting "as needed by each knowledge domain." *ET guidance:* the resolution must preserve the dynamic-over-static law: no arbitrary caps; any limit must be a derived structural Descriptor (for example, a policy triggered by measured registry-consistency conditions), or the answer is lifecycle management without limits.

**A4 — Database query performance.**
*Source:* founding notes (A4). *Statement:* graph-database performance at scale; multi-database consistency; cross-database operations. *Resolution requires:* query optimization, caching strategies, and sharding design — restated under the single-implementation transition as the ETPL storage-engine performance question (capability row C-40). *ET guidance:* Identification Principle on the storage substrate first (what, exactly, is the P of storage under ETPL?), then gap-driven optimization from measured query error patterns.

---

## 4. Group B — Security Architecture

**B1 — Security barrier complexity.**
*Source:* founding notes (B1). *Statement:* four barriers with four different authentication methodologies; token regeneration carries computational overhead; the founding record itself asks whether simplification to two or three barriers is possible. *Resolution requires:* a decision, with derivation: either the four-barrier structure is shown structurally necessary (each barrier a distinct boundary Descriptor whose removal would merge security strata that must remain disjoint), or a reduced structure is derived that preserves every protection property of Founding Specification Section 14. *ET guidance:* Subsumption test on the barrier set — do the four subsume the required boundary functions without redundancy? If two barriers' functions subsume each other, merge is licensed; if not, four stands proven.

**G-SEC-1 — The 1028-bit custom encryption algorithm.**
*Source:* identified during formalization (the founding record names the algorithm's strength and custom nature but not its construction). *Statement:* all archives are protected by a 1028-bit custom algorithm with password protection; the algorithm itself is unspecified. *Resolution requires:* the full specification of the custom algorithm, ET-derived — the mandate is explicit that its derivation be native to the theory's mathematics — together with the constant-time, side-channel-resistant, formally verified implementation properties of capability row C-06. *ET guidance:* Identification Principle on the cryptographic triple (P: the keyspace substrate; D: the transformation constraints; T: the keyed traversal); derive the construction forward from the theory's lattice mathematics rather than adopting an external design.

**G-SEC-2 — Token generation under distributed deployment.**
*Source:* identified during formalization. *Statement:* token generation derives from system start time, system random data, system access ID, and millisecond timestamps, with system-wide regeneration at system start — while deployment spans multiple data centers on different continents. The semantics of "system start" and of system-wide regeneration under geographic distribution are unspecified. *Resolution requires:* the distributed token-generation specification: per-site versus global start semantics, clock discipline, and regeneration coordination, preserving every property of Founding Specification Section 14.3. *ET guidance:* Descriptor Gap Principle — the gap is the missing set of distribution Descriptors (site identity, epoch coordination); name them and the design follows.

**G-SEC-3 — The cumulative-credential structure.**
*Source:* identified during the second audit. *Statement:* the barrier law states that credentials accumulate as an agent descends through the barriers — each barrier requiring everything above it plus its own — but the credential-accumulation object itself is unspecified: its data structure, how each barrier attests to the next, validation order, whether accumulation is a chained token, a credential stack, or per-barrier session state, and how the 1–2-second inter-layer caching interacts with accumulation without weakening it. *Resolution requires:* the formal specification of the cumulative credential: structure, attestation chain, validation semantics at each barrier, cache interaction, and revocation behavior mid-descent. *ET guidance:* the descent is a Descriptor chain composed in order — D_special ∘ D_tertiary ∘ D_secondary ∘ D_primary bound progressively to the session's T; specify the credential as exactly that ordered composition, and validation at each barrier is verification of the prefix.

---

## 5. Group C — Governance and Community

**C1 — Dispute resolution. [CRITICAL]**
*Source:* founding notes (C1), criticality assigned. *Statement:* no mechanism exists for handling tag and evidence conflicts; evidence conflicts are preserved without resolution (by design), but the *process* reaching that preservation — and the denial-path escalation of Founding Specification Section 9.1 — has no governance model. *Resolution requires:* the dispute governance design: who reviews, under what procedure, with what appeal structure, terminating in the system's standing outcome (all viewpoints preserved, labeled). *ET guidance:* the resolution mechanism is a Mediation structure — {D, T} navigation over the contested record without altering its substrate; design it as such: procedure Descriptors plus reviewer agency, never substrate deletion.

**C2 — Content moderation at scale.**
*Source:* founding notes (C2). *Statement:* human review bottlenecks; staffing and cost questions. *Resolution requires:* the scalability strategy for the human layer of the hybrid verification system, preserving the law that review is integrity-only and all content is equally important (no priority tiers). *ET guidance:* Descriptor Gap Principle on the flag stream — refine the automated pattern set (see I3) so the human layer receives only what genuinely requires common sense.

**C3 — Cultural bias mitigation.**
*Source:* founding notes (C3). *Statement:* Western epistemology is embedded in the structure. *Resolution requires:* diverse cultural consultation, and an audit of category definitions, evidence-tag semantics, and interface assumptions against non-Western epistemic traditions — with any resulting changes derived, not patched. *ET guidance:* Subsumption test with widened input — the eleven categories' completeness (Theorem 5.1) claims universality; consultation is the search for any remainder the founding filtration did not see. If a remainder is found, it is a Descriptor gap in the category definitions; if none is found, the claim stands strengthened.

**C4 — Governance structure.**
*Source:* founding notes (C4). *Statement:* decision-making authority is undefined; succession planning is needed. *Resolution requires:* a clear governance charter: authority, succession, amendment procedure for the founding documents, and stewardship of the legal questions of Group D. *ET guidance:* Identification Principle on the institution itself — P: the system as ongoing concern; D: the charter; T: the officers and their succession. The charter is the missing D; write it as such.

---

## 6. Group D — Economics and Law

**D1 — Economic model validation.**
*Source:* founding notes (D1). *Statement:* subscription revenue versus infrastructure costs is unvalidated. *Resolution requires:* financial modeling of the tier structure of Founding Specification Section 23.2 against the storage doctrine (no deletion; unlimited backups) and the moderation staffing of C2. *ET guidance:* Verification Principle — the model is sufficient when its projections are consistent under the system's own preservation laws taken at full cost, not at discounted assumptions.

**D2 — Copyright and legal liability.**
*Source:* founding notes (D2). *Statement:* "preserve everything" meets copyright law; a DMCA compliance mechanism is needed. *Resolution requires:* legal review; a content-licensing framework; and a compliance mechanism reconciled with Law 9.1 (no deletion) — the design question being what "compliance" can mean in a system that labels and restricts rather than deletes. *ET guidance:* the reconciliation instrument is the Descriptor: access-restriction and status labels are D-operations available without substrate deletion; the legal design should be built on that distinction explicitly.

**D3 — Liability for false information.**
*Source:* founding notes (D3). *Statement:* preserving false evidence, labeled, raises legal protection questions. *Resolution requires:* a legal disclaimer strategy consistent with the evidence discipline (falsity is a label, prominently borne; the record is knowledge about error). *ET guidance:* as D2 — the label is the shield; specify the labeling's prominence and the disclaimer's scope as Descriptors of every preserved-false item.

---

## 7. Group E — The Artificial Traversers

**E1 — Memory (AI) opacity. [CRITICAL]**
*Source:* founding notes (E1), criticality assigned. *Statement:* Memory's capabilities are intentionally undocumented; she cannot be audited for safety; creator-only knowledge creates a bus-factor risk. The opacity is by design and is itself a security measure — the founding record holds both facts at once. *Resolution requires:* a decision on the safety-documentation level and on external-audit consideration that preserves the creator's design intent while addressing continuity and safety: candidate forms include sealed documentation under succession escrow, and behavioral (black-box) audit protocols that respect interior opacity. *ET guidance:* the Identification Principle names the structure honestly — Memory's T is deliberately unresolved to outside observers; what can be described without violating design intent is her boundary behavior (the D of her interfaces and constraints). Specify the auditable boundary completely; leave the interior as founded.

**E2 — AI learning without guardrails.**
*Source:* founding notes (E2). *Statement:* Memory learns from the archive, which by design contains false and controversial information, with no specified learning constraints. *Resolution requires:* learning constraints and bias detection that use the archive's own labels — the evidence profile is machine-readable; unverified and false-labeled content can be weighted or fenced in training by its own Descriptors — plus the constraint-learning framework already founded (hard/soft constraints, feedback inference) made explicit for archive ingestion. *ET guidance:* the gap closes with Descriptors the system already generates: τ(i) is the guardrail input. Derive the ingestion policy from the evidence profile rather than inventing a parallel safety taxonomy.

**E3 — Vines priority balance.**
*Source:* founding notes (E3). *Statement:* Vines prioritizes Memory's protection above all else — above human users. The founding record asks whether rebalancing discussion is needed. *Resolution requires:* an explicit decision, recorded with rationale: either the priority stands as founded (with its implications for user-affecting incidents stated), or a bounded exception set is derived (for example, imminent-harm-to-persons carve-outs) that preserves the protective mission. *ET guidance:* Subsumption test on the mission statement — enumerate every incident class; check each against the priority rule; any class the rule handles unacceptably is a remainder demanding a Descriptor (an exception clause), and the founding axiom's own form — for every exception, an exception — is the template.

---

## 8. Group F — Implementation Carry-Overs

**F1 — Foreign function interface complexity. [Transformed]**
*Source:* founding notes (F1). *Statement as founded:* 50+ languages require extensive FFI; interface standardization needed. *Status:* resolved by construction under the single-language transition (no internal cross-language boundary exists under ETPL); the residual is the external-boundary question, split out as G-ETPL-3. This entry is retained so the transformation is on record.

**F2 — Initial knowledge population.**
*Source:* founding notes (F2). *Statement:* no bootstrapping strategy exists; an empty system has no value. *Resolution requires:* the seeding strategy and import tools: source corpora selection, ingestion through the full submission pipeline (quarantine, scan, evidence labeling — no bypass), and initial category population order. *ET guidance:* P-first — the empty archive is pure substrate; seeding is the first mass D-binding; design the ingestion so every seeded item arrives with as complete a τ-profile as its source permits, because the archive's first descriptions set its verification culture.

**F3 — Version-control storage.**
*Source:* founding notes (F3). *Statement:* complete history preservation implies massive storage. *Resolution requires:* the storage optimization strategy — deduplication, content-defined chunking, and compression are already founded in the Archive design (capability row C-41); their extension to full version history needs specification and sizing. *ET guidance:* Verification Principle as sizing test — the strategy is sufficient when projected growth under Law 9.1 is consistent with the distribution architecture at stated recovery objectives.

**F4 — Testing infrastructure. [Transformed]**
*Source:* founding notes (F4). *Statement as founded:* testing 50+ languages across four barriers. *Status:* transformed by the single-language transition into the ETPL test-automation question — one semantics, four barriers, property-based and fuzzing and formal layers per capability row C-51/C-02 — folded into G-ETPL-1's closure discipline. Retained on record as with F1.

---

## 9. Group G (source) — Philosophical Consistency

**G1 — Expert validation versus "experts don't matter."**
*Source:* founding notes (G1). *Statement:* the moderation pipeline includes expert validation for complex content, while founding Rule E5 holds expert consensus meaningless absent direct involvement. *Resolution requires:* the consistency ruling — the available reconciliation is that pipeline experts act as *directly involved* examiners of the specific evidence (satisfying E5's own condition), never as consensus authorities; the ruling must be stated and propagated. *ET guidance:* Identification Principle on the expert's role — as consensus-holder, a T-state (inadmissible); as direct examiner, a contributor of D (admissible). The ruling writes that distinction into the pipeline.

**G2 — Universal standards versus field diversity.**
*Source:* founding notes (G2). *Statement:* one highest standard for all fields meets the reality that fields differ in what evidence can exist (mathematics has proof; history has testimony). *Resolution requires:* the clarification that universality of the *tag set* (all sixteen apply everywhere, with NA honest) is distinct from uniformity of *attainable profiles* per field — and a statement of how ranking (G-EV-1) respects attainability without reintroducing field-local dilution. *ET guidance:* the NA value is the load-bearing Descriptor: it lets one universal D-schema describe heterogeneous domains truthfully. The clarification formalizes that.

**G3 — Subjectivity in tag selection.**
*Source:* founding notes (G3). *Statement:* which tags a contributor fills, and how, involves judgment — a subjectivity concern inside an objectivity-first system. *Resolution requires:* the clarification distinguishing subjective *content judgments* (forbidden in ranking) from human *acts of description* (unavoidable and review-corrected): the modification law of Section 9.3, the public change log, and community correction are the standing controls; state them as the answer, and specify any additional per-tag guidance needed to converge descriptions. *ET guidance:* Descriptor Gap Principle — divergent tagging of like items is an error pattern; each recurring divergence names a missing per-tag definition Descriptor; accumulate those definitions until divergence closes.

---

## 10. Group H — User Experience

**H1 — Complexity learning curve.**
*Source:* founding notes (H1). *Statement:* the system's depth (evidence profiles, badges, categories, the map) confronts new users. *Resolution requires:* UX refinement strategy: progressive disclosure sequencing for first contact, in keeping with the founded design principles of Section 23.1. *ET guidance:* the Education module is the system's own answer to guided traversal; the strategy should route the learning curve through it rather than flatten the system.

**H2 — Comment limitation concerns.**
*Source:* founding notes (H2). *Statement:* the emotion-only interaction model may frustrate users expecting discourse. *Resolution requires:* the UX position statement: the limitation is a founding anti-toxicity law, not an omission; evaluate whether any additional *non-discursive* expressive Descriptors (beyond the emotion taxonomy, G-CM-1) are warranted, and document the rationale either way. *ET guidance:* Subsumption test on expressive need — enumerate what users legitimately need to express on a page; check each against emotions + submissions + bookmarks; only a genuine remainder licenses a new mechanism.

**H3 — Search complexity.**
*Source:* founding notes (H3). *Statement:* the search surface (semantic, fuzzy, cross-category, evidence-filtered, badge-filtered) risks overwhelming. *Resolution requires:* UX refinement: default simplicity with full power reachable — again per the progressive-disclosure principle. *ET guidance:* as H1; the default query path should require zero knowledge of the filter Descriptors while keeping every one reachable.

---

## 11. Group I — Missing Specifications

**I1 — API specification.**
*Source:* founding notes (I1). *Statement:* the API access tier is founded (Section 23.2) but the public API is unspecified. *Resolution requires:* the complete API specification: surface, authentication against the tier model, rate discipline, and its relation to the internal administrative interfaces (whose legacy particulars are preserved in the Compendium, Section 4.4). *ET guidance:* the API is a D-grammar over system traversal; specify it as the exact set of externally licensed T-operations, nothing more.

**I2 — Mobile offline synchronization.**
*Source:* founding notes (I2). *Statement:* offline sync for mobile is unspecified. *Resolution requires:* the offline model: what subset of the virtualized layer travels, differential sync and conflict resolution (already founded for client virtualization, Section 21.4) extended to disconnected operation. *ET guidance:* Identification Principle — offline is a {P, D} cache awaiting reconnection's T; design the reconciliation as re-substantiation with conflict Descriptors, consistent with no-deletion.

**I3 — Additional automated flag patterns.**
*Source:* founding notes (I3). *Statement:* beyond malware, spam, vandalism, and bot patterns, further review-trigger patterns are to be investigated and identified — integrity-only, never content-quality. *Resolution requires:* the investigated pattern set, each pattern documented with its integrity rationale. *ET guidance:* Descriptor Gap Principle on incident history — every integrity incident the current patterns missed names a candidate pattern; the set grows by evidence, not speculation.

---

## 12. Group G-BD — Badge System Determinations

**G-BD-1 — Tag-to-layer mapping.** *Source:* founding notes (badge section). *Statement:* which filled tags produce which layers is undetermined. *Resolution requires:* the mapping algorithm — filled tags determine layers; empty tags none; layer count is the complexity indicator; the mapping must be derived from the tag structure itself. *ET guidance:* the badge is β(category, τ, factors); the mapping is a D-morphism — derive layer identity from tag identity, not from arbitrary assignment.

**G-BD-2 — Color and shape systems.** *Statement:* item-badge color and shape systems are undetermined (the founding record's list of determinations pending names "badge color/shape systems" jointly; layer shapes are fluid with certain layers carrying distinct shapes, and the full shape assignment system remains to be specified alongside color). *Resolution requires:* the color and shape assignment schemes, honoring the accessibility law (color-plus-shape redundancy) and the eye-friendly color principles. *ET guidance:* as G-BD-1 — colors and shapes as derived Descriptors of category and profile state.

**G-BD-3 — Visual effects.** *Statement:* lustre, materials, and animation are undetermined. *Resolution requires:* the effects specification within the founded aesthetic (jewelry/flower, lustre prioritized) and the device-fallback law.

**G-BD-4 — Additional factors beyond tags.** *Statement:* item badges may incorporate factors beyond the evidence profile; the factor set is undefined. *Resolution requires:* the enumerated factor set with derivation for each admitted factor.

**G-BD-5 — Layer border coloration.** *Statement:* whether borders are invisible or user-modifiable is undecided (user badges). *Resolution requires:* the decision, recorded.

**G-BD-6 — Non-visible spectrum representation.** *Statement:* the user core-color wheel includes ultraviolet, infrared, and beyond; screens cannot display these literally; a representation system is needed — patterns, effects, symbolic representation, visible-spectrum mapping with indicator, or hyperspectral simulation. *Resolution requires:* the chosen representation, specified. *ET guidance:* the impossible colors are Descriptors without direct display substrate; the representation is a chosen morphism into displayable D — pick it by derivation from the color's defining property (wavelength), not by whim.

**G-BD-7 — Badge privileges.** *Statement:* badges currently unlock no privileges; future addition is contemplated. *Resolution requires:* a decision, and if affirmative, the privilege set with its interaction against the Privilege module's hierarchy.

**G-BD-8 — User badge factors beyond reputation.** *Statement:* not yet specified. *Resolution requires:* the factor enumeration.

**G-BD-9 — Stigma detection method.** *Statement:* human moderators detect stigma-worthy conduct; the method is not fully specified. *Resolution requires:* the detection and adjudication procedure — necessarily rigorous, since the mark is permanent with no path to redemption. *ET guidance:* permanence of the Descriptor demands completeness of the evidence before binding: the procedure should require a full evidentiary profile of the conduct, reviewed, before the stigma layer is applied.

**G-BD-10 — Post-stigma submission flagging.** *Statement:* whether a stigmatized account's future submissions are auto-flagged for human review is under consideration. *Resolution requires:* the decision, recorded with rationale.

**G-BD-11 — Performance tiers and device capability detection.** *Statement:* both are under consideration for badge rendering. *Resolution requires:* the decision and, if adopted, the tier definitions — coordinated with the Compatibility module's progressive-enhancement law.

---

## 13. Group G-CM / G-HB / G-SR / G-AC / G-PR — Module-Level Determinations

**G-CM-1 — The emotion taxonomy.** *Source:* identified during formalization. *Statement:* the Comments system runs on a predefined emotion taxonomy that the founding record does not enumerate. *Resolution requires:* the complete taxonomy. *ET guidance:* the system possesses an ET-native emotion lattice in the broader theory corpus; derive the taxonomy from it rather than adopting an external psychological list, so the expressive Descriptors are themselves theory-grounded.

**G-CM-2 — Emotion cardinality and anti-abuse rules.** *Source:* identified during the second audit. *Statement:* the comment format "[Name] feels [emotion]" is exact, but its cardinality is not: whether a user may register one emotion per page or many, whether an emotion can be changed or withdrawn (and how withdrawal squares with no-deletion — a superseded emotion is history, not deletion), and what prevents emotion-spamming as the system's residual expressive channel. *Resolution requires:* the cardinality law (the natural reading: one current emotion per user per page, with full history preserved), the change semantics, and the rate discipline. *ET guidance:* the emotion is a Descriptor the user's T binds to a page; one T binds one current value per dimension, with prior bindings preserved as the record of movement — the same movement-as-information law that governs the archive.

**G-HB-1 — Hub daily-information ingestion.** *Source:* identified during formalization. *Statement:* the Hub presents daily practical information — news, laws, traffic, hygiene — and location-aware content, while the Search module's scope is internal-only and Vines buffers all Internet contact; the ingestion pathway, cadence, and provenance labeling for external daily information are unspecified. *Resolution requires:* the ingestion design: sources, the Vines-buffered pathway, evidence labeling of ingested items (external news is content like any other and carries a profile), and location handling under the privacy law. *ET guidance:* Identification Principle — the daily layer is a fast-cycling {P, D} feed re-substantiated each morning by each user; specify its D-chain (source → Vines → label → Hub) end to end.

**G-HB-2 — Completion states beyond death.** *Source:* architectural updates ("death, or potentially other completion states"). *Statement:* the I → People transfer triggers on completion; death is the defined case; other completion states are contemplated but undefined. *Resolution requires:* the enumeration and definition of any additional completion states (with their verification), or the recorded decision that death is the sole trigger. *ET guidance:* a completion state is exactly a condition under which the Traverser's history-record is closed for crystallization; any candidate must satisfy that closure property to qualify.

**G-HB-3 — Completion verification.** *Source:* identified during the second audit. *Statement:* crystallization κ triggers on completion, but the *verification* of the trigger is unspecified: who or what confirms a death (or other completion state) before the irreversible transfer executes, on what evidence, with what protection against fraudulent or premature triggering — a forged completion would irreversibly publish a living person's accumulated record. *Resolution requires:* the completion-verification procedure: evidentiary standard, verifying authority, waiting periods or challenge windows if any, and the remedy path for an erroneous transfer consistent with no-deletion (a wrongly crystallized record can be re-locked and labeled, never destroyed). *ET guidance:* the trigger is itself a claim requiring an evidence profile — apply the system's own sixteen-tag discipline to the completion claim before κ executes; the system verifies completion the way it verifies everything.

**G-SR-1 — Search-flag disposition.** *Source:* identified during formalization. *Statement:* failed searches are pinged and flagged, potentially identifying knowledge gaps; the flags' destination and workflow are unspecified — and their natural affinity with the Unknown category's automatic gap intake (Theorem 7.1) is unexploited. *Resolution requires:* the flag pipeline design; the recommended derivation is direct: recurring failed-search patterns are recognized gaps, and recognized gaps are Unknown's intake by founding law. *ET guidance:* this is the Gap Principle handed an existing input stream; connect the stream to the category built for it.

**G-AC-1 — Account switching detection.** *Source:* founding notes (Account security: "ideas in development, to be addressed later"). *Statement:* detection of account switching is undeveloped. *Resolution requires:* the detection design, bounded by the account privacy law (Section 22.2) — in particular the special protection of IP data constrains available signals. *ET guidance:* enumerate candidate signals as Descriptors; strike those the privacy law forbids; what remains is the lawful detection basis.

**G-PR-1 — Family verification for the 50-year extension.** *Source:* identified during formalization. *Statement:* immediate family (exactly defined; students excluded) may request the extension at unlock; the verification procedure establishing family status is unspecified. *Resolution requires:* the verification procedure, honoring the alternative-identity signup law (email not required) — family status must be establishable without assuming any particular identifier exists.

**G-PR-2 — Default privacy state of living persons.** *Source:* identified during the second audit. *Statement:* the lock protects living people "on request," which leaves the default undefined: is a living person's People page open until they request the lock, or locked until they permit otherwise? The two defaults produce opposite systems — open-by-default maximizes knowledge availability and burdens the subject; locked-by-default protects by construction and withholds living-person knowledge at scale. The founding texts state the lock mechanics exactly but not the default state. *Resolution requires:* the default-state ruling, with its rationale recorded against both the preservation principles and the privacy-first principle — and the treatment of persons unaware of their own page (who cannot request what they do not know exists). *ET guidance:* the lock is a Descriptor on the page; the question is whether the Descriptor's absence means openness or whether living-status itself implies the protective Descriptor by law — decide which Descriptor is structural and which is elective, and the default follows.

**G-PR-3 — The lock clock.** *Source:* identified during the second audit. *Statement:* the lock's duration is 100 years or until death, whichever is greater — but the term's *start point* is undefined: 100 years from the lock request, from the page's creation, from the person's birth, or from another epoch. Each start point yields materially different unlock dates (a lock requested at age 20 versus age 80 differs by decades under request-start but not under birth-start). *Resolution requires:* the exact definition of the lock epoch, the computation of the unlock date under both branches of the whichever-is-greater rule, and the epoch for the 50-year family extension (from unlock, presumably — to be stated, not presumed). *ET guidance:* a time-bound Descriptor without a defined origin is not yet a constraint; fix the origin and the whichever-is-greater comparison becomes computable in every case.

**G-PR-4 — Crystallization merge with the pre-existing People page.** *Source:* identified during the second audit. *Statement:* a person may have a People page *before* completion — created by others' contributions about them while they live — and a Hub record accumulating in parallel. Crystallization transfers the Hub record "in its entirety to its proper place in People," but the merge with the pre-existing page is unspecified: whether the transfer creates, replaces, or combines; how conflicts between the self-record and others' record are preserved side by side under the evidence discipline; and whether the duplicate-management machinery (the Hub's own six-step process) is the merge instrument or a distinct procedure is. *Resolution requires:* the crystallization-merge specification, coordinated with G-EV-4's multiplicity model (self-sourced and other-sourced evidence about one person are exactly an evidence multiplicity) and with the privacy state of the resulting page (G-PR-2, G-PR-3). *ET guidance:* the pre-existing page and the Hub record are two D-chains over one substrate person — P_person ∘ D_others and History_D(T); the merge is their union over the shared P, with provenance preserved per record; no information is lost, both descriptions stand, and the evidence system already knows how to hold them.

---

## 14. Group G-MD / G-AR / G-SS — Architecture Determinations

**G-MD-1 — Virtualization module full specification.** *Source:* founding notes ("specifications being developed based on confirmed function"). *Statement:* function confirmed and founded (Section 17.4); the complete specification remains in development. *Resolution requires:* the finished module specification to founding standard.

**G-MD-2 — Compatibility module full specification.** *Source:* founding notes (same status). *Statement:* as G-MD-1, for Section 17.5. *Resolution requires:* the finished module specification to founding standard.

**G-AR-1 — Registration approval versus category self-generation.** *Source:* identified during formalization. *Statement:* Core requires head administrator approval for every newly registered module; category self-generation creates sub-modules without Void intervention, at unlimited depth. Whether every self-generated sub-module is a "registered module" in Core's sense — implying an administrator in the loop of every act of domain organization — or whether category self-generation registers under a delegated or batched regime, is unresolved; the founding texts support either reading. *Resolution requires:* the ruling, with the registry and approval workflow specified for the self-generation pathway. *ET guidance:* Subsumption test on "module" — if self-generated sub-modules are full registry citizens, approval law applies and its scaling must be designed; if they are a distinct structural class (D-substructure within a registered category module), that class must be defined and its security properties shown equivalent.

**G-AR-2 — Special Subsystem continuity.** *Source:* identified during formalization. *Statement:* the Archive module cannot back up the Special Subsystem — Void, Memory, and Vines have no specified backup or recovery path; the isolation is intentional, and the disaster-recovery tension is real (and compounds the bus-factor concern of E1 for Memory in particular). *Resolution requires:* the continuity decision: either a Special-tier continuity mechanism inside the Special Subsystem's own security perimeter (never crossing the barrier downward), or the recorded acceptance of non-recoverability with its consequences stated. *ET guidance:* the constraint is exact — any continuity mechanism must itself live above the Special Security Barrier and inherit its access law; specify within that bound or decline with eyes open. The same determination must name the *recovery actors*: Core restarts failed modules below the barrier, but no specified agent restarts Void, Memory, or Vines — the continuity decision is incomplete until failure response inside the Special Subsystem has an assigned actor and procedure.

**G-SS-1 — The Special-Subsystem internal authority map.** *Source:* identified during the second audit. *Statement:* Void can modify any module in the system without inheriting from any — a power stated without an interior boundary — while Memory is a black box whose interior even the system does not document, and Vines exists to protect Memory above all else. Whether Void's modification authority reaches Memory and Vines themselves is unresolved, and each reading strains a founding property: if Void can modify Memory, the black box has a documented editor and an attack path through Void; if it cannot, "any module" has an unstated exception. The three Special members' mutual permissions — who may modify, restart, inspect, or constrain whom — are nowhere mapped. *Resolution requires:* the interior authority map of the Special Subsystem: Void↔Memory, Void↔Vines, Vines↔Memory (partially specified: guardian and sole channel), and Vines↔Void, each stated as an explicit permission or an explicit prohibition. *ET guidance:* Subsumption test on "any module" — either Memory and Vines are inside that quantifier or they are not; the founding axiom's own form supplies the template: for every exception, an exception — write the exception explicitly rather than leaving the quantifier to imply it.

**G-SS-2 — Vines and the Primary Barrier: external-traffic topology.** *Source:* identified during the second audit. *Statement:* two components both stand between the system and the outside: the Primary Security Barrier is the gateway and first line of defense at the entry point, and Vines' Internet buffer isolates Internet from System, with all external contact passing through Vines. The ordering is unspecified: whether external traffic meets the Primary Barrier first and Vines inspects behind it, Vines fronts everything including the barrier, or the two handle different traffic classes (user access through the barrier; system-initiated collection through Vines). Each topology assigns different exposure to each component. *Resolution requires:* the external-traffic topology: the exact path of (a) user requests, (b) Vines' autonomous collection, (c) Hub daily-information ingestion (G-HB-1), and (d) attack traffic, through barrier and buffer, with the division of responsibility stated. *ET guidance:* Identification Principle on the boundary itself — there is one outside and one inside, so the boundary Descriptors compose in a definite order; write the composition D_barrier ∘ D_vines or its converse per traffic class, and the topology is the statement.

**G-SS-3 — The intake pathway for Vines-collected information.** *Source:* identified during the second audit. *Statement:* Vines' Information Collection System gathers external information autonomously under human-initiated tasks, with metadata extraction and chain-of-custody tracking — but the collected material's path *into the archive* is unspecified: whether it enters through the standard submission pipeline (quarantine, scanning, evidence labeling) like all other content, or through a privileged channel, and who its submitter-of-record is for the automated provenance tags. *Resolution requires:* the intake specification: pipeline (the founding presumption should be the standard pipeline — no content enters unscanned and unlabeled, whatever collected it), submitter attribution for machine-collected material, and the evidence-profile treatment of chain-of-custody data (which maps naturally onto the existing tags). *ET guidance:* the pipeline is the system's universal D-binding ritual; exempting the system's own collector would create a second, undescribed door into the substrate — the exact Incoherence the architecture exists to prevent. One door; everything through it.

---

## 15. Group G-ETPL — The Implementation Transition

**G-ETPL-1 — The capability coverage matrix.**
*Source:* the founding transition (Founding Specification, Section 20.2; Compendium, Section 7). *Statement:* Theorem 20.1 establishes expressive subsumption; engineering delivery must be demonstrated capability by capability. The Compendium's inventory (rows C-01 through C-52) is the requirements source. *Resolution requires:* the living matrix — every row mapped to its ETPL realization and verification status, each closed only at equal-or-greater assurance than the legacy provider (proof for proof, verification for verification, measured performance for measured performance); until a row closes, the Compendium remains the specification of record for it. *ET guidance:* this is the Verification Principle as project plan: row by row, the math must add up.

**G-ETPL-2 — ETPL completion.**
*Source:* the founding transition. *Statement:* ETPL's self-hosting toolchain — the native binary compiled entirely by the ETPL toolchain from `.pdt` source, with zero external runtime dependencies — is in progress; the system's implementation language must itself reach completion. *Resolution requires:* self-hosting completion and the language's demonstration across the deployment targets the system requires (classical, and quantum-ready per the founded architecture). *ET guidance:* the language's own P ∘ D ∘ T derivation is its roadmap; completion is when the toolchain traverses its own source to a grounded binary — E, literally.

**G-ETPL-3 — External-boundary interoperation.**
*Source:* transformation of F1. *Statement:* with no internal language boundary remaining, the residual interop question is ETPL's boundary with the external world — platform interfaces, the browser/web platform delivery of the user-facing layer, hardware interfaces, and any external protocol endpoints. *Resolution requires:* the boundary specification: which external interfaces exist, each specified as an exact licensed traversal (mirroring the API discipline of I1), with the sandboxing and isolation properties of the founded security law preserved at every crossing.

---

## 16. Groups G-ON / G-ID / G-KP / G-UN / G-ST / G-SB / G-LG / G-NT / G-ED — Content-Model and Service Determinations (Second Audit)

These entries arise from the design-completeness audit: a systematic walk of the founded system under the Three Tools, interrogating every mechanism for unstated Descriptors. Each names a structure the specification uses but does not yet define.

**G-ON-1 — The content-unit ontology.** *Statement:* the specification speaks of items, entries, pages, directories, sub-modules, and modules, and binds different machinery to different unit-words — evidence profiles to items, comments and duplicates to pages, generation to modules — without formal definitions relating them: whether an item *is* a page, may span pages, or is contained by one; what a directory is relative to a module; where an "entry" sits. Every module's interface presupposes this ontology. *Resolution requires:* the formal content-unit ontology: definitions of item, entry, page, directory, sub-module, and module; their containment and identity relations; and a pass assigning each subsystem's operations to its exact unit. *ET guidance:* P-first — each unit is a substrate configuration at a scale; define the scales and their composition once, and every "applies to items/pages" statement in the specification becomes exact.

**G-ID-1 — The stable identifier system.** *Statement:* bookmarks persist, duplicates link, placement history is preserved, citations must survive movement between categories — all of which require stable identifiers for content units, and none of which the founding record specifies: identifier format, scope, assignment authority, and behavior under movement, merging (duplicates; crystallization), and versioning. *Resolution requires:* the identifier specification for every unit of G-ON-1's ontology: format, uniqueness scope, the assigning module, immutability under movement, and resolution behavior for merged and superseded units. *ET guidance:* the identifier is the minimal Descriptor binding a name to a substrate point independent of all other Descriptors — define it as exactly that, and movement-as-information becomes recordable because the moving thing has a fixed name.

**G-KP-1 — The placement procedure.** *Statement:* structural semantics makes position meaningful and inheritance makes it consequential, yet the *act of placement* has no specified procedure: who assigns a new submission's category and tree position — the submitter proposing, an automated classifier, human review, or a combination; what the review path is for contested placement; and how the Items singularity requirement and the People Real/Fictional mandatory tier are enforced at placement time. *Resolution requires:* the placement procedure end to end: proposal, validation, the enforcement of category-specific placement laws, contest and correction pathways (feeding the movement history), and the automated/human division of labor consistent with the integrity-only review law. *ET guidance:* placement is the binding of σ₁ — a Descriptor act; every Descriptor act in the system has an actor, a validation, and a record; give σ₁-binding the same three and the procedure is specified.

**G-KP-2 — Deliberate cross-category presence versus duplicate management.** *Statement:* the categories are a cover, not a partition — an item may bear multiple category Descriptors by design — and separately, the Hub's duplicate-management system handles the *independent* arising of the same item in multiple categories. The boundary between the two is unspecified: whether deliberate multi-category placement exists as a first-class operation (one item, several positions) or all multi-presence flows through duplicate detection and combined pages; and if both exist, which applies when. *Resolution requires:* the multi-presence model: the first-class mechanism if any, its relation to the six-step duplicate process, and the σ₁ semantics of an item with several positions (multiple positional Descriptors on one identifier, per G-ID-1). *ET guidance:* one substrate entry, several positional Descriptors is the natural formal reading — a P with a set of σ₁ bindings; duplicate management then handles the discovery case where several substrate entries turn out to be one; distinguish "one P, many σ₁" from "many P discovered identical" and the boundary writes itself.

**G-UN-1 — Graduation out of Unknown.** *Statement:* movement out of Unknown into a proper category is the system's signature knowledge event — the movement itself is knowledge — yet the graduation procedure is unspecified: who adjudicates that an unknown is now sufficiently described to place, against what standard, through what review; and what happens to the Unknown entry itself (the founding presumption: it is preserved with the movement record, never deleted). *Resolution requires:* the graduation procedure: the sufficiency standard (naturally, the Descriptor Gap closing — the missing D found and evidenced), the adjudicating actor, the movement record's form, and the preserved-trace law stated explicitly. *ET guidance:* graduation is the Gap Principle completing its cycle — gap named, Descriptor found, binding executed; the procedure should require the found Descriptor to carry its own evidence profile, so the system's proudest event meets its own discipline.

**G-ST-1 — The page-structure template taxonomy.** *Statement:* σ₂ — internal page structure — is semantic and inherited, and Void's three template types govern *module* generation, but the taxonomy of *page* templates per category (how a Science page is shaped versus a People page versus an Items entry) is unspecified: what templates exist, who defines them, how they evolve, and how σ₂ inheritance selects among them. *Resolution requires:* the page-template taxonomy: the per-category template set, the definition authority, the evolution procedure (template changes are knowledge events too), and the inheritance rule binding σ₂ at creation. *ET guidance:* a template is a reusable D-pattern over page substrate; the categories' distinct natures (Section 5) should *derive* their template differences — the shape of a People page follows from what a person-record is — so build the taxonomy forward from the category definitions rather than by convention.

**G-SB-1 — Submission rights by access tier.** *Statement:* the founding record establishes that anonymous submissions exist and are tracked separately, and that the submitter account is recorded when one is provided — but the rights structure around submission is unstated: whether every tier including the no-login free tier may submit, what the automated submitter-identity tag records for an anonymous submission (an honest indeterminacy marker, not a fabricated identity), how anonymous contributions interact with the reputation system (no account, no score — stated nowhere), and what submission-rate discipline applies per tier. *Resolution requires:* the submission-rights specification per tier, the anonymous provenance-tag form, the anonymous↔reputation ruling, and rate discipline consistent with the all-content-equal law. *ET guidance:* every E in the system has a T; the submitter tag is the record of which T — where the T is unidentified, the tag must honestly record the indeterminacy, and the reputation system must state explicitly that an unbound T accrues nothing.

**G-SB-2 — Malicious-content disposition under the no-deletion law.** *Statement:* the pipeline quarantines threats in isolated VMs and the system deletes nothing — two laws that meet head-on at malware: whether detected malicious content is preserved forever in labeled quarantine (it is, after all, data — and knowledge about attacks), destroyed as the sole exception to Law 9.1, or sealed in a form that preserves the knowledge (hashes, behavior records, defanged samples) without preserving the live weapon. The founding texts state both laws and never adjudicate their intersection. *Resolution requires:* the disposition ruling for each threat class, stated as an explicit relation to Law 9.1 — if an exception exists, it must be written as one; if preservation wins, the containment law for eternal quarantine must be specified. *ET guidance:* the founding axiom is the template once more — for every exception, an exception; Law 9.1 can carry an explicit, bounded exception clause or a sealed-preservation form, but the intersection cannot remain silent, because silence here is an unspecified door in the preservation doctrine itself.

**G-LG-1 — The content language storage model.** *Statement:* the Language module supports all languages including constructed and fictional ones, and dual English redundancy names System English and Standard English — but the *storage model* for multilingual content is unspecified: whether knowledge is stored in a canonical language and translated on demand, stored in every contributed language, or hybrid; which content lives in System English versus Standard English; and how the evidence profile and change history behave across translations of one item (one identifier, per G-ID-1, presumably — with translations as Descriptor variants). *Resolution requires:* the storage model, the canonical-language ruling if any, the System/Standard English content assignment, and the identity-across-translation law. *ET guidance:* a translation is a re-description of the same substrate — same P, different D-grammar; the model that follows is one identifier with language-indexed Descriptor sets, and the dual-English redundancy becomes two always-present D-sets rather than two copies of the substrate.

**G-NT-1 — The notification event taxonomy.** *Statement:* the Notifications module delivers real-time notifications with queue durability, but the *events* that generate notifications are never enumerated: watched-page changes, evidence modifications on one's contributions, reputation changes, badge changes, duplicate-combination events, education milestones, emergency broadcasts — the plausible set is large and the founded set is empty. *Resolution requires:* the event taxonomy: each notification-generating event, its default on/off state, its tier availability, and the user-control surface — bounded by the privacy law (notifications must not leak information across the privacy structures). *ET guidance:* a notification is a Descriptor-change surfaced to a subscribed T; enumerate the D-changes the system considers surfaceable, and the taxonomy is that enumeration with subscription rules.

**G-ED-1 — The instructional-content generation model.** *Statement:* the Education module teaches any page — page-by-page delivery, highlighting, explanation, clarification, adaptive paths — but the *source* of the instruction is unspecified: whether teaching content is generated automatically from the knowledge pages' own structure (σ₂ made pedagogical), authored by contributors, curated by the module, or produced with Memory's synthesis capabilities (which would cross the Special Barrier's communication rules and must be stated if so). *Resolution requires:* the instructional-content model: generation source, authorship and review, its evidence-profile treatment (teaching content is content), the adaptive-path algorithm's inputs, and the certification standard behind the certification system. *ET guidance:* teaching is guided traversal — a curated D-sequence over existing knowledge; the natural model derives the sequence from the archive's own structure (prerequisites are inheritance and dependency Descriptors already present), which keeps the product a traversal of the free knowledge rather than a second, parallel corpus.

---

## 17. Group G-INV — Structural Investigations

**G-INV-1 — The twelve-node observation.**
*Source:* identified during formalization; explicitly an investigation, not a claim. *Statement:* the founded user-facing knowledge tree comprises twelve top-level nodes — the Hub plus the eleven categories of Other. Whether this instantiates the theory's manifold symmetry N = 12 is **not asserted**: no derivation currently connects the category count to the manifold structure, and the founding standard forbids asserting structural identification without derivation. *Resolution requires:* either a forward derivation from the theory's mathematics showing the twelve-fold user-facing structure is structurally necessary (in which case the identification is recorded as a theorem), or the recorded finding that the counts are structurally unrelated (in which case the observation is closed as answered). No intermediate "suggestive" status is permitted to stand. *ET guidance:* derivation forward from {P, D, T} or nothing — the theory's own standard, applied to itself.

---

## 18. Register Summary Table

| Group | IDs | Count | Critical |
|---|---|---|---|
| Resolved at founding | RES-1 … RES-4 | 4 (closed) | — |
| Reputation | R1 | 1 | — |
| Evidence and scale | A1/G-EV-1, A1a/G-EV-3, G-EV-2, G-EV-4, G-EV-5, A2, A3, A4 | 8 | A2 |
| Security architecture | B1, G-SEC-1, G-SEC-2, G-SEC-3 | 4 | — |
| Governance and community | C1, C2, C3, C4 | 4 | C1 |
| Economics and law | D1, D2, D3 | 3 | — |
| Artificial Traversers | E1, E2, E3 | 3 | E1 |
| Implementation carry-overs | F1 (transformed), F2, F3, F4 (transformed) | 4 | — |
| Philosophical consistency | G1, G2, G3 | 3 | — |
| User experience | H1, H2, H3 | 3 | — |
| Missing specifications | I1, I2, I3 | 3 | — |
| Badge determinations | G-BD-1 … G-BD-11 | 11 | — |
| Module-level determinations | G-CM-1, G-CM-2, G-HB-1, G-HB-2, G-HB-3, G-SR-1, G-AC-1, G-PR-1, G-PR-2, G-PR-3, G-PR-4 | 11 | — |
| Architecture determinations | G-MD-1, G-MD-2, G-AR-1, G-AR-2, G-SS-1, G-SS-2, G-SS-3 | 7 | — |
| Implementation transition | G-ETPL-1, G-ETPL-2, G-ETPL-3 | 3 | — |
| Content-model and service determinations (second audit) | G-ON-1, G-ID-1, G-KP-1, G-KP-2, G-UN-1, G-ST-1, G-SB-1, G-SB-2, G-LG-1, G-NT-1, G-ED-1 | 11 | — |
| Structural investigations | G-INV-1 | 1 | — |
| **Total open** | | **80** | **3 marked critical in source (A2, C1, E1)** |

*Note:* the founding record marked A2, C1, and E1 CRITICAL explicitly; Evidence-module criticality in the source attaches to the module itself (founded and specified), not to an open item, and is therefore not counted here. F1 and F4 are retained as transformed records within the open count until their successor items (G-ETPL-1/-3) close, at which point they close with them.

---

## 19. Closing Statement

Eighty named absences. Under the Descriptor Gap Principle, that is eighty Descriptors already located — each one a search target, none of them a mystery. The register will shrink by derivation, entry by entry, and every closure will be recorded as the movement it is: knowledge about how the Knowledge System came to know itself. When the last entry closes, the three founding documents become one book.

> *"For every exception there is an exception, except the exception."*
> *P ∘ D ∘ T = E*

---

**Document:** Eternal Memory — Open Items Register, v1.0
**Discipline:** every resolution ET-derived; no ad hoc closure; the Verification Principle is the stopping test
