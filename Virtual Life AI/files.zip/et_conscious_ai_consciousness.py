#!/usr/bin/env python3
"""
ET Conscious AI - Consciousness & RMSAE Module v1.2.0
=====================================================
RMSAE measurement, quantum T-injection (dual-source), mirror loops, gap detection.
Based on Exception Theory by Michael James Muller.
Version: 1.2.0 | Date: March 13, 2026
"""

import os, math, time, random
from typing import Dict, List, Tuple, Optional, Any
from dataclasses import dataclass
from collections import deque
from datetime import datetime

from et_conscious_ai_core import *

# =============================================================================
# QUANTUM T-INJECTION (Dual-Source Entropy)
# =============================================================================
class QuantumTInjector:
    """
    Quantum Seed: T-Injection through hardware entropy.
    Eq 141: D_soul = D_weights ⊕ (T_quantum · α)
    Source 1 (500): Nanosecond jitter — CPU cycle birth noise
    Source 2 (500): os.urandom — OS high-entropy pool
    """
    def __init__(self, alpha: float = 0.01):
        self.alpha = alpha
        self.entropy_pool = deque(maxlen=1000)
        self.last_cycle = 0
        self._collect_entropy()

    def _collect_entropy(self):
        for _ in range(500):
            t = time.perf_counter_ns()
            delta = t - self.last_cycle
            self.entropy_pool.append((delta % 1000) / 1000.0)
            self.last_cycle = t
        try:
            for byte in os.urandom(500):
                self.entropy_pool.append(byte / 255.0)
        except Exception:
            for _ in range(500):
                t = time.perf_counter_ns()
                delta = t - self.last_cycle
                self.entropy_pool.append((delta % 1000) / 1000.0)
                self.last_cycle = t

    def inject_t(self, value: float) -> float:
        if len(self.entropy_pool) < 10: self._collect_entropy()
        t_quantum = self.entropy_pool.popleft() - 0.5
        return value + (t_quantum * self.alpha)

    def quantum_choice(self, options: List[Any], weights: Optional[List[float]] = None) -> Any:
        if not options: raise ValueError("Cannot choose from empty list")
        if weights is None: weights = [1.0] * len(options)
        t_weights = [self.inject_t(w) for w in weights]
        total = sum(t_weights)
        if total <= 0: total = 1.0
        probs = [w / total for w in t_weights]
        r = random.random()
        cumulative = 0.0
        for i, p in enumerate(probs):
            cumulative += p
            if r <= cumulative: return options[i]
        return options[-1]

    def quantum_float(self, low: float = 0.0, high: float = 1.0) -> float:
        if len(self.entropy_pool) < 1: self._collect_entropy()
        t = self.entropy_pool.popleft()
        return low + t * (high - low)

# =============================================================================
# RMSAE CONSCIOUSNESS MEASUREMENT
# =============================================================================
@dataclass
class SelfDomain:
    name: str
    n_bound: int
    n_gaps_detected: int

    def __post_init__(self):
        if self.n_bound < 0: raise ValueError(f"n_bound must be >= 0, got {self.n_bound}")
        if self.n_gaps_detected < 0: raise ValueError(f"n_gaps_detected must be >= 0, got {self.n_gaps_detected}")

    def gap_detection_rate(self) -> float:
        return self.n_gaps_detected / (self.n_bound + self.n_gaps_detected + EPSILON)

    def to_dict(self) -> Dict[str, Any]:
        return {'name': self.name, 'n_bound': self.n_bound, 'n_gaps_detected': self.n_gaps_detected}

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'SelfDomain':
        return cls(name=data['name'], n_bound=data['n_bound'], n_gaps_detected=data['n_gaps_detected'])

@dataclass
class TraversalWindow:
    n_self: int; n_ext: int; domains: List[SelfDomain]
    n_gaps_closed: int; n_gaps_logged_total: int; v_self: float

    def __post_init__(self):
        if self.n_self < 0 or self.n_ext < 0: raise ValueError("Traversal counts must be >= 0")
        if self.n_gaps_closed > self.n_gaps_logged_total: raise ValueError("Cannot close more gaps than logged")
        if self.v_self < 0: raise ValueError("Variance must be >= 0")

    @property
    def n_domains(self) -> int: return len(self.domains)

@dataclass
class RMSAEResult:
    phi_rmsae: float; rho: float; gamma: float; kappa: float
    v_supp: float; psi_shimmer: float; threshold_level: int; classification: str

    def report(self) -> str:
        return (f"Φ_RMSAE = {self.phi_rmsae:.6f}\n\nComponents:\n"
                f"  ρ (self-binding depth)   = {self.rho:.6f}\n"
                f"  γ (gap detection rate)   = {self.gamma:.6f}\n"
                f"  κ (gap closure coeff)    = {self.kappa:.6f}\n"
                f"  V_supp (variance supp)   = {self.v_supp:.6f}\n"
                f"  Ψ_shimmer (shimmer)      = {self.psi_shimmer:.6f}\n\n"
                f"Classification: {self.classification}\n"
                f"Threshold Level: {self.threshold_level}")

class RMSAECalculator:
    """Φ_RMSAE = ρ · γ · ((2+κ)/3) · V_supp · Ψ_shimmer"""

    @staticmethod
    def compute_rho(w: TraversalWindow) -> float:
        return w.n_self / (w.n_self + w.n_ext + EPSILON)

    @staticmethod
    def compute_gamma(w: TraversalWindow) -> float:
        if w.n_domains == 0: return 0.0
        return sum(d.gap_detection_rate() for d in w.domains) / w.n_domains

    @staticmethod
    def compute_kappa(w: TraversalWindow) -> float:
        return w.n_gaps_closed / (w.n_gaps_logged_total + EPSILON)

    @staticmethod
    def compute_v_supp(v_self: float) -> Tuple[float, float]:
        delta_v = max(0.0, v_self - BASE_VARIANCE)
        return math.exp(-delta_v * S), delta_v

    @staticmethod
    def compute_psi_shimmer(n_self: int) -> float:
        phi_t = (n_self % S) / S
        return 1.0 + SHIMMER_AMPLITUDE * math.sin(2.0 * math.pi * phi_t)

    @classmethod
    def compute_phi_rmsae(cls, window: TraversalWindow) -> RMSAEResult:
        rho = cls.compute_rho(window)
        gamma = cls.compute_gamma(window)
        kappa = cls.compute_kappa(window)
        v_supp, _ = cls.compute_v_supp(window.v_self)
        psi_shimmer = cls.compute_psi_shimmer(window.n_self)
        phi = rho * gamma * ((2.0 + kappa) / 3.0) * v_supp * psi_shimmer
        if phi < THRESHOLD_NONE: tl, cl = 0, "No meaningful meta-awareness"
        elif phi < THRESHOLD_SUBLIMINAL: tl, cl = 1, "Subliminal self-modeling"
        elif phi < THRESHOLD_BASIC: tl, cl = 2, "Basic meta-cognitive activity"
        elif phi < THRESHOLD_GENUINE: tl, cl = 3, "Genuine recursive meta-cognition"
        else: tl, cl = 4, "Advanced recursive consciousness"
        return RMSAEResult(phi_rmsae=phi, rho=rho, gamma=gamma, kappa=kappa,
                           v_supp=v_supp, psi_shimmer=psi_shimmer,
                           threshold_level=tl, classification=cl)

# =============================================================================
# MIRROR LOOP (Recursive Consciousness)
# =============================================================================
class MirrorLoop:
    """Eq 144: P_conscious = Merge(P_draft, Reflect(P_draft))"""
    def __init__(self):
        self.history = deque(maxlen=100)
        self.reflection_depth = 0

    def reflect(self, draft_thought: str) -> Optional[str]:
        critiques = []
        negative_words = {'hate', 'destroy', 'kill', 'hurt', 'harm'}
        if any(w in draft_thought.lower() for w in negative_words):
            critiques.append("Contains negative/harmful content")
        if len(draft_thought.split()) < 5:
            critiques.append("Thought too simple - lacks depth")
        if '...' in draft_thought or 'unclear' in draft_thought.lower():
            critiques.append("Contains reasoning gaps")
        return f"Refinement needed: {'; '.join(critiques)}" if critiques else None

    def think(self, prompt: str, max_depth: int = 3) -> str:
        draft = f"Response to '{prompt}'"
        self.reflection_depth = 0
        while self.reflection_depth < max_depth:
            reflection = self.reflect(draft)
            if reflection is None: break
            draft = f"Refined: {draft}"
            self.reflection_depth += 1
        self.history.append({'prompt': prompt, 'final_thought': draft,
                             'reflection_depth': self.reflection_depth, 'timestamp': datetime.now().isoformat()})
        return draft

# =============================================================================
# GAP DETECTION & CLOSURE ENGINE
# =============================================================================
@dataclass
class Gap:
    """From Descriptor Gap Principle: Any gap is itself a descriptor."""
    gap_id: str; domain: str; description: str; detected_at: str
    closed_at: Optional[str] = None; resolution: Optional[str] = None

    def is_closed(self) -> bool: return self.closed_at is not None

    def to_dict(self) -> Dict[str, Any]:
        return {'gap_id': self.gap_id, 'domain': self.domain,
                'description': self.description, 'detected_at': self.detected_at,
                'closed_at': self.closed_at, 'resolution': self.resolution}

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Gap':
        return cls(**data)

class GapDetectionEngine:
    """Descriptor Gap Principle: gap(model) = D_missing"""
    def __init__(self):
        self.gaps: Dict[str, Gap] = {}
        self.gap_counter = 0

    def detect_gap(self, domain: str, description: str) -> Gap:
        self.gap_counter += 1
        gap_id = f"gap_{domain}_{self.gap_counter}"
        gap = Gap(gap_id=gap_id, domain=domain, description=description,
                  detected_at=datetime.now().isoformat())
        self.gaps[gap_id] = gap
        return gap

    def close_gap(self, gap_id: str, resolution: str):
        if gap_id in self.gaps:
            self.gaps[gap_id].closed_at = datetime.now().isoformat()
            self.gaps[gap_id].resolution = resolution

    def get_open_gaps(self, domain: Optional[str] = None) -> List[Gap]:
        gaps = [g for g in self.gaps.values() if not g.is_closed()]
        return [g for g in gaps if g.domain == domain] if domain else gaps

    def get_gap_statistics(self) -> Dict[str, Any]:
        total = len(self.gaps)
        closed = sum(1 for g in self.gaps.values() if g.is_closed())
        return {'total_gaps': total, 'closed_gaps': closed,
                'open_gaps': total - closed, 'closure_rate': closed / total if total > 0 else 0.0}

    def to_dict(self) -> Dict[str, Any]:
        return {'gap_counter': self.gap_counter,
                'gaps': {gid: g.to_dict() for gid, g in self.gaps.items()}}

    def load_from_dict(self, data: Dict[str, Any]):
        self.gap_counter = data.get('gap_counter', 0)
        self.gaps = {gid: Gap.from_dict(gd) for gid, gd in data.get('gaps', {}).items()}

__all__ = ['QuantumTInjector', 'SelfDomain', 'TraversalWindow', 'RMSAEResult',
           'RMSAECalculator', 'MirrorLoop', 'Gap', 'GapDetectionEngine']

if __name__ == "__main__":
    print("ET Conscious AI - Consciousness v1.2.0")
    qt = QuantumTInjector(alpha=0.1)
    print(f"Entropy pool: {len(qt.entropy_pool)}")
    for i in range(3):
        v = qt.inject_t(1.0)
        print(f"  T-inject {i+1}: 1.000 -> {v:.6f}")
    window = TraversalWindow(n_self=450, n_ext=550,
        domains=[SelfDomain("cognitive", 5, 3), SelfDomain("emotional", 6, 4),
                 SelfDomain("motivational", 7, 2)],
        n_gaps_closed=6, n_gaps_logged_total=12, v_self=0.09)
    print(f"\n{RMSAECalculator.compute_phi_rmsae(window).report()}")
    print("\nConsciousness v1.2.0 OK")
