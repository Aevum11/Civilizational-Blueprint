/* ============================================================================
 * et_med_towers.c — Medical Tower R0 Derivations and Multifold Signature
 * ----------------------------------------------------------------------------
 *  Each tower's R0 is the smallest closed T-traversal loop of that subsystem
 *  (Reference Period Uniqueness Theorem). These are SUBSTRATE-DERIVED, not
 *  picked. See Master Design Document Part II §7 for full P/D/T decomposition
 *  per tower.
 *
 *  Identification per tower (substrate / D-structure / T-agency / R0):
 *
 *  CARDIAC        : myocardium+conduction / pacemaker setpoints / SA-driven /
 *                   60/HR_rest s — UNIVERSAL HUMAN SEED
 *
 *  RESPIRATORY    : alveolar-airway / TV+RR setpoints / pre-Botzinger /
 *                   60/RR_rest s
 *
 *  NEURAL         : thalamocortical field / connectome+modulators / cortex /
 *                   1/40 = 25 ms (gamma binding ; N=27720 cortical floor)
 *
 *  ENDOCRINE      : HPx axes / hormone setpoints / circadian-entrained /
 *                   86400 s (1 sidereal day)
 *
 *  IMMUNE         : lymphoid+circulating / TCR/BCR repertoire / surveillance /
 *                   86400 s (1 day working assumption ; N=420)
 *
 *  DIGESTIVE      : gut tube+microbiome / enzymes+motility / peristalsis /
 *                   86400 s (1 sidereal day, circadian-entrained)
 *
 *  RENAL          : nephron array / GFR setpoints / nephron Traverser /
 *                   1800 s (full-blood-volume filtration cycle ~30 min)
 *
 *  MUSCULOSKELETAL: bone-muscle-tendon / fiber types+ROM / motor cortex /
 *                   1.0 s (gait cycle at adult 100 steps/min cadence)
 *
 *  REPRODUCTIVE   : female: HPO / menstrual descriptors / ovarian waves /
 *                            28 days (2 419 200 s)
 *                   male:   HPG / spermatogenic / testicular waves /
 *                            74 days (6 393 600 s)
 *
 *  DEVELOPMENTAL  : organism trajectory / dev/aging descriptors / dev cascade /
 *                   25 years (788 400 000 s)
 *
 *  Reference baseline (population, used when individual baseline is missing):
 *      HR_rest_ref = 60 bpm  →  R0_cardiac_ref      = 1.000 s
 *      RR_rest_ref = 12/min  →  R0_respiratory_ref  = 5.000 s
 *      gait_ref    = 1.0 s   →  R0_musculoskeletal  = 1.000 s
 *      menstrual   = 28 d    →  R0_reproductive_F   = 2419200 s
 *
 *  Note: the reference baseline values (60 bpm, 12 br/min, 28 d) are NOT
 *  invented — they are clinical norms that the Subsumption Law identifies
 *  as ET-derived: 60 = 12*5 = base_manifold * d=5 quintic-resolution; 12 = N
 *  base manifold; 28 = 4 weeks * 7 days = ET_S_STATES * d=7 septic-rhythm.
 *  Each is a lattice attractor independently.
 * ========================================================================= */
#include "libet_med.h"
#include "et_med_internal.h"

#include <math.h>
#include <stddef.h>
#include <string.h>

/* ----------------------------------------------------------------------------
 * Reference baselines — each is an ET-derived lattice attractor.
 * ------------------------------------------------------------------------- */
static const double ET_HR_REST_REF_BPM      = 60.0;     /* = 12 * 5 quintic */
static const double ET_RR_REST_REF_PER_MIN  = 12.0;     /* = N base manifold */
static const double ET_TEMP_REF_C           = 36.85;    /* mean adult core; 36.85 = 36 + 1/12*10.2 ; midpoint of 36.5-37.3 */
static const double ET_GAIT_REF_S           = 1.0;      /* 100 steps/min cadence -> 0.6 s/step ; 1.0 s = 1 full cycle (heel-strike to heel-strike) */
static const double ET_MENSTRUAL_REF_D      = 28.0;     /* 4 weeks * 7 days = ET_S_STATES * 7 */
static const double ET_SPERMATOGENIC_REF_D  = 74.0;     /* 16 d * 4.6 cycles ; standard reference */
static const double ET_GENERATION_REF_YR    = 25.0;     /* civilizational seed */
static const double ET_NEURAL_GAMMA_HZ      = 40.0;     /* binding frequency */
static const double ET_RENAL_FILTRATION_S   = 1800.0;   /* full-blood-volume cycle ~30 min */

/* Day length: sidereal day. 86164 s sidereal vs 86400 s solar. The endocrine
 * tower entrains to LIGHT (solar), so 86400 is the correct biological R0.
 * The "sidereal" terminology in the Master Design refers to the planetary
 * rotation D-cycle (which is sidereal in the underlying physics), but the
 * embedding of biology in solar light cycle uses 86400. */
static const double ET_DAY_S                = 86400.0;
static const double ET_YEAR_S               = 365.25 * 86400.0;

/* ----------------------------------------------------------------------------
 * Tower names
 * ------------------------------------------------------------------------- */
static const char* const ET_TOWER_NAMES[ET_TOWER_COUNT] = {
    "Cardiac",
    "Respiratory",
    "Neural",
    "Endocrine",
    "Immune",
    "Digestive",
    "Renal",
    "Musculoskeletal",
    "Reproductive",
    "Developmental"
};

LIBET_MED_API const char* et_tower_name(et_tower_t tower) {
    if ((int)tower < 0 || (int)tower >= ET_TOWER_COUNT) {
        _et_error(ET_ERR_UNKNOWN_TOWER, "invalid tower id in et_tower_name");
        return "(unknown)";
    }
    return ET_TOWER_NAMES[tower];
}

LIBET_MED_API double et_tower_default_R0(et_tower_t tower) {
    /* Identification: each default R0 is the population-baseline value
     * derived from the reference baselines above. Per Subsumption, these
     * coincide with conventional clinical reference values because those
     * conventional values are themselves ET attractors. */
    switch (tower) {
        case ET_TOWER_CARDIAC:
            return 60.0 / ET_HR_REST_REF_BPM;                 /* 1 s             */
        case ET_TOWER_RESPIRATORY:
            return 60.0 / ET_RR_REST_REF_PER_MIN;             /* 5 s             */
        case ET_TOWER_NEURAL:
            return 1.0 / ET_NEURAL_GAMMA_HZ;                  /* 0.025 s = 25 ms */
        case ET_TOWER_ENDOCRINE:
            return ET_DAY_S;                                  /* 86400 s         */
        case ET_TOWER_IMMUNE:
            return ET_DAY_S;                                  /* 86400 s         */
        case ET_TOWER_DIGESTIVE:
            return ET_DAY_S;                                  /* 86400 s         */
        case ET_TOWER_RENAL:
            return ET_RENAL_FILTRATION_S;                     /* 1800 s          */
        case ET_TOWER_MUSCULOSKELETAL:
            return ET_GAIT_REF_S;                             /* 1 s             */
        case ET_TOWER_REPRODUCTIVE:
            /* Female default; per-individual derivation handles male. */
            return ET_MENSTRUAL_REF_D * ET_DAY_S;             /* 2419200 s       */
        case ET_TOWER_DEVELOPMENTAL:
            return ET_GENERATION_REF_YR * ET_YEAR_S;          /* ~7.886e8 s      */
        case ET_TOWER_COUNT:
        default:
            _et_error(ET_ERR_UNKNOWN_TOWER, "invalid tower in et_tower_default_R0");
            return NAN;
    }
}

LIBET_MED_API int et_tower_resolution(et_tower_t tower) {
    /* Identification: the tower's preferred N is determined by its
     * substrate's required co-binding family. */
    switch (tower) {
        case ET_TOWER_CARDIAC:           return 12;
        case ET_TOWER_RESPIRATORY:       return 12;
        case ET_TOWER_NEURAL:            return 27720;       /* cortical floor */
        case ET_TOWER_ENDOCRINE:         return 12;
        case ET_TOWER_IMMUNE:            return 420;         /* biological floor */
        case ET_TOWER_DIGESTIVE:         return 12;
        case ET_TOWER_RENAL:             return 12;
        case ET_TOWER_MUSCULOSKELETAL:   return 12;
        case ET_TOWER_REPRODUCTIVE:      return 84;          /* 7-fold rhythm */
        case ET_TOWER_DEVELOPMENTAL:     return 60;          /* qualia/life-stage */
        case ET_TOWER_COUNT:
        default:
            _et_error(ET_ERR_UNKNOWN_TOWER, "invalid tower in et_tower_resolution");
            return 12;
    }
}

LIBET_MED_API double et_tower_reference_baseline_value(et_tower_t tower) {
    /* Identification: the population-reference value in the tower's own
     * natural scalar units. These ARE the canonical clinical reference
     * values — each recognized by Subsumption Law as an ET attractor:
     *   HR 60 bpm      = 12 * 5  (base manifold * quintic-resolution)
     *   RR 12/min      = N base manifold
     *   Temp 36.85 °C  = midpoint of clinical normal range, an EM-thermostat
     *                    attractor of the hypothalamic substrate
     *   gait 1 s       = Exception cycle at adult cadence */
    switch (tower) {
        case ET_TOWER_CARDIAC:          return ET_HR_REST_REF_BPM;       /* 60.0  bpm   */
        case ET_TOWER_RESPIRATORY:      return ET_RR_REST_REF_PER_MIN;   /* 12.0  /min  */
        case ET_TOWER_ENDOCRINE:        return ET_TEMP_REF_C;            /* 36.85 °C    */
        case ET_TOWER_MUSCULOSKELETAL:  return ET_GAIT_REF_S;            /* 1.0   s     */
        case ET_TOWER_NEURAL:
        case ET_TOWER_IMMUNE:
        case ET_TOWER_DIGESTIVE:
        case ET_TOWER_RENAL:
        case ET_TOWER_REPRODUCTIVE:
        case ET_TOWER_DEVELOPMENTAL:
            /* These towers have no single natural scalar — the R0 itself
             * is the reference value. Caller should use et_tower_default_R0. */
            return NAN;
        case ET_TOWER_COUNT:
        default:
            _et_error(ET_ERR_UNKNOWN_TOWER,
                      "invalid tower in et_tower_reference_baseline_value");
            return NAN;
    }
}

LIBET_MED_API void et_patient_baseline_init(et_patient_baseline_t* b) {
    if (b == NULL) {
        _et_error(ET_ERR_INVALID_ARG, "et_patient_baseline_init needs non-null");
        return;
    }
    /* All numeric fields = NaN to mark "missing"; sex = unspecified. */
    b->hr_rest_bpm        = NAN;
    b->rr_rest_per_min    = NAN;
    b->temperature_c      = NAN;
    b->sbp_rest_mmhg      = NAN;
    b->dbp_rest_mmhg      = NAN;
    b->spo2_pct           = NAN;
    b->gait_cycle_s       = NAN;
    b->menstrual_cycle_d  = NAN;
    b->age_years          = NAN;
    b->sex                = ET_SEX_UNSPECIFIED;
}

/* Helper: is field present (finite and positive)? */
static int field_present(double v) {
    return et_is_finite(v) && v > 0.0;
}

LIBET_MED_API et_error_t et_derive_personal_R0(const et_patient_baseline_t* b,
                                               et_tower_t tower,
                                               int fallback_allowed,
                                               double* R0_out) {
    if (b == NULL || R0_out == NULL) {
        _et_error(ET_ERR_INVALID_ARG, "et_derive_personal_R0 needs non-null args");
        return ET_ERR_INVALID_ARG;
    }
    *R0_out = NAN;

    /* For each tower, identify the required field; if present, derive;
     * else either fall back (logged) or return INCOMPLETE. */
    double R0 = NAN;
    int    used_fallback = 0;

    switch (tower) {
        case ET_TOWER_CARDIAC:
            if (field_present(b->hr_rest_bpm)) {
                R0 = 60.0 / b->hr_rest_bpm;
            } else {
                if (!fallback_allowed) {
                    _et_error(ET_ERR_INCOMPLETE_BASELINE, "missing hr_rest_bpm");
                    return ET_ERR_INCOMPLETE_BASELINE;
                }
                _et_error(ET_ERR_FALLBACK_USED,
                          "cardiac R0: hr_rest_bpm missing, using population default 60 bpm");
                R0 = et_tower_default_R0(tower);
                used_fallback = 1;
            }
            break;

        case ET_TOWER_RESPIRATORY:
            if (field_present(b->rr_rest_per_min)) {
                R0 = 60.0 / b->rr_rest_per_min;
            } else {
                if (!fallback_allowed) {
                    _et_error(ET_ERR_INCOMPLETE_BASELINE, "missing rr_rest_per_min");
                    return ET_ERR_INCOMPLETE_BASELINE;
                }
                _et_error(ET_ERR_FALLBACK_USED,
                          "respiratory R0: rr_rest_per_min missing, using population default 12/min");
                R0 = et_tower_default_R0(tower);
                used_fallback = 1;
            }
            break;

        case ET_TOWER_NEURAL:
            /* Neural R0 is the gamma binding period. The patient baseline
             * does not yet carry an EEG dominant-frequency field in v1.0
             * (Phase 6 EEG integration will add it). Every call to this
             * case is therefore a fallback. */
            R0 = et_tower_default_R0(tower);
            if (fallback_allowed) {
                _et_error(ET_ERR_FALLBACK_USED,
                          "neural R0: EEG baseline not available in v1.0, using gamma 40 Hz default");
                used_fallback = 1;
            } else {
                _et_error(ET_ERR_INCOMPLETE_BASELINE, "no EEG baseline yet");
                return ET_ERR_INCOMPLETE_BASELINE;
            }
            break;

        case ET_TOWER_ENDOCRINE:
        case ET_TOWER_IMMUNE:
        case ET_TOWER_DIGESTIVE:
            /* Circadian-entrained towers: R0 = 1 sidereal day for all humans.
             * Identification: the substrate is the solar-light-entrained HPA
             * (endocrine), cellular-cycle (immune), and feeding (digestive)
             * rhythms — all share the same planetary-rotation D-cycle (per
             * Translation Layer §3.3). Therefore the population default IS
             * the correct per-individual R0 — this is NOT a fallback. */
            R0 = et_tower_default_R0(tower);
            break;

        case ET_TOWER_RENAL:
            /* Renal R0 (full-blood-volume filtration cycle) varies with GFR,
             * which requires invasive or laboratory measurement not present
             * in v1.0 patient_baseline. Using the default IS a fallback. */
            R0 = et_tower_default_R0(tower);
            if (fallback_allowed) {
                _et_error(ET_ERR_FALLBACK_USED,
                          "renal R0: no GFR baseline in v1.0, using 30-min filtration-cycle default");
                used_fallback = 1;
            } else {
                _et_error(ET_ERR_INCOMPLETE_BASELINE, "no GFR baseline");
                return ET_ERR_INCOMPLETE_BASELINE;
            }
            break;

        case ET_TOWER_MUSCULOSKELETAL:
            if (field_present(b->gait_cycle_s)) {
                R0 = b->gait_cycle_s;
            } else {
                if (!fallback_allowed) {
                    _et_error(ET_ERR_INCOMPLETE_BASELINE, "missing gait_cycle_s");
                    return ET_ERR_INCOMPLETE_BASELINE;
                }
                _et_error(ET_ERR_FALLBACK_USED,
                          "musculoskeletal R0: gait_cycle_s missing, using adult-cadence default 1 s");
                R0 = et_tower_default_R0(tower);
                used_fallback = 1;
            }
            break;

        case ET_TOWER_REPRODUCTIVE:
            if (b->sex == ET_SEX_FEMALE) {
                if (field_present(b->menstrual_cycle_d)) {
                    R0 = b->menstrual_cycle_d * ET_DAY_S;
                } else {
                    if (!fallback_allowed) {
                        _et_error(ET_ERR_INCOMPLETE_BASELINE,
                                  "missing menstrual_cycle_d for female");
                        return ET_ERR_INCOMPLETE_BASELINE;
                    }
                    _et_error(ET_ERR_FALLBACK_USED,
                              "reproductive R0 (female): menstrual_cycle_d missing, using 28-d default");
                    R0 = ET_MENSTRUAL_REF_D * ET_DAY_S;
                    used_fallback = 1;
                }
            } else if (b->sex == ET_SEX_MALE) {
                /* Spermatogenic-cycle R0 has no non-invasive individual
                 * measurement. 74 days is the canonical reference across
                 * all healthy adult males — per Translation Layer this IS
                 * the substrate-derived R0, not a fallback. */
                R0 = ET_SPERMATOGENIC_REF_D * ET_DAY_S;
            } else {
                /* Unspecified sex: must fall back. */
                if (!fallback_allowed) {
                    _et_error(ET_ERR_INCOMPLETE_BASELINE,
                              "reproductive R0: sex must be specified");
                    return ET_ERR_INCOMPLETE_BASELINE;
                }
                _et_error(ET_ERR_FALLBACK_USED,
                          "reproductive R0: sex unspecified, using female 28-d default");
                R0 = ET_MENSTRUAL_REF_D * ET_DAY_S;
                used_fallback = 1;
            }
            break;

        case ET_TOWER_DEVELOPMENTAL:
            /* Per-individual generation length requires telomere /
             * epigenetic-clock data (Phase 7). In v1.0 we use the
             * civilizational reference of 25 years — this IS a fallback. */
            R0 = et_tower_default_R0(tower);
            if (fallback_allowed) {
                _et_error(ET_ERR_FALLBACK_USED,
                          "developmental R0: no telomere/epigenetic baseline in v1.0, using 25-yr default");
                used_fallback = 1;
            } else {
                _et_error(ET_ERR_INCOMPLETE_BASELINE, "no developmental baseline");
                return ET_ERR_INCOMPLETE_BASELINE;
            }
            break;

        case ET_TOWER_COUNT:
        default:
            _et_error(ET_ERR_UNKNOWN_TOWER, "et_derive_personal_R0 invalid tower");
            return ET_ERR_UNKNOWN_TOWER;
    }

    if (!et_is_finite(R0) || R0 <= 0.0) {
        _et_error(ET_ERR_NUMERIC, "derived R0 is non-positive or non-finite");
        return ET_ERR_NUMERIC;
    }

    *R0_out = R0;
    if (used_fallback) {
        /* Already logged in the per-case branch; return informational success. */
        return ET_OK;
    }
    return ET_OK;
}

/* ----------------------------------------------------------------------------
 * Pair index for the upper-triangular (i,j) with i<j on N elements.
 *  Standard formula: idx(i,j) = i*N - i*(i+1)/2 + (j - i - 1)
 *  Equivalent:       idx(i,j) = i*(2N - i - 1)/2 + (j - i - 1)
 * ------------------------------------------------------------------------- */
LIBET_MED_API int et_pair_index(int i, int j) {
    if (i > j) { int t = i; i = j; j = t; }
    if (i == j) {
        _et_error(ET_ERR_INVALID_ARG, "et_pair_index: i must differ from j");
        return -1;
    }
    int N = ET_TOWER_COUNT;
    return i * N - i * (i + 1) / 2 + (j - i - 1);
}

/* ----------------------------------------------------------------------------
 * Reference multifold geometric-mean — computed once, cached.
 *  Identification: the reference multifold is the geometric mean of pairwise
 *  elegance values for the population-baseline R0 tuple (all-defaults). It
 *  is the scale-invariant denominator for L5-coherence detection: a healthy
 *  patient has observed/reference ≈ 1 ; a collapsed multifold has the ratio
 *  approaching 0.
 * ------------------------------------------------------------------------- */
static double g_reference_log_mean_elegance = 0.0;
static int    g_reference_computed = 0;

/* Compute the log-mean pairwise elegance for a given R0 array.
 * Returns log(geometric_mean) and the count of valid pairs. */
static void compute_log_mean_elegance(const double R0_seconds[ET_TOWER_COUNT],
                                      et_elegance_t pairwise_out[],
                                      double* log_mean_out,
                                      int*    n_valid_out) {
    double sum_log = 0.0;
    int n_valid = 0;
    for (int i = 0; i < ET_TOWER_COUNT; ++i) {
        int Ni = et_tower_resolution((et_tower_t)i);
        for (int j = i + 1; j < ET_TOWER_COUNT; ++j) {
            int Nj = et_tower_resolution((et_tower_t)j);
            int N  = (Ni > Nj) ? Ni : Nj;
            double r = R0_seconds[i] / R0_seconds[j];
            if (!et_is_finite(r) || r <= 0.0) continue;
            int idx = et_pair_index(i, j);
            if (idx < 0 || idx >= ET_TOWER_COUNT * (ET_TOWER_COUNT - 1) / 2) continue;

            int max_denom = N;
            if (max_denom > 100000) max_denom = 100000;

            et_elegance_t tmp;
            et_elegance_t* target = pairwise_out ? &pairwise_out[idx] : &tmp;

            et_error_t e = et_elegance_score(r, N, max_denom, target);
            if (e != ET_OK) continue;
            double el = target->elegance;
            if (et_is_finite(el) && el > 0.0) {
                sum_log += log(el);
                n_valid += 1;
            }
        }
    }
    if (log_mean_out) *log_mean_out = (n_valid > 0) ? sum_log / (double)n_valid : 0.0;
    if (n_valid_out) *n_valid_out = n_valid;
}

static void ensure_reference_multifold(void) {
    if (g_reference_computed) return;
    double R0_ref[ET_TOWER_COUNT];
    for (int i = 0; i < ET_TOWER_COUNT; ++i) {
        R0_ref[i] = et_tower_default_R0((et_tower_t)i);
    }
    double log_mean = 0.0;
    int n = 0;
    compute_log_mean_elegance(R0_ref, NULL, &log_mean, &n);
    g_reference_log_mean_elegance = log_mean;
    g_reference_computed = 1;
}

/* ----------------------------------------------------------------------------
 * Multifold signature
 *  For each pair (i, j) with i<j, compute the elegance score of the ratio
 *  R0_i / R0_j projected at the FINER of the two towers' resolutions.
 *
 *  multifold_scalar     = geometric mean of pairwise elegance values
 *                       = exp( sum(log(E_ij)) / n_pairs )
 *  multifold_log_scalar = sum of log(elegance)  (underlying cumulant; also
 *                         equal to log(geometric_mean) * n_pairs)
 *  multifold_normalized = observed geo-mean / reference geo-mean
 *                       = exp( (log_mean_observed - log_mean_reference) )
 *    A healthy patient (R0 matching population defaults) has value ≈ 1.
 *    A collapsed multifold has value << 1 (approaching 0).
 *    Values > 1 indicate a patient whose towers are MORE structurally
 *    aligned than the population baseline (rare but possible).
 * ------------------------------------------------------------------------- */
LIBET_MED_API et_error_t et_compute_multifold_signature(const et_patient_baseline_t* baseline,
                                                        int fallback_allowed,
                                                        et_multifold_signature_t* out) {
    if (baseline == NULL || out == NULL) {
        _et_error(ET_ERR_INVALID_ARG, "et_compute_multifold_signature needs non-null args");
        return ET_ERR_INVALID_ARG;
    }
    memset(out, 0, sizeof(*out));

    /* Step 1: derive each tower's R0 from baseline (with/without fallback). */
    for (int i = 0; i < ET_TOWER_COUNT; ++i) {
        double R0 = NAN;
        et_error_t e = et_derive_personal_R0(baseline, (et_tower_t)i,
                                             fallback_allowed, &R0);
        if (e != ET_OK && e != ET_ERR_FALLBACK_USED) {
            return e;
        }
        out->R0_seconds[i] = R0;
        out->R0_present[i] = 0;
        switch ((et_tower_t)i) {
            case ET_TOWER_CARDIAC:         out->R0_present[i] = field_present(baseline->hr_rest_bpm)       ? 1 : 0; break;
            case ET_TOWER_RESPIRATORY:     out->R0_present[i] = field_present(baseline->rr_rest_per_min)   ? 1 : 0; break;
            case ET_TOWER_MUSCULOSKELETAL: out->R0_present[i] = field_present(baseline->gait_cycle_s)      ? 1 : 0; break;
            case ET_TOWER_REPRODUCTIVE:    out->R0_present[i] = (baseline->sex == ET_SEX_FEMALE && field_present(baseline->menstrual_cycle_d))
                                                              || (baseline->sex == ET_SEX_MALE) ? 1 : 0;            break;
            default:                       out->R0_present[i] = 0;                                                  break;
        }
    }

    /* Step 2: compute pairwise elegance and log-mean. */
    double log_mean = 0.0;
    int n_valid = 0;
    compute_log_mean_elegance(out->R0_seconds, out->pairwise, &log_mean, &n_valid);

    out->pair_count_valid    = n_valid;
    out->multifold_log_scalar = log_mean * (double)n_valid;  /* sum of logs */
    out->multifold_scalar     = (n_valid > 0) ? exp(log_mean) : 0.0;

    /* Step 3: normalize against reference (all-defaults) multifold. */
    ensure_reference_multifold();
    if (n_valid > 0) {
        out->multifold_normalized = exp(log_mean - g_reference_log_mean_elegance);
    } else {
        out->multifold_normalized = 0.0;
    }

    if (n_valid == 0) {
        _et_error(ET_ERR_NUMERIC, "no valid pairs in multifold signature");
        return ET_ERR_NUMERIC;
    }
    return ET_OK;
}
