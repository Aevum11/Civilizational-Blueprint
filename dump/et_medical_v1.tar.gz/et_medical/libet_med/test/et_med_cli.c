/* ============================================================================
 * et_med_cli.c — Command-line demo for libet_med
 * ----------------------------------------------------------------------------
 *  Demonstrates the full pipeline Mike asked for:
 *     patient baseline -> multifold signature -> measurements -> findings -> report
 *
 *  Usage (no args -> built-in demo patient):
 *     et_med_cli
 *
 *  Usage (interactive JSON-ish):
 *     et_med_cli --hr-rest 60 --rr-rest 12 --temp 36.8 --sex male --age 45 \
 *                --measure HR 120 bpm CARDIAC \
 *                --measure RR 30 /min RESPIRATORY \
 *                --measure TEMP 38.5 C ENDOCRINE
 *
 *  Output:
 *     - Multifold signature (all 10 tower R0 values)
 *     - Findings table (sorted by urgency)
 *     - Fallback log summary
 *
 *  Identification: this CLI is the terminal UI for the C core — the same
 *  binary, linked against the same library, is what Android/Windows/Browser
 *  wrappers call under their platform-specific UI layers.
 * ========================================================================= */
#include "libet_med.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

/* Local ASCII case-insensitive compare — portable across C11 / Windows /
 * Android / Emscripten without depending on POSIX strcasecmp. */
static int ci_strcmp(const char* a, const char* b) {
    if (a == NULL || b == NULL) return (a == b) ? 0 : (a ? 1 : -1);
    while (*a && *b) {
        int ca = tolower((unsigned char)*a);
        int cb = tolower((unsigned char)*b);
        if (ca != cb) return ca - cb;
        ++a; ++b;
    }
    return tolower((unsigned char)*a) - tolower((unsigned char)*b);
}

static size_t g_cli_fallback_count = 0;
static int    g_verbose = 0;

static void cli_log_callback(et_error_t err, const char* file, int line,
                             const char* func, const char* message,
                             void* ud) {
    (void)ud;
    ++g_cli_fallback_count;
    if (g_verbose) {
        fprintf(stderr, "  [log:%s] %s (%s:%d in %s)\n",
                et_error_string(err), message, file, line, func);
    }
}

static void format_duration(double seconds, char* buf, size_t sz) {
    if (seconds < 1.0) {
        snprintf(buf, sz, "%.3f ms", seconds * 1000.0);
    } else if (seconds < 60.0) {
        snprintf(buf, sz, "%.3f s", seconds);
    } else if (seconds < 3600.0) {
        snprintf(buf, sz, "%.2f min", seconds / 60.0);
    } else if (seconds < 86400.0) {
        snprintf(buf, sz, "%.2f hr", seconds / 3600.0);
    } else if (seconds < 86400.0 * 365.25) {
        snprintf(buf, sz, "%.2f days", seconds / 86400.0);
    } else {
        snprintf(buf, sz, "%.2f years", seconds / (86400.0 * 365.25));
    }
}

static void print_header(const char* title) {
    printf("\n");
    printf("--------------------------------------------------------------------\n");
    printf("  %s\n", title);
    printf("--------------------------------------------------------------------\n");
}

static void print_multifold(const et_multifold_signature_t* mf) {
    print_header("Multifold Signature — the patient's 10 tower R0 values");
    printf("  %-18s %-22s %-8s  %s\n", "Tower", "R0", "N_res", "Source");
    printf("  %-18s %-22s %-8s  %s\n", "-----", "--", "-----", "------");
    for (int i = 0; i < ET_TOWER_COUNT; ++i) {
        char rbuf[32];
        format_duration(mf->R0_seconds[i], rbuf, sizeof(rbuf));
        printf("  %-18s %-22s N=%-6d  %s\n",
               et_tower_name((et_tower_t)i),
               rbuf,
               et_tower_resolution((et_tower_t)i),
               mf->R0_present[i] ? "patient-specific" : "population default");
    }
    printf("  %-18s %.6f   (log M = %.4f)\n",
           "Scalar M:",
           mf->multifold_scalar, mf->multifold_log_scalar);
}

static void print_findings(const et_finding_t* findings, int count) {
    print_header("Findings — sorted by urgency (most urgent first)");
    if (count == 0) {
        printf("  (no measurements provided)\n");
        return;
    }
    printf("  %-4s  %-6s  %-18s  %-18s  %-16s  %-7s  %s\n",
           "#", "Tower", "Name", "State", "Incoherence", "Sev%%", "Details");
    printf("  ----  ------  ------------------  ------------------  ----------------  -------  -------\n");
    for (int i = 0; i < count; ++i) {
        const et_finding_t* f = &findings[i];
        printf("  %-4d  %-6s  %-18s  %-18s  %-16s  %6.2f   k=%d d=%d eps=%+.2f¢\n",
               f->urgency_rank,
               et_tower_name(f->tower),
               f->name,
               et_manifold_state_name(f->state),
               et_incoherence_level_name(f->incoherence_level),
               f->severity_score_pct,
               f->projection.k, f->projection.d, f->projection.eps_cents);
    }
    /* Narrative block */
    printf("\n  Narrative:\n");
    for (int i = 0; i < count; ++i) {
        const et_finding_t* f = &findings[i];
        printf("    [%d] %s (%s tower @ N=%d) -> %s / %s, severity=%.2f%% (%s)\n",
               f->urgency_rank, f->name,
               et_tower_name(f->tower), f->lattice_resolution,
               et_manifold_state_name(f->state),
               et_incoherence_level_name(f->incoherence_level),
               f->severity_score_pct, f->severity_text);
        printf("        %s\n", f->description);
    }
}

/* --- Simple arg parser ---------------------------------------------------- */
static et_tower_t parse_tower(const char* s) {
    if (ci_strcmp(s, "CARDIAC") == 0)         return ET_TOWER_CARDIAC;
    if (ci_strcmp(s, "RESPIRATORY") == 0)     return ET_TOWER_RESPIRATORY;
    if (ci_strcmp(s, "NEURAL") == 0)          return ET_TOWER_NEURAL;
    if (ci_strcmp(s, "ENDOCRINE") == 0)       return ET_TOWER_ENDOCRINE;
    if (ci_strcmp(s, "IMMUNE") == 0)          return ET_TOWER_IMMUNE;
    if (ci_strcmp(s, "DIGESTIVE") == 0)       return ET_TOWER_DIGESTIVE;
    if (ci_strcmp(s, "RENAL") == 0)           return ET_TOWER_RENAL;
    if (ci_strcmp(s, "MUSCULOSKELETAL") == 0) return ET_TOWER_MUSCULOSKELETAL;
    if (ci_strcmp(s, "REPRODUCTIVE") == 0)    return ET_TOWER_REPRODUCTIVE;
    if (ci_strcmp(s, "DEVELOPMENTAL") == 0)   return ET_TOWER_DEVELOPMENTAL;
    return ET_TOWER_COUNT;
}

static et_sex_t parse_sex(const char* s) {
    if (ci_strcmp(s, "female") == 0 || ci_strcmp(s, "f") == 0) return ET_SEX_FEMALE;
    if (ci_strcmp(s, "male")   == 0 || ci_strcmp(s, "m") == 0) return ET_SEX_MALE;
    return ET_SEX_UNSPECIFIED;
}

static void usage(const char* prog) {
    printf("libet_med CLI %s — ET-native medical projection\n", LIBET_MED_VERSION_STRING);
    printf("Usage: %s [--baseline OPTS] [--measure NAME VALUE UNITS TOWER]...\n", prog);
    printf("Baseline options:\n");
    printf("  --hr-rest  BPM       (resting heart rate, bpm)\n");
    printf("  --rr-rest  PER_MIN   (resting respiratory rate)\n");
    printf("  --temp     C         (core body temperature, Celsius)\n");
    printf("  --sbp      MMHG      (systolic BP)\n");
    printf("  --dbp      MMHG      (diastolic BP)\n");
    printf("  --spo2     PCT       (pulse-ox saturation %%)\n");
    printf("  --gait     SECONDS   (gait cycle)\n");
    printf("  --cycle    DAYS      (menstrual cycle length)\n");
    printf("  --age      YEARS     (age)\n");
    printf("  --sex      M|F|U     (sex)\n");
    printf("  --measure NAME VALUE UNITS TOWER (repeat up to 64 times)\n");
    printf("    Tower must be one of: CARDIAC RESPIRATORY NEURAL ENDOCRINE\n");
    printf("                          IMMUNE DIGESTIVE RENAL MUSCULOSKELETAL\n");
    printf("                          REPRODUCTIVE DEVELOPMENTAL\n");
    printf("  --verbose   Enable fallback-log output to stderr\n");
    printf("  --help      This text\n");
    printf("\nWith no arguments, runs a demo patient (HR=60 baseline; HR=120 tachycardia,\n");
    printf("RR=30 tachypnea, Temp=38.8°C fever).\n");
}

typedef struct cli_state_s {
    et_patient_baseline_t baseline;
    et_measurement_t*     measurements;
    int                   n_meas;
    int                   cap_meas;
} cli_state_t;

static void cli_add_measurement(cli_state_t* s, const char* name,
                                double value, const char* units,
                                et_tower_t tower) {
    if (s->n_meas >= s->cap_meas) {
        /* Grow dynamically — no static cap per Rule 33. */
        int new_cap = s->cap_meas * 2;
        if (new_cap < 8) new_cap = 8;
        et_measurement_t* nm = (et_measurement_t*)realloc(
            s->measurements, (size_t)new_cap * sizeof(*nm));
        if (nm == NULL) {
            fprintf(stderr, "out of memory adding measurement\n");
            exit(2);
        }
        s->measurements = nm;
        s->cap_meas = new_cap;
    }
    et_measurement_t* m = &s->measurements[s->n_meas++];
    et_measurement_init(m);
    strncpy(m->name,  name,  sizeof(m->name)  - 1); m->name [sizeof(m->name)  - 1] = '\0';
    strncpy(m->units, units, sizeof(m->units) - 1); m->units[sizeof(m->units) - 1] = '\0';
    m->current_value = value;
    m->tower         = tower;
}

int main(int argc, char** argv) {
    cli_state_t S;
    memset(&S, 0, sizeof(S));
    et_patient_baseline_init(&S.baseline);

    et_set_log_callback(cli_log_callback, NULL);

    /* Parse args */
    int use_demo = (argc == 1);
    for (int i = 1; i < argc; ++i) {
        const char* a = argv[i];
        if (strcmp(a, "--help") == 0 || strcmp(a, "-h") == 0) {
            usage(argv[0]); return 0;
        } else if (strcmp(a, "--verbose") == 0) {
            g_verbose = 1;
        } else if (strcmp(a, "--hr-rest") == 0 && i + 1 < argc) {
            S.baseline.hr_rest_bpm = atof(argv[++i]);
        } else if (strcmp(a, "--rr-rest") == 0 && i + 1 < argc) {
            S.baseline.rr_rest_per_min = atof(argv[++i]);
        } else if (strcmp(a, "--temp") == 0 && i + 1 < argc) {
            S.baseline.temperature_c = atof(argv[++i]);
        } else if (strcmp(a, "--sbp") == 0 && i + 1 < argc) {
            S.baseline.sbp_rest_mmhg = atof(argv[++i]);
        } else if (strcmp(a, "--dbp") == 0 && i + 1 < argc) {
            S.baseline.dbp_rest_mmhg = atof(argv[++i]);
        } else if (strcmp(a, "--spo2") == 0 && i + 1 < argc) {
            S.baseline.spo2_pct = atof(argv[++i]);
        } else if (strcmp(a, "--gait") == 0 && i + 1 < argc) {
            S.baseline.gait_cycle_s = atof(argv[++i]);
        } else if (strcmp(a, "--cycle") == 0 && i + 1 < argc) {
            S.baseline.menstrual_cycle_d = atof(argv[++i]);
        } else if (strcmp(a, "--age") == 0 && i + 1 < argc) {
            S.baseline.age_years = atof(argv[++i]);
        } else if (strcmp(a, "--sex") == 0 && i + 1 < argc) {
            S.baseline.sex = parse_sex(argv[++i]);
        } else if (strcmp(a, "--measure") == 0 && i + 4 < argc) {
            const char* nm    = argv[++i];
            double      val   = atof(argv[++i]);
            const char* units = argv[++i];
            et_tower_t  tw    = parse_tower(argv[++i]);
            if (tw == ET_TOWER_COUNT) {
                fprintf(stderr, "unknown tower: %s\n", argv[i]);
                free(S.measurements);
                return 2;
            }
            cli_add_measurement(&S, nm, val, units, tw);
        } else {
            fprintf(stderr, "unknown argument: %s (try --help)\n", a);
            free(S.measurements);
            return 2;
        }
    }

    if (use_demo) {
        printf("[demo patient: HR=60 baseline, tachycardia + tachypnea + fever]\n");
        S.baseline.hr_rest_bpm     = 60.0;
        S.baseline.rr_rest_per_min = 12.0;
        S.baseline.temperature_c   = 36.8;
        S.baseline.age_years       = 45.0;
        S.baseline.sex             = ET_SEX_MALE;
        cli_add_measurement(&S, "HR",   120.0, "bpm",  ET_TOWER_CARDIAC);
        cli_add_measurement(&S, "RR",    30.0, "/min", ET_TOWER_RESPIRATORY);
        cli_add_measurement(&S, "TEMP",  38.8, "C",    ET_TOWER_ENDOCRINE);
        cli_add_measurement(&S, "GAIT",   1.0, "s",    ET_TOWER_MUSCULOSKELETAL);
    }

    /* Header */
    printf("====================================================================\n");
    printf("  libet_med %s — ET-native medical projection\n", LIBET_MED_VERSION_STRING);
    printf("====================================================================\n");
    printf("  Baseline: HR=%-4.0f bpm  RR=%-3.0f/min  Temp=%-5.2f°C  Age=%-3.0f  Sex=%s\n",
           S.baseline.hr_rest_bpm,
           S.baseline.rr_rest_per_min,
           S.baseline.temperature_c,
           S.baseline.age_years,
           S.baseline.sex == ET_SEX_FEMALE ? "F" :
           S.baseline.sex == ET_SEX_MALE   ? "M" : "U");

    /* Multifold signature */
    et_multifold_signature_t mf;
    et_error_t e = et_compute_multifold_signature(&S.baseline, 1, &mf);
    if (e != ET_OK) {
        fprintf(stderr, "multifold signature failed: %s\n", et_error_string(e));
        free(S.measurements);
        return 1;
    }
    print_multifold(&mf);

    /* Findings */
    et_finding_t* findings = NULL;
    int fcount = 0;
    e = et_generate_findings(S.measurements, S.n_meas,
                             &S.baseline, 1, &findings, &fcount);
    if (e != ET_OK) {
        fprintf(stderr, "findings generation failed: %s\n", et_error_string(e));
        et_free_findings(findings, fcount);
        free(S.measurements);
        return 1;
    }
    print_findings(findings, fcount);

    /* Footer */
    printf("\n====================================================================\n");
    printf("  Fallback paths invoked during this run: %zu  (all logged %s)\n",
           g_cli_fallback_count,
           g_verbose ? "to stderr above" : "(use --verbose to see them)");
    printf("====================================================================\n");

    et_free_findings(findings, fcount);
    free(S.measurements);
    return 0;
}
