/* ============================================================================
 * et_med_internal.h — Internal helpers (not part of the public ABI)
 * ----------------------------------------------------------------------------
 *  This header is consumed only by libet_med .c source files. It is NOT
 *  installed alongside libet_med.h.
 * ========================================================================= */
#ifndef LIBET_MED_INTERNAL_H
#define LIBET_MED_INTERNAL_H

#include "libet_med.h"
#include <math.h>

/* The actual implementation of fallback logging. */
void _et_error_impl(et_error_t err, const char* file, int line,
                    const char* func, const char* message);

/* Macro form so __FILE__, __LINE__, __func__ are captured automatically.
 * Per Rule 33: every call here is mandatory whenever a fallback is taken. */
#define _et_error(err, msg) \
    _et_error_impl((err), __FILE__, __LINE__, __func__, (msg))

/* Greatest common divisor (Euclidean). gcd(0, n) = n. Always non-negative. */
static inline int et_gcd(int a, int b) {
    if (a < 0) a = -a;
    if (b < 0) b = -b;
    while (b != 0) {
        int t = a % b;
        a = b;
        b = t;
    }
    return a;
}

/* Least common multiple. */
static inline long long et_lcm(int a, int b) {
    int g = et_gcd(a, b);
    if (g == 0) return 0;
    /* widen to avoid intermediate overflow */
    return (long long)(a / g) * (long long)b;
}

/* Finite check that works without -ffinite-math-only assumptions. */
static inline int et_is_finite(double x) {
    /* Standard IEEE: NaN != NaN, Inf - Inf = NaN, |Inf| > DBL_MAX */
    return !(x != x) && (x < 1.0e308) && (x > -1.0e308);
}

/* Round-half-to-even for symmetric epsilon distribution. */
static inline int et_round_int(double x) {
    /* nearbyint() with FE_TONEAREST default = banker's rounding. */
    return (int) nearbyint(x);
}

/* Canonical LCM landmark tower {12, 60, 84, 420, 2520, 27720}.
 * 12      = base
 * 60      = LCM(1..6) — extends to senary
 * 84      = LCM(1..7,12) variant — septic + base
 * 420     = LCM(1..7) — biological floor (5,7) co-binding
 * 2520    = LCM(1..10)
 * 27720   = LCM(1..11) — cortical floor (Blue Brain 11D cliques)
 */
#define ET_LCM_TOWER_COUNT 6
extern const int ET_LCM_LANDMARKS[ET_LCM_TOWER_COUNT];

/* Validate that N is one of the supported resolutions. Logs a fallback if
 * N is some other positive value (we still allow it for research use, but
 * the user should know). Returns ET_ERR_INVALID_N only if N <= 0. */
static inline et_error_t et_validate_N(int N) {
    if (N <= 0) {
        _et_error(ET_ERR_INVALID_N, "N must be positive");
        return ET_ERR_INVALID_N;
    }
    /* Check membership in the canonical tower */
    int known = 0;
    for (int i = 0; i < ET_LCM_TOWER_COUNT; ++i) {
        if (ET_LCM_LANDMARKS[i] == N) { known = 1; break; }
    }
    if (!known) {
        _et_error(ET_ERR_FALLBACK_USED,
                  "non-canonical lattice resolution N (allowed but informational)");
        /* Do not fail — return OK so the caller can use a research lattice. */
    }
    return ET_OK;
}

#endif /* LIBET_MED_INTERNAL_H */
