"""
Exception Theory Classes Module

This module contains all ET-derived computational patterns organized by batch:
- Batch 1: Computational Exception Theory (The Code of Reality)
- Batch 2: Advanced Manifold Architectures (Code of the Impossible)
- Batch 3: Distributed Consciousness (The Code of Connection)
- Batch 4: Quantum Mechanics Foundations (The Code of the Atom)
- Batch 5: Electromagnetism (The Code of Forces)
- Batch 6: Hydrogen Atom Core (The Code of Matter)
- Batch 7: Spectroscopy (The Code of Light)
- Batch 8: Fine Structure & Corrections (The Code of Precision)

From: "For every exception there is an exception, except the exception."

Author: Derived from M.J.M.'s Exception Theory
Version: 3.1.0
"""

from .batch1 import (
    TraverserEntropy,
    TrinaryState,
    ChameleonObject,
    TraverserMonitor,
    RealityGrounding,
    TemporalCoherenceFilter,
    EvolutionarySolver,
    PNumber,
)

from .batch2 import (
    TeleologicalSorter,
    ProbabilisticManifold,
    HolographicValidator,
    ZeroKnowledgeProtocol,
    ContentAddressableStorage,
    ReactivePoint,
    GhostSwitch,
    UniversalAdapter,
)

from .batch3 import (
    SwarmConsensus,
    PrecognitiveCache,
    ImmortalSupervisor,
    SemanticManifold,
    VarianceLimiter,
    ProofOfTraversal,
    EphemeralVault,
    ConsistentHashingRing,
    TimeTraveler,
    FractalReality,
)

from .batch4 import (
    QuantumState,
    UncertaintyAnalyzer,
    OperatorAlgebra,
    CoulombPotential,
    HydrogenEnergyCalculator,
    BohrRadiusCalculator,
    FineStructureCalculator,
    RydbergWavelengthCalculator,
    WavefunctionNormalizer,
    QuantumMeasurement,
)

from .batch5 import (
    CoulombForceCalculator,
    ElectricPotentialField,
    ElectricFieldCalculator,
    MagneticFieldCalculator,
    LorentzForceCalculator,
    EMEnergyCalculator,
    FineStructureConstant,
    VacuumImpedance,
    CoulombConstantCalculator,
    MagneticConstantCalculator,
)

from .batch6 import (
    ReducedMassCalculator,
    HydrogenEnergyLevels,
    BohrRadiusSystem,
    HydrogenHamiltonian,
    RadialWavefunction,
    SphericalHarmonicCalculator,
    HydrogenWavefunction,
    OrbitalAngularMomentumCalculator,
    TotalAngularMomentumCoupling,
    QuantumNumberValidator,
)

from .batch7 import (
    RydbergSeriesCalculator,
    TransitionCalculator,
    WavelengthCalculator,
    FrequencyCalculator,
    LymanSeries,
    BalmerSeries,
    PaschenSeries,
    SelectionRules,
    OscillatorStrength,
    SpectralLineIntensity,
)

from .batch8 import (
    SpinOrbitCoupling,
    RelativisticCorrection,
    FineStructureShift,
    LambShiftCalculator,
    HyperfineSplitting,
    Hydrogen21cmLine,
    AngularMomentumCoupler,
    ZeemanEffect,
    StarkEffect,
    IsotopeShift,
)

__all__ = [
    # Batch 1: Computational ET
    'TraverserEntropy',
    'TrinaryState',
    'ChameleonObject',
    'TraverserMonitor',
    'RealityGrounding',
    'TemporalCoherenceFilter',
    'EvolutionarySolver',
    'PNumber',
    
    # Batch 2: Manifold Architectures
    'TeleologicalSorter',
    'ProbabilisticManifold',
    'HolographicValidator',
    'ZeroKnowledgeProtocol',
    'ContentAddressableStorage',
    'ReactivePoint',
    'GhostSwitch',
    'UniversalAdapter',
    
    # Batch 3: Distributed Consciousness
    'SwarmConsensus',
    'PrecognitiveCache',
    'ImmortalSupervisor',
    'SemanticManifold',
    'VarianceLimiter',
    'ProofOfTraversal',
    'EphemeralVault',
    'ConsistentHashingRing',
    'TimeTraveler',
    'FractalReality',
    
    # Batch 4: Quantum Mechanics
    'QuantumState',
    'UncertaintyAnalyzer',
    'OperatorAlgebra',
    'CoulombPotential',
    'HydrogenEnergyCalculator',
    'BohrRadiusCalculator',
    'FineStructureCalculator',
    'RydbergWavelengthCalculator',
    'WavefunctionNormalizer',
    'QuantumMeasurement',
    
    # Batch 5: Electromagnetism
    'CoulombForceCalculator',
    'ElectricPotentialField',
    'ElectricFieldCalculator',
    'MagneticFieldCalculator',
    'LorentzForceCalculator',
    'EMEnergyCalculator',
    'FineStructureConstant',
    'VacuumImpedance',
    'CoulombConstantCalculator',
    'MagneticConstantCalculator',
    
    # Batch 6: Hydrogen Atom
    'ReducedMassCalculator',
    'HydrogenEnergyLevels',
    'BohrRadiusSystem',
    'HydrogenHamiltonian',
    'RadialWavefunction',
    'SphericalHarmonicCalculator',
    'HydrogenWavefunction',
    'OrbitalAngularMomentumCalculator',
    'TotalAngularMomentumCoupling',
    'QuantumNumberValidator',
    
    # Batch 7: Spectroscopy
    'RydbergSeriesCalculator',
    'TransitionCalculator',
    'WavelengthCalculator',
    'FrequencyCalculator',
    'LymanSeries',
    'BalmerSeries',
    'PaschenSeries',
    'SelectionRules',
    'OscillatorStrength',
    'SpectralLineIntensity',
    
    # Batch 8: Fine Structure
    'SpinOrbitCoupling',
    'RelativisticCorrection',
    'FineStructureShift',
    'LambShiftCalculator',
    'HyperfineSplitting',
    'Hydrogen21cmLine',
    'AngularMomentumCoupler',
    'ZeemanEffect',
    'StarkEffect',
    'IsotopeShift',
]
