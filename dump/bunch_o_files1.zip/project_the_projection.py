"""
Mike's curiosity question: project the lattice projection through a lattice projection.

The projection proj(r) = (k, d, ε) takes a positive real r and returns three quantities.
'Projecting the projection' has several natural readings. Try them all.
"""
import math
from math import gcd, log2

N = 12
def project(r, Nl=N):
    if r <= 0: return None
    ex = Nl * log2(r)
    k = round(ex)
    g = gcd(abs(k), Nl) if k != 0 else Nl
    d = Nl // g
    eps = (ex - k) * (1200.0 / Nl)
    return dict(k=k, d=d, eps=eps, exact=ex)

# ═════════════════════════════════════════════════════════════════════════════
# READING 1 — Project the projection's OWN STRUCTURAL CONSTANTS
# The projection formula itself is a D-object with internal constants
#     N = 12, 1/N = 1/12, 1200 (cents/octave), 1200/N = 100 (cents/semitone),
#     #{divisors of N} = 6, log₂'s base = 2, round's granularity = 1
# Project each.
# ═════════════════════════════════════════════════════════════════════════════
print("═" * 78)
print("READING 1 — The projection's internal structural constants, projected")
print("═" * 78)
formula_constants = [
    ("N (symmetry)",            12),
    ("1/N (base variance V)",   1/12),
    ("log₂ base",               2),
    ("cents/octave",            1200),
    ("cents/semitone (1200/N)", 100),
    ("# divisors of N",         6),
    ("round granularity",       1),
    ("N² = FQG cell count",     144),
    ("N(N-1) = d_max",          132),
]
print(f"  {'internal constant':<32}  {'value':>10}  {'(k, d, ε¢)':>22}")
print("  " + "─" * 70)
for name, v in formula_constants:
    p = project(v)
    print(f"  {name:<32}  {v:>10.6f}  ({p['k']:>+4}, {p['d']:>3}, {p['eps']:>+7.3f})")

# ═════════════════════════════════════════════════════════════════════════════
# READING 2 — Project the set of DIVISORS OF N (the d-family values themselves)
# Each d ∈ {1, 2, 3, 4, 6, 12} is a specific positive integer; project each.
# ═════════════════════════════════════════════════════════════════════════════
print()
print("═" * 78)
print("READING 2 — The d-family values {1, 2, 3, 4, 6, 12}, each projected")
print("═" * 78)
print(f"  {'d':>3}  {'(k, d, ε¢)':>22}  sublattice character")
print("  " + "─" * 58)
for d in [1, 2, 3, 4, 6, 12]:
    p = project(d)
    print(f"  {d:>3}  ({p['k']:>+4}, {p['d']:>3}, {p['eps']:>+7.3f})")

# Meta-pattern: look at which d-class each d-value lands in
groups = {}
for d in [1, 2, 3, 4, 6, 12]:
    p = project(d)
    groups.setdefault((p['d'], round(p['eps'], 3)), []).append(d)
print()
print("  BIMODAL FINDING:")
for (d_landed, eps_landed), members in sorted(groups.items()):
    marker = "KOIDE ATTRACTOR" if (d_landed == 12 and abs(eps_landed - 1.955) < 0.01) else "octave/unison class"
    print(f"    d-values {members} → all land at (d={d_landed}, ε={eps_landed:+.3f}¢) — {marker}")

# ═════════════════════════════════════════════════════════════════════════════
# READING 3 — ITERATED d-PROJECTION (the projection recursively applied to its
# own d-output).  Given r₀, form r₁ = proj(r₀).d, then r₂ = proj(r₁).d, etc.
# What are the fixed points and basins of attraction?
# ═════════════════════════════════════════════════════════════════════════════
print()
print("═" * 78)
print("READING 3 — Iterated d-projection: r_{n+1} = proj(r_n).d")
print("═" * 78)
print("  Starting from various r, compute r → proj.d → proj.d → ... until stable.\n")

def iterate_d(r0, max_iter=10):
    trajectory = [r0]
    r = r0
    for _ in range(max_iter):
        p = project(r)
        if p is None: break
        r_next = p['d']  # next r = current d
        trajectory.append(r_next)
        if r_next == trajectory[-2]:  # fixed point reached
            break
        r = r_next
    return trajectory

starts = [
    ("1 (unison)",           1),
    ("12 (N itself)",        12),
    ("2 (octave)",           2),
    ("3 (cubic root)",       3),
    ("4 (double-octave)",    4),
    ("6 (hexadic)",          6),
    ("π",                    math.pi),
    ("e",                    math.e),
    ("√2",                   math.sqrt(2)),
    ("φ (golden ratio)",     (1+math.sqrt(5))/2),
    ("3/2 (perfect fifth)",  1.5),
    ("2/3 (Koide)",          2/3),
    ("5/4 (major third)",    5/4),
    ("6/5 (minor third)",    6/5),
    ("9/8 (whole tone)",     9/8),
    ("137 (fine structure)", 137),
    ("1/137 (α)",            1/137),
]
print(f"  {'starting r₀':<22}  trajectory r₀ → r₁ → r₂ → ...")
print("  " + "─" * 76)
for name, r0 in starts:
    traj = iterate_d(r0)
    traj_str = " → ".join(f"{t:.4g}" for t in traj)
    print(f"  {name:<22}  {traj_str}")

print()
print("  FIXED POINTS of the iterated d-projection:")
print("    r* = 1  (unison / identity)")
print("    r* = 12 (N itself / full symmetry)")
print()
print("  BASINS (verified from the trajectories above):")
print("    Basin of 1:  all r whose proj.d ∈ {1, 2, 4}  (power-of-2 collapse)")
print("    Basin of 12: all r whose proj.d ∈ {3, 6, 12} (non-power-of-2 rises)")

# ═════════════════════════════════════════════════════════════════════════════
# READING 4 — Project the PROJECTION FUNCTION'S IMAGE (the lattice points)
# The image of proj is {2^(k/N) : k ∈ Z} ∪ {sublattice-family ε values}.
# Projecting a lattice point 2^(k/N) back through proj gives (k, d, 0) — ε=0 always.
# So lattice points are ε-invariant under self-projection. Non-lattice points have ε≠0.
# ═════════════════════════════════════════════════════════════════════════════
print()
print("═" * 78)
print("READING 4 — Projecting lattice POINTS 2^(k/N) back through projection")
print("═" * 78)
print("  Lattice points are points where proj(r).ε = 0 by definition.")
print("  Self-projecting them should give ε=0 each time — invariance test.\n")
print(f"  {'k':>4}  {'2^(k/12)':>18}  {'(k, d, ε¢)':>22}")
print("  " + "─" * 52)
for k_in in [-7, -6, -3, 0, 3, 7, 12, 14, 43]:
    r = 2**(k_in/N)
    p = project(r)
    exact_eps = "exactly 0" if abs(p['eps']) < 1e-10 else f"{p['eps']:+.3f}¢"
    print(f"  {k_in:>+4}  {r:>18.12f}  (k={p['k']:>+3}, d={p['d']:>2}, ε={exact_eps})")

# ═════════════════════════════════════════════════════════════════════════════
# READING 5 — FIXED POINTS of proj where d = r (r equals its own sublattice family)
# ═════════════════════════════════════════════════════════════════════════════
print()
print("═" * 78)
print("READING 5 — Fixed points where d(r) = r (r is its own sublattice family)")
print("═" * 78)
print("  For r to equal its own d, r must be a divisor of N=12.")
print("  Check each divisor of 12:\n")
print(f"  {'r':>3}  {'proj.d':>6}  {'fixed?':>10}")
print("  " + "─" * 26)
for r in [1, 2, 3, 4, 6, 12]:
    p = project(r)
    fixed = "✓ FIXED" if p['d'] == r else ""
    print(f"  {r:>3}  {p['d']:>6}  {fixed:>10}")
print()
print("  Exactly TWO d-fixed points exist: r=1 (unison) and r=12 (manifold symmetry).")
print("  These are the two attractors of Reading 3, recovered from a different angle.")

# ═════════════════════════════════════════════════════════════════════════════
# READING 6 — Project the EPSILON RESIDUAL itself (as a fraction of the step)
# ε is measured in cents. The step size is 100 cents/semitone. So |ε|/100 is the
# fractional step residual. Project 1 + |ε|/100 to see where the residual lives.
# ═════════════════════════════════════════════════════════════════════════════
print()
print("═" * 78)
print("READING 6 — Projecting (1 + |ε|/100) — the residual as a fractional step")
print("═" * 78)
probes = [
    ("π",                    math.pi),
    ("e",                    math.e),
    ("3/2",                  1.5),
    ("2/3",                  2/3),
    ("erf(1)",               math.erf(1)),
    ("ζ(3) Apéry",           1.2020569031595943),
    ("γ (Euler-Mascheroni)", 0.5772156649015329),
]
print(f"  {'original r':<22}  {'orig proj':<22}  {'residual r_ε':>12}  {'proj(r_ε)':>22}")
print("  " + "─" * 84)
for name, r in probes:
    p1 = project(r)
    r_eps = 1 + abs(p1['eps'])/100
    p2 = project(r_eps)
    p1_str = f"({p1['k']:>+3},{p1['d']:>2},{p1['eps']:>+7.3f})"
    p2_str = f"({p2['k']:>+3},{p2['d']:>2},{p2['eps']:>+7.3f})"
    print(f"  {name:<22}  {p1_str:<22}  {r_eps:>12.6f}  {p2_str:>22}")
