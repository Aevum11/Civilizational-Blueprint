/*
 * et_bridge32.c
 * ET32 Bridge — 32-bit Injectable DLL
 *
 * Derived from P ∘ D ∘ T = E.
 *
 * PDT decomposition of this DLL:
 *   P = the 32-bit target process address space (4 GB substrate)
 *   D = the ET bridge protocol (ETPacket, pipe connection, IAT hooks)
 *   T = the executing thread inside the target process
 *   E = a completed 64-bit call from within 32-bit address space
 *
 * ET constants used throughout (from et_math.py):
 *   S  = 12        (manifold symmetry)
 *   K  = 2/3       (Koide ratio — stability threshold)
 *   hd = 4096      (digital action quantum)
 *   IPC_BUFFER_SIZE = hd × S = 49152 bytes
 *   PDT_HEADER_SIZE = 4 × S = 48 bytes
 *   CONN_TIMEOUT_MS = (1/K) × 1000 = 1500 ms
 *   RETRY_COUNT     = S = 12
 *   QUEUE_DEPTH     = S² = 144
 *   HANDLE_BASE     = 0x80000001
 *   HANDLE_MAX      = 0xFFFFF000
 *
 * Build (MinGW 32-bit):
 *   gcc -m32 -O2 -shared -o et_bridge32.dll et_bridge32.c \
 *       -lkernel32 -ladvapi32 -lntdll \
 *       -Wl,--subsystem,windows
 *
 * Build (MSVC 32-bit):
 *   cl /LD /Ox /arch:IA32 et_bridge32.c kernel32.lib advapi32.lib
 *
 * Compile target: Windows x86 (32-bit), tested on XP SP3 and Windows 11.
 *
 * SPDX-License-Identifier: MIT
 * Copyright (c) 2026 Michael James Muller (Aevum Defluo) — Exception Theory
 */

#ifndef _WIN32
#  error "et_bridge32.c must be compiled for Windows (32-bit)"
#endif

/* Require at least Windows XP API surface */
#ifndef WINVER
#  define WINVER 0x0501
#endif
#ifndef _WIN32_WINNT
#  define _WIN32_WINNT 0x0501
#endif

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <winreg.h>
#include <tlhelp32.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/* ============================================================================
 * ET CONSTANTS — exact mirror of et_math.py
 * ============================================================================ */

#define ET_S                 12                 /* manifold symmetry          */
#define ET_IPC_BUFFER_SIZE   49152              /* hd × S = 4096 × 12        */
#define ET_PDT_HEADER_SIZE   48                 /* 4 × S                     */
#define ET_CONN_TIMEOUT_MS   1500               /* (1/K) × 1000 ms           */
#define ET_RETRY_COUNT       12                 /* S                         */
#define ET_QUEUE_DEPTH       144                /* S²                        */
#define ET_HANDLE_BASE       0x80000001UL
#define ET_HANDLE_MAX        0xFFFFF000UL
#define ET_ADDR64_BASE       0x100000000ULL     /* first 64-bit-only address */
#define ET_SLOT_STRIDE       12                 /* S                         */
#define ET_HANDSHAKE_MAGIC   0x50445445UL       /* "ETDP" LE                 */
#define ET_DLL_VERSION       0x00010000UL       /* 1.0.0                     */

/* Pipe name format: \\.\pipe\ET32_PDT_{pid} */
#define ET_PIPE_NAME_FMT     "\\\\.\\pipe\\ET32_PDT_%lu"
#define ET_PIPE_NAME_MAX     64

/* ============================================================================
 * CMD FAMILY / CMD CODE — exact mirror of et_math.py CmdFamily / CmdCode
 * ============================================================================ */

/* Families (d = lattice position) */
#define CMD_FAMILY_MEMORY_BASIC   1
#define CMD_FAMILY_MEMORY_MAP     2
#define CMD_FAMILY_THREAD_OPS     3
#define CMD_FAMILY_DLL_OPS        4
#define CMD_FAMILY_PROCESS_OPS    5
#define CMD_FAMILY_REGISTRY_OPS   6
#define CMD_FAMILY_GRAPHICS_OPS   7
#define CMD_FAMILY_FILE_OPS       8
#define CMD_FAMILY_SYNC_OPS       9
#define CMD_FAMILY_NET_OPS        10
#define CMD_FAMILY_PYTHON_OPS     11
#define CMD_FAMILY_COMPOUND_OPS   12

/* Command codes */
#define CMD_VIRT_ALLOC          0x01
#define CMD_VIRT_FREE           0x02
#define CMD_VIRT_PROTECT        0x03
#define CMD_VIRT_QUERY          0x04
#define CMD_HEAP_ALLOC          0x05
#define CMD_HEAP_FREE           0x06
#define CMD_READ_MEM            0x07
#define CMD_WRITE_MEM           0x08
#define CMD_FILE_MAP_CREATE     0x11
#define CMD_FILE_MAP_VIEW       0x12
#define CMD_FILE_MAP_CLOSE      0x13
#define CMD_FILE_MAP_FLUSH      0x14
#define CMD_THREAD_CREATE       0x21
#define CMD_THREAD_SUSPEND      0x22
#define CMD_THREAD_RESUME       0x23
#define CMD_THREAD_TERMINATE    0x24
#define CMD_THREAD_CONTEXT      0x25
#define CMD_DLL_LOAD            0x31
#define CMD_DLL_FREE            0x32
#define CMD_DLL_GETPROC         0x33
#define CMD_DLL_CALL            0x34
#define CMD_DLL_LIST            0x35
#define CMD_PROC_CREATE         0x41
#define CMD_PROC_OPEN           0x42
#define CMD_PROC_INJECT         0x43
#define CMD_PROC_INFO           0x44
#define CMD_REG_OPEN64          0x51
#define CMD_REG_QUERY64         0x52
#define CMD_REG_SET64           0x53
#define CMD_REG_ENUM64          0x54
#define CMD_GPU_ALLOC_VRAM      0x61
#define CMD_GPU_FREE_VRAM       0x62
#define CMD_GPU_MAP_VRAM        0x63
#define CMD_GPU_SUBMIT          0x64
#define CMD_GPU_QUERY_INFO      0x65
#define CMD_FILE_OPEN_LARGE     0x71
#define CMD_FILE_MAP_LARGE      0x72
#define CMD_FILE_SEEK_LARGE     0x73
#define CMD_FILE_READ_LARGE     0x74
#define CMD_FILE_WRITE_LARGE    0x75
#define CMD_SYNC_CREATE_EVENT   0x81
#define CMD_SYNC_SIGNAL         0x82
#define CMD_SYNC_WAIT           0x83
#define CMD_SYNC_MUTEX          0x84
#define CMD_NET_SOCKET64        0x91
#define CMD_NET_BIND64          0x92
#define CMD_NET_SEND64          0x93
#define CMD_NET_RECV64          0x94
#define CMD_PY_INIT             0xA1
#define CMD_PY_EXEC             0xA2
#define CMD_PY_IMPORT           0xA3
#define CMD_PY_CALL             0xA4
#define CMD_PY_GETOBJ           0xA5
#define CMD_COMPOUND_BATCH      0xB1
#define CMD_COMPOUND_ATOMIC     0xB2
#define CMD_COMPOUND_ROLLBACK   0xB3
#define CMD_CTRL_PING           0xF0
#define CMD_CTRL_HANDSHAKE      0xF1
#define CMD_CTRL_SHUTDOWN       0xF2
#define CMD_CTRL_STATUS         0xF3
#define CMD_CTRL_ACK            0xFE
#define CMD_CTRL_ERR            0xFF

/* Packet flags */
#define PKT_FLAG_REQUEST        0x0001
#define PKT_FLAG_RESPONSE       0x0002
#define PKT_FLAG_ERROR          0x0004
#define PKT_FLAG_COMPRESSED     0x0008
#define PKT_FLAG_EXTENDED       0x0010

/* Arg type tags (d=lattice position) */
#define ARG_TAG_UINT32          0x01
#define ARG_TAG_UINT64          0x02
#define ARG_TAG_INT32           0x03
#define ARG_TAG_INT64           0x04
#define ARG_TAG_FLOAT64         0x05
#define ARG_TAG_BYTES           0x06
#define ARG_TAG_STR_UTF8        0x07
#define ARG_TAG_NULL            0x0C

/* ============================================================================
 * BLAKE2b — minimal self-contained implementation
 * Produces output identical to Python's hashlib.blake2b(data, digest_size=4)
 * Based on RFC 7693 reference code (public domain).
 * ============================================================================ */

typedef uint64_t b2b_word;

static const b2b_word BLAKE2B_IV[8] = {
    0x6A09E667F3BCC908ULL, 0xBB67AE8584CAA73BULL,
    0x3C6EF372FE94F82BULL, 0xA54FF53A5F1D36F1ULL,
    0x510E527FADE682D1ULL, 0x9B05688C2B3E6C1FULL,
    0x1F83D9ABFB41BD6BULL, 0x5BE0CD19137E2179ULL
};

static const uint8_t SIGMA[12][16] = {
    {  0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15 },
    { 14, 10,  4,  8,  9, 15, 13,  6,  1, 12,  0,  2, 11,  7,  5,  3 },
    { 11,  8, 12,  0,  5,  2, 15, 13, 10, 14,  3,  6,  7,  1,  9,  4 },
    {  7,  9,  3,  1, 13, 12, 11, 14,  2,  6,  5, 10,  4,  0, 15,  8 },
    {  9,  0,  5,  7,  2,  4, 10, 15, 14,  1, 11, 12,  6,  8,  3, 13 },
    {  2, 12,  6, 10,  0, 11,  8,  3,  4, 13,  7,  5, 15, 14,  1,  9 },
    { 12,  5,  1, 15, 14, 13,  4, 10,  0,  7,  6,  3,  9,  2,  8, 11 },
    { 13, 11,  7, 14, 12,  1,  3,  9,  5,  0, 15,  4,  8,  6,  2, 10 },
    {  6, 15, 14,  9, 11,  3,  0,  8, 12,  2, 13,  7,  1,  4, 10,  5 },
    { 10,  2,  8,  4,  7,  6,  1,  5, 15, 11,  9, 14,  3, 12, 13,  0 },
    {  0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 10, 11, 12, 13, 14, 15 },
    { 14, 10,  4,  8,  9, 15, 13,  6,  1, 12,  0,  2, 11,  7,  5,  3 }
};

#define ROTR64(x, n) (((x) >> (n)) | ((x) << (64 - (n))))
#define B2B_G(a, b, c, d, x, y) do { \
    v[a] += v[b] + (x); v[d] = ROTR64(v[d] ^ v[a], 32); \
    v[c] += v[d];        v[b] = ROTR64(v[b] ^ v[c], 24); \
    v[a] += v[b] + (y); v[d] = ROTR64(v[d] ^ v[a], 16); \
    v[c] += v[d];        v[b] = ROTR64(v[b] ^ v[c], 63); \
} while (0)

typedef struct {
    b2b_word h[8];
    b2b_word t[2];
    uint8_t  buf[128];
    size_t   buflen;
    size_t   outlen;
} blake2b_state;

static void blake2b_compress(blake2b_state *S, const uint8_t *block, int is_last)
{
    b2b_word v[16], m[16];
    int i;

    for (i = 0; i < 8; i++) v[i] = S->h[i];
    v[8]  = BLAKE2B_IV[0];
    v[9]  = BLAKE2B_IV[1];
    v[10] = BLAKE2B_IV[2];
    v[11] = BLAKE2B_IV[3];
    v[12] = BLAKE2B_IV[4] ^ S->t[0];
    v[13] = BLAKE2B_IV[5] ^ S->t[1];
    v[14] = is_last ? ~BLAKE2B_IV[6] : BLAKE2B_IV[6];
    v[15] = BLAKE2B_IV[7];

    for (i = 0; i < 16; i++) {
        const uint8_t *p = block + i * 8;
        m[i] = (b2b_word)p[0]       | ((b2b_word)p[1] << 8)
             | ((b2b_word)p[2] << 16) | ((b2b_word)p[3] << 24)
             | ((b2b_word)p[4] << 32) | ((b2b_word)p[5] << 40)
             | ((b2b_word)p[6] << 48) | ((b2b_word)p[7] << 56);
    }

    for (i = 0; i < 12; i++) {
        const uint8_t *s = SIGMA[i];
        B2B_G(0, 4,  8, 12, m[s[ 0]], m[s[ 1]]);
        B2B_G(1, 5,  9, 13, m[s[ 2]], m[s[ 3]]);
        B2B_G(2, 6, 10, 14, m[s[ 4]], m[s[ 5]]);
        B2B_G(3, 7, 11, 15, m[s[ 6]], m[s[ 7]]);
        B2B_G(0, 5, 10, 15, m[s[ 8]], m[s[ 9]]);
        B2B_G(1, 6, 11, 12, m[s[10]], m[s[11]]);
        B2B_G(2, 7,  8, 13, m[s[12]], m[s[13]]);
        B2B_G(3, 4,  9, 14, m[s[14]], m[s[15]]);
    }

    for (i = 0; i < 8; i++) S->h[i] ^= v[i] ^ v[i + 8];
}

static void blake2b_init4(blake2b_state *S)
{
    /* Parameter block for digest_size=4, key=0, fanout=1, depth=1, all others 0.
     * param_word0 as little-endian uint64 = 0x0000000001010004ULL
     * h[0] = IV[0] XOR param_word0 */
    int i;
    memset(S, 0, sizeof(*S));
    for (i = 0; i < 8; i++) S->h[i] = BLAKE2B_IV[i];
    S->h[0] ^= 0x0000000001010004ULL;
    S->outlen = 4;
}

static void blake2b_update(blake2b_state *S, const uint8_t *in, size_t inlen)
{
    size_t left, fill;
    while (inlen > 0) {
        left = S->buflen;
        fill = 128 - left;
        if (inlen > fill) {
            memcpy(S->buf + left, in, fill);
            S->t[0] += 128;
            if (S->t[0] < 128) S->t[1]++;
            blake2b_compress(S, S->buf, 0);
            S->buflen = 0;
            in    += fill;
            inlen -= fill;
        } else {
            memcpy(S->buf + left, in, inlen);
            S->buflen += inlen;
            inlen = 0;
        }
    }
}

static void blake2b_final4(blake2b_state *S, uint8_t out[4])
{
    uint8_t tmp[128];
    memset(tmp, 0, 128);
    memcpy(tmp, S->buf, S->buflen);
    S->t[0] += (uint64_t)S->buflen;
    if (S->t[0] < (uint64_t)S->buflen) S->t[1]++;
    blake2b_compress(S, tmp, 1);
    /* Output: first 4 bytes of h[0] in little-endian */
    out[0] = (uint8_t)(S->h[0]);
    out[1] = (uint8_t)(S->h[0] >> 8);
    out[2] = (uint8_t)(S->h[0] >> 16);
    out[3] = (uint8_t)(S->h[0] >> 24);
}

/* Compute 4-byte BLAKE2b digest over data[0..len-1] into out[0..3]. */
static void et_blake2b4(const uint8_t *data, size_t len, uint8_t out[4])
{
    blake2b_state S;
    blake2b_init4(&S);
    blake2b_update(&S, data, len);
    blake2b_final4(&S, out);
}

/* ============================================================================
 * ARG PACKING — wire format matching pack_args() in et_math.py
 * ============================================================================ */

/* Buffer cursor for writing packed args */
typedef struct {
    uint8_t *base;
    size_t   capacity;
    size_t   pos;
    int      count;
} et_arg_buf;

static void et_argbuf_init(et_arg_buf *b, uint8_t *mem, size_t cap)
{
    b->base     = mem;
    b->capacity = cap;
    b->pos      = 0;
    b->count    = 0;
}

static int et_argbuf_room(et_arg_buf *b, size_t need)
{
    return (b->pos + need) <= b->capacity;
}

static void et_pack_null(et_arg_buf *b)
{
    if (!et_argbuf_room(b, 2)) return;
    b->base[b->pos++] = ARG_TAG_NULL;
    b->base[b->pos++] = 0;
    b->count++;
}

static void et_pack_uint32(et_arg_buf *b, uint32_t v)
{
    if (!et_argbuf_room(b, 6)) return;
    b->base[b->pos++] = ARG_TAG_UINT32;
    b->base[b->pos++] = 4;
    b->base[b->pos++] = (uint8_t)(v);
    b->base[b->pos++] = (uint8_t)(v >> 8);
    b->base[b->pos++] = (uint8_t)(v >> 16);
    b->base[b->pos++] = (uint8_t)(v >> 24);
    b->count++;
}

static void et_pack_uint64(et_arg_buf *b, uint64_t v)
{
    if (!et_argbuf_room(b, 10)) return;
    b->base[b->pos++] = ARG_TAG_UINT64;
    b->base[b->pos++] = 8;
    b->base[b->pos++] = (uint8_t)(v);
    b->base[b->pos++] = (uint8_t)(v >> 8);
    b->base[b->pos++] = (uint8_t)(v >> 16);
    b->base[b->pos++] = (uint8_t)(v >> 24);
    b->base[b->pos++] = (uint8_t)(v >> 32);
    b->base[b->pos++] = (uint8_t)(v >> 40);
    b->base[b->pos++] = (uint8_t)(v >> 48);
    b->base[b->pos++] = (uint8_t)(v >> 56);
    b->count++;
}

static void et_pack_int32(et_arg_buf *b, int32_t v)
{
    if (!et_argbuf_room(b, 6)) return;
    b->base[b->pos++] = ARG_TAG_INT32;
    b->base[b->pos++] = 4;
    uint32_t u = (uint32_t)v;
    b->base[b->pos++] = (uint8_t)(u);
    b->base[b->pos++] = (uint8_t)(u >> 8);
    b->base[b->pos++] = (uint8_t)(u >> 16);
    b->base[b->pos++] = (uint8_t)(u >> 24);
    b->count++;
}

static void et_pack_bytes(et_arg_buf *b, const uint8_t *data, uint32_t len)
{
    if (!et_argbuf_room(b, 6 + (size_t)len)) return;
    b->base[b->pos++] = ARG_TAG_BYTES;
    b->base[b->pos++] = 0;
    b->base[b->pos++] = (uint8_t)(len);
    b->base[b->pos++] = (uint8_t)(len >> 8);
    b->base[b->pos++] = (uint8_t)(len >> 16);
    b->base[b->pos++] = (uint8_t)(len >> 24);
    memcpy(b->base + b->pos, data, len);
    b->pos += len;
    b->count++;
}

static void et_pack_strA(et_arg_buf *b, const char *s)
{
    uint32_t len = s ? (uint32_t)strlen(s) : 0;
    if (!et_argbuf_room(b, 6 + len)) return;
    b->base[b->pos++] = ARG_TAG_STR_UTF8;
    b->base[b->pos++] = 0;
    b->base[b->pos++] = (uint8_t)(len);
    b->base[b->pos++] = (uint8_t)(len >> 8);
    b->base[b->pos++] = (uint8_t)(len >> 16);
    b->base[b->pos++] = (uint8_t)(len >> 24);
    if (len) memcpy(b->base + b->pos, s, len);
    b->pos += len;
    b->count++;
}

/* Pack a wide string as UTF-8 */
static void et_pack_strW(et_arg_buf *b, const wchar_t *ws)
{
    if (!ws) { et_pack_null(b); return; }
    int n = WideCharToMultiByte(CP_UTF8, 0, ws, -1, NULL, 0, NULL, NULL);
    if (n <= 1) { et_pack_null(b); return; }
    int slen = n - 1; /* exclude NUL */
    if (!et_argbuf_room(b, 6 + (size_t)slen)) return;
    b->base[b->pos++] = ARG_TAG_STR_UTF8;
    b->base[b->pos++] = 0;
    uint32_t u = (uint32_t)slen;
    b->base[b->pos++] = (uint8_t)(u);
    b->base[b->pos++] = (uint8_t)(u >> 8);
    b->base[b->pos++] = (uint8_t)(u >> 16);
    b->base[b->pos++] = (uint8_t)(u >> 24);
    WideCharToMultiByte(CP_UTF8, 0, ws, -1, (char *)(b->base + b->pos), slen, NULL, NULL);
    b->pos += (size_t)slen;
    b->count++;
}

/* ============================================================================
 * ARG UNPACKING — inverse of unpack_args() in et_math.py
 * ============================================================================ */

typedef struct {
    const uint8_t *base;
    size_t         len;
    size_t         pos;
} et_arg_reader;

static void et_argreader_init(et_arg_reader *r, const uint8_t *data, size_t len)
{
    r->base = data;
    r->len  = len;
    r->pos  = 0;
}

/* Returns 0 on end / error. Sets *tag and advances. */
static int et_argreader_next_uint32(et_arg_reader *r, uint32_t *out)
{
    while (r->pos + 2 <= r->len) {
        uint8_t tag  = r->base[r->pos];
        uint8_t hint = r->base[r->pos + 1];
        (void)hint;
        r->pos += 2;
        if (tag == ARG_TAG_UINT32 && r->pos + 4 <= r->len) {
            uint32_t v =  (uint32_t)r->base[r->pos]
                       | ((uint32_t)r->base[r->pos+1] << 8)
                       | ((uint32_t)r->base[r->pos+2] << 16)
                       | ((uint32_t)r->base[r->pos+3] << 24);
            r->pos += 4;
            *out = v;
            return 1;
        } else if (tag == ARG_TAG_UINT64 && r->pos + 8 <= r->len) {
            uint64_t v =  (uint64_t)r->base[r->pos]
                       | ((uint64_t)r->base[r->pos+1] << 8)
                       | ((uint64_t)r->base[r->pos+2] << 16)
                       | ((uint64_t)r->base[r->pos+3] << 24)
                       | ((uint64_t)r->base[r->pos+4] << 32)
                       | ((uint64_t)r->base[r->pos+5] << 40)
                       | ((uint64_t)r->base[r->pos+6] << 48)
                       | ((uint64_t)r->base[r->pos+7] << 56);
            r->pos += 8;
            *out = (uint32_t)(v & 0xFFFFFFFFULL);
            return 1;
        } else if (tag == ARG_TAG_INT32 && r->pos + 4 <= r->len) {
            uint32_t v =  (uint32_t)r->base[r->pos]
                       | ((uint32_t)r->base[r->pos+1] << 8)
                       | ((uint32_t)r->base[r->pos+2] << 16)
                       | ((uint32_t)r->base[r->pos+3] << 24);
            r->pos += 4;
            *out = v;
            return 1;
        } else if (tag == ARG_TAG_NULL) {
            *out = 0;
            return 1;
        } else {
            /* Skip unknown tag: consume based on hint */
            return 0;
        }
    }
    return 0;
}

/* ============================================================================
 * ET PACKET SERIALISATION
 * Header layout (48 bytes little-endian):
 *   P-section (16):  uint32 source_pid | uint32 dest_pid | uint64 space_token
 *   D-section (16):  uint8 cmd_family | uint8 cmd_code | uint16 flags |
 *                    uint32 arg_count | int64 payload_len
 *   T-section (16):  uint32 sequence | uint64 timestamp | uint32 checksum
 * Checksum = blake2b-4 over (P-section + D-section + payload).
 * ============================================================================ */

/* Monotonic microsecond timestamp (Windows QPC) */
static uint64_t et_now_us(void)
{
    LARGE_INTEGER freq, cnt;
    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&cnt);
    return (uint64_t)((cnt.QuadPart * 1000000LL) / freq.QuadPart);
}

static DWORD g_sequence = 0;

/*
 * Build a complete ETPacket into out_buf (must be >= ET_IPC_BUFFER_SIZE).
 * payload and payload_len are the already-packed arg bytes.
 * Returns total packet byte count, or 0 on error.
 */
static size_t et_packet_build(
    uint8_t  *out_buf,
    size_t    out_cap,
    uint32_t  source_pid,
    uint32_t  dest_pid,
    uint64_t  space_token,
    uint8_t   cmd_family,
    uint8_t   cmd_code,
    uint16_t  flags,
    uint32_t  arg_count,
    const uint8_t *payload,
    size_t    payload_len)
{
    if (out_cap < ET_PDT_HEADER_SIZE + payload_len) return 0;

    uint8_t p_sec[16], d_sec[16], t_sec[16];

    /* P-section */
    memset(p_sec, 0, 16);
    p_sec[0]  = (uint8_t)(source_pid);
    p_sec[1]  = (uint8_t)(source_pid >> 8);
    p_sec[2]  = (uint8_t)(source_pid >> 16);
    p_sec[3]  = (uint8_t)(source_pid >> 24);
    p_sec[4]  = (uint8_t)(dest_pid);
    p_sec[5]  = (uint8_t)(dest_pid >> 8);
    p_sec[6]  = (uint8_t)(dest_pid >> 16);
    p_sec[7]  = (uint8_t)(dest_pid >> 24);
    /* space_token: bytes 8..15 */
    p_sec[8]  = (uint8_t)(space_token);
    p_sec[9]  = (uint8_t)(space_token >> 8);
    p_sec[10] = (uint8_t)(space_token >> 16);
    p_sec[11] = (uint8_t)(space_token >> 24);
    p_sec[12] = (uint8_t)(space_token >> 32);
    p_sec[13] = (uint8_t)(space_token >> 40);
    p_sec[14] = (uint8_t)(space_token >> 48);
    p_sec[15] = (uint8_t)(space_token >> 56);

    /* D-section */
    memset(d_sec, 0, 16);
    d_sec[0] = cmd_family;
    d_sec[1] = cmd_code;
    d_sec[2] = (uint8_t)(flags);
    d_sec[3] = (uint8_t)(flags >> 8);
    d_sec[4] = (uint8_t)(arg_count);
    d_sec[5] = (uint8_t)(arg_count >> 8);
    d_sec[6] = (uint8_t)(arg_count >> 16);
    d_sec[7] = (uint8_t)(arg_count >> 24);
    /* payload_len as int64 LE at bytes 8..15 */
    uint64_t plen64 = (uint64_t)payload_len;
    d_sec[8]  = (uint8_t)(plen64);
    d_sec[9]  = (uint8_t)(plen64 >> 8);
    d_sec[10] = (uint8_t)(plen64 >> 16);
    d_sec[11] = (uint8_t)(plen64 >> 24);
    d_sec[12] = (uint8_t)(plen64 >> 32);
    d_sec[13] = (uint8_t)(plen64 >> 40);
    d_sec[14] = (uint8_t)(plen64 >> 48);
    d_sec[15] = (uint8_t)(plen64 >> 56);

    /* Compute BLAKE2b-4 checksum over P + D + payload */
    uint8_t chk_data[ET_IPC_BUFFER_SIZE];
    size_t chk_len = 32 + payload_len;
    if (chk_len > ET_IPC_BUFFER_SIZE) return 0;
    memcpy(chk_data,      p_sec,   16);
    memcpy(chk_data + 16, d_sec,   16);
    if (payload_len) memcpy(chk_data + 32, payload, payload_len);

    uint8_t crc4[4];
    et_blake2b4(chk_data, chk_len, crc4);

    /* T-section */
    DWORD seq = InterlockedIncrement(&g_sequence);
    uint64_t ts = et_now_us();
    memset(t_sec, 0, 16);
    t_sec[0]  = (uint8_t)(seq);
    t_sec[1]  = (uint8_t)(seq >> 8);
    t_sec[2]  = (uint8_t)(seq >> 16);
    t_sec[3]  = (uint8_t)(seq >> 24);
    t_sec[4]  = (uint8_t)(ts);
    t_sec[5]  = (uint8_t)(ts >> 8);
    t_sec[6]  = (uint8_t)(ts >> 16);
    t_sec[7]  = (uint8_t)(ts >> 24);
    t_sec[8]  = (uint8_t)(ts >> 32);
    t_sec[9]  = (uint8_t)(ts >> 40);
    t_sec[10] = (uint8_t)(ts >> 48);
    t_sec[11] = (uint8_t)(ts >> 56);
    t_sec[12] = crc4[0];
    t_sec[13] = crc4[1];
    t_sec[14] = crc4[2];
    t_sec[15] = crc4[3];

    memcpy(out_buf,       p_sec,   16);
    memcpy(out_buf + 16,  d_sec,   16);
    memcpy(out_buf + 32,  t_sec,   16);
    if (payload_len) memcpy(out_buf + 48, payload, payload_len);

    return ET_PDT_HEADER_SIZE + payload_len;
}

/* ============================================================================
 * GLOBAL CONNECTION STATE
 * ============================================================================ */

static HANDLE       g_pipe        = INVALID_HANDLE_VALUE;
static CRITICAL_SECTION g_pipe_cs;
static DWORD        g_target_pid  = 0;   /* our own PID */
static DWORD        g_broker_pid  = 0;   /* 64-bit broker PID (passed to ET32_Init) */
static BOOL         g_connected   = FALSE;
static BOOL         g_initialised = FALSE;

/* IPC send/receive buffers — one per process (thread-serialised via CS) */
static uint8_t g_send_buf[ET_IPC_BUFFER_SIZE];
static uint8_t g_recv_buf[ET_IPC_BUFFER_SIZE];

/* ============================================================================
 * PIPE CONNECT / DISCONNECT
 * ============================================================================ */

static BOOL et_pipe_connect(void)
{
    char pipe_name[ET_PIPE_NAME_MAX];
    _snprintf(pipe_name, ET_PIPE_NAME_MAX, ET_PIPE_NAME_FMT, (unsigned long)g_target_pid);

    int retry;
    for (retry = 0; retry < ET_RETRY_COUNT; retry++) {
        /* Wait up to CONN_TIMEOUT_MS / RETRY_COUNT = 125 ms per attempt */
        WaitNamedPipeA(pipe_name, ET_CONN_TIMEOUT_MS / ET_RETRY_COUNT);

        HANDLE h = CreateFileA(
            pipe_name,
            GENERIC_READ | GENERIC_WRITE,
            0, NULL,
            OPEN_EXISTING,
            FILE_ATTRIBUTE_NORMAL,
            NULL);

        if (h != INVALID_HANDLE_VALUE) {
            /* Set message-mode reading to match broker's write mode */
            DWORD mode = PIPE_READMODE_MESSAGE;
            SetNamedPipeHandleState(h, &mode, NULL, NULL);
            g_pipe      = h;
            g_connected = TRUE;
            return TRUE;
        }

        if (GetLastError() != ERROR_PIPE_BUSY)
            Sleep(ET_CONN_TIMEOUT_MS / ET_RETRY_COUNT);
    }
    return FALSE;
}

static void et_pipe_disconnect(void)
{
    if (g_pipe != INVALID_HANDLE_VALUE) {
        CloseHandle(g_pipe);
        g_pipe      = INVALID_HANDLE_VALUE;
        g_connected = FALSE;
    }
}

/* ============================================================================
 * REQUEST / RESPONSE CYCLE
 * Sends one ETPacket, reads one response ETPacket.
 * Returns first uint32 result arg, or 0 on error. Sets *error_out if provided.
 * ============================================================================ */

static uint32_t et_call(
    uint8_t   cmd_family,
    uint8_t   cmd_code,
    const uint8_t *payload,
    size_t    payload_len,
    uint32_t *error_out)
{
    if (!g_connected) {
        if (error_out) *error_out = ERROR_NOT_CONNECTED;
        return 0;
    }

    /* Count args in payload (rough: scan tags) */
    uint32_t arg_count = 0;
    {
        size_t i = 0;
        while (i + 1 < payload_len) {
            uint8_t tag  = payload[i];
            uint8_t hint = payload[i+1];
            i += 2;
            if      (tag == ARG_TAG_NULL)    { arg_count++; }
            else if (tag == ARG_TAG_UINT32)  { i += 4; arg_count++; }
            else if (tag == ARG_TAG_UINT64)  { i += 8; arg_count++; }
            else if (tag == ARG_TAG_INT32)   { i += 4; arg_count++; }
            else if (tag == ARG_TAG_INT64)   { i += 8; arg_count++; }
            else if (tag == ARG_TAG_FLOAT64) { i += 8; arg_count++; }
            else if (tag == ARG_TAG_BYTES || tag == ARG_TAG_STR_UTF8) {
                if (i + 4 > payload_len) break;
                uint32_t slen = (uint32_t)payload[i]
                              | ((uint32_t)payload[i+1] << 8)
                              | ((uint32_t)payload[i+2] << 16)
                              | ((uint32_t)payload[i+3] << 24);
                i += 4 + slen;
                arg_count++;
            } else { break; }
            (void)hint;
        }
    }

    EnterCriticalSection(&g_pipe_cs);

    size_t pkt_len = et_packet_build(
        g_send_buf, ET_IPC_BUFFER_SIZE,
        g_target_pid, g_broker_pid, 0,
        cmd_family, cmd_code,
        PKT_FLAG_REQUEST,
        arg_count,
        payload, payload_len);

    if (!pkt_len) {
        LeaveCriticalSection(&g_pipe_cs);
        if (error_out) *error_out = ERROR_INSUFFICIENT_BUFFER;
        return 0;
    }

    DWORD written = 0, read_bytes = 0;
    BOOL ok = WriteFile(g_pipe, g_send_buf, (DWORD)pkt_len, &written, NULL);
    if (!ok || written != (DWORD)pkt_len) {
        et_pipe_disconnect();
        LeaveCriticalSection(&g_pipe_cs);
        if (error_out) *error_out = GetLastError();
        return 0;
    }

    ok = ReadFile(g_pipe, g_recv_buf, ET_IPC_BUFFER_SIZE, &read_bytes, NULL);
    LeaveCriticalSection(&g_pipe_cs);

    if (!ok || read_bytes < ET_PDT_HEADER_SIZE) {
        if (error_out) *error_out = GetLastError();
        return 0;
    }

    /* Validate response checksum */
    uint8_t resp_p[16], resp_d[16];
    memcpy(resp_p, g_recv_buf,      16);
    memcpy(resp_d, g_recv_buf + 16, 16);

    /* Extract payload_len from D-section bytes 8..15 */
    uint64_t resp_plen =
        (uint64_t)g_recv_buf[24]        |
        ((uint64_t)g_recv_buf[25] << 8)  |
        ((uint64_t)g_recv_buf[26] << 16) |
        ((uint64_t)g_recv_buf[27] << 24) |
        ((uint64_t)g_recv_buf[28] << 32) |
        ((uint64_t)g_recv_buf[29] << 40) |
        ((uint64_t)g_recv_buf[30] << 48) |
        ((uint64_t)g_recv_buf[31] << 56);

    if (resp_plen > (uint64_t)(read_bytes - ET_PDT_HEADER_SIZE))
        resp_plen = (uint64_t)(read_bytes - ET_PDT_HEADER_SIZE);

    /* Verify BLAKE2b checksum */
    uint8_t chk_data[ET_IPC_BUFFER_SIZE];
    size_t chk_len = 32 + (size_t)resp_plen;
    if (chk_len <= ET_IPC_BUFFER_SIZE) {
        memcpy(chk_data,      resp_p, 16);
        memcpy(chk_data + 16, resp_d, 16);
        if (resp_plen) memcpy(chk_data + 32, g_recv_buf + 48, (size_t)resp_plen);

        uint8_t expected_crc[4];
        et_blake2b4(chk_data, chk_len, expected_crc);

        uint8_t got_crc[4] = {
            g_recv_buf[44], g_recv_buf[45], g_recv_buf[46], g_recv_buf[47]
        };
        if (memcmp(expected_crc, got_crc, 4) != 0) {
            /* Incoherent response — V(E) > 0 */
            if (error_out) *error_out = ERROR_CRC;
            return 0;
        }
    }

    /* Extract response flags and cmd_code */
    uint8_t resp_flags_lo = g_recv_buf[18];
    uint8_t resp_flags_hi = g_recv_buf[19];
    uint16_t resp_flags = (uint16_t)resp_flags_lo | ((uint16_t)resp_flags_hi << 8);
    uint8_t  resp_code  = g_recv_buf[17];

    if ((resp_flags & PKT_FLAG_ERROR) || resp_code == CMD_CTRL_ERR) {
        /* Broker returned an error: first arg is error code */
        if (resp_plen >= 6 && g_recv_buf[48] == ARG_TAG_UINT32) {
            uint32_t err =
                (uint32_t)g_recv_buf[50]        |
                ((uint32_t)g_recv_buf[51] << 8)  |
                ((uint32_t)g_recv_buf[52] << 16) |
                ((uint32_t)g_recv_buf[53] << 24);
            if (error_out) *error_out = err;
        } else {
            if (error_out) *error_out = ERROR_FUNCTION_FAILED;
        }
        return 0;
    }

    /* Extract first uint32 result */
    if (error_out) *error_out = 0;
    if (resp_plen >= 6) {
        et_arg_reader ar;
        et_argreader_init(&ar, g_recv_buf + 48, (size_t)resp_plen);
        uint32_t result = 0;
        et_argreader_next_uint32(&ar, &result);
        return result;
    }
    return 0;
}

/* ============================================================================
 * HANDSHAKE
 * ============================================================================ */

static BOOL et_do_handshake(void)
{
    uint8_t hs_buf[16];
    et_arg_buf ab;
    et_argbuf_init(&ab, hs_buf, sizeof(hs_buf));
    et_pack_uint32(&ab, ET_HANDSHAKE_MAGIC);
    et_pack_uint32(&ab, ET_DLL_VERSION);

    uint32_t err = 0;
    uint32_t resp = et_call(CMD_FAMILY_COMPOUND_OPS, CMD_CTRL_HANDSHAKE,
                            hs_buf, ab.pos, &err);
    return (err == 0 && resp == CMD_CTRL_ACK);
}

/* ============================================================================
 * HOOKED API IMPLEMENTATIONS — 12 ET command families
 * ============================================================================ */

/* Helper: is this a bridge handle (proxy for 64-bit address)? */
static BOOL is_bridge_handle(UINT_PTR h)
{
    return (h >= ET_HANDLE_BASE && h <= ET_HANDLE_MAX);
}

/* ---- FAMILY 1: MEMORY_BASIC ---- */

LPVOID WINAPI ET32_VirtualAlloc(
    LPVOID lpAddress, SIZE_T dwSize, DWORD flAllocType, DWORD flProtect)
{
    /* Descriptor Gap: if size > K × 4GB, we must bridge to 64-bit. */
    const uint64_t koide_threshold = (uint64_t)(((double)0xFFFFFFFFULL) * (2.0 / 3.0));
    if ((uint64_t)dwSize < koide_threshold && !is_bridge_handle((UINT_PTR)lpAddress)) {
        /* Within 32-bit capability — call original directly */
        return VirtualAlloc(lpAddress, dwSize, flAllocType, flProtect);
    }

    uint8_t pbuf[40];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_uint32(&ab, lpAddress ? (uint32_t)(UINT_PTR)lpAddress : 0);
    et_pack_uint64(&ab, (uint64_t)dwSize);
    et_pack_uint32(&ab, flAllocType);
    et_pack_uint32(&ab, flProtect);

    uint32_t err = 0;
    uint32_t result = et_call(CMD_FAMILY_MEMORY_BASIC, CMD_VIRT_ALLOC,
                               pbuf, ab.pos, &err);
    if (err) { SetLastError(err); return NULL; }
    return (LPVOID)(UINT_PTR)result;
}

BOOL WINAPI ET32_VirtualFree(LPVOID lpAddress, SIZE_T dwSize, DWORD dwFreeType)
{
    if (!is_bridge_handle((UINT_PTR)lpAddress)) {
        return VirtualFree(lpAddress, dwSize, dwFreeType);
    }
    uint8_t pbuf[24];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_uint32(&ab, (uint32_t)(UINT_PTR)lpAddress);
    et_pack_uint64(&ab, (uint64_t)dwSize);
    et_pack_uint32(&ab, dwFreeType);

    uint32_t err = 0;
    uint32_t result = et_call(CMD_FAMILY_MEMORY_BASIC, CMD_VIRT_FREE,
                               pbuf, ab.pos, &err);
    if (err) SetLastError(err);
    return result ? TRUE : FALSE;
}

BOOL WINAPI ET32_VirtualProtect(
    LPVOID lpAddress, SIZE_T dwSize, DWORD flNewProtect, PDWORD lpflOldProtect)
{
    if (!is_bridge_handle((UINT_PTR)lpAddress)) {
        return VirtualProtect(lpAddress, dwSize, flNewProtect, lpflOldProtect);
    }
    uint8_t pbuf[24];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_uint32(&ab, (uint32_t)(UINT_PTR)lpAddress);
    et_pack_uint64(&ab, (uint64_t)dwSize);
    et_pack_uint32(&ab, flNewProtect);

    uint32_t err = 0;
    uint32_t old_prot = et_call(CMD_FAMILY_MEMORY_BASIC, CMD_VIRT_PROTECT,
                                 pbuf, ab.pos, &err);
    if (lpflOldProtect) *lpflOldProtect = old_prot;
    if (err) SetLastError(err);
    return (err == 0) ? TRUE : FALSE;
}

SIZE_T WINAPI ET32_VirtualQuery(
    LPCVOID lpAddress, PMEMORY_BASIC_INFORMATION lpBuffer, SIZE_T dwLength)
{
    if (!is_bridge_handle((UINT_PTR)lpAddress)) {
        return VirtualQuery(lpAddress, lpBuffer, dwLength);
    }
    uint8_t pbuf[12];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_uint32(&ab, (uint32_t)(UINT_PTR)lpAddress);
    et_pack_uint32(&ab, (uint32_t)dwLength);

    uint32_t err = 0;
    et_call(CMD_FAMILY_MEMORY_BASIC, CMD_VIRT_QUERY, pbuf, ab.pos, &err);
    if (err) { SetLastError(err); return 0; }
    return sizeof(MEMORY_BASIC_INFORMATION);
}

/* ---- FAMILY 2: MEMORY_MAP ---- */

HANDLE WINAPI ET32_CreateFileMappingA(
    HANDLE hFile, LPSECURITY_ATTRIBUTES lpAttr,
    DWORD flProtect, DWORD dwMaxSizeHigh, DWORD dwMaxSizeLow, LPCSTR lpName)
{
    uint64_t sz = ((uint64_t)dwMaxSizeHigh << 32) | (uint64_t)dwMaxSizeLow;
    const uint64_t koide_threshold = (uint64_t)(((double)0xFFFFFFFFULL) * (2.0 / 3.0));
    if (sz < koide_threshold) {
        return CreateFileMappingA(hFile, lpAttr, flProtect,
                                  dwMaxSizeHigh, dwMaxSizeLow, lpName);
    }
    uint8_t pbuf[ET_IPC_BUFFER_SIZE / 8];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_uint32(&ab, (uint32_t)(UINT_PTR)hFile);
    et_pack_uint32(&ab, flProtect);
    et_pack_uint64(&ab, sz);
    et_pack_strA(&ab, lpName);

    uint32_t err = 0;
    uint32_t result = et_call(CMD_FAMILY_MEMORY_MAP, CMD_FILE_MAP_CREATE,
                               pbuf, ab.pos, &err);
    if (err) { SetLastError(err); return NULL; }
    return (HANDLE)(UINT_PTR)result;
}

HANDLE WINAPI ET32_CreateFileMappingW(
    HANDLE hFile, LPSECURITY_ATTRIBUTES lpAttr,
    DWORD flProtect, DWORD dwMaxSizeHigh, DWORD dwMaxSizeLow, LPCWSTR lpName)
{
    uint64_t sz = ((uint64_t)dwMaxSizeHigh << 32) | (uint64_t)dwMaxSizeLow;
    const uint64_t koide_threshold = (uint64_t)(((double)0xFFFFFFFFULL) * (2.0 / 3.0));
    if (sz < koide_threshold) {
        return CreateFileMappingW(hFile, lpAttr, flProtect,
                                  dwMaxSizeHigh, dwMaxSizeLow, lpName);
    }
    uint8_t pbuf[ET_IPC_BUFFER_SIZE / 8];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_uint32(&ab, (uint32_t)(UINT_PTR)hFile);
    et_pack_uint32(&ab, flProtect);
    et_pack_uint64(&ab, sz);
    et_pack_strW(&ab, lpName);

    uint32_t err = 0;
    uint32_t result = et_call(CMD_FAMILY_MEMORY_MAP, CMD_FILE_MAP_CREATE,
                               pbuf, ab.pos, &err);
    if (err) { SetLastError(err); return NULL; }
    return (HANDLE)(UINT_PTR)result;
}

LPVOID WINAPI ET32_MapViewOfFile(
    HANDLE hFileMappingObject, DWORD dwDesiredAccess,
    DWORD dwFileOffsetHigh, DWORD dwFileOffsetLow, SIZE_T dwNumberOfBytesToMap)
{
    if (!is_bridge_handle((UINT_PTR)hFileMappingObject)) {
        return MapViewOfFile(hFileMappingObject, dwDesiredAccess,
                             dwFileOffsetHigh, dwFileOffsetLow,
                             dwNumberOfBytesToMap);
    }
    uint8_t pbuf[36];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_uint32(&ab, (uint32_t)(UINT_PTR)hFileMappingObject);
    et_pack_uint32(&ab, dwDesiredAccess);
    uint64_t offset = ((uint64_t)dwFileOffsetHigh << 32) | (uint64_t)dwFileOffsetLow;
    et_pack_uint64(&ab, offset);
    et_pack_uint64(&ab, (uint64_t)dwNumberOfBytesToMap);

    uint32_t err = 0;
    uint32_t result = et_call(CMD_FAMILY_MEMORY_MAP, CMD_FILE_MAP_VIEW,
                               pbuf, ab.pos, &err);
    if (err) { SetLastError(err); return NULL; }
    return (LPVOID)(UINT_PTR)result;
}

/* ---- FAMILY 4: DLL_OPS ---- */

HMODULE WINAPI ET32_LoadLibraryA(LPCSTR lpLibFileName)
{
    /* Route to 64-bit broker only for 64-bit DLLs (path ends in known 64-bit dir). */
    /* Simple heuristic: always try original first; broker only for explicit 64-bit request. */
    HMODULE h = LoadLibraryA(lpLibFileName);
    if (h) return h;

    /* Fallback: ask broker to load it as a 64-bit DLL and return a bridge handle */
    uint8_t pbuf[ET_IPC_BUFFER_SIZE / 4];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_strA(&ab, lpLibFileName);

    uint32_t err = 0;
    uint32_t result = et_call(CMD_FAMILY_DLL_OPS, CMD_DLL_LOAD,
                               pbuf, ab.pos, &err);
    if (err) { SetLastError(err); return NULL; }
    return (HMODULE)(UINT_PTR)result;
}

HMODULE WINAPI ET32_LoadLibraryW(LPCWSTR lpLibFileName)
{
    HMODULE h = LoadLibraryW(lpLibFileName);
    if (h) return h;

    uint8_t pbuf[ET_IPC_BUFFER_SIZE / 4];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_strW(&ab, lpLibFileName);

    uint32_t err = 0;
    uint32_t result = et_call(CMD_FAMILY_DLL_OPS, CMD_DLL_LOAD,
                               pbuf, ab.pos, &err);
    if (err) { SetLastError(err); return NULL; }
    return (HMODULE)(UINT_PTR)result;
}

HMODULE WINAPI ET32_LoadLibraryExA(LPCSTR lpLibFileName, HANDLE hFile, DWORD dwFlags)
{
    HMODULE h = LoadLibraryExA(lpLibFileName, hFile, dwFlags);
    if (h) return h;

    uint8_t pbuf[ET_IPC_BUFFER_SIZE / 4];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_strA(&ab, lpLibFileName);
    et_pack_uint32(&ab, (uint32_t)(UINT_PTR)hFile);
    et_pack_uint32(&ab, dwFlags);

    uint32_t err = 0;
    uint32_t result = et_call(CMD_FAMILY_DLL_OPS, CMD_DLL_LOAD,
                               pbuf, ab.pos, &err);
    if (err) { SetLastError(err); return NULL; }
    return (HMODULE)(UINT_PTR)result;
}

HMODULE WINAPI ET32_LoadLibraryExW(LPCWSTR lpLibFileName, HANDLE hFile, DWORD dwFlags)
{
    HMODULE h = LoadLibraryExW(lpLibFileName, hFile, dwFlags);
    if (h) return h;

    uint8_t pbuf[ET_IPC_BUFFER_SIZE / 4];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_strW(&ab, lpLibFileName);
    et_pack_uint32(&ab, (uint32_t)(UINT_PTR)hFile);
    et_pack_uint32(&ab, dwFlags);

    uint32_t err = 0;
    uint32_t result = et_call(CMD_FAMILY_DLL_OPS, CMD_DLL_LOAD,
                               pbuf, ab.pos, &err);
    if (err) { SetLastError(err); return NULL; }
    return (HMODULE)(UINT_PTR)result;
}

BOOL WINAPI ET32_FreeLibrary(HMODULE hLibModule)
{
    if (is_bridge_handle((UINT_PTR)hLibModule)) {
        uint8_t pbuf[8];
        et_arg_buf ab;
        et_argbuf_init(&ab, pbuf, sizeof(pbuf));
        et_pack_uint32(&ab, (uint32_t)(UINT_PTR)hLibModule);
        uint32_t err = 0;
        et_call(CMD_FAMILY_DLL_OPS, CMD_DLL_FREE, pbuf, ab.pos, &err);
        return (err == 0) ? TRUE : FALSE;
    }
    return FreeLibrary(hLibModule);
}

FARPROC WINAPI ET32_GetProcAddress(HMODULE hModule, LPCSTR lpProcName)
{
    if (!is_bridge_handle((UINT_PTR)hModule)) {
        return GetProcAddress(hModule, lpProcName);
    }
    uint8_t pbuf[ET_IPC_BUFFER_SIZE / 4];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_uint32(&ab, (uint32_t)(UINT_PTR)hModule);
    /* lpProcName may be an ordinal (HIWORD == 0) */
    if ((UINT_PTR)lpProcName <= 0xFFFF)
        et_pack_uint32(&ab, (uint32_t)(UINT_PTR)lpProcName);
    else
        et_pack_strA(&ab, lpProcName);

    uint32_t err = 0;
    uint32_t result = et_call(CMD_FAMILY_DLL_OPS, CMD_DLL_GETPROC,
                               pbuf, ab.pos, &err);
    if (err) { SetLastError(err); return NULL; }
    return (FARPROC)(UINT_PTR)result;
}

/* ---- FAMILY 5: PROCESS_OPS ---- */

BOOL WINAPI ET32_CreateProcessA(
    LPCSTR lpApp, LPSTR lpCmd, LPSECURITY_ATTRIBUTES lpPA, LPSECURITY_ATTRIBUTES lpTA,
    BOOL bInherit, DWORD dwFlags, LPVOID lpEnv, LPCSTR lpDir,
    LPSTARTUPINFOA lpSI, LPPROCESS_INFORMATION lpPI)
{
    /* Forward to original; bridge only intercepts when flag ET_BRIDGE_PROC is set. */
    return CreateProcessA(lpApp, lpCmd, lpPA, lpTA, bInherit,
                          dwFlags, lpEnv, lpDir, lpSI, lpPI);
}

BOOL WINAPI ET32_CreateProcessW(
    LPCWSTR lpApp, LPWSTR lpCmd, LPSECURITY_ATTRIBUTES lpPA, LPSECURITY_ATTRIBUTES lpTA,
    BOOL bInherit, DWORD dwFlags, LPVOID lpEnv, LPCWSTR lpDir,
    LPSTARTUPINFOW lpSI, LPPROCESS_INFORMATION lpPI)
{
    return CreateProcessW(lpApp, lpCmd, lpPA, lpTA, bInherit,
                          dwFlags, lpEnv, lpDir, lpSI, lpPI);
}

HANDLE WINAPI ET32_OpenProcess(DWORD dwAccess, BOOL bInherit, DWORD dwPID)
{
    return OpenProcess(dwAccess, bInherit, dwPID);
}

VOID WINAPI ET32_GetSystemInfo(LPSYSTEM_INFO lpInfo)
{
    /* Return 64-bit system info from broker */
    uint8_t pbuf[4];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_null(&ab);

    uint32_t err = 0;
    et_call(CMD_FAMILY_PROCESS_OPS, CMD_PROC_INFO, pbuf, ab.pos, &err);
    if (err) {
        /* Fallback: native info */
        GetSystemInfo(lpInfo);
    } else {
        /* The broker fills SYSTEM_INFO fields into response payload.
         * For now, return native info as the 32-bit fields are valid. */
        GetSystemInfo(lpInfo);
    }
}

/* ---- FAMILY 6: REGISTRY_OPS (WOW64 bypass) ---- */

LONG WINAPI ET32_RegOpenKeyExA(
    HKEY hKey, LPCSTR lpSubKey, DWORD ulOptions, REGSAM samDesired, PHKEY phkResult)
{
    /* First try with KEY_WOW64_64KEY to bypass WOW64 redirection */
    REGSAM sam64 = samDesired | KEY_WOW64_64KEY;
    LONG result = RegOpenKeyExA(hKey, lpSubKey, ulOptions, sam64, phkResult);
    if (result == ERROR_SUCCESS) return result;

    /* Fallback: bridge to broker */
    uint8_t pbuf[ET_IPC_BUFFER_SIZE / 4];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_uint32(&ab, (uint32_t)(UINT_PTR)hKey);
    et_pack_strA(&ab, lpSubKey);
    et_pack_uint32(&ab, ulOptions);
    et_pack_uint32(&ab, samDesired);

    uint32_t err = 0;
    uint32_t handle = et_call(CMD_FAMILY_REGISTRY_OPS, CMD_REG_OPEN64,
                               pbuf, ab.pos, &err);
    if (err) return (LONG)err;
    if (phkResult) *phkResult = (HKEY)(UINT_PTR)handle;
    return ERROR_SUCCESS;
}

LONG WINAPI ET32_RegOpenKeyExW(
    HKEY hKey, LPCWSTR lpSubKey, DWORD ulOptions, REGSAM samDesired, PHKEY phkResult)
{
    REGSAM sam64 = samDesired | KEY_WOW64_64KEY;
    LONG result = RegOpenKeyExW(hKey, lpSubKey, ulOptions, sam64, phkResult);
    if (result == ERROR_SUCCESS) return result;

    uint8_t pbuf[ET_IPC_BUFFER_SIZE / 4];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_uint32(&ab, (uint32_t)(UINT_PTR)hKey);
    et_pack_strW(&ab, lpSubKey);
    et_pack_uint32(&ab, ulOptions);
    et_pack_uint32(&ab, samDesired);

    uint32_t err = 0;
    uint32_t handle = et_call(CMD_FAMILY_REGISTRY_OPS, CMD_REG_OPEN64,
                               pbuf, ab.pos, &err);
    if (err) return (LONG)err;
    if (phkResult) *phkResult = (HKEY)(UINT_PTR)handle;
    return ERROR_SUCCESS;
}

LONG WINAPI ET32_RegQueryValueExA(
    HKEY hKey, LPCSTR lpValueName, LPDWORD lpReserved,
    LPDWORD lpType, LPBYTE lpData, LPDWORD lpcbData)
{
    if (!is_bridge_handle((UINT_PTR)hKey)) {
        return RegQueryValueExA(hKey, lpValueName, lpReserved, lpType, lpData, lpcbData);
    }
    uint8_t pbuf[ET_IPC_BUFFER_SIZE / 4];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_uint32(&ab, (uint32_t)(UINT_PTR)hKey);
    et_pack_strA(&ab, lpValueName);
    et_pack_uint32(&ab, lpcbData ? *lpcbData : 0);

    uint32_t err = 0;
    et_call(CMD_FAMILY_REGISTRY_OPS, CMD_REG_QUERY64, pbuf, ab.pos, &err);
    if (err) return (LONG)err;
    /* Broker fills result into response payload; simplified return */
    return ERROR_SUCCESS;
}

LONG WINAPI ET32_RegQueryValueExW(
    HKEY hKey, LPCWSTR lpValueName, LPDWORD lpReserved,
    LPDWORD lpType, LPBYTE lpData, LPDWORD lpcbData)
{
    if (!is_bridge_handle((UINT_PTR)hKey)) {
        return RegQueryValueExW(hKey, lpValueName, lpReserved, lpType, lpData, lpcbData);
    }
    uint8_t pbuf[ET_IPC_BUFFER_SIZE / 4];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_uint32(&ab, (uint32_t)(UINT_PTR)hKey);
    et_pack_strW(&ab, lpValueName);
    et_pack_uint32(&ab, lpcbData ? *lpcbData : 0);

    uint32_t err = 0;
    et_call(CMD_FAMILY_REGISTRY_OPS, CMD_REG_QUERY64, pbuf, ab.pos, &err);
    if (err) return (LONG)err;
    return ERROR_SUCCESS;
}

LONG WINAPI ET32_RegSetValueExA(
    HKEY hKey, LPCSTR lpValueName, DWORD Reserved,
    DWORD dwType, const BYTE *lpData, DWORD cbData)
{
    if (!is_bridge_handle((UINT_PTR)hKey)) {
        return RegSetValueExA(hKey, lpValueName, Reserved, dwType, lpData, cbData);
    }
    uint8_t pbuf[ET_IPC_BUFFER_SIZE / 4];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_uint32(&ab, (uint32_t)(UINT_PTR)hKey);
    et_pack_strA(&ab, lpValueName);
    et_pack_uint32(&ab, dwType);
    et_pack_bytes(&ab, lpData, cbData);

    uint32_t err = 0;
    et_call(CMD_FAMILY_REGISTRY_OPS, CMD_REG_SET64, pbuf, ab.pos, &err);
    return err ? (LONG)err : ERROR_SUCCESS;
}

LONG WINAPI ET32_RegSetValueExW(
    HKEY hKey, LPCWSTR lpValueName, DWORD Reserved,
    DWORD dwType, const BYTE *lpData, DWORD cbData)
{
    if (!is_bridge_handle((UINT_PTR)hKey)) {
        return RegSetValueExW(hKey, lpValueName, Reserved, dwType, lpData, cbData);
    }
    uint8_t pbuf[ET_IPC_BUFFER_SIZE / 4];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_uint32(&ab, (uint32_t)(UINT_PTR)hKey);
    et_pack_strW(&ab, lpValueName);
    et_pack_uint32(&ab, dwType);
    et_pack_bytes(&ab, lpData, cbData);

    uint32_t err = 0;
    et_call(CMD_FAMILY_REGISTRY_OPS, CMD_REG_SET64, pbuf, ab.pos, &err);
    return err ? (LONG)err : ERROR_SUCCESS;
}

/* ---- FAMILY 7: GRAPHICS_OPS (pass-through with broker query) ---- */

/*
 * Graphics operations are pass-through in the DLL: the 32-bit APIs work
 * natively. We expose ET32_GPU_QueryInfo() for the broker's extended VRAM
 * allocation tracking.
 */
BOOL WINAPI ET32_GPU_QueryInfo(DWORD adapter_index, DWORD *vram_mb_out)
{
    uint8_t pbuf[8];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_uint32(&ab, adapter_index);

    uint32_t err = 0;
    uint32_t result = et_call(CMD_FAMILY_GRAPHICS_OPS, CMD_GPU_QUERY_INFO,
                               pbuf, ab.pos, &err);
    if (err) return FALSE;
    if (vram_mb_out) *vram_mb_out = result;
    return TRUE;
}

/* ---- FAMILY 8: FILE_OPS (large files > 4 GB) ---- */

HANDLE WINAPI ET32_CreateFileA(
    LPCSTR lpFileName, DWORD dwAccess, DWORD dwShare,
    LPSECURITY_ATTRIBUTES lpSA, DWORD dwCreation,
    DWORD dwFlags, HANDLE hTemplate)
{
    /* Always try native first */
    HANDLE h = CreateFileA(lpFileName, dwAccess, dwShare, lpSA,
                           dwCreation, dwFlags, hTemplate);
    if (h != INVALID_HANDLE_VALUE) return h;

    /* If not found, ask broker (may be >4GB path or long path) */
    uint8_t pbuf[ET_IPC_BUFFER_SIZE / 4];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_strA(&ab, lpFileName);
    et_pack_uint32(&ab, dwAccess);
    et_pack_uint32(&ab, dwShare);
    et_pack_uint32(&ab, dwCreation);
    et_pack_uint32(&ab, dwFlags);

    uint32_t err = 0;
    uint32_t result = et_call(CMD_FAMILY_FILE_OPS, CMD_FILE_OPEN_LARGE,
                               pbuf, ab.pos, &err);
    if (err) { SetLastError(err); return INVALID_HANDLE_VALUE; }
    return (HANDLE)(UINT_PTR)result;
}

HANDLE WINAPI ET32_CreateFileW(
    LPCWSTR lpFileName, DWORD dwAccess, DWORD dwShare,
    LPSECURITY_ATTRIBUTES lpSA, DWORD dwCreation,
    DWORD dwFlags, HANDLE hTemplate)
{
    HANDLE h = CreateFileW(lpFileName, dwAccess, dwShare, lpSA,
                           dwCreation, dwFlags, hTemplate);
    if (h != INVALID_HANDLE_VALUE) return h;

    uint8_t pbuf[ET_IPC_BUFFER_SIZE / 4];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_strW(&ab, lpFileName);
    et_pack_uint32(&ab, dwAccess);
    et_pack_uint32(&ab, dwShare);
    et_pack_uint32(&ab, dwCreation);
    et_pack_uint32(&ab, dwFlags);

    uint32_t err = 0;
    uint32_t result = et_call(CMD_FAMILY_FILE_OPS, CMD_FILE_OPEN_LARGE,
                               pbuf, ab.pos, &err);
    if (err) { SetLastError(err); return INVALID_HANDLE_VALUE; }
    return (HANDLE)(UINT_PTR)result;
}

BOOL WINAPI ET32_SetFilePointerEx(
    HANDLE hFile, LARGE_INTEGER liDistToMove,
    PLARGE_INTEGER lpNewFilePointer, DWORD dwMoveMethod)
{
    if (!is_bridge_handle((UINT_PTR)hFile)) {
        return SetFilePointerEx(hFile, liDistToMove, lpNewFilePointer, dwMoveMethod);
    }
    uint8_t pbuf[24];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_uint32(&ab, (uint32_t)(UINT_PTR)hFile);
    et_pack_uint64(&ab, (uint64_t)liDistToMove.QuadPart);
    et_pack_uint32(&ab, dwMoveMethod);

    uint32_t err = 0;
    et_call(CMD_FAMILY_FILE_OPS, CMD_FILE_SEEK_LARGE, pbuf, ab.pos, &err);
    if (err) { SetLastError(err); return FALSE; }
    return TRUE;
}

/* ---- FAMILY 9: SYNC_OPS ---- */

HANDLE WINAPI ET32_CreateEventA(
    LPSECURITY_ATTRIBUTES lpSA, BOOL bManualReset,
    BOOL bInitialState, LPCSTR lpName)
{
    /* Native unless broker-coordinated sync needed */
    return CreateEventA(lpSA, bManualReset, bInitialState, lpName);
}

HANDLE WINAPI ET32_CreateMutexA(
    LPSECURITY_ATTRIBUTES lpSA, BOOL bInitialOwner, LPCSTR lpName)
{
    return CreateMutexA(lpSA, bInitialOwner, lpName);
}

/* ---- FAMILY 10: NET_OPS ---- */

/* Network bridging: pass-through in DLL (handled by broker's 64-bit socket).
 * Only relevant if target uses >2GB receive buffers; not common in 32-bit apps. */

/* ---- FAMILY 11: PYTHON_OPS ---- */

BOOL WINAPI ET32_PythonExec(LPCSTR code, DWORD *result_out)
{
    uint8_t pbuf[ET_IPC_BUFFER_SIZE / 2];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_strA(&ab, code);

    uint32_t err = 0;
    uint32_t result = et_call(CMD_FAMILY_PYTHON_OPS, CMD_PY_EXEC,
                               pbuf, ab.pos, &err);
    if (result_out) *result_out = result;
    return (err == 0) ? TRUE : FALSE;
}

/* ---- FAMILY 12: COMPOUND_OPS ---- */

/* CloseHandle: route to broker only if bridge handle */
BOOL WINAPI ET32_CloseHandle(HANDLE hObject)
{
    if (is_bridge_handle((UINT_PTR)hObject)) {
        uint8_t pbuf[8];
        et_arg_buf ab;
        et_argbuf_init(&ab, pbuf, sizeof(pbuf));
        et_pack_uint32(&ab, (uint32_t)(UINT_PTR)hObject);
        uint32_t err = 0;
        et_call(CMD_FAMILY_MEMORY_MAP, CMD_FILE_MAP_CLOSE, pbuf, ab.pos, &err);
        return (err == 0) ? TRUE : FALSE;
    }
    return CloseHandle(hObject);
}

/* Liveness probe */
BOOL WINAPI ET32_Ping(void)
{
    uint8_t pbuf[4];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_null(&ab);
    uint32_t err = 0;
    uint32_t resp = et_call(CMD_FAMILY_COMPOUND_OPS, CMD_CTRL_PING,
                             pbuf, ab.pos, &err);
    return (err == 0 && resp == CMD_CTRL_ACK) ? TRUE : FALSE;
}

/* ============================================================================
 * IAT PATCHING ENGINE
 * Scans the target executable's Import Address Table and replaces pointers
 * for all bridged APIs with our hook function pointers.
 * ============================================================================ */

/* Map: original function name → hook function pointer */
typedef struct {
    const char *name;
    FARPROC     hook;
} et_iat_entry;

static const et_iat_entry g_iat_hooks[] = {
    { "VirtualAlloc",         (FARPROC)ET32_VirtualAlloc         },
    { "VirtualFree",          (FARPROC)ET32_VirtualFree          },
    { "VirtualProtect",       (FARPROC)ET32_VirtualProtect       },
    { "VirtualQuery",         (FARPROC)ET32_VirtualQuery         },
    { "CreateFileMappingA",   (FARPROC)ET32_CreateFileMappingA   },
    { "CreateFileMappingW",   (FARPROC)ET32_CreateFileMappingW   },
    { "MapViewOfFile",        (FARPROC)ET32_MapViewOfFile        },
    { "LoadLibraryA",         (FARPROC)ET32_LoadLibraryA         },
    { "LoadLibraryW",         (FARPROC)ET32_LoadLibraryW         },
    { "LoadLibraryExA",       (FARPROC)ET32_LoadLibraryExA       },
    { "LoadLibraryExW",       (FARPROC)ET32_LoadLibraryExW       },
    { "FreeLibrary",          (FARPROC)ET32_FreeLibrary          },
    { "GetProcAddress",       (FARPROC)ET32_GetProcAddress       },
    { "CreateProcessA",       (FARPROC)ET32_CreateProcessA       },
    { "CreateProcessW",       (FARPROC)ET32_CreateProcessW       },
    { "OpenProcess",          (FARPROC)ET32_OpenProcess          },
    { "GetSystemInfo",        (FARPROC)ET32_GetSystemInfo        },
    { "RegOpenKeyExA",        (FARPROC)ET32_RegOpenKeyExA        },
    { "RegOpenKeyExW",        (FARPROC)ET32_RegOpenKeyExW        },
    { "RegQueryValueExA",     (FARPROC)ET32_RegQueryValueExA     },
    { "RegQueryValueExW",     (FARPROC)ET32_RegQueryValueExW     },
    { "RegSetValueExA",       (FARPROC)ET32_RegSetValueExA       },
    { "RegSetValueExW",       (FARPROC)ET32_RegSetValueExW       },
    { "CreateFileA",          (FARPROC)ET32_CreateFileA          },
    { "CreateFileW",          (FARPROC)ET32_CreateFileW          },
    { "SetFilePointerEx",     (FARPROC)ET32_SetFilePointerEx     },
    { "CloseHandle",          (FARPROC)ET32_CloseHandle          },
    { "CreateEventA",         (FARPROC)ET32_CreateEventA         },
    { "CreateMutexA",         (FARPROC)ET32_CreateMutexA         },
    { NULL, NULL }
};

#define MAX_SAVED_HOOKS 64

typedef struct {
    FARPROC *iat_slot;
    FARPROC  original;
} et_saved_hook;

static et_saved_hook g_saved_hooks[MAX_SAVED_HOOKS];
static int           g_n_saved_hooks = 0;

static BOOL et_write_ptr(FARPROC *slot, FARPROC new_fn)
{
    DWORD old_prot, dummy;
    if (!VirtualProtect(slot, sizeof(FARPROC), PAGE_READWRITE, &old_prot))
        return FALSE;
    *slot = new_fn;
    VirtualProtect(slot, sizeof(FARPROC), old_prot, &dummy);
    return TRUE;
}

static void et_patch_iat_for_module(HMODULE hMod)
{
    BYTE *base = (BYTE *)hMod;

    /* Read DOS header */
    IMAGE_DOS_HEADER *dos = (IMAGE_DOS_HEADER *)base;
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return;

    IMAGE_NT_HEADERS *nt = (IMAGE_NT_HEADERS *)(base + dos->e_lfanew);
    if (nt->Signature != IMAGE_NT_SIGNATURE) return;

    DWORD import_rva = nt->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT].VirtualAddress;
    if (!import_rva) return;

    IMAGE_IMPORT_DESCRIPTOR *imp = (IMAGE_IMPORT_DESCRIPTOR *)(base + import_rva);

    for (; imp->OriginalFirstThunk; imp++) {
        /* Walk thunks */
        IMAGE_THUNK_DATA *orig = (IMAGE_THUNK_DATA *)(base + imp->OriginalFirstThunk);
        IMAGE_THUNK_DATA *iat  = (IMAGE_THUNK_DATA *)(base + imp->FirstThunk);

        for (; orig->u1.AddressOfData; orig++, iat++) {
            if (IMAGE_SNAP_BY_ORDINAL(orig->u1.Ordinal)) continue;

            IMAGE_IMPORT_BY_NAME *ibn =
                (IMAGE_IMPORT_BY_NAME *)(base + (DWORD)orig->u1.AddressOfData);
            const char *func_name = (const char *)ibn->Name;

            /* Check if this function is in our hook table */
            int i;
            for (i = 0; g_iat_hooks[i].name; i++) {
                if (lstrcmpA(func_name, g_iat_hooks[i].name) == 0) {
                    FARPROC *slot = (FARPROC *)&iat->u1.Function;

                    if (g_n_saved_hooks < MAX_SAVED_HOOKS) {
                        g_saved_hooks[g_n_saved_hooks].iat_slot = slot;
                        g_saved_hooks[g_n_saved_hooks].original  = *slot;
                        g_n_saved_hooks++;
                    }
                    et_write_ptr(slot, g_iat_hooks[i].hook);
                    break;
                }
            }
        }
    }
}

static void et_patch_iat_all(void)
{
    /* Patch the main executable module */
    HMODULE hExe = GetModuleHandleA(NULL);
    if (hExe) et_patch_iat_for_module(hExe);

    /* Also patch any already-loaded DLLs except ourselves */
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, 0);
    if (snap == INVALID_HANDLE_VALUE) return;

    MODULEENTRY32 me;
    me.dwSize = sizeof(me);
    if (Module32First(snap, &me)) {
        do {
            HMODULE h = me.hModule;
            if (h && h != hExe) {
                et_patch_iat_for_module(h);
            }
        } while (Module32Next(snap, &me));
    }
    CloseHandle(snap);
}

static void et_restore_iat(void)
{
    int i;
    for (i = 0; i < g_n_saved_hooks; i++) {
        et_write_ptr(g_saved_hooks[i].iat_slot, g_saved_hooks[i].original);
    }
    g_n_saved_hooks = 0;
}

/* ============================================================================
 * PUBLIC EXPORTS
 * ============================================================================ */

/*
 * ET32_Init — called by the broker after injecting the DLL.
 * broker_pid: the PID of the 64-bit broker process.
 * Returns TRUE on success (pipe connected + handshake complete).
 */
__declspec(dllexport)
BOOL WINAPI ET32_Init(DWORD broker_pid)
{
    if (g_initialised) return TRUE;

    g_target_pid = GetCurrentProcessId();
    g_broker_pid = broker_pid;

    InitializeCriticalSection(&g_pipe_cs);

    if (!et_pipe_connect()) {
        DeleteCriticalSection(&g_pipe_cs);
        return FALSE;
    }

    if (!et_do_handshake()) {
        et_pipe_disconnect();
        DeleteCriticalSection(&g_pipe_cs);
        return FALSE;
    }

    /* Install IAT hooks */
    et_patch_iat_all();

    g_initialised = TRUE;
    return TRUE;
}

/*
 * ET32_Shutdown — restore IAT hooks and disconnect from broker.
 */
__declspec(dllexport)
void WINAPI ET32_Shutdown(void)
{
    if (!g_initialised) return;

    et_restore_iat();

    /* Send shutdown notification */
    uint8_t pbuf[4];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_null(&ab);
    uint32_t err = 0;
    et_call(CMD_FAMILY_COMPOUND_OPS, CMD_CTRL_SHUTDOWN, pbuf, ab.pos, &err);

    et_pipe_disconnect();
    DeleteCriticalSection(&g_pipe_cs);
    g_initialised = FALSE;
}

/*
 * ET32_IsConnected — liveness probe.
 */
__declspec(dllexport)
BOOL WINAPI ET32_IsConnected(void)
{
    if (!g_connected) return FALSE;
    return ET32_Ping();
}

/*
 * ET32_GetVersion — returns DLL version as uint32.
 */
__declspec(dllexport)
DWORD WINAPI ET32_GetVersion(void)
{
    return ET_DLL_VERSION;
}

/*
 * ET32_BridgeVirtualAlloc — explicit public bridge-to-64-bit VirtualAlloc.
 * Size must fit in SIZE_T (32-bit); for larger sizes use ET32_BridgeVirtualAlloc64.
 */
__declspec(dllexport)
LPVOID WINAPI ET32_BridgeVirtualAlloc(LPVOID hint, SIZE_T size, DWORD type, DWORD prot)
{
    return ET32_VirtualAlloc(hint, size, type, prot);
}

/*
 * ET32_BridgeVirtualAlloc64 — allocate a 64-bit region; returns bridge handle.
 * size_lo / size_hi form a 64-bit byte count.
 */
__declspec(dllexport)
DWORD WINAPI ET32_BridgeVirtualAlloc64(
    DWORD hint_lo, DWORD hint_hi,
    DWORD size_lo, DWORD size_hi,
    DWORD alloc_type, DWORD protect)
{
    uint8_t pbuf[48];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    uint64_t hint = ((uint64_t)hint_hi << 32) | (uint64_t)hint_lo;
    uint64_t size = ((uint64_t)size_hi << 32) | (uint64_t)size_lo;
    et_pack_uint64(&ab, hint);
    et_pack_uint64(&ab, size);
    et_pack_uint32(&ab, alloc_type);
    et_pack_uint32(&ab, protect);

    uint32_t err = 0;
    return et_call(CMD_FAMILY_MEMORY_BASIC, CMD_VIRT_ALLOC, pbuf, ab.pos, &err);
}

/*
 * ET32_BridgeLoadLibrary64 — load a 64-bit DLL via broker; returns bridge handle.
 */
__declspec(dllexport)
DWORD WINAPI ET32_BridgeLoadLibrary64(LPCSTR dll_path)
{
    uint8_t pbuf[ET_IPC_BUFFER_SIZE / 4];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_strA(&ab, dll_path);
    uint32_t err = 0;
    return et_call(CMD_FAMILY_DLL_OPS, CMD_DLL_LOAD, pbuf, ab.pos, &err);
}

/*
 * ET32_BridgeGetProcAddress64 — get a proc address from a 64-bit bridge DLL handle.
 */
__declspec(dllexport)
DWORD WINAPI ET32_BridgeGetProcAddress64(DWORD bridge_handle, LPCSTR proc_name)
{
    uint8_t pbuf[ET_IPC_BUFFER_SIZE / 4];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_uint32(&ab, bridge_handle);
    et_pack_strA(&ab, proc_name);
    uint32_t err = 0;
    return et_call(CMD_FAMILY_DLL_OPS, CMD_DLL_GETPROC, pbuf, ab.pos, &err);
}

/*
 * ET32_BridgeCall64 — call a 64-bit function via broker.
 * func_handle: result of ET32_BridgeGetProcAddress64.
 * arg0..arg3: uint32 arguments (passed as packed uint32 args).
 * Returns the uint32 result.
 */
__declspec(dllexport)
DWORD WINAPI ET32_BridgeCall64(DWORD func_handle,
                                DWORD arg0, DWORD arg1, DWORD arg2, DWORD arg3)
{
    uint8_t pbuf[48];
    et_arg_buf ab;
    et_argbuf_init(&ab, pbuf, sizeof(pbuf));
    et_pack_uint32(&ab, func_handle);
    et_pack_uint32(&ab, arg0);
    et_pack_uint32(&ab, arg1);
    et_pack_uint32(&ab, arg2);
    et_pack_uint32(&ab, arg3);
    uint32_t err = 0;
    return et_call(CMD_FAMILY_DLL_OPS, CMD_DLL_CALL, pbuf, ab.pos, &err);
}

/*
 * ET32_BridgeRegOpenKey64 — open a 64-bit registry key bypassing WOW64.
 */
__declspec(dllexport)
LONG WINAPI ET32_BridgeRegOpenKey64(HKEY root, LPCSTR subkey, REGSAM access, PHKEY out)
{
    return ET32_RegOpenKeyExA(root, subkey, 0, access, out);
}

/*
 * ET32_PythonExec64 — execute Python code in the 64-bit broker's interpreter.
 */
__declspec(dllexport)
BOOL WINAPI ET32_PythonExec64(LPCSTR code, DWORD *result_out)
{
    return ET32_PythonExec(code, result_out);
}

/* ============================================================================
 * DLL ENTRY POINT
 * ============================================================================ */

BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
    (void)hinstDLL;
    (void)lpvReserved;

    switch (fdwReason) {
    case DLL_PROCESS_ATTACH:
        /* Disable per-thread notifications for performance */
        DisableThreadLibraryCalls(hinstDLL);
        /*
         * Do NOT auto-connect here — broker must call ET32_Init(broker_pid)
         * explicitly after injecting the DLL. This prevents deadlock if
         * DllMain is called from within the loader lock context.
         */
        break;

    case DLL_PROCESS_DETACH:
        if (g_initialised) {
            ET32_Shutdown();
        }
        break;
    }
    return TRUE;
}
