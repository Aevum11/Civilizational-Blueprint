/* ============================================================================
 * et_med_elegance.c — Elegance Score and Magical Impedance
 * ----------------------------------------------------------------------------
 *  Identification: a ratio's elegance is the product of three orthogonal
 *  factors:
 *      symmetry_factor  = N / d                   (sublattice symmetry)
 *      tightness_factor = 100 / (100 + |eps|)    (lattice attractor proximity)
 *      simplicity_factor = 100 / (p + q)          (rational simplicity)
 *
 *  Subsumption: this is the same Elegance Score used by music theory, fractal
 *  generation, and the ET fine-structure-constant derivation; medical use is
 *  one application of the same formula.
 *
 *  Magical Impedance xi(d) = A_0 / ((d-1)^2 + S^2) where S = number of
 *  manifold states (= 4) and A_0 = local-EM constant 137. This is the
 *  CORRECTED form per Projection Guide §43.
 *
 *  xi(1) = 137/16 = 8.5625    (gravitational class — strongest binding)
 *  xi(2) = 137/17 = 8.0588    (bimodal/tritone)
 *  xi(3) = 137/20 = 6.85      (cubic/strong)
 *  xi(4) = 137/25 = 5.48      (quartic/weak)
 *  xi(5) = 137/32 = 4.281
 *  xi(6) = 137/41 = 3.341
 *  xi(7) = 137/52 = 2.6346    (septic/sacred-7)
 *  xi(12)= 137/137 = 1.0000   (full-resolution unit reference)
 * ========================================================================= */
#include "libet_med.h"
#include "et_med_internal.h"

#include <math.h>
#include <stdlib.h>
#include <string.h>

LIBET_MED_API double et_magical_impedance(int d, int S, int A0_local) {
    /* Identification: xi(d) is the binding strength on sublattice family d.
     * Descriptor Gap: the formula xi(d) = A_0 / ((d-1)^2 + S^2) is derived
     * from the (D-1)^2 displacement squared norm + the S^2 manifold-state
     * cross term. */
    if (d < 1) {
        _et_error(ET_ERR_INVALID_ARG, "d must be >= 1 in et_magical_impedance");
        return NAN;
    }
    if (S < 1 || A0_local < 1) {
        _et_error(ET_ERR_INVALID_ARG, "S and A0_local must be >= 1");
        return NAN;
    }
    double denom = (double)(d - 1) * (double)(d - 1) + (double)S * (double)S;
    return (double)A0_local / denom;
}

/* ----------------------------------------------------------------------------
 * Best rational approximation by continued fractions.
 *  This is a clean, well-known algorithm; the only twist is that we cap by
 *  max_denom rather than by depth.
 * ------------------------------------------------------------------------- */
LIBET_MED_API et_error_t et_best_rational(double r, int max_denom,
                                          int* p_out, int* q_out) {
    if (p_out == NULL || q_out == NULL) {
        _et_error(ET_ERR_INVALID_ARG, "et_best_rational needs non-null outs");
        return ET_ERR_INVALID_ARG;
    }
    if (!et_is_finite(r) || r <= 0.0) {
        _et_error(ET_ERR_INVALID_RATIO, "r must be > 0 and finite");
        return ET_ERR_INVALID_RATIO;
    }
    if (max_denom < 1) {
        _et_error(ET_ERR_INVALID_ARG, "max_denom must be >= 1");
        return ET_ERR_INVALID_ARG;
    }

    /* Continued-fraction expansion: r = a0 + 1/(a1 + 1/(a2 + ...))
     * Convergents h_n/k_n by:
     *   h_-1 = 1, h_0 = a0
     *   k_-1 = 0, k_0 = 1
     *   h_n = a_n*h_{n-1} + h_{n-2}
     *   k_n = a_n*k_{n-1} + k_{n-2}
     * Stop when next convergent would exceed max_denom. */
    double x = r;
    long h_prev = 1, h_curr = (long)floor(x);
    long k_prev = 0, k_curr = 1;
    /* Safety on very large floor values (e.g. r huge) — clamp to int range */
    if (h_curr > (long)max_denom * 1000L) {
        _et_error(ET_ERR_FALLBACK_USED,
                  "ratio is huge — best rational is essentially r/1");
        *p_out = (int)((double)max_denom * r);
        *q_out = max_denom;
        return ET_OK;
    }

    /* If x is already an integer, we're done. */
    double frac = x - (double)h_curr;
    if (fabs(frac) < 1e-15) {
        *p_out = (int)h_curr;
        *q_out = 1;
        return ET_OK;
    }

    int max_iter = 64; /* CF expansion of an irrational converges fast */
    for (int i = 0; i < max_iter; ++i) {
        x = 1.0 / frac;
        long a_n = (long)floor(x);
        long h_next = a_n * h_curr + h_prev;
        long k_next = a_n * k_curr + k_prev;

        if (k_next > (long)max_denom || h_next > (long)2147483647L / 2) {
            break;
        }
        h_prev = h_curr; h_curr = h_next;
        k_prev = k_curr; k_curr = k_next;

        frac = x - (double)a_n;
        if (fabs(frac) < 1e-15) break;
    }

    *p_out = (int)h_curr;
    *q_out = (int)k_curr;
    return ET_OK;
}

/* ----------------------------------------------------------------------------
 * Elegance Score
 * ------------------------------------------------------------------------- */
LIBET_MED_API et_error_t et_elegance_score(double r, int N, int max_denom,
                                           et_elegance_t* out) {
    if (out == NULL) {
        _et_error(ET_ERR_INVALID_ARG, "et_elegance_score needs non-null out");
        return ET_ERR_INVALID_ARG;
    }
    memset(out, 0, sizeof(*out));

    /* Project to obtain d and eps. */
    et_projection_t proj;
    et_error_t e = et_project_real(r, N, &proj);
    if (e != ET_OK) return e;

    /* Best rational approximation. */
    int p, q;
    e = et_best_rational(r, max_denom, &p, &q);
    if (e != ET_OK) return e;

    out->r                 = r;
    out->p                 = p;
    out->q                 = q;
    out->p_plus_q          = p + q;
    out->d                 = proj.d;
    out->eps_cents         = proj.eps_cents;
    out->symmetry_factor   = (double)N / (double)proj.d;
    out->tightness_factor  = 100.0 / (100.0 + fabs(proj.eps_cents));
    /* Avoid division-by-zero for r=1 (p+q = 2 minimum). */
    int denom_pq = out->p_plus_q;
    if (denom_pq < 1) {
        _et_error(ET_ERR_FALLBACK_USED, "p+q < 1 — clamped to 1");
        denom_pq = 1;
    }
    out->simplicity_factor = 100.0 / (double)denom_pq;
    out->elegance          = out->symmetry_factor *
                             out->tightness_factor *
                             out->simplicity_factor;

    if (!et_is_finite(out->elegance)) {
        _et_error(ET_ERR_NUMERIC, "elegance produced non-finite");
        return ET_ERR_NUMERIC;
    }
    return ET_OK;
}
