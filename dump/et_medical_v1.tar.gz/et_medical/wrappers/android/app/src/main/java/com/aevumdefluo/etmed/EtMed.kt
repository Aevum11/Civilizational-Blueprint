/* ============================================================================
 * EtMed.kt — Kotlin facade over libet_med_jni.so
 * ----------------------------------------------------------------------------
 *  Identification: this is the Android Kotlin projection of the C ABI. All
 *  native calls are wrapped in idiomatic Kotlin types; failures surface as
 *  either nullable results or EtMedException.
 *
 *  Subsumption: mirrors the Windows C# / WebAssembly JS facades — same
 *  names, same semantics, same fallback logging contract.
 * ========================================================================= */
package com.aevumdefluo.etmed

enum class EtError(val code: Int) {
    Ok(0), InvalidRatio(1), InvalidN(2), InvalidArg(3),
    OutOfMemory(4), UnknownTower(5), IncompleteBaseline(6),
    FallbackUsed(7), CascadeStabilityExceeded(8),
    OffLattice(9), Numeric(10), Last(11);

    companion object {
        fun fromCode(c: Int): EtError = values().firstOrNull { it.code == c } ?: Last
    }
}

enum class Tower(val code: Int) {
    Cardiac(0), Respiratory(1), Neural(2), Endocrine(3), Immune(4),
    Digestive(5), Renal(6), Musculoskeletal(7), Reproductive(8),
    Developmental(9);

    companion object {
        val count = 10
        fun fromCode(c: Int): Tower = values().firstOrNull { it.code == c } ?: Cardiac
    }
}

enum class Sex(val code: Int) {
    Female(0), Male(1), Unspecified(2);
    companion object {
        fun fromCode(c: Int): Sex = values().firstOrNull { it.code == c } ?: Unspecified
    }
}

enum class ManifoldState(val code: Int) {
    Exception(0), Unsubstantiated(1), Mediation(2), Incoherence(3);
    companion object {
        fun fromCode(c: Int): ManifoldState =
            values().firstOrNull { it.code == c } ?: Exception
    }
}

enum class IncoherenceLevel(val code: Int) {
    None(0), L1Categorical(1), L2Binding(2),
    L3Cascade(3), L4Stability(4), L5Coherence(5);
    companion object {
        fun fromCode(c: Int): IncoherenceLevel =
            values().firstOrNull { it.code == c } ?: None
    }
}

class EtMedException(val err: EtError, msg: String) : Exception(msg)

data class PatientBaseline(
    @JvmField var hrRestBpm      : Double = Double.NaN,
    @JvmField var rrRestPerMin   : Double = Double.NaN,
    @JvmField var temperatureC   : Double = Double.NaN,
    @JvmField var sbpRestMmHg    : Double = Double.NaN,
    @JvmField var dbpRestMmHg    : Double = Double.NaN,
    @JvmField var spo2Pct        : Double = Double.NaN,
    @JvmField var gaitCycleS     : Double = Double.NaN,
    @JvmField var menstrualCycleD: Double = Double.NaN,
    @JvmField var ageYears       : Double = Double.NaN,
    @JvmField var sex            : Int    = Sex.Unspecified.code
)

data class Projection(
    val r: Double, val log2R: Double, val exactPos: Double,
    val k: Int, val g: Int, val d: Int,
    val epsCents: Double, val n: Int
)

data class Finding(
    val name: String,
    val state: ManifoldState,
    val incoherenceLevel: IncoherenceLevel,
    val tower: Tower,
    val latticeResolution: Int,
    val projection: Projection,
    val severityPct: Double,
    val urgencyRank: Int
)

data class MultifoldSignature(
    val scalar: Double,
    val normalizedVsReference: Double,
    val r0Seconds: DoubleArray,
    val r0Present: BooleanArray
)

object EtMed {
    init { System.loadLibrary("et_med_jni") }

    /* Constants (mirrored from C) */
    val vBase:    Double = nativeVBase()
    val kKoide:   Double = nativeKKoide()
    val a0LocalEm: Int    = nativeA0LocalEm()
    val biologicalFloor: Int = nativeBiologicalFloor()
    val corticalFloor: Int   = nativeCorticalFloor()

    /* ---- Public API ----------------------------------------------------- */
    fun projectReal(r: Double, n: Int): Projection {
        val buf = nativeProjectReal(r, n)
            ?: throw EtMedException(EtError.InvalidRatio,
                    "projectReal($r, $n) failed")
        return Projection(
            r = buf[0], log2R = buf[1], exactPos = buf[2],
            k = buf[3].toInt(), g = buf[4].toInt(), d = buf[5].toInt(),
            epsCents = buf[6], n = buf[7].toInt()
        )
    }

    fun magicalImpedance(d: Int, s: Int = 4, a0: Int = a0LocalEm): Double =
        nativeMagicalImpedance(d, s, a0)

    fun palindromeD(nMod12: Int): Int = nativePalindromeD(nMod12)
    fun shimmer(n: Int): Double       = nativeShimmer(n)

    fun towerName(t: Tower): String         = nativeTowerName(t.code)
    fun towerDefaultR0(t: Tower): Double    = nativeTowerDefaultR0(t.code)
    fun towerResolution(t: Tower): Int      = nativeTowerResolution(t.code)
    fun towerReferenceBaseline(t: Tower): Double =
        nativeTowerReferenceBaseline(t.code)

    fun errorString(e: EtError): String     = nativeErrorString(e.code)
    fun fallbackCount(): Long               = nativeFallbackCount()
    fun resetFallbackCount()                = nativeResetFallbackCount()

    fun computeMultifoldSignature(b: PatientBaseline,
                                  fallbackAllowed: Boolean = true): MultifoldSignature {
        val buf = nativeComputeMultifold(b, fallbackAllowed)
            ?: throw EtMedException(EtError.Numeric, "multifold failed")
        val n = Tower.count
        val r0  = DoubleArray(n)
        val pres = BooleanArray(n)
        for (i in 0 until n) {
            r0[i]  = buf[2 + i]
            pres[i] = buf[2 + n + i] != 0.0
        }
        return MultifoldSignature(
            scalar = buf[0], normalizedVsReference = buf[1],
            r0Seconds = r0, r0Present = pres
        )
    }

    fun classifyMeasurement(name: String, currentValue: Double,
                            baselineValue: Double = Double.NaN,
                            tower: Tower,
                            baseline: PatientBaseline,
                            fallbackAllowed: Boolean = true): Finding {
        val buf = nativeClassifyMeasurement(
            name, currentValue, baselineValue, tower.code, baseline, fallbackAllowed
        ) ?: throw EtMedException(EtError.Numeric, "classify failed")
        val proj = Projection(
            r = currentValue / (if (baselineValue.isFinite() && baselineValue > 0)
                                   baselineValue else 1.0),
            log2R = 0.0, exactPos = 0.0,
            k = buf[4].toInt(), g = 0, d = buf[5].toInt(),
            epsCents = buf[6], n = buf[3].toInt()
        )
        return Finding(
            name = name,
            state = ManifoldState.fromCode(buf[0].toInt()),
            incoherenceLevel = IncoherenceLevel.fromCode(buf[1].toInt()),
            tower = Tower.fromCode(buf[2].toInt()),
            latticeResolution = buf[3].toInt(),
            projection = proj,
            severityPct = buf[7],
            urgencyRank = buf[8].toInt()
        )
    }

    /* ---- native ----------------------------------------------------------- */
    @JvmStatic private external fun nativeVBase(): Double
    @JvmStatic private external fun nativeKKoide(): Double
    @JvmStatic private external fun nativeA0LocalEm(): Int
    @JvmStatic private external fun nativeBiologicalFloor(): Int
    @JvmStatic private external fun nativeCorticalFloor(): Int

    @JvmStatic private external fun nativeProjectReal(r: Double, n: Int): DoubleArray?
    @JvmStatic private external fun nativeMagicalImpedance(d: Int, s: Int, a0: Int): Double
    @JvmStatic private external fun nativePalindromeD(n: Int): Int
    @JvmStatic private external fun nativeShimmer(n: Int): Double

    @JvmStatic private external fun nativeTowerName(t: Int): String
    @JvmStatic private external fun nativeTowerDefaultR0(t: Int): Double
    @JvmStatic private external fun nativeTowerResolution(t: Int): Int
    @JvmStatic private external fun nativeTowerReferenceBaseline(t: Int): Double

    @JvmStatic private external fun nativeErrorString(err: Int): String
    @JvmStatic private external fun nativeFallbackCount(): Long
    @JvmStatic private external fun nativeResetFallbackCount()

    @JvmStatic private external fun nativeComputeMultifold(
        b: PatientBaseline, fallbackAllowed: Boolean): DoubleArray?

    @JvmStatic private external fun nativeClassifyMeasurement(
        name: String, currentValue: Double, baselineValue: Double,
        tower: Int, baseline: PatientBaseline, fallbackAllowed: Boolean): DoubleArray?
}
