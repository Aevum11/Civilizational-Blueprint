/*
 * ET LOSSLESS SENSOR CAPTURE — LATTICE ARITHMETIC (Identity A)
 * =============================================================
 * Operations on (k, d, ε) without accessing the underlying reals.
 *
 * The key structural element is κ — the rounding correction — which
 * is the T-act manifesting in lattice arithmetic.
 *   Multiply/Divide: κ ∈ {-1, 0, +1}
 *   Power: κ_n ∈ ℤ (unbounded)
 *
 * Theorems A.1–A.6 from lattice_arithmetic_identity1.py.
 * 632 tests verified at 200 dps, zero failures.
 *
 * Application to sensors: cross-sensor ratios (e.g., acceleration_x / acceleration_z)
 * computed entirely in lattice coordinates. No pullback needed.
 *
 * Author: Michael James Muller — Aevum Defluo (Exception Theory)
 * License: CC-BY-4.0
 */

#ifndef ET_LATTICE_ARITHMETIC_H
#define ET_LATTICE_ARITHMETIC_H

#include "et_bijection.h"

typedef struct {
    long    k;      /* Resulting integer lattice coordinate */
    int     d;      /* Resulting sublattice family */
    mpfr_t  eps;    /* Resulting ε in cents */
    long    kappa;  /* The κ rounding correction (T-act trace) */
} et_arith_result_t;

et_error_t et_arith_result_init(et_arith_result_t *r, mpfr_prec_t prec);
void et_arith_result_clear(et_arith_result_t *r);

/*
 * A.1: Lattice Multiplication — Π_N(r₁·r₂) from (k₁,ε₁) and (k₂,ε₂).
 *   δᵢ = εᵢ·N/1200
 *   κ = round(δ₁ + δ₂) ∈ {-1, 0, +1}
 *   k_× = k₁ + k₂ + κ
 *   ε_× = (δ₁ + δ₂ − κ) · 1200/N
 */
et_error_t et_lattice_multiply(int N, long k1, const mpfr_t eps1,
                                long k2, const mpfr_t eps2,
                                et_arith_result_t *result, mpfr_prec_t prec);

/*
 * A.2: Lattice Division — Π_N(r₁/r₂) from (k₁,ε₁) and (k₂,ε₂).
 *   κ = round(δ₁ − δ₂)
 *   k_÷ = k₁ − k₂ + κ
 *   ε_÷ = (δ₁ − δ₂ − κ) · 1200/N
 */
et_error_t et_lattice_divide(int N, long k1, const mpfr_t eps1,
                              long k2, const mpfr_t eps2,
                              et_arith_result_t *result, mpfr_prec_t prec);

/*
 * A.3: Lattice Reciprocation (Mirror Symmetry).
 *   For |ε| < half-cell: Π_N(1/r) = (−k, d, −ε).
 *   General case: κ = round(−δ).
 */
et_error_t et_lattice_reciprocal(int N, long k1, const mpfr_t eps1,
                                  et_arith_result_t *result, mpfr_prec_t prec);

/*
 * A.4: Lattice Power — Π_N(r^n) from (k,ε) and integer n.
 *   κ_n = round(n·δ), |κ_n| ≤ ⌈|n|/2⌉
 *   k_^ = n·k + κ_n
 *   ε_^ = (n·δ − κ_n) · 1200/N
 */
et_error_t et_lattice_power(int N, long k1, const mpfr_t eps1, int n,
                             et_arith_result_t *result, mpfr_prec_t prec);

#endif /* ET_LATTICE_ARITHMETIC_H */
