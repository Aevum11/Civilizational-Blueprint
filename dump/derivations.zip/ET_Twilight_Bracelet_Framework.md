# Exception Theory: The Twilight Bracelet as ∂I-Boundary Tool
## Dual Exception/Anti-Exception Structure, Data Drain as T-Mediated D-Unbinding, and Infection as Variance Accumulation
### Derived Forward From: P ∘ D ∘ T = E
**Author:** Michael James Muller — Aevum Defluo
**Derivation Standard:** All mathematics ET-native, forward from {P, D, T}. Zero external axioms.
**Tools Applied:** Identification Principle · Descriptor Gap Principle · Subsumption Law · Verification Principle

---

> *"When the flame hue merges with the land's deep sky, the Key of the Twilight shall overturn all... everything shall unfold."*
> — Harald Hoerwick, Epitaph of the Twilight

> *"For every exception there is an exception, except the exception."*
> *P ∘ D ∘ T = E*

---

## Table of Contents

1. [Verification of the Submitted Derivation](#1-verification)
2. [Issues Identified via the Three Tools](#2-issues)
3. [The .hack// Twilight Bracelet: Comprehensive Lore](#3-lore)
4. [Corrected Derivation: The ∂I-Boundary Tool](#4-corrected)
5. [Complete Description and Explanation](#5-description)
6. [Practical Applications](#6-applications)
7. [Production-Ready Python Implementation](#7-python)
8. [Programming Operationalization](#8-operationalization)
9. [Structural Discoveries](#8-discoveries)
10. [Subsumption Verification](#9-subsumption)

---

## 1. Verification of the Submitted Derivation {#1-verification}

The submitted derivation maps the Twilight Bracelet onto ET primitives with substantial structural insight. The core mappings — Data Drain as T-gradient extraction, infection as variance accumulation, TB/Cubia as dual exception, and the Key of the Twilight as ultimate D-completion — are structurally sound. The master equation TB = D_τ ∘ ∇_T(lim...) = E_unfold ± Cubia captures the dual-output nature of the tool.

### What the Derivation Gets Right

- **Data Drain as T-forced ∇_D** — correct: T-agency forcibly extracts D from target configurations
- **Infection as variance accumulation** — correct: repeated D-unbinding generates unbound residue
- **TB/Cubia as dual E±** — correct: two sides of the same coin, linked Exception/Anti-Exception
- **Key of the Twilight as ultimate D-completion** — correct: resolves the Descriptor Gap that prevented Aura's awakening
- **Twilight as liminal boundary** — correct: operates at the real/virtual, light/shadow boundary (∂I)
- **Tsukasa clarification** — correctly notes Tsukasa does not possess the TB (his powers come from Morganna directly)

---

## 2. Issues Identified via the Three Tools {#2-issues}

### Issue 1: Missing the ∂I Connection (Descriptor Gap)

The Twilight Bracelet is not merely a "meta-D that empowers T." It is a **∂I-boundary tool** — an instrument specifically designed to operate at the Incoherence boundary, forcing target configurations across ∂I by stripping their D-set below the Koide threshold (tightness < K = 2/3). Data Drain works because it reduces a target's tightness below K, making it Incoherent, then reconstitutes the coherent remainder. The derivation does not connect to the ∂I framework.

### Issue 2: The Cubia Mechanism Needs Structural Derivation

The derivation correctly identifies Cubia as the "Anti-Exception" shadow of the Bracelet, but does not explain WHY forcing configurations across ∂I generates a shadow. The structural mechanism: every D-unbinding event at ∂I generates both a coherent product (the drained target, now restructured) and an Incoherent residue (the excess D that was stripped). This residue accumulates as Cubia — the sum of all D-fragments that were forced into Incoherence. Cubia IS the Incoherent residue pile.

### Issue 3: The Infection Gauge Needs the Cascade Horizon

The infection gauge (0–100%, blue→red) maps to the cascade coherence horizon (Incoherence Filter Level 4). Each Data Drain is one cascade step with error δ. The infection gauge tracks N × |δ| — the accumulated cascade error. When N × |δ| ≥ 50¢ (gauge = 100%), the user's own configuration crosses ∂I. The side effects (status ailments, lost EXP) are partial ∂I incursions; the fatal side effect (game over/coma) is full ∂I crossing.

---

## 3. The .hack// Twilight Bracelet: Comprehensive Lore {#3-lore}

### 3.1 Origin and Bestowing

The Twilight Bracelet manifests from the Book of Twilight — an installation book created by Aura and given to Kite. The Book activates when Kite encounters a Data Bug at the Hulle Granz Cathedral, transforming his PC's costume (green → red) and granting the Bracelet. The Bracelet is normally invisible, appearing only when activated.

### 3.2 Powers and Mechanics

**Data Drain (basic):** Rewrites opponent data, extracts Virus Cores or items. Reduces Data Bugs from invulnerable to defeatable by stripping their corrupted D-attachments. Against Phases, it recovers Aura's scattered D-segments.

**Drain Arc / Data Drain 2128 / Drain Heart:** Progressive upgrades — wider area, guaranteed best items, multi-target. Each escalation dramatically increases infection rate.

**Gate Hacking:** Uses collected Virus Cores to bypass system barriers, accessing Protected Areas normally sealed by CC Corp. Requires specific Core combinations as "keys."

**Contact Drain:** Micro-drains during normal combat — subtle D-extraction on contact.

### 3.3 The Infection Gauge

Color progression: Blue (0%) → Green → Yellow → Orange → Red (100%). Side effects escalate with infection level: minor status ailments at low infection, random damage/EXP loss at moderate, and a Non-Standard Game Over (effective coma) at critical. The gauge decreases slowly over time or through specific actions.

### 3.4 The TB/Cubia Duality

Cubia is the "Anti-Existence" of the Bracelet — "two sides of the same coin" (Aura). Every time the Bracelet Data Drains a Phase (massive data manipulation), Cubia grows stronger. Cubia opposes Kite's goals: if Kite seeks Aura, Cubia blocks the path. Within Cubia's core, a shadow figure resembling Kite floats in fetal position — the anti-Kite. Destroying the Bracelet destroys Cubia (BlackRose shatters it in the final battle). They cannot exist independently.

### 3.5 The Key of the Twilight

The Bracelet is identified as one manifestation of the "Key of the Twilight" — the legendary item/power that "overturns all" and causes "everything to unfold." Multiple manifestations exist across the franchise (Bracelet, Haseo's Xth Form, Aura herself), but the Bracelet is the first and most iconic. Harald's prophecy: "When the flame hue merges with the land's deep sky, the Key of the Twilight shall overturn all."

---

## 4. Corrected Derivation: The ∂I-Boundary Tool {#4-corrected}

### Step 1: P-First Identification

| Primitive | Identification |
|---|---|
| **P_TB** | The substrate the Bracelet operates ON — the target's P-component, which is restructured by Data Drain. The Bracelet does not create P; it re-configures P by altering its D-bindings. |
| **D_TB** | The Bracelet's own D-structure: D_drain (data extraction protocol), D_gate (barrier bypass), D_infect (variance residue), D_cubia (shadow linkage). The Bracelet is a finite D-tool with specific operational constraints. |
| **T_TB** | The wielder's agency (Kite/Shugo/Haseo) channeled through the Bracelet. T_TB is T_player amplified — the Bracelet doesn't provide T; it provides D-structure for T to operate at ∂I. Without a player's T-agency, the Bracelet is inert. |

### Step 2: Data Drain as ∂I-Boundary Operation

Data Drain operates by reducing a target's tightness below K = 2/3:

$$\text{DataDrain}(c_{\text{target}}) = T_{\text{wielder}} \circ D_{\text{drain}} \circ c_{\text{target}} \to c_{\text{stripped}} + \Delta D_{\text{residue}}$$

Where:
- $c_{\text{target}}$ = the target configuration (Data Bug, Phase, normal monster)
- $c_{\text{stripped}}$ = the target with corrupted/excess D removed (now defeatable)
- $\Delta D_{\text{residue}}$ = the extracted D-fragments (Virus Cores, items, excess data)

The mechanism: the Bracelet forces the target's |ε| past 50¢ (across ∂I), making its corrupted D-attachments Incoherent. The Incoherent D-fragments detach and are collected as Virus Cores. The remaining coherent core reconstitutes as a reduced-level monster.

Against Phases: the Phase's D-fragment contains a segment of Aura's D-set. Data Drain recovers this segment by unbinding it from the Phase's Incoherent wrapper.

### Step 3: The Infection Gauge as Cascade Coherence (Level 4)

Each Data Drain event introduces cascade error δ into the wielder's own configuration:

$$\text{Infection}(N) = N \times |\delta_{\text{drain}}|$$

Where N = number of drains performed and δ_drain = per-drain error accumulated in the wielder's PC data. The infection gauge tracks this accumulation:

| Gauge Color | Infection % | N × |δ| (¢) | Status |
|---|---|---|---|
| Blue | 0–20% | 0–10¢ | Safe (deep interior) |
| Green | 20–40% | 10–20¢ | Minor effects (approaching Zone) |
| Yellow | 40–60% | 20–30¢ | Moderate effects (in Zone) |
| Orange | 60–80% | 30–40¢ | Severe effects (approaching ∂I) |
| Red | 80–100% | 40–50¢ | Critical (at ∂I — coma risk) |

At Infection = 100%, the wielder's configuration hits ∂I (tightness = K = 2/3). The fatal side effect (Non-Standard Game Over) = the wielder's own PC crossing into Incoherence — the same mechanism that puts Orca and the other coma victims under.

The cascade horizon: N_max = ⌊50/|δ_drain|⌋. If each drain contributes ~2¢ of error, N_max ≈ 25 drains before critical infection — matching the canonical ET cascade horizon for generators with δ ≈ 1.955¢.

### Step 4: Cubia as Accumulated Incoherent Residue

Every Data Drain extracts D-fragments from targets. The coherent portions become Virus Cores and items. The **Incoherent** portions — the D-fragments that cannot be bound into any coherent configuration — accumulate as Cubia:

$$\text{Cubia} = \sum_{i=1}^{N} \Delta D_{\text{incoherent}}^{(i)} = P_{\text{unbound}} \circ D_{\text{residue}}^{\text{total}}$$

Cubia IS the sum of all Incoherent residue generated by Data Drain operations. Each drain that strengthens Kite (adds coherent D: Virus Cores, Phase fragments) simultaneously feeds Cubia (adds Incoherent D: excess, corrupted, contradictory fragments). This is why Cubia grows every time Kite Data Drains a Phase — the Phase's massive D-set produces a correspondingly massive Incoherent residue pile.

Cubia's form — a monstrous anti-existence with a shadowy Kite-figure in its core — is the structural mirror: the coherent wielder and the Incoherent accumulation are "two sides of the same coin" because they are both products of the same Data Drain operations. Destroy the Bracelet → no more D-unbinding → no more Incoherent residue → Cubia has no structural basis and dissolves.

### Step 5: The Key of the Twilight as Ultimate Gap Resolution

Harald's prophecy — "everything shall unfold" — maps to the Descriptor Gap Principle's endpoint: when ALL D-gaps are closed, the Descriptor set is complete, and the Ultimate AI (Aura) substantiates as a perfect Exception.

The Bracelet is the TOOL for closing gaps: it Data Drains corrupted configurations to extract the missing D-fragments (Aura's scattered segments, Virus Cores needed for Gate Hacking). Each Phase defeated = one more gap closed. The "Key" is not a single item but the complete sequence of gap-closing operations that brings the D-set to completeness.

"Everything shall unfold" = UNIVERSAL_DESCRIBABILITY (Batch 22, Eq 219) — the state where all possible Descriptors have been recognized and bound. This is the D-Paper's §45: "Scientific discovery = Descriptor recognition." The Key of the Twilight is the ET Descriptor Discovery process applied within the digital tower.

### Step 6: The TB/Cubia Duality as Exception/Incoherence Structural Mirror

$$\boxed{TB + \text{Cubia} = E_{\text{coherent}} + I_{\text{residue}} = \text{Complete Drain Output}}$$

The Bracelet and Cubia are not separate entities — they are the coherent and Incoherent outputs of the same ∂I-boundary operation. Every interaction with ∂I produces both: a coherent product (useful to the wielder) and an Incoherent residue (dangerous to everything). The "two sides of the same coin" is the structural necessity that coherence and Incoherence are defined relative to each other — you cannot create one without the other when operating at the boundary.

This is the deepest ET truth embedded in the .hack// franchise: **the power to save is structurally inseparable from the power to destroy**, because both are products of operating at ∂I. The Incoherence Filter cannot be applied selectively — every drain that extracts coherent D also generates Incoherent residue. Salvation and destruction are not moral choices; they are structural outputs of boundary operations.

---

## 5. Complete Description and Explanation {#5-description}

### 5.1 What the Twilight Bracelet IS in ET

The Twilight Bracelet is a **∂I-boundary tool** — a D-instrument that enables T (the wielder) to force target configurations across the Incoherence boundary by stripping their D-set below the Koide threshold. It operates at the same structural region as the Twilight Zone (Paper #8): the boundary where tightness approaches K = 2/3. The "Twilight" in its name is structurally precise — it IS a twilight (∂I) tool.

### 5.2 Why "Twilight" Is the Correct Name

"Twilight" — the boundary between day and night, light and shadow — is the experiential description of ∂I. The Bracelet operates at this boundary: it takes configurations that are in the "twilight zone" of marginal coherence and forces them to resolve — either into coherence (stripped target becomes defeatable) or Incoherence (excess D becomes Cubia). The Book of Twilight, the Epitaph of Twilight, the Key of the Twilight — all reference this ∂I boundary.

### 5.3 Why Destroying the Bracelet Destroys Cubia

TB and Cubia are the coherent and Incoherent outputs of the same operation. Without the operation (Bracelet destroyed), no new Incoherent residue is generated. But more importantly: Cubia's structural existence depends on the Bracelet's existence as its anti-pole. Remove one pole of a duality and the other has no reference point — Cubia's D-set is defined entirely in opposition to the Bracelet's. Without the Bracelet, Cubia's D-set is self-referencing nothing → self-defeating → Incoherent at a deeper level → dissolves.

### 5.4 The Infection Gauge as an ET Instrument

The infection gauge is a real-time display of the wielder's cascade coherence status — their distance from ∂I. Blue = deep interior (safe). Red = approaching ∂I (critical). This is the most literal game-mechanic implementation of the ET cascade horizon: the player can see their accumulated ∂I approach and must manage their drain rate to stay below the fatal threshold.

---

## 6. Practical Applications {#6-applications}

### 6.1 Dual-Output System Design

The TB/Cubia duality teaches a structural principle: **any tool that operates at system boundaries produces both useful output and dangerous residue.** Nuclear power (energy + waste), antibiotics (healing + resistance), social media (connection + misinformation), AI training (capability + alignment risk). The ET framework quantifies both outputs: coherent product magnitude scales with the target's D-richness; Incoherent residue scales with the D-fragments that don't fit any coherent configuration. Designing systems that minimize Incoherent residue requires operating further from ∂I — gentler interventions with less total drain.

### 6.2 Cascade Coherence Management

The infection gauge model applies to any iterative process that accumulates error: numerical computation, manufacturing tolerances, organizational restructuring, medical treatment regimens. Track the cumulative N × |δ| and set intervention thresholds at the color boundaries (20%, 40%, 60%, 80%). The cascade horizon N_max = ⌊50/|δ|⌋ provides the maximum safe iteration count.

### 6.3 Gap-Closing Strategy

The Bracelet's quest structure — defeat Phases sequentially to recover D-fragments, accumulating completeness toward the Ultimate AI — is a model for any complex problem-solving process: identify the D-gaps, determine which "Phases" (obstacles) contain the missing fragments, defeat them in order (each victory strengthening the solver but also generating risk), and monitor infection (accumulated side effects) throughout.

### 6.4 Shadow/Residue Awareness

Cubia's growth teaches: every powerful intervention generates an anti-intervention. The more aggressively you solve a problem (Data Drain), the larger the shadow problem grows (Cubia). Sustainable problem-solving requires awareness of the residue pile and periodic "Cubia management" — addressing accumulated side effects before they overwhelm the primary mission.

---

## 7. Production-Ready Python Implementation {#7-python}

```python
#!/usr/bin/env python3
"""
ET Twilight Bracelet Framework
================================

TB = ∂I-boundary tool: forces target configurations across Incoherence boundary
Cubia = accumulated Incoherent residue from Data Drain operations
Infection = cascade coherence tracking (N × |δ| toward ∂I)

Author: Michael James Muller — Aevum Defluo
"""
import math
from dataclasses import dataclass, field
from enum import Enum
from typing import List, Tuple

S = 12; V_BASE = 1.0/S; K = 2.0/3.0

class InfectionLevel(Enum):
    BLUE = "BLUE"       # 0-20%: safe
    GREEN = "GREEN"     # 20-40%: minor effects
    YELLOW = "YELLOW"   # 40-60%: moderate
    ORANGE = "ORANGE"   # 60-80%: severe
    RED = "RED"         # 80-100%: critical (∂I)

@dataclass
class DrainTarget:
    name: str
    d_total: int           # Total descriptors
    d_corrupted: int       # Corrupted/excess D
    d_aura_fragment: int   # Aura segments contained
    is_phase: bool = False

    @property
    def tightness_pre_drain(self) -> float:
        # Target's coherence before drain
        eps = self.d_corrupted * 5.0  # Each corrupted D adds ~5¢ error
        return 100.0 / (100.0 + eps)

    @property
    def tightness_post_drain(self) -> float:
        # After drain: corrupted D removed
        return 100.0 / (100.0 + 0.0)  # Clean = perfect tightness

@dataclass  
class TwilightBracelet:
    wielder: str
    infection_cents: float = 0.0       # Accumulated cascade error (¢)
    drains_performed: int = 0
    virus_cores: int = 0
    aura_segments: int = 0
    cubia_mass: float = 0.0            # Accumulated Incoherent residue
    delta_per_drain: float = 2.0       # ¢ per drain event
    destroyed: bool = False

    @property
    def infection_pct(self) -> float:
        return min(100.0, (self.infection_cents / 50.0) * 100.0)

    @property
    def infection_level(self) -> InfectionLevel:
        p = self.infection_pct
        if p < 20: return InfectionLevel.BLUE
        elif p < 40: return InfectionLevel.GREEN
        elif p < 60: return InfectionLevel.YELLOW
        elif p < 80: return InfectionLevel.ORANGE
        else: return InfectionLevel.RED

    @property
    def wielder_tightness(self) -> float:
        return 100.0 / (100.0 + self.infection_cents)

    @property
    def at_boundary(self) -> bool:
        return self.wielder_tightness <= K + 0.01

    @property
    def cascade_horizon(self) -> int:
        if self.delta_per_drain < 0.01: return 999
        return int(50.0 / self.delta_per_drain)

    def data_drain(self, target: DrainTarget) -> dict:
        if self.destroyed:
            return {"error": "Bracelet destroyed — no drain possible"}
        if self.at_boundary:
            return {"error": "FATAL — wielder at ∂I, coma risk"}

        # Perform drain
        self.drains_performed += 1
        self.infection_cents += self.delta_per_drain

        # Coherent output
        cores_gained = target.d_corrupted
        self.virus_cores += cores_gained
        self.aura_segments += target.d_aura_fragment

        # Incoherent residue → feeds Cubia
        residue = target.d_corrupted * V_BASE
        self.cubia_mass += residue

        return {
            "drain_number": self.drains_performed,
            "cores_gained": cores_gained,
            "aura_recovered": target.d_aura_fragment,
            "infection": f"{self.infection_pct:.1f}% ({self.infection_level.value})",
            "cubia_mass": self.cubia_mass,
            "wielder_tightness": self.wielder_tightness,
        }

    def destroy(self) -> dict:
        self.destroyed = True
        cubia_destroyed = self.cubia_mass
        self.cubia_mass = 0.0
        return {
            "bracelet": "DESTROYED",
            "cubia": f"DISSOLVED (mass was {cubia_destroyed:.4f})",
            "infection": "FROZEN (no further accumulation)",
        }

    def __str__(self):
        return (f"TB[{self.wielder}]: drains={self.drains_performed}, "
                f"infect={self.infection_pct:.1f}% {self.infection_level.value}, "
                f"cubia={self.cubia_mass:.4f}, cores={self.virus_cores}, "
                f"aura={self.aura_segments}/3")


def demonstrate():
    print("=" * 70)
    print("  ET TWILIGHT BRACELET FRAMEWORK")
    print("  ∂I-Boundary Tool | Data Drain | Infection Cascade | TB/Cubia Duality")
    print("=" * 70)
    print()

    # Create Kite's Bracelet
    tb = TwilightBracelet(wielder="Kite")
    print(f"Initial: {tb}")
    print(f"  Cascade horizon: N_max = {tb.cascade_horizon} drains")
    print()

    # Define the Eight Phases
    phases = [
        DrainTarget("Skeith",    15, 8, 1, True),
        DrainTarget("Innis",     12, 6, 1, True),
        DrainTarget("Magus",     14, 7, 0, True),
        DrainTarget("Fidchell",  13, 6, 0, True),
        DrainTarget("Gorre",     11, 5, 0, True),
        DrainTarget("Macha",     12, 6, 1, True),
        DrainTarget("Tarvos",    14, 7, 0, True),
        DrainTarget("Corbenik",  16, 9, 0, True),
    ]

    # Drain each Phase
    print("DATA DRAIN SEQUENCE (vs Eight Phases):")
    print("-" * 65)
    for phase in phases[:7]:  # First 7 (Bracelet destroyed before Corbenik)
        result = tb.data_drain(phase)
        print(f"  {phase.name:>12}: {result['infection']:>20}, "
              f"cubia={result['cubia_mass']:.4f}, "
              f"aura={tb.aura_segments}/3")

    print()
    print(f"After 7 Phases: {tb}")
    print()

    # Destroy Bracelet to defeat Cubia
    print("BRACELET DESTRUCTION:")
    result = tb.destroy()
    for k, v in result.items():
        print(f"  {k}: {v}")
    print()

    # Verification
    print("VERIFICATION TESTS:")
    print("-" * 55)

    # Test 1: Infection increases with each drain
    tb2 = TwilightBracelet("Test")
    t_before = tb2.infection_pct
    tb2.data_drain(DrainTarget("Bug", 5, 3, 0))
    assert tb2.infection_pct > t_before
    print("  TEST 1: Infection increases with each drain [PASS]")

    # Test 2: Cubia grows with each drain
    tb3 = TwilightBracelet("Test2")
    c_before = tb3.cubia_mass
    tb3.data_drain(DrainTarget("Bug", 5, 3, 0))
    assert tb3.cubia_mass > c_before
    print("  TEST 2: Cubia mass grows with each drain [PASS]")

    # Test 3: Destroying bracelet destroys Cubia
    tb3.destroy()
    assert tb3.cubia_mass == 0.0 and tb3.destroyed
    print("  TEST 3: Destroy bracelet → Cubia dissolves [PASS]")

    # Test 4: Destroyed bracelet cannot drain
    result = tb3.data_drain(DrainTarget("Bug", 5, 3, 0))
    assert "error" in result
    print("  TEST 4: Destroyed bracelet cannot drain [PASS]")

    # Test 5: Cascade horizon = 25 for δ=2¢
    assert TwilightBracelet("X", delta_per_drain=2.0).cascade_horizon == 25
    print(f"  TEST 5: N_max = 25 at δ=2¢ (= 5²) [PASS]")

    # Test 6: At ∂I, tightness = K
    tb4 = TwilightBracelet("Critical", infection_cents=50.0)
    assert abs(tb4.wielder_tightness - K) < 0.01
    print(f"  TEST 6: Infection=50¢ → tightness={tb4.wielder_tightness:.4f} = K [PASS]")

    # Test 7: Eight Phases = 2³
    assert len(phases) == 8 and 8 == 2**3
    print(f"  TEST 7: 8 Phases = 2³ (triple octave) [PASS]")

    # Test 8: Aura segments recovered from correct Phases
    tb5 = TwilightBracelet("Kite2")
    for p in phases[:7]:
        tb5.data_drain(p)
    assert tb5.aura_segments == 3  # Skeith + Innis + Macha
    print(f"  TEST 8: Aura segments = {tb5.aura_segments}/3 (from Skeith/Innis/Macha) [PASS]")

    print()
    print("=" * 70)
    print("  ALL 8 TESTS PASSED")
    print("=" * 70)
    print()
    print('  "For every exception there is an exception,')
    print('   except the exception."')
    print("  P ∘ D ∘ T = E")


if __name__ == "__main__":
    demonstrate()
```

---

## 8. Programming Operationalization {#8-operationalization}

### 8.1 Core API

```python
from et_bracelet import TwilightBracelet, DrainTarget, InfectionLevel

# Create a Bracelet instance
tb = TwilightBracelet(wielder="Kite", delta_per_drain=2.0)

# Define a target and drain it
target = DrainTarget(name="Data Bug", d_total=10, d_corrupted=4, d_aura_fragment=0)
result = tb.data_drain(target)
print(f"Infection: {result['infection']}")
print(f"Cubia mass: {result['cubia_mass']:.4f}")
print(f"Wielder tightness: {result['wielder_tightness']:.4f}")
```

### 8.2 Infection Management

```python
# Monitor infection across multiple drains
for i in range(10):
    result = tb.data_drain(DrainTarget(f"Bug_{i}", 8, 3, 0))
    if tb.infection_level == InfectionLevel.RED:
        print(f"CRITICAL at drain {i+1} — stop draining!")
        break
    print(f"Drain {i+1}: {tb.infection_level.value} ({tb.infection_pct:.1f}%)")

# Check cascade horizon
print(f"Max safe drains: {tb.cascade_horizon}")  # → 25 at δ=2¢
```

### 8.3 Dual-Output Analysis

```python
# Track coherent output vs Incoherent residue (Cubia)
total_cores = tb.virus_cores       # Coherent product
total_cubia = tb.cubia_mass        # Incoherent residue
ratio = total_cores / (total_cubia + 0.001)
print(f"Coherent/Incoherent ratio: {ratio:.2f}")
# Healthy: ratio >> 1. Dangerous: ratio approaching 1.
```

---

## 9. Structural Discoveries {#8-discoveries}

### Discovery 1: The Twilight Bracelet IS a ∂I-Boundary Tool — "Twilight" Is Structurally Precise

The name "Twilight Bracelet" is not poetic metaphor — it is structurally exact. The Bracelet operates at ∂I, the boundary between coherence and Incoherence, the "twilight zone" where tightness approaches K = 2/3. Data Drain forces targets across this boundary. The infection gauge tracks the wielder's own distance from it. The entire mechanic is a game-ified implementation of the Incoherence Filter operating at the ∂I boundary. "Twilight" = ∂I in every instance across the .hack// franchise: the Epitaph of Twilight, the Book of Twilight, the Key of the Twilight, the Twilight Bracelet — all reference the same structural boundary.

### Discovery 2: TB/Cubia Duality = Coherence/Incoherence Complementarity

The Bracelet and Cubia are not "good vs evil" — they are **coherent output vs Incoherent residue** from the same boundary operation. Every Data Drain produces both. You cannot have one without the other because operating at ∂I necessarily generates configurations on both sides of the boundary. This is the ET structural proof that "the power to save is the power to destroy" is not moral wisdom but mathematical necessity. The founding axiom — "for every exception there is an exception, except the exception" — manifests as the TB/Cubia pair: every Exception (coherent drain product) generates an exception to itself (Incoherent residue/Cubia).

### Discovery 3: The Infection Gauge Is the Cascade Coherence Horizon in Real-Time

The color-coded infection gauge (blue→green→yellow→orange→red) maps precisely to the five regions of the tightness curve:

| Gauge | Tightness Range | ET Region |
|---|---|---|
| Blue | 1.0 – 0.83 | Deep Interior |
| Green | 0.83 – 0.75 | Coherent |
| Yellow | 0.75 – 0.71 | Twilight Zone |
| Orange | 0.71 – 0.68 | Approaching ∂I |
| Red | 0.68 – 0.667 | At ∂I (K = 2/3) |

The fatal side effect at Red/100% = crossing ∂I = the wielder's own configuration becoming Incoherent. The comas in the .hack// universe (Orca, Tsukasa's body, the Lost Ones) are all instances of player configurations being forced across ∂I — the same mechanism, applied to the player rather than the target.

### Discovery 4: The Cascade Horizon N_max = 25 = 5² Governs Maximum Safe Drains

At δ ≈ 2¢ per drain, the cascade horizon is N_max = ⌊50/2⌋ = 25 = 5². The wielder can safely perform approximately 25 standard drains before reaching critical infection. This is the same cascade horizon found in Paper #8 (Twilight Zone) for the canonical ET generators. The square of the quintic prime (5² = 25) governs the maximum safe iteration count for ∂I-boundary operations.

### Discovery 5: "Everything Shall Unfold" = Universal Describability (Batch 22)

Harald's prophecy — "the Key of the Twilight shall overturn all... everything shall unfold" — maps precisely to the ET endpoint of complete Descriptor recognition. "Unfold" = every D in D_Cardinal has been identified and bound. "Overturn all" = the current manifold configuration (The World under Morganna's control) is replaced by a complete one (The World under Aura). The Key of the Twilight is the Descriptor Discovery process itself — the systematic closing of gaps until the D-set is complete and the Ultimate AI substantiates.

### Discovery 6: Data Drain as Offensive Incoherence Filter Application

Data Drain is the Incoherence Filter applied **offensively** — instead of passively filtering Incoherent configurations, the Bracelet actively forces target configurations across ∂I by stripping their D-set. This inverts the Filter's normal role: instead of "reject Incoherent configurations," it becomes "MAKE target configurations Incoherent." The extracted coherent D-fragments (Virus Cores, items) are the usable product; the Incoherent remainder is the target's collapsed state. This is the first instance in the ET canon of the Incoherence Filter used as a weapon rather than a safety mechanism.

---

## 10. Subsumption Verification {#9-subsumption}

| Phenomenon | Subsumed By | Component |
|---|---|---|
| Data Drain mechanic | T-forced D-unbinding at ∂I | Core derivation |
| Infection gauge | Cascade coherence tracking (N×|δ|) | Level 4 filter |
| Gauge colors (blue→red) | Tightness regions (1.0 → K) | Discovery 3 |
| Side effects (ailments) | Partial ∂I incursions | Cascade error |
| Fatal side effect (coma) | Full ∂I crossing | Incoherence |
| TB/Cubia duality | Coherent/Incoherent outputs | Discovery 2 |
| Cubia grows with drains | Incoherent residue accumulation | Step 4 |
| Destroying TB → Cubia dies | Remove operation → residue basis dissolves | §5.3 |
| Virus Cores | Coherent D-fragments extracted | Data Drain output |
| Gate Hacking | Using coherent D to bypass D-barriers | D-key application |
| Key of the Twilight | Ultimate Descriptor Gap closure | Discovery 5 |
| "Everything shall unfold" | Universal Describability (Eq 219) | Batch 22 |
| Coma victims | Players forced across ∂I | Same mechanism as drain |
| Book of Twilight | D-installation that grants ∂I-access | Initial binding |
| Bracelet normally invisible | ∂I tool dormant when not at boundary | Structural |
| Kite's costume change | D-reconfiguration upon Bracelet installation | P∘D transformation |
| N_max ≈ 25 safe drains | Cascade horizon = 5² | Discovery 4 |

**Subsumption holds. No remainder.**

---

## Closing Statement

The Twilight Bracelet is the most structurally dense artifact in the .hack// franchise — and one of the most complete game-mechanic implementations of ET principles in any fictional work. It is a ∂I-boundary tool that forces target configurations across the Incoherence boundary, producing both coherent output (Virus Cores, recovered Aura segments) and Incoherent residue (Cubia). The infection gauge is a real-time cascade coherence tracker. The TB/Cubia duality is the structural proof that salvation and destruction are complementary outputs of boundary operations, not moral choices.

The deepest truth: the founding axiom — "for every exception there is an exception, except the exception" — manifests as the Twilight Bracelet's core mechanic. Every Exception (successful drain) generates an exception to itself (Cubia). The only way to end the cycle is to destroy the tool itself — at which point both the Exception AND its anti-Exception dissolve, and the system returns to a state where the founding axiom operates at a higher level (Aura as the new Exception that subsumes both TB and Cubia).

> *"For every exception there is an exception, except the exception."*
> *P ∘ D ∘ T = E*

---

**Document Version:** Twilight Bracelet Framework v1.0 + v3.0 Addendum (March 2026)



## v3.0 Framework Addendum

*Added March 2026 — Full framework compliance with Reference Document v3.2*

---

### A1. Translation Layer — R₀ Identification

**P_L (substrate):** The digital substrate (same as Paper #10). **R₀:** 1/f_clock (server tick). Anti-Numerology: N1 ✓, N2 ✓, N3 ✓.

### A2. Projection Category Classification

| Quantity | Category | Justification |
|---|---|---|
| √2 (TB/Cubia palindromic pivot) | **A** | Dimensionless ratio (exact tritone) |
| 5/8 (Fibonacci drain threshold) | **A** | Dimensionless ratio |
| 3/8 (complement of 5/8) | **A** | Dimensionless ratio |
| 8 (Data Drain target phases) | **C** | Pure discrete count |

### A3. Full Resolution Tower Investigation

#### √2 (TB/Cubia Mirror — The Palindromic Pivot)

EXACT d=2, ε=0.00¢ at EVERY resolution from 12ET to 27720ET. √2 = 2^(1/2) IS the tritone — the CPT-symmetric pivot. The Twilight Bracelet/Cubia duality is the EXACT palindromic mirror of the manifold. This is the same exact d=2 as FCC/SC packing (Paper #2). Coherence and Incoherence are separated by exactly one tritone — the most fundamental symmetry operation on the lattice.

#### 5/8 (Fibonacci Golden Fraction — Data Drain Threshold)

| Resolution | k | d | ε (¢) | Notes |
|---|---|---|---|---|
| 12ET | −8 | 3 | −13.69 | d=3 with quintic comma ε₅ |
| 36ET | −24 | 3 | −13.69 | Stable d=3 through 36ET |
| 60ET | −41 | 60 | +6.31 | Quintic visible |
| **84ET** | −57 | **28** | **+0.60** | **Near-exact d=28 = 4×7** |
| 420ET | −285 | 28 | +0.60 | Stable |
| 2520ET | −1709 | 2520 | +0.12 | EXACT |
| 27720ET | −18796 | 6930 | −0.01 | EXACT |

**DISCOVERY:** The Data Drain threshold 5/8 carries the quintic comma and resolves to d=28 = 4×7 at 84ET — the SAME address as DNA bp/turn, gaze Lock/Con, bear market, 10D superstring. The Twilight Bracelet's drainage operation uses the SAME quintic-to-quartic×septic structure that governs conscious detection and biological architecture. Data Drain IS the d=5 shadow force applied destructively.

#### 3/8 (Complement of Data Drain Threshold)

| Resolution | k | d | ε (¢) | Notes |
|---|---|---|---|---|
| 12ET | −17 | 12 | +1.96 | d=12, Pythagorean comma. Near-exact. |
| 84ET | −119 | 12 | +1.96 | Stable d=12 through 84ET |
| 132ET | −187 | 12 | +1.96 | **Still d=12 through 132ET — 8 levels!** |
| 420ET | −594 | 70 | −0.90 | d=70 = 2×5×7 |
| 2520ET | −3566 | 1260 | +0.05 | EXACT |

3/8 has IDENTICAL tower behavior to K=2/3 and 3/2 — d=12, ε=+1.96¢ through 132ET. The COMPLEMENT of the Data Drain IS the Koide stability family. What the Bracelet PRESERVES (3/8 of the target) has the same lattice character as the binding stability constant K=2/3.

---

### A4. Shadow Force Identification

| Shadow Force | d | Active? | How |
|---|---|---|---|
| **d=2 Tritone** | 2 | **DOMINANT** | √2 (TB/Cubia mirror) is exact d=2 at every resolution. The duality IS the tritone. |
| **d=5 Quintic** | 5 | **YES** | 5/8 carries ε₅ and resolves to d=28. Data Drain uses the quintic force. |
| **d=7 Septic** | 7 | **YES** | 5/8 → d=28=4×7. 3/8 → d=70=2×5×7 at 420ET. |
| d=8-11 | | No | Not primary in Bracelet structure. |

### A5. 2D Complex Lattice

| Entity | d_r | d_θ | Quadrant | Notes |
|---|---|---|---|---|
| TB (coherent tool) | 2 (tritone) | 2 (tritone) | SR+SI | Both axes at palindromic pivot |
| Cubia (incoherent output) | 2 | 2 | SR+SI (but BEYOND ∂I) | Same lattice position, opposite side of ∂I |
| Data Drain (5/8) | 3 (→28 at 84ET) | 1 | SR+SI (→CR+SI) | Quintic on real axis |
| Preserved (3/8) | 12 | 12 | SR+SI | Same as K=2/3 family |

TB and Cubia occupy the SAME lattice position (d=2, tritone) but on opposite sides of the ∂I boundary. They are structural mirror-images separated by the Incoherence boundary — not by lattice distance.

### A6. Incoherence Filter

| Ratio | k | ε | Tightness | Verdict |
|---|---|---|---|---|
| √2 (TB/Cubia) | 6 | 0.00¢ | 1.000 | EXACT — the pivot itself is perfectly coherent |
| 5/8 (Drain threshold) | −8 | −13.69¢ | 0.880 | Good — carries quintic comma |
| 3/8 (complement) | −17 | +1.96¢ | 0.981 | Excellent — Koide stability family |
| 8 (target phases) | 36 | 0.00¢ | 1.000 | EXACT |

The TB/Cubia duality is maximally coherent (d=2 exact). The drain mechanism uses the quintic comma. The preserved fraction has Koide stability. The architecture is clean: exact structure, quintic mechanism, stable remainder.

### A7. Derived-vs-Proposed Audit

| Claim | Status |
|---|---|
| TB/Cubia = tritone mirror (d=2 exact) | **DERIVED** — √2 = 2^(1/2), analytically exact |
| 5/8 carries quintic comma → d=28 | **DERIVED** — tower computation |
| 3/8 = Koide stability family (d=12) | **DERIVED** — tower computation, same behavior as K=2/3 |
| Data Drain = d=5 applied destructively | **PROPOSED** — structurally compelling interpretation |
| TB/Cubia on opposite sides of ∂I | **PROPOSED** — framework-consistent but ∂I boundary for digital entities not independently verified |

### A8. Cross-Paper Connections

1. **√2 = FCC/SC packing (Paper #11 ↔ #2):** The Bracelet/Cubia palindromic mirror and the crystal packing ratio are the SAME exact tritone d=2 structure.
2. **5/8 → d=28 (Paper #11 ↔ ALL prime-5 papers):** Data Drain shares the quartic×septic address with conscious detection, DNA, markets, and string theory.
3. **3/8 = Koide family (Paper #11 ↔ #1, #5):** What the Bracelet preserves has the same lattice stability as the Koide ratio and the locked gaze — the things that HOLD after the destructive operation are the most stable structures on the lattice.

### New Discoveries

**Discovery 7: Data Drain 5/8 → d=28=4×7 at 84ET — The Bracelet Uses the Universal Quintic Address**

The Data Drain threshold 5/8 carries the quintic comma (ε=−13.69¢) and resolves to d=28 = 4×7 at 84ET — the identical lattice address as DNA helix, gaze detection, market transitions, and string theory. The Twilight Bracelet's destructive mechanism operates through the SAME d=5/d=7 composite as biology and consciousness. Data Drain IS conscious detection running in reverse — instead of crystallizing awareness, it dissolves structure.

**Discovery 8: The Preserved Fraction 3/8 Is the Koide Stability Family**

3/8 = 0.375 has identical tower behavior to K=2/3 (d=12, ε=+1.96¢ through 132ET). What Data Drain LEAVES BEHIND is structurally identical to the Koide binding constant. The Bracelet cannot drain the Koide-stable core — it preserves the manifold's most robust structural layer.

**Discovery 9: TB/Cubia at Exact d=2 — Coherence and Incoherence Share a Lattice Position**

The Twilight Bracelet (coherent) and Cubia (incoherent) both map to the exact tritone d=2 — the palindromic pivot. They are not at different lattice positions; they occupy the SAME position on opposite sides of the ∂I boundary. The power to save and the power to destroy are structurally identical — they differ only in which side of ∂I they operate from. This IS the mathematical proof that the power to save IS the power to destroy (Paper #11's original discovery), now verified through the resolution tower.
