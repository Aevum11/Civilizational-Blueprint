# www.ExceptionTheory.com — Local Run & Pre-Deployment Verification

**Exception Theory — Michael James Muller — Exception Theory LLC**
*P ∘ D ∘ T = E*

This document is the complete procedure for running the site locally on the
Windows 10 machine, verifying it (visually and computationally), testing it on
the Galaxy S22 Ultra and the Samsung TV over LAN, and clearing the gates before
deployment. The site is fully static — zero JavaScript, zero backend — so
"running" it means serving files; "verifying" it means (a) rebuilding it from
the forge and watching 176/176 pass, and (b) checking the four effects against
their laws with your own eyes.

---

## 0. READ THIS FIRST — Required folder structure (the white-page fix)

**If you opened the page and got a WHITE page — plain black text, links, and a
giant diagram — nothing is broken and nothing "failed to load" except one
file: the stylesheet.** The page loaded; `css/et.css` did not, because the
files were not arranged in the folder tree the page expects. A from-scratch
static site is not like Weebly: there is no platform resolving paths for you.
`index.html` contains the line

```
<link rel="stylesheet" href="css/et.css">
```

which is a **relative path**: it means "the file `et.css` inside a folder
named `css` sitting next to me." If that file is not exactly there, the
browser's built-in error handling is to render the page unstyled — silently,
no crash, no popup. White page = wrong file placement. Full stop.

### The required tree

Assemble the downloaded files EXACTLY like this before doing anything else:

```
et_site\                       ← the folder name and location are your choice
│                                 (e.g. C:\Users\Mike\Desktop\et_site\)
├── index.html                 ← at the TOP level of the folder
├── et_tokens.json             ← top level
├── VERIFICATION_REPORT.txt    ← top level
├── css\                       ← a folder named exactly:  css
│   └── et.css                 ← the stylesheet, inside it, named exactly:  et.css
└── assets\                    ← a folder named exactly:  assets
    └── et_wheel.svg           ← the wheel, inside it
```

The forge sources and documents (`et_site_forge.cpp`, `cie_observer_data.hpp`,
`et_site_forge.py`, `cie_observer_data.py`, `ET_Site_Design_Document.md`, this
file) may sit at the top level alongside `index.html` — they have no effect on
rendering. Only the tree above matters to the browser.

### Assembly steps (Windows)

1. Create the folder, e.g. `Desktop\et_site`.
2. Inside it create the two subfolders — Explorer ▸ New Folder twice, named
   `css` and `assets` — or from a terminal opened in the folder:
   `mkdir css assets`
3. Move the downloads into place per the tree: `index.html`,
   `et_tokens.json`, `VERIFICATION_REPORT.txt` at the top;
   `et.css` **into** `css\`; `et_wheel.svg` **into** `assets\`.
4. **File-name gotcha:** Windows hides extensions by default, and some
   browsers save text files with an extra `.txt`. In Explorer turn on
   View ▸ Show ▸ **File name extensions**, and confirm the names are exactly
   `index.html`, `et.css`, `et_wheel.svg` — lowercase, no `.txt` tacked on.

### 10-second self-check (do this before anything else in this document)

Double-click `index.html`.

- **Correct:** a near-black page; the equation **P ∘ D ∘ T = E** glowing in
  color; drifting, twinkling stars behind everything.
- **Wrong:** a white page with plain text and a huge diagram → the tree above
  is not in place. Fix file locations and names; change no code.

### If it is still white after the tree is in place

Press **F12** ▸ **Network** tab ▸ reload the page. Look at the `et.css` row:

- Status **200** → stylesheet loaded; the page cannot be white.
- Status **404** (or `net::ERR_FILE_NOT_FOUND` when opened via
  double-click) → the browser tells you the exact URL where it looked;
  compare that path against the tree and correct the placement or the name.

**Shortcut that skips manual assembly entirely:** the forge rebuild in §5
emits a ready-made `dist\` folder already in this exact structure — copy or
serve `dist\` whole and the layout is guaranteed.

---

## 1. What is in this folder

The paths in this table ARE the required tree from §0: `css/et.css` means
"the file `et.css` inside the folder `css`" — not a file named `css/et.css`
and not `et.css` sitting loose next to `index.html`.

| File / dir | Role |
|---|---|
| `index.html` | The site (single page) |
| `css/et.css` | Every value a lattice address; all four effects live here |
| `assets/et_wheel.svg` | The sigil wheel (also inlined in the page) |
| `et_tokens.json` | The full token ledger: every value + its derivation law |
| `VERIFICATION_REPORT.txt` | The 176/176 check log from the shipping build |
| `et_site_forge.cpp` | **The authoritative forge** (C++ MPFR) — rebuilds everything above |
| `CMakeLists.txt` | **Shipped build system** — open the folder in CLion and it just works |
| `vcpkg.json` | vcpkg manifest — mpfr + gmp auto-install on first configure (MSVC path) |
| `vcpkg-configuration.json` | Enables the project's overlay ports (gmp build-failure fix) |
| `vcpkg-overlays/gmp/` | Drop-in gmp port (registry #4 + one configure preseed) — see §5b troubleshooting |
| `CMakePresets.json` | Two ready presets: `vcpkg` (CLion/MSVC) and `default` (MSYS2/Linux) |
| `cie_observer_data.hpp` | Frozen CIE/sRGB translation layer (compile-time include) |
| `et_site_forge.py`, `cie_observer_data.py` | Independent Python cross-check (superseded as authority; see §6) |
| `ET_Site_Design_Document.md` | Full design record, laws, work history |
| `LOCAL_RUN_INSTRUCTIONS.md` | This file |

**Deployment set** (what actually goes to the server, nothing else):
`index.html`, `css/`, `assets/`, `et_tokens.json`, `VERIFICATION_REPORT.txt`.
The tokens file and report are intentionally public — they are the site's
transparency layer.

---

## 2. Fastest look (30 seconds, no server)

**Prerequisite: the §0 tree is assembled and its 10-second self-check shows
the dark page.** If your page is white, go back to §0 — do not continue.

Because the site has **no JavaScript and no fetches**, `file://` works:

1. Double-click `index.html`.
2. It opens in your default browser and everything renders, including all four
   effects, because every resource is a relative-path static file.

This is fine for a first look. For real testing, use the HTTP server in §3 —
it mirrors deployment exactly (MIME types, paths, caching behavior) and lets
the phone and TV connect.

---

## 3. Proper local server (mirrors deployment)

**Prerequisite: the §0 tree is assembled and verified.** The server does not
fix placement — it serves whatever folder you point it at, exactly as-is. A
white page over `http://` means the same thing it means over `file://`: the
tree is wrong.

Python 3 is already on the machine. From a terminal (**cmd**, PowerShell, or
Windows Terminal), `cd` into the folder that **directly contains
`index.html`** — the `et_site` folder itself from §0, NOT the `css` folder,
NOT its parent. Example:

```
cd C:\Users\Mike\Desktop\et_site
```

Then run:

```
py -m http.server 8080 --bind 127.0.0.1
```

Then open: **http://localhost:8080/**

- The console will log each request (`index.html`, `css/et.css`, …). You
  should see **no request for any `.js` file** — there are none.
- Stop the server with `Ctrl+C`.
- If `py` isn't on PATH, use `python -m http.server 8080 --bind 127.0.0.1`.

Alternative (if you prefer the Node toolchain from the TLP work):
`npx serve . -l 8080` — equivalent result.

---

## 4. Phone and TV testing over LAN (S22 Ultra, Samsung TV)

1. Find the PC's LAN IPv4: run `ipconfig` and read the `IPv4 Address` of the
   active adapter (e.g. `192.168.1.23`).
2. Start the server bound to all interfaces:

```
py -m http.server 8080 --bind 0.0.0.0
```

3. If Windows Firewall prompts, allow access on **Private networks**. (If no
   prompt appears and the phone can't connect, add an inbound rule for TCP
   8080, Private profile, or temporarily use
   `netsh advfirewall firewall add rule name="et-site-test" dir=in action=allow protocol=TCP localport=8080`
   and delete the rule after testing.)
4. On the S22 Ultra (same Wi-Fi), open **http://192.168.1.23:8080/**
   (your IP from step 1). Same on the TV's browser.

**Expected differences on non-Chromium-desktop engines:**
- **Comet:** `offset-path: path(...)` on SVG children requires a current
  Chrome/Edge/Firefox. On engines without it (some TV browsers, older
  Samsung Internet), the comet simply does not appear — by design the comet
  circles carry `opacity: 0` outside the animation, so degradation is clean,
  not broken.
- Everything else (tunnel, glow, starfield, Engine panels) is plain CSS
  animation + gradients and runs anywhere modern.

---

## 5. Rebuild from the forge and verify (the real test)

This is the verification that matters: compile the authoritative forge,
run it, and watch it refuse to emit a site unless **176/176** checks pass.

### 5a. Recommended path — MSYS2 (g++, matches the build header exactly)

1. Install MSYS2 from msys2.org (default location `C:\msys64`).
2. Open the **"MSYS2 UCRT64"** shell and install the toolchain + libraries:

```
pacman -S --needed mingw-w64-ucrt-x86_64-gcc mingw-w64-ucrt-x86_64-mpfr mingw-w64-ucrt-x86_64-gmp
```

3. `cd` to this folder (Windows drives mount as `/c/...`, e.g.
   `cd "/c/Users/Mike/Downloads/et_site"`).
4. Compile — this is the exact command from the file header:

```
g++ -std=c++17 -O2 -Wall -o et_site_forge et_site_forge.cpp -lmpfr -lgmp
```

   Expected: **no output** (clean, zero warnings).
5. Run it:

```
./et_site_forge.exe
```

   Expected tail of output:

```
  PASSED: 179   FAILED: 0   TOTAL: 179

  dist/ written & post-write verified: index.html, css/et.css,
  assets/et_wheel.svg, et_tokens.json, VERIFICATION_REPORT.txt
  (zero JavaScript emitted; every write size-checked)
```

   **Exit-code contract (complete error handling):**
   - `0` — all 179 checks passed AND every file was emitted and
     post-write size-verified.
   - `1` — a verification check failed. **`dist/` is left untouched**
     (the forge verifies everything in memory *before* writing anything),
     and the full report is saved to `VERIFICATION_REPORT_FAILED.txt`
     in the working directory.
   - `2` — a fatal environment or internal error (unwritable path, bad
     parse, non-finite value, unreplaced template token, …). Nothing is
     written; the exact cause and the last `errno` are printed on a
     `[FATAL]` line.

   Check with `echo $?` after the run.
6. **Reproducibility check** (byte-identical determinism):

```
cp -r dist dist_run1
./et_site_forge.exe
diff -r dist_run1 dist && echo BYTE-IDENTICAL
```

   Expected: `BYTE-IDENTICAL`.
7. Compare your fresh build against the shipped files (they should match
   byte-for-byte except the footer year if rebuilt in a different calendar
   year):

```
diff dist/css/et.css css/et.css
diff dist/index.html index.html
```

8. Serve the fresh build: `cd dist` then §3.

### 5b. CLion + MSVC + vcpkg (your toolchain)

**The project now arms vcpkg by itself.** `CMakeLists.txt` locates vcpkg
(searching `VCPKG_ROOT`, `VCPKG_INSTALLATION_ROOT`,
`%USERPROFILE%\.vcpkg-clion\vcpkg`, `%USERPROFILE%\vcpkg`, `C:\vcpkg`,
`C:\dev\vcpkg`, `C:\src\vcpkg`, `C:\tools\vcpkg`) and loads its
toolchain before `project()` — no CLion CMake-options field required.
If MSVC is detected with no vcpkg anywhere, configure **stops with a
message that contains its own complete fix instructions** instead of a
bare `find_path` error.

1. **Delete the stale build directory — mandatory, not optional.**
   CMake honors a toolchain file only on a **fresh cache**; an existing
   `cmake-build-debug` silently ignores toolchain changes, which is one
   of the two ways the previous failure happened. Close CLion, then:

```
rd /s /q "C:\Users\aevum\Desktop\ET_website\cmake-build-debug"
```

   (Also delete `cmake-build-vcpkg` / `cmake-build` if present.)

2. **Reopen the folder in CLion** and let it configure. Watch the CMake
   output for these lines, in order:

```
-- ET forge: vcpkg toolchain auto-selected: <your vcpkg path>
-- ET forge: FIRST configure builds gmp+mpfr from source (several minutes, one time); ...
-- Running vcpkg install
...
-- Running vcpkg install - done
-- ET forge: vcpkg active — triplet x64-windows; packages: ...
-- Configuring done
```

   The **first** configure really does take several minutes — vcpkg is
   compiling gmp and mpfr for MSVC. It is not hung. Every configure
   after that is instant. If you instead see the big `ET forge: MSVC
   detected but the vcpkg toolchain is NOT loaded` error, it lists the
   fixes — the two **guaranteed** ones, straight from the JetBrains
   documentation: (i) View ▸ Tool Windows ▸ **Vcpkg** ▸ Edit vcpkg
   (pencil icon) ▸ link vcpkg to the CMake profile you are building
   with — CLion adds the toolchain flag **per profile**, so an unlinked
   profile configures without vcpkg; and/or (ii) that same dialog shows
   vcpkg's installation directory — set the `VCPKG_ROOT` environment
   variable to that path and auto-detect takes over. After either,
   delete the build folder again and reload.

3. **Working directory**: Run ▸ Edit Configurations ▸ set *Working
   directory* to the project folder (the forge writes `dist/` into its
   working directory).

4. **Build and Run** the `et_site_forge` target. Expect
   `PASSED: 179  FAILED: 0`, exit code 0, and `dist\` in the project
   folder already in the §0 tree. The mpfr/gmp DLLs are copied next to
   the executable automatically (vcpkg app-local deployment), so it
   runs from CLion directly.

Portability notes: the source is MSVC-clean — the POSIX-only header
`<unistd.h>` is guarded out on Windows, directory calls go through
`_mkdir`/`_rmdir`, and `<algorithm>`/`<cstdio>` are included explicitly
(MSVC does not provide them transitively the way GCC's library does).

#### Troubleshooting: `make: *** No rule to make target 'gen-fac_.c'`

If vcpkg's **gmp** build dies with this exact line in
`C:\vcpkg\buildtrees\gmp\build-x64-windows-dbg-err.log`, that underscore
is GMP's `U_FOR_BUILD=_` mis-fire: configure's ANSI probe for the build
compiler (`gmp_cv_c_for_build_ansi`, acinclude.m4) failed spuriously
under the 2026 msys2 toolset, and modern automake deleted the ansi2knr
rules that `_`-suffixed files would need. The two errors after it in
the CLion output (`vcpkg.cmake:953` and `CMAKE_CXX_COMPILER not set`)
are pure cascade — they vanish once the install succeeds.

**Step 0 — delete the two scratch folders (always, before every retry):**
`C:\vcpkg\buildtrees\gmp` is vcpkg's scratch workspace holding the
failed attempt's wreckage — including the wrong cached configure
answer; `cmake-build-debug` is CLion/CMake's scratch folder for the
project, left in a broken half-state by the aborted configure. Both
tools reuse leftover state, so a failed attempt must be erased or it
repeats. Neither folder contains any of your work; both are recreated
automatically, and vcpkg's downloads are cached elsewhere so nothing
re-downloads. **Close CLion first** (it locks the build folder), then
either delete both folders in File Explorer (`C:\vcpkg\buildtrees\` →
delete `gmp`; `Desktop\ET_website` → delete `cmake-build-debug`), or
use the Windows **Command Prompt** — the black window built into
Windows, NOT CLion's console: press the Windows key, type `cmd`, press
Enter; when `C:\Users\aevum>` appears, paste each line below
(right-click pastes in Command Prompt) and press Enter. **Silence —
just a new prompt line — means success.** "The system cannot find the
file specified" also means you're fine (already gone). "Access is
denied" / "in use" means CLion is still running — close it and paste
again.

```
rd /s /q C:\vcpkg\buildtrees\gmp
rd /s /q C:\Users\aevum\Desktop\ET_website\cmake-build-debug
```

(`rd` = remove directory; `/s` = including all contents; `/q` = no
per-item confirmation. It deletes without asking — paste the lines
exactly rather than retyping them.)

**Step 1 — update the registry (likely sufficient):**

```
git -C C:\vcpkg pull
```

Reconfigure. The failing port was `gmp 6.3.0#3` (old
`vcpkg_configure_make` pipeline); the registry's `#4` migrated gmp to
the new `vcpkg_make_configure` pipeline. If configure now lists
`gmp:x64-windows@6.3.0#4` or higher and the build passes — done.

**Step 2 — the shipped overlay (deterministic):** the overlay is a
**folder structure**, not loose files. The easiest delivery is the
single archive **`et_gmp_overlay_fix.zip`**: right-click it ▸ Extract
All ▸ choose `C:\Users\aevum\Desktop\ET_website` as the destination —
it creates the entire tree below in one step (say Yes if asked to
merge/replace `vcpkg-configuration.json`). If placing files manually
instead, create the two folders and place the 10 files exactly like
this:

```
ET_website\
├── vcpkg.json                      ← the PROJECT manifest ("name": "et-site-forge") — keep
├── vcpkg-configuration.json        ← top level, next to vcpkg.json
└── vcpkg-overlays\                 ← folder, exact name
    └── gmp\                        ← folder, exact name
        ├── portfile.cmake
        ├── vcpkg.json              ← the OVERLAY port's manifest ("name": "gmp")
        ├── usage
        ├── arm64-coff.patch
        ├── asmflags.patch
        ├── c23.patch
        ├── cross-tools.patch
        ├── msvc_symbol.patch
        ├── remove_compiler_info.patch
        └── subdirs.patch
```

**⚠ Two different files are named `vcpkg.json`.** The project manifest
stays at the top level and contains `"name": "et-site-forge"`; the
overlay's own manifest goes in `vcpkg-overlays\gmp\` and contains
`"name": "gmp"` with `"port-version": 5`. Putting the gmp one at the
top level overwrites the project manifest and breaks everything —
verify both in Notepad before configuring.

If the folder is missing or misplaced, configure fails fast with:
`Overlay path "...vcpkg-overlays" must be an existing directory.` —
that message means the configuration file was found and only the
folder placement is wrong.

With the tree in place, repeat Step 0, reconfigure.
**The tell that it engaged:** configure lists
`gmp:x64-windows@6.3.0#5` — the overlay (registry tops out at #4).
It is the registry port plus exactly one configure preseed,
`gmp_cv_c_for_build_ansi=yes`: GMP skips the broken probe, states the
truth (cl.exe is ANSI), `U_FOR_BUILD` stays empty, and `gen-fac.c`
builds as itself. Overlay ports are drop-in replacements consulted
before any registry lookup, and omitting `default-registry` in
`vcpkg-configuration.json` keeps the built-in registry for everything
else (both per Microsoft's reference docs). To return to the pure
registry port later, delete `vcpkg-configuration.json` and
`vcpkg-overlays\` and repeat Step 0.

#### After a successful configure: red editor marks ≠ build errors

If the editor shows **"Cannot resolve symbol 'mpfr_…'"** on every mpfr
name after configuring, that is CLion's *code-insight index*, not the
compiler — real MSVC errors read `error C2065` or `C1083` in the Build
panel. The index goes stale after failed configures. Ground truth:
**Build ▸ Build Project** and read the Build output panel. If the
build passes, clear the stale index with **File ▸ Invalidate Caches… ▸
Invalidate and Restart** and let re-indexing finish (bottom progress
bar) — the squiggles disappear. Only if the Build panel itself shows
errors is something actually wrong.

#### forge_run.log — the run record that always exists

Every run of the forge writes its **entire output** to
**`forge_run.log`** in the folder it runs from (double-click ⇒ next to
the exe in `cmake-build-debug\`; CLion Run ⇒ the configured working
directory). Console windows can flash, close, or swallow text — the
log cannot. Reading it after any run:

- Ends with `dist/ written & post-write verified … PASSED: 179` →
  the run succeeded, full stop; whatever the console did is cosmetic.
- Contains a `[FATAL] …` line → that line names the exact failure.
- Contains `[CRASH] unhandled Windows exception 0x…` → the process
  died mid-run; the code and address are in the line.
- **The file does not exist at all** → the exe never reached its first
  instruction (a loader-level failure, e.g. a missing DLL) — that fact
  alone is the diagnosis to report.

When reporting a problem, paste the last ~10 lines of this file.

Encoding note: the log is UTF-8 with a BOM, and the forge forces the
Windows console to UTF-8 at startup — so both the live window and the
file render ε, ¢, π, Ψ correctly. If an old run's output showed
`╬╡`/`┬ó`/`ΓÇö` garbage, that was a legacy console codepage displaying
valid UTF-8 bytes wrongly, not corruption.

#### Endless `[0/N] Re-running CMake…` loop on Build

Mechanism: Ninja re-runs CMake whenever a tracked input file is newer
than the generated build files. In manifest mode the vcpkg toolchain
tracks exactly two: the project's `vcpkg.json` and
`vcpkg-configuration.json`.

**Root cause here:** files delivered from the build machine carry its
clock, which runs hours ahead of local time — and this applies to
**every download, not just zips**: Chromium-family browsers stamp
downloaded files with the server's Last-Modified time. So
`CMakeLists.txt`, `CMakePresets.json`, `vcpkg.json`, and
`vcpkg-configuration.json` — exactly the four files CMake/Ninja track
as re-run triggers — all sat hours in the future. A future-born file
is "newer" than every build file CMake generates, so configure repeats
endlessly with the `[0/N]` counter climbing and compilation never
starting.

**Fix:** stop the build (red square), download
**`et_website_files_v3.zip`** (every project file, all entries
hard-stamped 2026-07-10 — in the past in every timezone — plus
`fix_timestamps.bat`), Extract All into `ET_website` and **Replace the
files in the destination**, then **double-click
`fix_timestamps.bat`** — it re-stamps every file in the whole folder
tree to the current local time, killing any future timestamp from any
source, including files not in the zip. Then Tools ▸ CMake ▸ Reload
CMake Project: one configure, then real compile lines
(`Building CXX object … et_site_forge.cpp.obj`, `Linking …`). Do NOT
delete `cmake-build-debug` — the installed libraries live inside it.

Fallback only (if a loop ever appears from some *other* file-toucher,
e.g. cloud sync on the project folder): append
`-DVCPKG_MANIFEST_INSTALL=OFF` to the profile's CMake options and
reload — it skips install-on-configure and never registers the two
manifests as re-run triggers. Caveat: with the flag set, a changed
`vcpkg.json` needs the flag removed for one reload to install new
dependencies.

Note on `mpfr_rint` ties-to-even, precision (250 digits = 200 working + 50
guard), and the zero-float guarantee: all enforced inside the source and its
own checks — nothing to configure.

---

## 6. The Python cross-check (optional)

`et_site_forge.py` is retained as the **independent cross-implementation**,
not for deployment. Its dist output is the superseded v1 architecture.

- If you want to reproduce the 48/48 hex agreement: copy `et_site_forge.py`
  and `cie_observer_data.py` into a **separate scratch folder** (it also
  writes `./dist` and would otherwise overwrite the C++ output), run
  `py et_site_forge.py` (needs `pip install mpmath`), then compare the
  48 `hex*` values under `spectral_classes` in the two `et_tokens.json`
  files. They must be identical, character for character.
- **Never deploy the Python `dist/`.**

---

## 7. Visual verification checklist — each effect against its law

Do this on desktop Chrome or Edge at http://localhost:8080/ with DevTools
open (F12).

**Global**
- [ ] Page renders **dark** with the colored, glowing equation and stars.
      A white unstyled page means the §0 tree is wrong — `et.css` must show
      status **200** in the Network tab. Fix placement, not code.
- [ ] **Runtime diagnostics (the page's own error handling):** in a
      healthy environment **no banner appears** at the top of the page.
      If a banner does appear, it names the exact degraded capability —
      OS-level reduced motion (all animations intentionally frozen,
      with the Windows setting to change), missing `offset-path`
      (meteor parked), or missing `color-mix()` (washes simplified).
      **A page with no animations and no banner is a stale file** —
      view source and look for the comment
      `ET runtime diagnostics layer v1`; if absent, an old
      `index.html`/`et.css` pair is being viewed.
- [ ] **Network tab:** no `.js` requested anywhere. **Console:** empty.
- [ ] Disable JavaScript (DevTools ▸ Ctrl+Shift+P ▸ "Disable JavaScript"),
      reload: the site is **identical**. Re-enable after.
- [ ] View source: no `<script>` element exists.

**The deep field (the real sky)**
- [ ] Stars fill the viewport as a scattered 2-D field of radiant orbs
      in **true blackbody colors**: ember-orange M dwarfs through solar
      white to blue B/O giants — Planck's law at each star's lattice
      temperature T = 2^((135+4c)/12) K, through the CIE 1931 observer
      with exact SI constants.
- [ ] **Chromatic scintillation:** blue-white stars flash hard (to full
      brightness and down toward black); orange embers barely breathe —
      Kolmogorov's 7/6 law, amplitude ∝ T^(7/6).
- [ ] The **anchor giants glow ember-red with two slowly rotating
      dipole streamers** (256 s per revolution); the second-magnitude
      shell carries four ice-blue quadrupole lobes. Drift layers as
      before (3072/6144/12288 s per wrap); the violet Breath crosses
      once per 64 s.
- [ ] **The Deep is a volume**: stars sit at true 3-D depths (each has
      its own translate3d z between ±512 px in a 2048 px perspective
      frustum). The **±15° sway every 128 s** makes it unmistakable —
      near stars visibly sweep past far ones. The whole vault also
      turns once per lattice-sidereal day about an axis tilted by the
      real obliquity, 23.439°.
- [ ] **Every star is a simulated sphere**: colorful limb-darkened
      discs in pure blackbody tint — bright Eddington center softening
      toward the limb, NO spikes, NO white cores — and each one
      **breathes**: radial pulsation of 1.5625 % (1+2⁻⁶) on its class
      period, 241–456 s (the solar p-mode cell, k = 99 ↔ 304 s, sits
      at class 4). The red giants keep their two slowly rotating
      dipole streamers. The verification report now carries the
      interior-solution gates (Lane–Emden ξ₁ eigenvalues), the h/h⁄2
      method-ε witness, and the Sempaevum-rounding ε gates — 205 total.
- [ ] **The nebula is unmissable now**: four vast cloud planes at
      different depths (true parallax under the sway), glowing in real
      emission-line colors — Hα red, [OIII] teal-green, Hβ, [SII],
      blue scatter — each breathing by one semitone of scale on its
      own period (128–362 s).
- [ ] **True background**: scroll the page hard — the sky must not move
      with the content at all (it is position:fixed, mounted before the
      header, and gated in the build).

**Octave Tunnel (hero backdrop)**
- [ ] Faint spectral rings expand behind the equation.
- [ ] **Seamlessness test:** watch across the 32 s mark (one full period) —
      there must be **no visible jump or seam**, because the loop is one
      exact octave. Watch two periods (64 s) to be sure.

**Ψ-glow (hero equation)**
- [ ] The aura of `P ∘ D ∘ T = E` breathes with an 8 s period, subtle,
      never dying to zero (Shimmer range [1−√V, 1+√V]).

**Cascade Meteor (sigil wheel — scroll to The Lattice)**
- [ ] A meteor: a bright head trailed by a tapering 12-ghost tail hugging
      the path (tail fades by K per ghost; whole tail spans one segment).
- [ ] **It runs the spectrum:** the head's color morphs through ALL 12
      spectral classes in circle-of-fifths order as it passes each node,
      and the tail drags the previous colors behind it.
- [ ] Full circuit = **12.99 s**. Time it.
- [ ] **Impedance law visible:** it crawls through the segments landing on
      gravity/tritone-class nodes and whips through the EM-class ones —
      the speed ratio between slowest and fastest segment is ξ(1)/ξ(12) =
      8.5625 : 1.
- [ ] The four generator lines under it are faint neutral hairlines (the
      g = 7 rail slightly stronger) — the meteor owns the wheel.

**The Engine (nav ▸ Engine)**
- [ ] Panels change every 8 s; full cycle 96 s (12 panels).
- [ ] The **3/2** panel shows ε = 1.955…¢ — the canonical delta.
- [ ] The **4/3** panel shows the *same* |ε| (IC-149) and k = 5, d = 12.
- [ ] The **2^(1/12)** and **√2** panels read **ε = 0 — lattice-exact**.
- [ ] On every panel, the `Π⁻¹(k,ε)` line's 60 digits match the `r` line's
      60 digits exactly. Pick one and compare by eye.

**Starfield + motion (robustness by construction — no diagnostics UI)**
- [ ] The stars now fill the whole viewport as a scattered 2-D field —
      radiant orbs with soft cores, not discs, and **no diagonal line**.
      Placement law: star i sits at (frac(i·φ), frac(i·√2)) — golden ×
      tritone torus windings, Weyl-exact equidistribution.
- [ ] A vast, slow violet **breath** crosses the deep once per 64 s.
- [ ] Animations run **unconditionally** on every engine: the meteor
      travels by plain translate() keyframes (no offset-path anywhere),
      the atmosphere uses forge-computed 8-digit hex (no color-mix on
      any critical path), and all motion is opacity/transform/
      background-position — primitives every browser supports. There is
      no diagnostic banner by design: the failure causes were
      engineered out, not reported.

**Layout / responsive**
- [ ] DevTools device toolbar at 393 px width (S22 Ultra class): columns
      collapse to single at the 512 px breakpoint (bp-mid = 2^(108/12) =
      512 exactly); hero equation scales fluidly; nothing overflows.
- [ ] Real-device pass on the S22 Ultra via §4.

**Content gates**
- [ ] Footer + About email reads **exceptiontheory@gmail.com** (typo fix
      confirmed in place).
- [ ] DOI link opens `https://doi.org/10.5281/zenodo.19762311`.
- [ ] Products shows the "Forthcoming" state (list still pending).

---

## 8. Pre-deployment gate (all boxes required)

- [ ] §0 folder tree verified: page renders dark; `et.css` loads with 200.
- [ ] §5 rebuild: clean compile, **176/176 PASSED**, exit code 0.
- [ ] §5.6 double-run **BYTE-IDENTICAL**.
- [ ] §7 checklist complete on desktop.
- [ ] §4 pass on the S22 Ultra (and TV if desired).
- [ ] Deployment set copied (§1 list only — no forge sources unless you
      *want* to publish them).
- [ ] Server: any static host works; for the planned VPS, the nginx block
      in ET_Site_Design_Document §9 applies unchanged (static root + TLS;
      `gzip on;` recommended — `et.css` and `index.html` compress ~4:1).

When every box is checked, the site is verified end to end: the mathematics
by the forge's own 176 gates, the rendering by your eyes, on your hardware.

*Michael James Muller — Aevum Defluo — Exception Theory LLC — P ∘ D ∘ T = E*
