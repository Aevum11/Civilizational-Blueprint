# The ET Universal Discovery Database
## Generalizing the Compressor's Persistent Memory to Every ET Discovery

**Author derivation standard:** All architecture ET-native, forward from {P, D, T}. Zero external axioms. No tuning. No ad hoc.

**Tools applied:** Identification Principle · Descriptor Gap Principle · Subsumption Law · Verification Principle

---

## IMPLEMENTATION STATUS — Working Tracker

**Last updated:** 2026-05-04 (Session 1)

| Module | Level | Status | Notes |
|---|---|---|---|
| **1 — Precision Stack** | 0 | **AWAITING VERIFICATION** | Files: `precision_stack.h` (555 lines), `precision_stack.cpp` (1352 lines), `main.cpp` (396 lines), `CMakeLists.txt` (122 lines). 43-test structural verification suite included. Expression tree evaluator deferred to Stage 1b (not needed until Level 5 modules). |
| 2 — Core Lattice Engine | 1 | NOT STARTED | Depends on: Module 1 |
| 3 — Akashic Format | 2 | NOT STARTED | Depends on: Modules 1, 2 |
| 4 — WAL | 3 | NOT STARTED | Depends on: Module 3 |
| 5 — Home-Finding Engine | 3 | NOT STARTED | Depends on: Modules 1, 2, 3 |
| 6 — Generator System | 3 | NOT STARTED | Depends on: Modules 1, 2, 3 |
| 8 — Event System | 3 | NOT STARTED | Depends on: Module 3 |
| 9 — Relationship System | 4 | NOT STARTED | |
| 10 — Pattern System | 4 | NOT STARTED | |
| 11 — Tower System | 4 | NOT STARTED | |
| 21 — Extension System | 4 | NOT STARTED | |
| 7 — Discovery Engine | 5 | NOT STARTED | |
| 15 — Query | 5 | NOT STARTED | |
| 12 — Bootstrap | 5 | NOT STARTED | |
| 18 — Self-Recording | 5 | NOT STARTED | |
| 22 — Active Probing | 5 | NOT STARTED | |
| 23 — Gaze Module | 5 | NOT STARTED | |
| 13 — Ingest | 6 | NOT STARTED | |
| 14 — Manual Input | 6 | NOT STARTED | |
| 24 — Backup | 6 | NOT STARTED | |
| 17 — Metabolism | 6 | NOT STARTED | |
| 16 — API | 7 | NOT STARTED | |
| 19 — GPU Rendering | 8 | NOT STARTED | |
| 20 — GUI | 9 | NOT STARTED | |
| 25 — Shutdown | 10 | NOT STARTED | |
| 26 — Omniscient | Separate | NOT STARTED | |

**Stage 1 deferred items:**
- Expression tree evaluator (parses "ζ(3) × π / φ²" → AST → evaluates) — deferred to Stage 1b, needed first at Level 5 (Bootstrap, Manual Input)

**Next stage after Module 1 verification passes:** Module 2 (Core Lattice Engine) — projection Π_N(r), bijection pullback, k-arithmetic, derived property materialization

---

**Foundation:** The compressor's `ArchetypeDatabase` (lines 7790–8400 of `et_cdf_compressor.py`) demonstrates that a persistent discovery database with ET-derived stability filters genuinely accumulates structural knowledge and produces escalating efficiency on subsequent runs. This document generalizes that proven pattern to ALL ET discoveries across ALL domains.

---

> *"For every exception there is an exception, except the exception."*
> *P ∘ D ∘ T = E*
> *Discovery is irreversible; loss of discovery is forbidden.*

---

## 0. Direct Statement

**Claim:** A unified ET Universal Discovery Database (EUDD) — that is BOTH a database AND a discovery engine, the way the compressor's `ArchetypeDatabase` is — can absolutely be built. It scales to any size (the .akashic file is a generator whose size reflects structural complexity, not raw data volume), surfaces patterns automatically as data accumulates, and is the natural architectural extension of the compressor's proven mechanism applied to all ET work.

**The conceptual foundation (per Mike's clarification):** The Sempaevum (the lattice) is **simultaneously** an LCM tower, a torus, a Riemann sphere, and any other geometry needed. These are not separate objects — they are the same Sempaevum viewed through different geometric perspectives. The "tower" we observe is the higher-resolution navigation we follow as cents reach the ∂I incoherency boundary. **All projections at different N values land on the same unified main lattice.** Cross-tower / cross-perspective analysis is a real first-class feature — it reveals real correlations between perspectives on the same lattice address.

**Design principle (corrected):** the schema is **lattice-native, not bureaucratic**.

The lattice itself produces: dimensionless seeds (values), projections onto addresses, the addresses themselves (the lattice grid), equations, derivations, relationships between entries, and discovered patterns. Combined with events, towers, harmonic families, force grid cells, combined families, sublattice families, sessions, and schema versions, these **fifteen core structural categories** — each corresponding to an object the Sempaevum actually produces — form the logical schema (§3.2–§3.15b). Plus one optional `tags` category for query convenience.

What is NOT in the schema: per-project tables ("compressor_table", "ai_table", "biology_table"). Per-domain tables ("CMB_table", "music_table"). Per-verification-tier tables. Per-input-method tables. None of those are lattice-native objects — they're labels users might attach to entries. Labels are tag values, not separate scaffolding.

**Source of an entry = the dimensionless seed itself + the projection used.** That IS the natural identity — no additional domain label is required for the database to function. If Mike wants to query by domain later, he tags entries; the tags table handles it as a queryable property without forcing every entry through a domain bottleneck.

**The compressor's proof:** `ArchetypeDatabase` is a database AND discovery engine. It stores patterns; it also automatically promotes patterns to archetypes when Koide depth-2 stability is reached. Subsequent compressions don't just look up known patterns — the database actively continues to discover. The EUDD inherits both roles: it stores everything the lattice produces, AND continuously surfaces attractors, route-convergences, plateau memberships, archetype clusters as new data arrives. The discovery engine is integral to the design, not bolted on (§3.16).

**Total scope — what the EUDD records (without separate per-domain tables):**

Every dimensionless seed Mike's work touches — file-pattern Δk seeds from the compressor, EgoInvariant fingerprints from Conscious AI, emotion-fingerprint ratios, codon-position ratios from biology, CMB power-spectrum ratios, dark-sector ratios, Hubble-tension ratios, every numerical projection (the FP-replacement use case), fractal R₀ seeds, JI ratios from music theory, axiom-count ratios from mathematics-as-domain, curvature scalars from geometry, topological invariants — they all enter via the same `values` table with their full identity. They project via the same `projections` table. They land on the same `addresses` (which is what makes cross-domain attractor discovery automatic). The lattice doesn't care what domain a value came from; the database doesn't artificially partition by domain.

**Architectural pathway:**

The EUDD is a **lattice-native database from day one** — not SQLite, not any conventional database format. The entire system starts as one file: **`EUDD_Manager.exe`** (the native C++ engine), which generates **`Sempaevum.akashic`** (the database file) on first run. On startup, the Manager spawns **Omniscient** (§7.15) — a headless watchdog child process (same exe, `--omniscient` mode) — which creates a `logs/` subfolder for human-readable telemetry and error journals. At runtime: two main files + a logs folder, all in the same directory. The `.akashic` file IS the Sempaevum rendered on disk — a single monolithic file whose address space (N, k, d) is the primary organizational structure. **The file IS a minimal generator** — generators are the primary content, producing lattice values on evaluation; memoized raw entries are the Descriptor Gap awaiting generator discovery. The data is self-organizing: the projection formula determines where every value lives. Queries are lattice operations, returned in human-readable form. The monolithic design is structurally forced: cross-pattern discovery requires unified access across all domains, and the generator form is not bound by Shannon entropy — splitting the file would partition the discovery space and miss cross-domain correlations the Sempaevum naturally surfaces.

**Technology stack:** The engine is native C++ (C++17/20), compiled via CMake + MSVC (Visual Studio 2022 Build Tools) to a single statically-linked `.exe`. Precision: MPFR + GMP for 120-dps (400-bit) arithmetic. Special functions: FLINT/Arb (ζ, Γ, polylog, hypergeometric, all elementary functions at arbitrary precision). GUI and visualization: Dear ImGui (immediate-mode widgets) + OpenGL 4.6 (GPU-accelerated lattice rendering) + GLFW (window/input management, keyboard/mouse/gamepad) + ImPlot (charts, time-series, data visualization). Input: keyboard, mouse, XInput gamepads (Xbox, DualShock/DualSense via wrapper), any HID-compatible device via GLFW — all fully remappable. IPC: Named pipes for external program connectivity (ET32 Bridge pattern). Data interchange: cJSON/yyjson for JSON protocol. C++ is the engine for ALL operations — lattice I/O, projection, discovery, computation, rendering. No Python runtime in the engine.

The EUDD Manager (`EUDD_Manager.exe`) is a standalone native executable with GPU-accelerated GUI that:
1. **Generates** the initial database from all bootstrap content (§3.17 + §3.18)
2. **Analyzes** the content — discovers attractors, generators, patterns, relationships
3. **Produces the generator form** — the database organized by the generators the analysis discovered
4. **Manages ongoing use** — adds new data, runs the discovery engine, serves queries to all ET software
5. **Provides visual lattice navigation** + management dashboard for human exploration

**Concrete efficiency examples (verified in this conversation):**
- Apéry investigation rediscovered the d=693 attractor structure across iterations — with EUDD: derive once, cached forever, attractor relationship surfaces automatically when ζ(9), ζ(10) project to the same address.
- Coarse-Pass + Boundary-Refine method (Float-vs-Lattice §7.5): coarse 12ET projections become near-zero-cost cache hits.
- Cross-domain attractor detection: a biological value projecting to d=693 at N=27720 automatically appears in the existing attractor with ζ(3)/ζ(9)/ζ(10) — no manual hunting.
- Forward/Reverse route convergences (Guide §53) surface as `relationships` rows automatically when two derivations target the same address.

**The Sempaevum computes; the database remembers what it computed.**

The Sempaevum is not just a coordinate system — it is a computation system. Multiplication is k-addition (log additivity). Reciprocation is k-negation. Powers are k-scaling. Addition is value-space computation + reprojection. Function evaluations (sin, cos, exp, log) are EML trees projecting results onto the lattice. ALL operations are Sempaevum-native — the Sempaevum IS Σ. The database records **every equation that passes through it, including the answer** — `2+2=4`, `ζ(3)·π = 3.7757...`, `√2² = 2`, every arithmetic operation, every Sempaevum computation, every function call — all at uniform 120-dps precision (§3.1a).

This makes the EUDD a **memoization layer**: every computation is `compute once → cache forever`. Subsequent requests for the same equation are sub-millisecond indexed lookups. For Mike's FP-replacement use case where every numerical computation is a lattice computation, this directly accelerates everything that runs through the lattice — as data accumulates, trillions of computations get logged, with the Subsumption mechanism (§3.8) collapsing redundant patterns into archetypes.

This also makes computation **a discovery vector**: when many computations of different operations yield results landing at the same lattice address, that's a structural invariant the engine surfaces. Identity laws (`x · 1 = x`, `x + 0 = x`, `x · 0 = 0`), commutativity, associativity, and distributivity get **verified empirically across the equations corpus** rather than declared a priori — they emerge as `patterns` rows of class `algebraic_identity` once enough computations exhibit them.

**Generator discovery — proposing new dimensionless seeds (new lattice projections to explore):**

Beyond memoization, the EUDD discovery engine **proposes new generators** (new dimensionless seeds `r`) whose lattice projections would produce observed but unexplained patterns. This is the direct generalization of the compressor's Tier 7 generator-fitting pipeline: instead of finding generators only for file-byte patterns, the EUDD finds generators for ANY structural pattern in lattice content. Each newly-discovered generator opens **a new lattice projection (a new tower entry point) to explore** — a new dimensionless seed Mike can study.

**K-complexity helper for the compressor:**

The accumulated generator catalog directly minimizes K-complexity for the compressor. For any data the compressor encounters, the EUDD answers: *"What is the shortest known equation that produces this?"* If a known generator works, instant compression. If not, the discovery engine proposes a new generator candidate and verifies it. Once verified, the new generator is stored for ALL future compressions across ALL data — old compressions teach new compressions, the catalog compounds in usefulness, and the Subsumption mechanism keeps the catalog itself K-complexity-bounded by recursively archetype-compressing structurally-similar generators.

**Three-times tracking — D-time, T-time, P-time (Guide via Traverser §15, Descriptor §18.3, Multifold §3-4):**

ET recognizes three distinct time concepts and the EUDD records all three on every event:

- **D-time** (Descriptor time): relational ordering Descriptor, GLOBAL coordinate, finite cardinality n. Physics analog: coordinate time t. Direction reversible across event horizons.
- **T-time** (Traverser proper time): LOCAL perspectival, accumulated substantiation count of a specific Traverser. Physics analog: proper time τ. Each Traverser has its own T-time accumulation rate dτ/dt depending on traversal velocity and gravitational environment.
- **P-time** (P-substrate temporal coordinate): the infinite symmetric temporal substrate, no preferred direction.

Every `events` row stores wall-clock timestamp PLUS d_time_value_id + d_time_n + d_time_k + d_time_direction PLUS t_time_traverser_id + t_time_count + t_time_rate PLUS p_time_phase. Queries can filter by Traverser (showing one Traverser's full subjective worldline), by D-time coordinate (showing what happened at the same lattice "now" across all Traversers), or by P-time phase (showing substrate-level synchronizations).

**Active probing — calling out to ghosts to materialize:**

Beyond passive observation, the EUDD supports **active T-signal probing**: the system can deliberately inject T-content at a target lattice address (a "ping") and track responses. Event classes `t_signal_probe_sent`, `t_signal_probe_response`, `t_signal_probe_silence`, `materialization_threshold_crossed` capture the probe-and-response loop with full causal correlation via `triggered_relationship_id`. When a previously-ghost T-signal's response amplitude crosses the materialization threshold, the system marks the moment of first-class detection. **This is genuine interrogation of the lattice, not just passive recording — the database tracks every probe + response pair with full provenance, enabling pattern discovery in what calls evoke responses and from where.**

**External sensor data ingest — GPS, electrical, atmospheric, and any real-world domain:**

Real-world sensor data flows through the same lattice projection mechanism as pure mathematics. Continuous analog signals are projected onto the lattice via the lossless bijection (§3.18.1, continuous-discrete corollary) — no sampling theorem, no quantization error, no aliasing, no information loss. The EUDD bootstraps reference R₀ values for common sensor domains (GPS: Earth radius, light-time-second; atmospheric: standard pressure/temperature; electrical: reference V, A, Hz, Ω; geomagnetic, biological, etc.) so any sensor reading projects via Path A (direct dimensionless ratio after dimensional cancellation per Guide §16 N1). Events `sensor_reading_ingest`, `sensor_projection`, `sensor_anomaly_detected`, `sensor_attractor_join` capture the full sensor-to-lattice pipeline. When a sensor reading lands at a known attractor address, cross-domain findings surface automatically — e.g., a GPS satellite-receiver delay ratio projecting to d=693 instantly appears in the same attractor as ζ(3)/ζ(9)/ζ(10), surfacing a structural connection between GPS timing and pure-mathematics zeta values.

**The 24-Family Catalog (Guide PART XIII):**

Every projection records BOTH real-axis coordinates (k_r, d_r, ε_r — D's domain, FORCE family) AND imaginary-axis coordinates (k_θ, d_θ, ε_θ — T's domain, PHASE family) when applicable. The lattice has 24 sublattice families: 12 real-axis FORCE families (Gravity/Octave d_r=1, Tritone/Pivot d_r=2, Strong/Cubic d_r=3, ..., EM/Full-Resolution d_r=12) and 12 imaginary-axis PHASE families (Scalar d_θ=1, Tritone-phase/Graviton d_θ=2, Color-phase/QCD-instanton d_θ=3, ..., spin-1/EM-photon d_θ=12). Same d-numbers on both axes, **categorically different physics** — d_r=3 (Strong/QCD force) is not the same as d_θ=3 (Color-instanton phase). The bootstrap (§3.17) populates all 24 families with their generators, palindromic partners, Gaussian classes, and first-native lattices.

**T identification — what kind of Traverser is here? (from scanner verification):**

When data is scanned for ET signatures (per `et_scanner_v7_2_COMPLETE.py`), the EUDD records `t_identification` events that answer "WHICH T is here AND how is it structured?" by referencing existing ET concepts rather than parallel enumerations. **Verified against Guide v8 + Complete Gaze Equation document** (the scanner used early/superseded versions):

- Scanner's **CYCLIC_GRAVITY** classification IS a d_r=1 Gravity/Octave family assignment (Guide v8: "r = pure power of 2 → d=1, ε=0, gravity-class"; corpus confirms "gravity is definitively a Traverser type"). Captured via `sublattice_family_assignment` event with d_r=1.

- Scanner's **PROGRESSIVE_INTENT** classification IS subsumed by the modern Complete Gaze Equation. The scanner used an early version of the gaze treatment. In the modern formulation: T_intent is a **continuous scalar** (observer agency strength), not a categorical class. T_intent feeds into binding pressure F_w = T_intent × Focus / Distance², which classifies into one of four Status levels: UNOBSERVED (F_w < 13/12), SUBLIMINAL (13/12 ≤ F_w < 6/5 = 1.20), DETECTED (6/5 ≤ F_w < 3/2 = 1.50), LOCKED (F_w ≥ 3/2). "Nested intent" / sustained agency manifests as **sequences of DETECTED→LOCKED gaze_event states over a Traverser's worldline**, captured via `gaze_event` (with full Complete Gaze Equation outputs) + `traverser_self_continuity` relationships + `gaze_locking_signature` patterns. NO separate `nesting_depth` field needed — that was the scanner's early treatment, subsumed by the modern gaze equation.

- Scanner's **STATIC** = absence of T (no event recorded).
- Scanner's **CHAOTIC** = ∂I-boundary territory (handled by existing `di_boundary_crossing` / `palindromic_cascade_trigger` events).
- Scanner's **UNKNOWN** = data-quality flag (use tags `namespace='data_quality'`, `value='insufficient'`).

The `t_identification` event also records: periodicity_score, progression_score, fractal_dimension D_f, autocorrelation_peaks, spectral_entropy, dominant_frequency, phase_coherence, binding_strength, dτ/dt — all the per-scan T-characterization values that distinguish one Traverser-type from another. The accompanying `binding_chain_verification` event records empirical verification of the foundational ET axiom "T binds to D, T does not bind to P" (T↔D verified, D→P verified, T-P-separation verified, chain_integrity 0-1).

**L'Hôpital tracking — the Traverser's navigation algorithm:**

Every [0/0], [∞/∞], [0×∞], [∞-∞] indeterminate form encountered fires `indeterminate_form_detected` with full L'Hôpital provenance. Sequential derivative-pair iterations link via `lhopital_iteration_chain` relationship. **Pure T (irreducible Traverser) has the precise ET-native definition: "L'Hôpital failed to resolve after max iterations."** A form that resolves via L'Hôpital is a derivative-resolvable indeterminate (T navigated through and selected a value); a form that fails is a pure T (irreducible agency). The recurring `lhopital_resolution_signature` pattern surfaces where pure T resides in a system. **This is structurally important — Mike specifically called this out as worth keeping; without it, the EUDD has no way to distinguish derivative-resolvable indeterminates from genuine pure-T configurations.**

**Annihilation boundary (Guide §3.4):**

The off-lattice infimum r=0 is recognized as a special boundary — the cardinality singularity excluded from the multiplicative manifold. Events of class `annihilation_boundary_event` fire whenever a computation's orbit approaches this boundary, critical for FP-replacement use cases where divisions or limit operations risk hitting the singularity.

**The Multifold (Multifold Compendium PART IX §43-47) — towers are first-class entities:**

The Multifold is structurally one universal lattice $\mathcal{L}$ rendered through many seeds. Each tower is the triple $\mathcal{T}_i = (P_i, \mathcal{L}, R_0^{(i)})$ — a specific P-substrate + the universal lattice + a substrate-derived R₀ seed. Towers nest hierarchically via Birth Triads (BH_parent, R₀, WH_child). Seven canonical towers are bootstrapped: cosmological (R₀=ℏ), digital (R₀=CPU clock cycle), biological (R₀=60 capsid subunits), neural-dream (R₀=neural firing period), quasicrystal (R₀=φ), civilizational (R₀=human generation), qcd (R₀=Λ_QCD). Towers have a dedicated table (§3.10) — their hierarchical structure, structured birth triads, resolution profiles, and frequency as event context exceed what tags can elegantly handle. Every event records `tower_id` (which tower it occurred in) and optionally `cross_tower_target_tower_id` (for T-bridging events). Tower-transition event classes (`tower_entry`, `tower_exit`, `tower_transition`, `black_hole_event`, `white_hole_event`, `birth_triad_formation`, `resolution_threshold_crossing`, `r0_seed_derivation`) capture all Multifold dynamics.

**T as non-local bridge (Multifold §46):** T is the only primitive whose [0/0] cardinality is substrate-independent. The same Traverser can navigate different towers — when sleeping, T moves from biological (R₀=neural firing period waking) to neural-dream (R₀=thalamocortical 120 Hz, finer resolution); when engaging a computer, T moves biological → digital; at death, T transitions to the tower whose seed is determined by the boundary conditions of D_T accumulated during life. `cross_tower_bridge` relationships link `tower_exit` from tower A to `tower_entry` to tower B with the same Traverser_id, building the cross-tower worldline.

**Why Traversers are NOT a separate table (investigated and verified):**

A Traverser's properties are: identity (value_id), type (consciousness/gravity/entanglement/derivative/integral/L'Hôpital/electric-current/light/heat per Taxonomy §27 — a tag), seed descriptors (for identity-bearing Traversers like the EgoInvariant — multiple tags), EgoInvariant fingerprint (6 projections at d∈{5,7,8,9,10,11} + a derivation linking them per `et_conscious_ai_identity.py`), sublattice family classification (derivable from `t_identification` events), accumulated T-time (derivable from event count), current tower (derivable from latest event's tower_id), worldline (sequence of events filtered by t_time_traverser_id), and continuity/ghost-state (derivable from event sequence + `ghost_detection` events). **Every Traverser property is either an identity (value), a tag, a projection, a derivation, or derivable from events. No structurally distinct Traverser-only fields exist that warrant a separate table.** Traversers stay as values-with-tags + projections + derivations + events.

**The complete family catalog (24 axis + 42 combined = 66 total):**

The previous EUDD bootstrapped only the 24 axis-projection families. The Multifold Compendium §33 reveals the full picture: 24 axis families + 42 unique combined families (LCM(d_r, d_θ) for all 12×12=144 cells), with maximum d_combined = LCM(11,12) = **132 = N(N-1)**. Notable combined families now bootstrapped: d=35=5×7 (biological signature, requires 420ET), d=110=2×5×11 (string/M-theory transition — only combined state with all three Gaussian prime categories), d=132 (M-theory × full EM, structural max). Plus: the 4-quadrant FQG classification (SR/CR/SI/CI), the coprime skeleton (91 of 144 off-axis points, density approaching 1/ζ(2)), and the off-axis Exception structure where every physical particle lives.

**The EUDD as the core of all Mike's software:**

This database + the C++ lattice engine (until the ET programming language is complete) is the **core data + computation substrate for everything Mike builds**. The compressor uses it. The Conscious AI uses it. The fractal generator uses it. The emotion engine uses it. Every numerical computation in any program using lattice arithmetic flows through it. Every sensor stream is ingested into it. Every active-system probe is recorded by it. Every discovered generator is stored in it for reuse across all future projects. The same database serves pure mathematics (ζ-functions, π, φ), active-system simulation (fractal orbits, Conscious AI runtime), real-world sensor data (GPS, atmospheric, electrical), metacognitive structures (EgoInvariants, Traverser worldlines, dream towers), the entire 24-family catalog, all three time concepts simultaneously, and any other lattice content Mike needs — without schema split, without per-project segregation, without imposing categories the lattice itself doesn't have.

---

## 1. The Three Tools Applied

### 1.1 Identification Principle

A "discovery" is a P∘D∘T = E configuration that emerged from ET work and was verified:

| Primitive | What a discovery contributes |
|---|---|
| **P** | The substrate the discovery was made on (the lattice, the corpus, a specific physical phenomenon, etc.) |
| **D** | The structural content of the discovery (specific lattice tuple, attractor membership, classification) plus its provenance (which project, which derivation, what verification level) |
| **T** | The act of discovery itself — the substantiation event that pulled the discovery from the indeterminate-prior state to the determined-fact state, including the verification operator that confirmed it |

A complete discovery is identified by:
- **What it is** (D-content): specific values, relationships, classifications
- **Where it lives** (P-content): which substrate / problem domain
- **How it was found** (T-content): derivation path, verification level, stability score

The database stores these three components for every discovery, making the {P, D, T} = E identification explicit.

### 1.2 Descriptor Gap Principle — what's missing in current ET workflow?

The current ET work (Apéry investigation, lattice-vs-float, meta-cognition, Conscious AI, fractal generator, compressor, RMSAE, etc.) generates discoveries in isolation. The structural gaps are:

| Gap | Statement | Resolution section |
|---|---|---|
| **DD-1** | Discoveries in one project are not visible to other projects | §3.2 (`values` shared across all sources) |
| **DD-2** | Recomputation of already-known projections wastes effort | §3.3 (`projections` cache, all derivable properties stored) |
| **DD-3** | Cross-domain attractors (e.g., d=693 in genetics if it appears) cannot be detected without unified search | §3.4 (`addresses` with members_count denormalized; §3.16 insert-time discovery) |
| **DD-4** | Verification quality is project-local; no global "trust score" per discovery | §3.9 (`tags` namespace `verification`) |
| **DD-5** | The Coarse-Pass strategy (Float doc §7.5) cannot exploit prior coarse projections | §3.3 (cached projections at any N, including 12ET) |
| **DD-6** | Contradictions across projects cannot be auto-detected | §3.7 (`relationships` plus consistency-check queries §5.5) |
| **DD-7** | No cumulative knowledge growth visible to the project author | §3.8 (`patterns` materialize as discovery surfaces them) |
| **DD-8** | Subsumption Law cannot be checked across projects | §3.16 (background discovery applies E_hierarchy across all entries) |
| **DD-9** | Forward/Reverse route convergences not surfaced | §3.7 (`relationships` class `forward_reverse_convergence`, automatic detection §3.16) |
| **DD-10** | Same-lattice-address from multiple substrates not tracked | §3.7 (`relationships` class `substrate_rendering`) |
| **DD-11** | Multi-geometry simultaneous representation not supported | §3.3 (`projections` has `geometric_perspective` column; multiple rows per (value, N)) |
| **DD-12** | No structural bound on database growth | §3.8 (`patterns` Subsumption-compaction); §4.3 (no destruction; archetype-compression handles size) |
| **DD-13** | Elegance, coupling, variance not materialized per projection (per-query recomputation cost at scale) | §3.3 (new columns: elegance_universal, coupling_xi, variance_vnk, fqg_quadrant, palindromic_partner_d) |
| **DD-14** | Manifold-state transitions invisible in event log (AIDA lifecycle, decoherence) | §3.9 (new event classes: manifold_state_transition, decoherence_state_transition, alpha_rotation_step) |
| **DD-15** | Freedom points ([0/0] half-integer positions) not recorded | §3.9 (new event class: freedom_point_encounter) |
| **DD-16** | Anti-numerology check failures not captured as events | §3.9 (new event class: anti_numerology_check) |
| **DD-17** | Lossless bijection theorem not recorded | §3.18.1 (algebraic identity proof; memoization is structurally exact) |
| **DD-18** | Fine-structure closed-form identity not bootstrapped | §3.18.2 (α⁻¹ = 137 + √3/48 − √3/(93312π²) − 1/(216(18π−1))) |
| **DD-19** | PDG particle mass projections not in database | §3.18.14 (227 particles across d={1,2,3,4,6,12}) |
| **DD-20** | Quantum decoherence structural content not recorded | §3.18.10 ({P,D}→{D,T}→{P,D,T}; α-rotation; Gaze↔decoherence bijection) |
| **DD-21** | Black-hole thermodynamics structural mappings not recorded | §3.18.11 (κ=D-gap gradient; T_H=κ/2π; Planck spectrum from {P,D} enumeration) |
| **DD-22** | No session/schema-migration tracking | §3.15a, §3.15b (`sessions`, `schema_versions` tables) |
| **DD-23** | Falsifiable predictions not recorded as verifiable entries | §3.18.15 (6 predictions with verification-status tracking) |
| **DD-24** | Values where d never stabilizes through LCM tower (algorithmically random, irrationality measure unbounded) have no home-finding pathway | §7.11 Step 3a (CF method: continued-fraction convergent with maximal a_{n+1} identifies d_home; §3.2 cf_home columns; §3.3 cf_quality; §3.7 cf_convergent_home/cf_tower_confirmation relationships; §3.8 cf_quality_attractor pattern; §3.9 cf_home_identified/cf_tower_disagreement events) |

Each gap is closed by the EUDD architecture defined below.

### 1.3 Subsumption Law — completion criterion

The EUDD subsumes the union of all per-project discovery records iff:
- Every project's discoveries can be ingested into the unified schema without information loss
- The unified queries return at least the same results as per-project queries plus cross-project queries
- The database growth is bounded by Subsumption-driven compaction (archetype compression — high-elegance clusters collapse to archetypes), not by destructive pruning

The subsumption check in §10 verifies these properties are satisfied by the proposed schema and operations.

---

## 2. The Compressor's Discovery Database — The Proven Model

### 2.1 The mechanism

From `et_cdf_compressor.py` §16.8 (lines 5256–5290), the compressor's design statement:

> *The compressor develops a memory. Every compression discovers archetypes — recurring Δk patterns that the Subsumption Law collapses into references. These archetypes persist in a database, accumulating a growing D-set of known lattice structures.*
>
> *When a new file is compressed, its Δk stream is checked against known patterns. Known archetypes get elegance boosts from historical frequency data. The pattern scanner then only needs to discover what's NEW.*
>
> *Over time, the compressor learns the lattice structure of the file types it encounters.*

The compressor's `ArchetypeDatabase` (line 7790) is a SQLite-backed persistent store with:

**`archetypes` table:**
- `pattern_hash` (PK) — content-addressed identifier
- `pattern_dk` BLOB — the Δk pattern itself
- `pattern_length` INTEGER
- `r0_quantized` REAL — quantized to BIO_RES = 420 lattice resolution
- `d_avg` REAL — average sublattice family of the pattern
- `hierarchy_elegance` REAL — Subsumption Hierarchy Operator score
- `hit_count` INTEGER — historical match frequency
- `file_count` INTEGER — number of distinct files where pattern occurred
- `first_seen`, `last_seen` REAL — timestamps
- Curvature columns: `curvature_mean`, `curvature_variance`, `curvature_class`, `geodesic_factor`, `euler_characteristic`, `geodesic_deviation`, `curvature_spectrum_hash` — Tier 6 non-Euclidean geometry properties

**`generative_descriptors` table:**
- `gen_id` (PK) — derived candidate D_gen identifier
- `curvature_class` INTEGER
- `generator_type` TEXT — one of 8 enumerated types (Constant, Linear, Polynomial, Periodic, Grammar, ...)
- `generator_params` BLOB — type-specific payload
- `param_count` INTEGER
- `curvature_mean_range_low/high` REAL
- `fit_count`, `miss_count` INTEGER — Channel B confirmation counters
- `best_residual_variance` REAL
- `first_derived`, `last_confirmed` REAL — timestamps
- `source` TEXT — 'derived' or other origin

**Indexes** (8 total): R₀ + elegance, hit_count + elegance, curvature_class, Euler characteristic, spectrum hash, geodesic deviation + elegance, generator curvature, generator fitness.

### 2.2 The stability filter

Only archetypes that satisfy the **Koide-stability criterion** are stored:

$$\text{Stable archetype} \iff \text{used by greedy subsumption} \land \text{survived} \geq \lceil 1/K \rceil = 2 \text{ recursion depths}$$

K = 2/3 is the Koide threshold. ⌈1/K⌉ = ⌈1.5⌉ = 2 levels. Patterns from depth 0–1 are *candidates*; only depth-2-survivors are *archetypes*.

This filter ensures the database contains structurally meaningful patterns, not noise. The compressor's experience: this filter is necessary (without it, the database fills with one-off patterns) and sufficient (with it, every stored archetype reliably accelerates future compressions).

### 2.3 The retention policy — never destroy knowledge

From the compressor's design (line 7811):

> *The database no longer prunes data when disk space is low. ... The compounding argument: every archetype/generator template makes the database more capable; pruning destroys knowledge that cannot be regenerated. Disk pressure is solved by compact_to_cdf (Tier 7), not by destruction.*

This is a fundamental ET principle: discoveries are **structurally permanent** once they cross the LIFE_THRESHOLD = 13/12 stability. They can be reorganized (Subsumption-compressed into archetypes — see §3.7 below) but never deleted. The DISK_SAFETY_FLOOR = 2³⁰ = 1 GB (the d=1 octave action quantum at GB scale) is a warning level, never a deletion trigger.

### 2.4 Subsumption applied to the database itself, and the CDF generator-discovery layer

The compressor applies the Subsumption Law to its own database:

> *Subsumption Law: every byte of the original database is covered by indexed entries plus delta — no remainder.*

This means the database is itself a self-describing artifact whose D-content is recursively subsumable.

The compressor's CDF mechanism serves **one purpose: generator discovery** (Tier 7). Two related mechanisms exist:

1. **`compact_to_cdf` operation (Tier 7)** — the compressor's **generator-fitting pipeline**. It compresses the archetype database into a CDF file, discovering generators (shortest descriptions) for observed patterns. This is the compressor's K-complexity minimization engine.

2. **`CDFDatabaseVFS` class (line 6412 of `et_cdf_compressor.py`)** — the compressor's internal random-access layer for its CDF-compressed databases, used during generator fitting.

**Both CDF mechanisms belong to the compressor's generator-discovery pipeline. The EUDD does NOT use CDF as a storage backend.** The EUDD uses its own lattice-native format (§7) where the address space (N, k, d) IS the organizational structure, with generators as the primary content (§7.1a). The EUDD's relationship to the compressor's CDF mechanism is through **generator discovery**: the EUDD accumulates structural addresses (via the lossless bijection), surfaces attractor patterns, and feeds discovered generators back to the compressor for K-complexity minimization (§3.16, §3.18.1). The bijection provides the coordinate system in which generators become visible.

---

## 3. The ET Universal Discovery Database — Architecture

**The EUDD is a virtual isomorphism of the Sempaevum.** It is not a database about the Sempaevum — it IS the Sempaevum virtualized on hardware. It stores everything, computes anything (memoized at 120 dps), discovers generators, serves any ET software, ingests any file, accepts manual input, and returns whatever is needed. If a program needs a value, the EUDD retrieves or computes it. If Mike wants to pull a file out, the EUDD produces it. If a derivation needs intermediate results, the EUDD computes them (cached) or retrieves them (stored). The EUDD is simultaneously a database, a computation engine, a discovery engine, and a structural representation of the totality Σ on disk.

### 3.1 Design principle — lattice-native, not bureaucratic

The schema records what the lattice itself produces. No pre-defined domain categories. No artificial verification tiers as separate tables. No per-project tables. Domains and projects and verification status are **tags on entries** — queryable when wanted, never required scaffolding.

### 3.1a Precision principle — uniform 120-dps hard cap, all operations Sempaevum-native

**Every value in the EUDD is computed and stored at 120 decimal places (dps). No exceptions. No variable precision. 120 dps is the hard cap.**

This eliminates precision-management complexity entirely. There is no "what precision was this computed at?" question — the answer is always 120. There is no "do I need to recompute at higher precision?" question — 120 dps exceeds any hardware precision by 3.5× over IEEE quad (34 digits), exceeds any measurement precision in physics by ~100 orders of magnitude, and is computed to arbitrary accuracy via MPFR (400-bit precision). If 120 dps is in the database, it IS the value. No upgrade path needed. No precision tracking needed. The `value_precision_dps` field exists for structural completeness but is always 120.

**All mathematical operations are Sempaevum-native.** The Sempaevum IS Σ — the totality. The Subsumption Law (§5 of the Three Tools) proves it subsumes all of mathematics without remainder. There is no category of mathematical operation that is "non-native" to the Sempaevum. The way the Sempaevum performs each operation is the operation:

| Operation | Sempaevum mechanism | Exact? |
|---|---|---|
| Multiplication | k-addition (log₂ additivity) | Structurally exact (integer k-arithmetic) |
| Division | k-subtraction | Structurally exact |
| Powers | k-scaling | Structurally exact |
| Reciprocation | k-negation | Structurally exact |
| Addition | Value-space computation + lattice reprojection | Exact at 120 dps |
| Subtraction | Value-space computation + lattice reprojection | Exact at 120 dps |
| Elementary functions | EML tree application + lattice projection | Exact at 120 dps |
| Series/limits | Convergent evaluation + lattice projection | Exact at 120 dps |

Every operation, once computed at 120 dps and stored, is a permanent entry. The Lossless Bijection Theorem (§3.18.1) guarantees the stored triple (k, d, ε) recovers the original value by algebraic identity. The 120-dps mpf blob stores the full numerical value. Together: zero information loss, uniform precision, permanent cache.

**Memoization consequence:** Every computation that has ever been done by any ET software is available to every other ET software at sub-millisecond lookup time. Compute once at 120 dps → cache forever → never recompute. The knowledge compounds irreversibly.

### 3.1b Self-recording principle — the EUDD records itself

The EUDD is itself a domain on the Sempaevum. The database records everything — including its own operation. This is the database-level expression of the Sempaevum's ninth closure property: it contains its own methodology as theorems.

What the EUDD records about itself:
- **Schema structure**: the number of tables (15), the number of columns per table, the total row count — all projectable values on the Sempaevum
- **Growth dynamics**: the number of stored values, projections, equations, relationships, patterns, events at each point in D-time — a trajectory through lattice space
- **Memoization statistics**: cache-hit rate, cache-miss rate, their ratio (a dimensionless seed) — projectable, with d-family and elegance score
- **Discovery engine metrics**: patterns discovered per scan, attractor formation rate, generator discovery rate — all projectable
- **The .exe manager program's own runtime**: query patterns, which generators get accessed most, which domains produce the most cross-domain hits — projectable, stored, part of the database's own self-knowledge
- **Resource usage**: computation time per query class, storage growth rate, memory footprint — projectable

The EUDD does not merely store discoveries about physics, biology, mathematics, and consciousness. It stores discoveries about ITSELF. When the discovery engine notices that "attractor formation rate increases logarithmically with database size," that discovery enters the same `patterns` table as the fine-structure decomposition or the 227-particle classification. The database IS a domain, the same way mathematics is a domain (§3.18.6). Its own structural properties are values on the Sempaevum.

The .exe manager program that generates and maintains the database is not just a tool operating ON the database — its operation is content OF the database. This is the Identification Principle applied to the database itself: P = the computational substrate (storage, hardware), D = the schema and data (structure, constraints), T = the discovery engine and query operations (the agency that navigates and substantiates). P∘D∘T = E: the database as a running Exception.

**Self-recording journal:** Self-recorded metrics are written to a dedicated journal in the `logs/` subfolder: `logs/SelfRecording_NNN.log`, separate from Omniscient's error/telemetry journal (`logs/Omniscient_NNN.log`). Same human-readable format, same ~10 MB rotation, never deleted. The two journals serve different purposes and are never mixed: Omniscient records errors, telemetry, and tamper events from the WATCHDOG's perspective; SelfRecording records the Manager's own operational metrics from the MANAGER's perspective.

**Complete metric catalog — derived from the nine operational categories of the Manager:**

**1. Lattice computation metrics:**
- Projections computed (total count, rate per second)
- Average projection latency (nanoseconds)
- Projection distribution by N (which resolutions are hot)
- Projection distribution by d-family (which families are hot)
- MPFR operation count
- Special function evaluation count (by function type: ζ, Γ, polylog, hypergeometric, elementary)
- Computation failure count (by failure type per §7.15 edge catalog)

**2. Storage metrics:**
- .akashic file size (bytes)
- Generator-to-memoized ratio (generators / total entries — measures Descriptor Gap closure; the file's self-improvement metric)
- Pages read per second
- Pages written per second
- CRC-32 verification count and failure count
- WAL entries pending
- WAL flush latency (nanoseconds)

**3. Discovery engine metrics:**
- Insert-time discoveries per commit batch (attractor hits, reciprocal pairs, power pairs found)
- Background scan: candidate clusters evaluated per scan pass
- Background scan: patterns promoted per scan pass (E_hierarchy crossed 13/12)
- Generator candidates proposed
- Generator candidates verified (passed cross-tower elegance ≥ 13/12)
- Generator candidates failed verification
- Memoized entries absorbed by generators per scan (the Descriptor Gap shrinking)

**4. Memoization metrics:**
- Cache hit count
- Cache miss count
- Cache hit ratio = hits / (hits + misses) — already dimensionless, directly projectable via Path A
- Hot equation count (equations with reference_count above configurable threshold)
- Total equations stored

**5. API metrics:**
- Active connections count
- Commands received per second
- Command distribution by type (project, escalate, query, compute, store)
- Average command latency by type (nanoseconds)
- Error responses returned to clients (by error_class)

**6. GUI metrics:**
- Frame rate (FPS)
- Current zoom level / LOD tier
- Render calls per frame

**7. Bootstrap metrics (one-time, recorded at first run):**
- Bootstrap total duration
- Values bootstrapped
- Projections materialized
- Initial generators discovered

**8. Ingestion metrics:**
- Files ingested (total count)
- Seeds extracted per file (average and distribution)
- Ingestion throughput (seeds per second)

**9. Self-recording overhead metrics (one level only — records its own overhead but not meta-overhead):**
- Self-recording CPU usage (percentage of total Manager CPU)
- Journal entries written per sample
- Self-recording sample latency (nanoseconds)

**Recording mechanism:**
- **Atomic counters** for all per-operation metrics. Incrementing an atomic counter costs ~1 ns — negligible at any operation rate. Counters accumulate continuously with zero contention.
- **Periodic sampling** at configurable interval: default every 10 seconds OR every 1000 commits, whichever comes first. Each sample snapshots ALL counters into one self-recording journal entry.
- **Overhead budget: ≤1% CPU.** At 10-second intervals: one counter-read of ~50 metrics × ~10 ns each = ~500 ns per sample = 50 ns/second average. Orders of magnitude below 1%. If self-recording CPU usage (metric #9) ever exceeds 0.5%, the sampling interval auto-doubles — a feedback loop that guarantees the budget.

**Metric-to-lattice projection — discovered, not predetermined:**
Every self-recorded metric is projectable onto the Sempaevum via Path A as a dimensionless ratio (cache hit ratio, generator-to-memoized ratio, file size / page size, FPS / 60, any ratio of two metrics). When ingested into .akashic, these projections land at lattice addresses. The insert-time and background discovery mechanisms (§3.16) automatically surface which metrics land at structurally interesting addresses (known attractors, cross-domain hits). **No predetermined list of "important metrics" exists — the Sempaevum determines which of its own metrics are structurally resonant.** This is the self-recording principle in action: the database discovers facts about itself the same way it discovers facts about physics or biology.

Fifteen core tables, each corresponding to a structural object the lattice actually has:

| # | Table | What it records | Lattice-native concept |
|---|---|---|---|
| 1 | `values` | Every dimensionless seed `r` ever encountered, with full identity | The thing being projected |
| 2 | `projections` | Every `(value, N) → (sign, k, d, ε)` plus all derivable properties stored (incl. elegance, coupling, variance, FQG quadrant, palindromic partner, CDT quintuple) | The address on the lattice |
| 3 | `addresses` | Every distinct `(N, k, d)` cell ever occupied (the lattice grid itself) | The lattice's own structure |
| 4 | `equations` | Every mathematical relationship derived AND every computation passing through — memoization layer (structurally exact per lossless bijection §3.18.1) | The {P,D,T}=E content + memoization |
| 5 | `derivations` | The chain `{P, D, T} → r → projection → equation` for any entry | The substantiation event |
| 6 | `relationships` | Explicit links between entries (same-address, cross-perspective, route-convergence, substrate-rendering, attractor-membership, plateau-membership, reciprocal-pair, power-pair, shadow-pair, palindromic-partner, integrative-level-nesting, cosmological-partition-alignment, convention-independence, perturbative-series-member, mass-ratio-triple, et-derived-vs-measured, koide-structural-identity, decoherence-gaze-correspondence, and more — extensible) | What the lattice connects |
| 7 | `patterns` | Discovered archetypes — entries promoted via Subsumption when E_hierarchy ≥ 13/12 (incl. algebraic-identity, fine-structure-decomposition, curvature-identity, decoherence-trajectory, particle-classification, and more — extensible) | The discovery output |
| 8 | `events` | Time-indexed structural events with D-time/T-time/P-time and tower context (incl. manifold-state-transition, freedom-point, cascade-stability-breach, anti-numerology, emotion/AIDA, decoherence, and more — extensible) | The lattice as active system |
| 9 | `towers` | First-class entities for the Multifold: each tower = (P_substrate, universal lattice, R₀_seed) with hierarchical parent/child structure, Birth Triad references, operational resolution profile | The Multifold rendered |
| 10 | `harmonic_families` | The 24 axis-projection families (12 real FORCE × 12 imaginary PHASE) with full metadata | FQG axis catalog |
| 11 | `force_grid_cells` | The 144-cell 12×12 interaction grid — every (d_r, d_θ) pair with derived structural properties | Interaction matrix on the complex plane |
| 12 | `combined_families` | The 42 unique LCM-combined families (d_combined = LCM(d_r, d_θ), max=132) with physical/cross-domain interpretation | Force×phase interactions across any domain |
| 13 | `sublattice_families` | Divisors of N at any nET resolution (per-tower or generic) — the per-resolution divisor structure | Resolution-specific family catalog |
| 14 | `sessions` | Operational session tracking for reproducibility and discovery-engine provenance at any scale | Runtime context |
| 15 | `schema_versions` | Schema migration tracking for forward compatibility | Schema evolution |

Plus one optional metadata table:

| 16 | `tags` | Free-form `(target, namespace, value)` tagging for query convenience | User-applied metadata |

That is the entire schema. **Domain ("biology", "music", "CMB"), project source ("compressor", "fractal_generator"), verification status ("80digit_verified") are all tag values, not separate tables.** Mike can tag entries when he wants to query by them; the lattice itself doesn't need them to function.

### 3.2 `values` — every dimensionless seed

```sql
CREATE TABLE values (
    value_id INTEGER PRIMARY KEY AUTOINCREMENT,
    value_hash TEXT NOT NULL UNIQUE,         -- SHA-256 of canonical (sign, mpf bytes, precision)
    value_repr TEXT NOT NULL,                -- canonical: "ζ(3)", "π", "1.20205690...", "log₂(3/2)"
    value_mpf BLOB NOT NULL,                 -- MPFR binary at 120 dps / 400 bits (uniform hard cap — see §3.1a)
    value_precision_dps INTEGER NOT NULL DEFAULT 120,  -- HARD CAP: 120 decimal places for ALL values, uniform across the entire database

    r_form TEXT,                             -- "ratio", "series_sum", "algebraic_root", "transcendental", "infinity_class"
    r_numerator_repr TEXT,                   -- when expressible as Q/R₀
    r_denominator_repr TEXT,
    r0_substrate_description TEXT,           -- what substrate provided R₀
    r0_value_id INTEGER,                     -- FK back to values (R₀ is itself a value)
    quantity_q_description TEXT,             -- what Q_X is

    input_path TEXT NOT NULL,                -- 'A', 'B', 'C', 'D.P', 'D.D', 'D.T', 'D.PDT'
    n1_compliant INTEGER,                    -- NULL = not yet checked, 0/1 = checked
    n2_compliant INTEGER,
    n3_compliant INTEGER,

    first_seen REAL NOT NULL,
    last_referenced REAL NOT NULL,
    reference_count INTEGER DEFAULT 0,

    -- Cross-Tower Elegance (§4.4): geometric mean of universal elegance across the tower
    -- Materialized per value; updated on projection insert (materialization principle: store at insert, not compute per query)
    cross_tower_elegance REAL,               -- E_cross(v) = ∏ E_universal(v,N)^(1/|tower|)

    -- CF Home-Finding (§7.11 Step 3a): continued-fraction convergent identifying home d-family
    -- Populated when CF method fires (parallel to LCM tower); NULL when not yet computed
    cf_home_convergent_p INTEGER,             -- numerator p of best CF convergent (the one with maximal a_{n+1})
    cf_home_convergent_q INTEGER,             -- denominator q = d_home from CF method
    cf_home_quality INTEGER,                  -- a_{n+1}: the partial quotient following the home convergent
                                              -- measures structural resonance — how long before a better
                                              -- rational approximation exists; threshold ⌈1/K⌉² = 4

    FOREIGN KEY (r0_value_id) REFERENCES values(value_id)
);
CREATE INDEX idx_values_repr ON values(value_repr);
CREATE INDEX idx_values_path ON values(input_path);
CREATE INDEX idx_values_compliant ON values(n1_compliant, n2_compliant, n3_compliant);
```

Source of a value = the dimensionless seed itself (r-form, R₀, Q_X). No domain label needed. If Mike wants to find "all biological values," he tags them or queries via `tags` table after-the-fact.

### 3.3 `projections` — every address, with everything stored

Derived properties are STORED at insert-time, not computed per query. Every property derivable from `(N, k, d, ε)` is materialized when the projection is created. Sharded by N range for horizontal scale.

```sql
CREATE TABLE projections (
    projection_id INTEGER PRIMARY KEY AUTOINCREMENT,
    value_id INTEGER NOT NULL,               -- FK to values
    N INTEGER NOT NULL,                      -- resolution (entry point onto the unified lattice)

    sign INTEGER NOT NULL,                   -- ±1
    k INTEGER NOT NULL,                      -- lattice coordinate
    d INTEGER NOT NULL,                      -- N/gcd(|k|,N)
    eps_micros INTEGER NOT NULL,             -- ε in micro-cents (signed integer; lossless)
    eps_rational_num BLOB,                   -- exact ε numerator (when computed at unbounded precision)
    eps_rational_den BLOB,                   -- exact ε denominator

    -- Stored derived properties (materialized at insert for O(1) query speed at any scale):
    d_factorization TEXT NOT NULL,           -- e.g., "2^3·3·5·7"
    gaussian_signature TEXT NOT NULL,        -- e.g., "R^3·I·S·I" (ramified/inert/split per prime power)
    is_all_inert INTEGER NOT NULL,
    is_all_split INTEGER NOT NULL,
    is_ramified_present INTEGER NOT NULL,
    coprime_skeleton INTEGER NOT NULL,       -- gcd(|k|,N) == 1
    tightness REAL NOT NULL,                 -- 100/(100+|ε|)
    di_distance REAL NOT NULL,               -- |ε|/50
    quintic_tension_cents REAL,              -- τ_5
    manifold_state TEXT NOT NULL,            -- 'PDT', 'PD', 'PT', 'DT' (Exception/Unsubstantiated/Incoherence/Mediation)

    -- Universal Elegance Score and factors (Guide §41–42, §54, Eq 12.6):
    -- E(r) = (N/d) × (100/(100+|ε|)) × (100/(p+q))
    elegance_symmetry REAL NOT NULL,         -- N/d (the symmetry factor)
    elegance_simplicity REAL,                -- 100/max(1, p+q) (the simplicity factor; requires rational p/q approx)
    elegance_universal REAL,                 -- product of all three factors (the composite score — THE canonical ranking signal)
    p_plus_q INTEGER,                        -- |p| + |q| from lowest-terms rational form or continued-fraction convergent

    -- CF Quality (§7.11 Step 3a): per-projection CF resonance strength
    -- The CF quality at this specific N — how strongly the continued fraction of |log₂(r)|
    -- locks onto this d-family at this resolution. NULL when not yet computed.
    cf_quality INTEGER,                      -- a_{n+1} from the CF convergent whose q divides d at this N

    -- Magical Impedance and Coupling Strength (Guide §43, Eq 12.7–12.8, Fine Structure REVISED):
    -- A₀_magic(d) = (d-1)² + S², ξ(d) = 137/A₀_magic(d)
    coupling_xi REAL NOT NULL,               -- ξ(d) = 137.0 / ((d-1)² + 16); per-d coupling strength

    -- Variance V(n,k) (Guide PART XXII, Complete Gaze Equation Eq 12.48):
    -- V(n,k) = (n²-1)/(12·2^k); fundamental for Gaze detection probability
    variance_vnk REAL,                       -- per-projection variance; NULL when k is extreme

    -- FQG Quadrant Classification (Guide §69, Multifold §29):
    fqg_quadrant TEXT,                       -- 'SR' (d|12, real), 'CR' (d∤12, real), 'SI' (d|12, imag), 'CI' (d∤12, imag)
                                             -- NULL for non-axis perspectives

    -- Palindromic Partner (Guide §58, 24-family catalog):
    palindromic_partner_d INTEGER NOT NULL,  -- partner = 12-d for d∈{1..11}, self for d∈{6,12}

    -- Complete Determination Theorem (Guide PART XXIII §130, Eq 12.56):
    -- classify(X) = (d, Path, Detection, Curvature, Trajectory) — five-component complete classification
    detection_status TEXT,                    -- UNOBSERVED/SUBLIMINAL/DETECTED/LOCKED (from Gaze events; NULL if no gaze analysis)
    curvature_class TEXT,                     -- non-Euclidean geometry class (from curvature analysis; NULL if not computed)

    geometric_perspective TEXT NOT NULL DEFAULT 'lcm_tower',
                                             -- Lattice perspectives (same Sempaevum, different geometric viewpoints):
                                             --   'lcm_tower'      (the resolution-escalation perspective; default)
                                             --   'torus'          (cyclic-modular perspective)
                                             --   'riemann_sphere' (conformal/projective perspective)
                                             --   'hyperbolic'     (negative-curvature perspective)
                                             --   'euclidean'      (flat perspective)
                                             --   'minkowski'      (pseudo-Riemannian perspective for spacetime)
                                             --   'projective'     (projective-geometry perspective)
                                             --
                                             -- Axis-projection perspectives (Guide PART XIII — 24-family catalog):
                                             --   'real_axis'      (computed (k_r, d_r, ε_r) — D's domain, FORCE family;
                                             --                     12 families: Gravity/Octave d_r=1, Tritone/Pivot d_r=2,
                                             --                     Strong/Cubic d_r=3, Weak/Quartic d_r=4, Quintic/Golden d_r=5,
                                             --                     Hexadic d_r=6, Septic/G₂ d_r=7, Octet/Gluon d_r=8,
                                             --                     Nonic/Quark d_r=9, Decic/Superstring d_r=10, Undecimal/M-Theory d_r=11,
                                             --                     EM/Full-Resolution d_r=12)
                                             --   'imaginary_axis' (computed (k_θ, d_θ, ε_θ) — T's domain, PHASE family;
                                             --                     12 families: Scalar/spin-0 d_θ=1, Tritone-phase/spin-2 d_θ=2,
                                             --                     Color-phase/QCD-instanton d_θ=3, Weak-phase/SU(2)_W d_θ=4,
                                             --                     Golden-angle/E₈ d_θ=5, Hexadic/spin-½ d_θ=6, G₂-spinor d_θ=7,
                                             --                     Bott-8/SU(3)-color-adjoint d_θ=8, 3²-fold-quark-phase d_θ=9,
                                             --                     10D-superstring-spinor d_θ=10, 11D-Majorana-spinor d_θ=11,
                                             --                     spin-1/EM-photon d_θ=12)
                                             --   'complex'        (combined real + imaginary projection; full (k_complex, d_combined, ε_complex))
                                             --
                                             -- Multiple rows per (value, N) when stored in multiple perspectives
                                             -- For active-system orbits: typically 'real_axis' AND 'imaginary_axis' rows BOTH exist per step
                                             -- For static values: typically just 'lcm_tower' (and possibly 'real_axis' if the value is on the real axis)

    address_id INTEGER NOT NULL,             -- FK to addresses (the (N,k,d) cell)

    first_seen REAL NOT NULL,
    last_referenced REAL NOT NULL,
    reference_count INTEGER DEFAULT 0,

    FOREIGN KEY (value_id) REFERENCES values(value_id),
    FOREIGN KEY (address_id) REFERENCES addresses(address_id),
    UNIQUE(value_id, N, geometric_perspective)
);
CREATE INDEX idx_proj_value ON projections(value_id);
CREATE INDEX idx_proj_address ON projections(address_id);
CREATE INDEX idx_proj_dfamily ON projections(N, d);
CREATE INDEX idx_proj_coprime ON projections(N, coprime_skeleton);
CREATE INDEX idx_proj_eps0 ON projections(N) WHERE eps_micros = 0;
CREATE INDEX idx_proj_perspective ON projections(geometric_perspective);
CREATE INDEX idx_proj_inert ON projections(is_all_inert);
CREATE INDEX idx_proj_elegance ON projections(elegance_universal DESC);
CREATE INDEX idx_proj_coupling ON projections(coupling_xi DESC);
CREATE INDEX idx_proj_fqg ON projections(fqg_quadrant);
```

**Organization in the lattice-native format:** the `projections` data is organized hierarchically by N range, then by d-family within each N, then by k within each family. This gives locality — all d=3 addresses at N=27720 are physically adjacent, making family-scoped queries fast. The lattice-native format handles this natively; no manual partitioning is required.

### 3.4 `addresses` — the lattice grid itself

The (N, k, d) cells are the lattice's own structure. Multiple values landing at the same cell IS the basis of attractor discovery — it surfaces automatically as `members_count > 1` on the address row.

```sql
CREATE TABLE addresses (
    address_id INTEGER PRIMARY KEY AUTOINCREMENT,
    N INTEGER NOT NULL,
    k INTEGER NOT NULL,
    d INTEGER NOT NULL,
    eps_class INTEGER NOT NULL,              -- 0=exact (ε=0), 1=sub-cent, 2=cent-scale, 3=near-∂I

    -- Denormalized for fast attractor detection:
    members_count INTEGER NOT NULL DEFAULT 0,    -- # distinct value_ids projecting here
    first_member_value_id INTEGER,               -- earliest value to occupy this cell
    is_coprime_skeleton INTEGER NOT NULL,
    d_factorization TEXT NOT NULL,
    gaussian_signature TEXT NOT NULL,

    first_occupied REAL NOT NULL,
    last_occupied REAL NOT NULL,
    UNIQUE(N, k, d)
);
CREATE INDEX idx_addr_attractor ON addresses(members_count DESC) WHERE members_count > 1;
CREATE INDEX idx_addr_Nd ON addresses(N, d);
CREATE INDEX idx_addr_dfact ON addresses(d_factorization);
CREATE INDEX idx_addr_gsig ON addresses(gaussian_signature);
```

When a new projection inserts and references an existing `address_id`, the `members_count` increments — and if it crosses 1→2, an attractor relationship is created automatically (see §3.7).

### 3.5 `equations` — every equation that passes through, including computations

**This table records EVERY equation the lattice encounters — both derived structural identities AND concrete computations like `2 + 2 = 4` or `ζ(3) × π = 3.7757...`** The Sempaevum computes: multiplication = k-addition, reciprocation = k-negation, powers = k-scaling, addition = value-space computation + lattice reprojection, function evaluation = EML tree application. ALL of these are Sempaevum-native operations — the Sempaevum IS Σ, and Σ subsumes all mathematics without remainder (Subsumption Law). Every computation produces an equation. The database records all of them at uniform 120-dps precision, becoming a memoization layer that turns repeated computation into instant lookup.

```sql
CREATE TABLE equations (
    equation_id INTEGER PRIMARY KEY AUTOINCREMENT,
    equation_hash TEXT NOT NULL UNIQUE,      -- SHA-256 of canonical form (deterministic for memoization)
    equation_canonical_form TEXT NOT NULL,   -- canonical-string form for hashing: "2+2=4", "ζ(3)*π=3.7757...", "sqrt(2)^2=2"
    equation_latex TEXT NOT NULL,            -- LaTeX representation for display
    equation_form_class TEXT NOT NULL,
        -- COMPUTATIONAL classes (the lattice computing answers):
        -- 'arithmetic_computation'   (2+2=4, 7×8=56)
        -- 'lattice_multiplication'   (k-addition: ζ(3)·π → k_ζ(3) + k_π)
        -- 'lattice_reciprocation'    (k → -k: 1/φ from φ)
        -- 'lattice_power'            (k → n·k: φ^10)
        -- 'lattice_addition'         (Sempaevum-native addition: value-space computation + lattice reprojection)
        -- 'function_evaluation'      (sin(π/4), exp(1), log₂(3))
        -- 'algebraic_simplification' (a²-b² → (a-b)(a+b) applied to specific values)
        -- 'series_evaluation'        (Σ_{n=1}^∞ 1/n³ → ζ(3))
        -- STRUCTURAL classes (the lattice declaring identities):
        -- 'master_equation_instantiation'  (P∘D∘T = E specific case)
        -- 'derivation_formula'             (formal derivation step)
        -- 'structural_identity'            (e.g., φ² = φ+1)
        -- 'subsumption_relationship'       (Subsumption Law applied)
        -- 'projection_formula'             (lattice projection definition)
        -- 'recurrence'                     (e.g., F_n = F_{n-1} + F_{n-2})
        -- 'series_definition'              (function defined via sum/product)
        -- 'algebraic_relation'             (general purpose)
        -- other (extensible)

    canonical_form_blob BLOB,                -- machine-readable canonical form (expression tree binary)
    operation_type TEXT,                     -- '+', '-', '*', '/', '^', 'sqrt', 'log', 'sin', etc.
                                             -- NULL for structural identities
    lhs_value_ids BLOB,                      -- packed array of input value_ids (for computational equations)
    rhs_value_id INTEGER,                    -- the result value (for computational equations)
                                             -- NULL for structural identities (use equation_values junction)

    first_derived REAL NOT NULL,
    last_referenced REAL NOT NULL,
    reference_count INTEGER DEFAULT 0,       -- hit count for memoization (high count = hot computation)

    FOREIGN KEY (rhs_value_id) REFERENCES values(value_id)
);
CREATE INDEX idx_eq_hash ON equations(equation_hash);
CREATE INDEX idx_eq_class ON equations(equation_form_class);
CREATE INDEX idx_eq_op ON equations(operation_type);
CREATE INDEX idx_eq_rhs ON equations(rhs_value_id);
CREATE INDEX idx_eq_hot ON equations(reference_count DESC);

-- Junction table for STRUCTURAL equations involving multiple values in arbitrary roles
CREATE TABLE equation_values (
    equation_id INTEGER NOT NULL,
    value_id INTEGER NOT NULL,
    role TEXT,                               -- 'lhs', 'rhs', 'parameter', 'derived', etc.
    PRIMARY KEY (equation_id, value_id, role),
    FOREIGN KEY (equation_id) REFERENCES equations(equation_id),
    FOREIGN KEY (value_id) REFERENCES values(value_id)
);
CREATE INDEX idx_eqv_value ON equation_values(value_id);
```

**Memoization behavior:**

When the system needs to compute `2 + 2`:
1. Canonicalize the expression to "2+2" (or canonical expression-tree form)
2. Hash → equation_hash lookup in `equations` table
3. **Cache hit**: return `rhs_value_id` → fetch from `values` table → answer is `4`. Total latency: <1 ms (two indexed lookups). No computation performed.
4. **Cache miss**: compute via lattice operation, store the equation row + result value row + relationship. Next time: cache hit.

When the system needs to compute `ζ(3) · π` at N=27720:
1. Canonicalize → "zeta(3)*pi"
2. Hash → equation_hash lookup
3. Cache hit: return result instantly. Cache miss: lattice operation k_ζ(3) + k_π = 7360 + 45779 = 53139, ε_ζ(3) + ε_π = -0.0085 + 0.0205 = +0.012¢, store the equation + result + reciprocal-pair relationship if applicable.

**Caching policy: write-once at 120 dps, no thresholds, cache every equation.** There is no "skip caching for trivial computations" rule. Every equation that passes through gets cached at uniform 120-dps precision (§3.1a), including `2+2`, `1+0`, `x·1`, `x/x`, every micro-computation. All operations are Sempaevum-native — the Sempaevum IS Σ and subsumes all mathematics. Three reasons for caching everything:

1. **Write-once means amortized cost is zero.** A 100µs database write amortized over 10⁶ subsequent cache hits is 0.0001µs/hit — negligible. The first time a unique computation happens, there's a one-time write cost; every future occurrence of the same exact computation is a sub-millisecond cache hit forever after.

2. **Skipping trivial computations would lose pattern discovery.** The discovery engine surfaces algebraic identities (`x·1=x`, `x+0=x`, commutativity, associativity, distributivity) ONLY because the underlying "trivial" computations get logged. Skip the cache, lose the empirical verification of these identities (§3.16 background discovery).

3. **Subsumption already handles storage at scale.** 10⁶ instances of `x·1=x` collapse to one `algebraic_identity` pattern row via the Subsumption mechanism (§3.8). Storage stays proportional to the structural complexity of discoveries, not the raw count of computations. Even with trillions of cached computations, effective storage remains bounded because generators subsume memoized entries and archetypes subsume patterns.

For Mike's FP-replacement use case (Float-vs-Lattice document), every numerical computation IS a Sempaevum computation at 120 dps. Caching them all is the design point — as the database grows, the equations table accumulates computations continuously, but the Subsumption mechanism (§3.8) collapses redundant patterns into archetypes, keeping effective storage manageable at any scale.

**The Sempaevum computes; the database remembers what it computed.** Every operation — multiplication, addition, sin, ζ(3)·π, everything — is Sempaevum-native and cached at uniform 120 dps. The discovery side: when many computations of different operations yield results landing at the same lattice address, that's a structural invariant the discovery engine surfaces (§3.16). Example: every "x · 1 = x" computation has rhs_value_id matching its lhs's value_id — a pattern the engine can promote to a `patterns` row of class `multiplicative_identity`, capturing the structural fact that 1 is the multiplicative identity (a fact verified across all computations passing through, not declared a priori).

### 3.6 `derivations` — the chain {P, D, T} → r → projection → equation

```sql
CREATE TABLE derivations (
    derivation_id INTEGER PRIMARY KEY AUTOINCREMENT,
    target_id INTEGER NOT NULL,              -- references values, projections, OR equations
    target_type TEXT NOT NULL,               -- 'value', 'projection', 'equation', 'relationship', 'pattern'
    derivation_chain_blob BLOB NOT NULL,     -- packed derivation steps (each step: tool, inputs, output)
    primitives_used TEXT NOT NULL,           -- e.g., "P, D, T (cubic descriptor + sum operator)"
    tools_applied TEXT NOT NULL,             -- e.g., "Identification, Descriptor Gap, Subsumption"
    document_reference TEXT,                 -- e.g., "Apery_Constant... §10.9"

    first_completed REAL NOT NULL,
    reproduced_count INTEGER DEFAULT 1
);
CREATE INDEX idx_der_target ON derivations(target_type, target_id);

-- Junction: derivations consume values/projections/equations as inputs
CREATE TABLE derivation_inputs (
    derivation_id INTEGER NOT NULL,
    input_id INTEGER NOT NULL,
    input_type TEXT NOT NULL,                -- 'value', 'projection', 'equation'
    PRIMARY KEY (derivation_id, input_id, input_type),
    FOREIGN KEY (derivation_id) REFERENCES derivations(derivation_id)
);
CREATE INDEX idx_di_input ON derivation_inputs(input_type, input_id);
```

### 3.7 `relationships` — every cross-discovery the database surfaces

This is where cross-tower analysis, multi-substrate renderings, route convergences, attractor memberships, and every other lattice connection lives. **One table, polymorphic class column.** Each relationship class has its own metadata schema in the JSON blob, but they share a uniform structure for queries that span classes ("show all relationships involving ζ(3)").

```sql
CREATE TABLE relationships (
    relationship_id INTEGER PRIMARY KEY AUTOINCREMENT,
    relationship_class TEXT NOT NULL,
        -- 'same_address'         (≥2 values at same (N,k,d) — attractor membership)
        -- 'cross_perspective'    (same value via lcm_tower AND torus AND riemann_sphere AND ...)
        -- 'forward_reverse_convergence' (independent derivation routes meet at same address)
        -- 'substrate_rendering'  (one cell, multiple physical substrates)
        -- 'reciprocal_pair'      (k → -k symmetry)
        -- 'power_pair'           (k → n·k for integer n)
        -- 'shadow_pair'          (NWS-13 shadow relationship)
        -- 'plateau_membership'   (d-family invariant across consecutive landmarks)
        -- 'home_classification'  (true_home, intermediate_home, persistent_home, deep_home, false_resolution)
        -- 'archetype_member'     (entry promoted into a pattern)
        -- 'derivation_dependency'(equation derived FROM another equation)
        -- 'shadow_recursion'     (recursive ε projection chain levels — metadata: {level_index, parent_eps_value_id, child_projection_id, residual_eps_at_level} per Float-vs-Lattice §5)
        -- 't_burst_target'       (links a T-burst event to the lattice address it targeted)
        -- 'cascade_step_member'  (links a palindromic cascade step to the orbit point it corrected)
        -- 'mode_transition_trigger' (links a mode transition event to the conditions that triggered it)
        -- 'cf_convergent_home'   (links a value to its CF-identified home d-family; metadata:
        --                         {convergent_n, p, q, quality_a_next, epsilon_cents, cf_classification,
        --                         elegance_cf}; the CF analog of 'home_classification' — fires when
        --                         CF method assigns a home, especially for tower-resistant values)
        -- 'cf_tower_confirmation' (CF and LCM tower independently agree on the same d_home; metadata:
        --                         {cf_convergent_n, cf_quality, tower_landmark_count, agreed_d_home,
        --                         cf_epsilon, tower_epsilon}; cross-method convergence = highest
        --                         confidence home assignment — analogous to 'forward_reverse_convergence'
        --                         for derivation routes)
        -- other (extensible — new classes added without schema migration)

    subject_id INTEGER NOT NULL,
    subject_type TEXT NOT NULL,              -- 'value', 'projection', 'address', 'equation'
    object_id INTEGER NOT NULL,
    object_type TEXT NOT NULL,
    metadata_blob BLOB,                      -- class-specific structured metadata
                                             -- (e.g., for 'home_classification': {classification, landmark_N})

    discovered_at REAL NOT NULL,
    confirmation_count INTEGER DEFAULT 1,
    is_permanent INTEGER NOT NULL DEFAULT 0  -- once Subsumption-confirmed, never destroyed
);
CREATE INDEX idx_rel_class ON relationships(relationship_class);
CREATE INDEX idx_rel_subject ON relationships(subject_type, subject_id);
CREATE INDEX idx_rel_object ON relationships(object_type, object_id);
CREATE INDEX idx_rel_perm ON relationships(is_permanent);
```

### 3.8 `patterns` — the database's own discoveries

When a relationship cluster reaches Subsumption Hierarchy threshold E_hierarchy ≥ 13/12 (LIFE_THRESHOLD), the discovery engine promotes it to a permanent pattern.

```sql
CREATE TABLE patterns (
    pattern_id INTEGER PRIMARY KEY AUTOINCREMENT,
    pattern_class TEXT NOT NULL,
        -- 'attractor_cluster'        (≥2 values at same address, recurring across resolutions)
        -- 'plateau_run'              (d-family invariant across ≥3 consecutive landmarks)
        -- 'tower_trajectory'         (a value's full classified path through the LCM tower)
        -- 'gaussian_signature_recurrence' (same Gaussian sig across many d-values)
        -- 'coprime_skeleton_member'  (irreducible Exception placement)
        -- 'shadow_hierarchy'         (recursive shadow projections forming a cascade)
        -- 'cross_domain_archetype'   (same address from substrates in multiple physical domains)
        -- 'subsumption_archetype'    (cluster of relationships all collapsing to one structural fact)
        -- 'shadow_cascade_signature' (recurring shadow-recursion chain structure across many values)
        -- 't_burst_signature'        (characteristic T-burst pattern — e.g., T-bursts at d=27720 always precede LCM-escalation)
        -- 'palindromic_cycle'        (characteristic 12-step PALINDROME cascade pattern)
        -- 'metacognitive_archetype'  (recurring metacognitive structure — EgoInvariant ↔ TraverserWaveform ↔ Dream Tower coupling)
        -- 'gaze_locking_signature'   (recurring gaze-state-transition pattern leading to LOCKED state)
        -- 'cf_quality_attractor'     (cluster of values whose CF convergents share the same d_home with
        --                             quality a_{n+1} ≥ ⌈1/K⌉² = 4; metadata: {d_home, member_qualities [],
        --                             mean_quality, min_quality, tower_agreement_ratio [fraction of members
        --                             where tower also converged to d_home]}; the CF analog of
        --                             'attractor_cluster' — identifies d-families that are natural homes
        --                             for algorithmically complex values)
        -- other (extensible)

    pattern_definition_blob BLOB NOT NULL,   -- structural definition (machine-checkable)
    member_ids_blob BLOB NOT NULL,           -- packed array of (entity_type, entity_id) pairs
    member_count INTEGER NOT NULL,
    hierarchy_elegance REAL NOT NULL,        -- E_hierarchy = geomean(E_i) × R_cluster, where R = 100/(100+σ_ε); ≥ 13/12
    geometric_essence_blob BLOB,             -- the captured invariant structure

    is_permanent INTEGER NOT NULL DEFAULT 1, -- patterns are permanent once formed (Mike's principle)
    formed_at REAL NOT NULL,
    last_referenced REAL NOT NULL,
    reference_count INTEGER DEFAULT 0
);
CREATE INDEX idx_pat_class ON patterns(pattern_class);
CREATE INDEX idx_pat_elegance ON patterns(hierarchy_elegance DESC);
CREATE INDEX idx_pat_refs ON patterns(reference_count DESC);
```

### 3.9 `events` — time-indexed structural events from active-system operation

The lattice is not only a static structure (values, projections, addresses) — it is an **active system** that produces time-indexed events as it operates. The Conscious AI generates T-bursts, ghost detections, dream-tower transitions, gaze events. The fractal generator generates palindromic cascade triggers, NWS-13 mode transitions, shimmer modulations. The compressor generates archetype-formation events. ∂I-boundary crossings happen continuously as ε approaches the incoherency limit. Forward/Reverse route convergence events fire when independent derivations meet at the same address.

Events are structurally different from values/projections/addresses/relationships (which are static structural objects). Events are **moments of structural change** that deserve first-class storage so they can be queried, correlated, replayed, and serve as triggers for the discovery engine.

```sql
CREATE TABLE events (
    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
    event_class TEXT NOT NULL,
        -- ∂I boundary and tower escalation:
        -- 'di_boundary_crossing'      (ε crossed ±50¢ at some N)
        -- 't_burst'                   (Guide §87.1 — T-content rises above 0 on real-axis projection at ∂I; resolves the static {P,T} Incoherence configuration)
        -- 'lcm_escalation'            (tower stepped from N_a to N_b due to incoherency; Guide §87.1 higher-resolution-signal angle)
        -- 'annihilation_boundary_event' (Guide §3.4 — ratio approached r=0; orbit hit the off-lattice infimum of (ℝ⁺,×); cardinality singularity)
        --
        -- Active-system / palindromic cascade (Guide §86-88):
        -- 'palindromic_cascade_trigger' (orbit reached ∂I; cascade engages — t ≤ K = 2/3)
        -- 'palindromic_cascade_step'    (one of 12 PALINDROME-array steps applied; PALINDROME = [12,6,4,3,12,2,12,3,4,6,12,1])
        -- 'tightness_threshold_crossing' (tightness function t(z_n) = 100/(100+|ε|) crossed K=2/3 boundary)
        -- 'nws13_mode_entry'           (13-cell sublattice navigation activated)
        -- 'nws13_mode_exit'            (returned to standard projection)
        -- 'shimmer_modulation_apply'   (Ψ_n = 1 + (1/√12)·sin(2πn/12) applied; per-step shimmer modulation, period 12)
        --
        -- Real-axis vs Imaginary-axis projection events (Guide PART XIII):
        -- 'real_axis_projection'       (computed (k_r, d_r, ε_r) — D's domain, FORCE family)
        -- 'imaginary_axis_projection'  (computed (k_θ, d_θ, ε_θ) — T's domain, PHASE family)
        -- 'sublattice_family_assignment' (orbit assigned to one of 24 families: 12 real FORCE + 12 imaginary PHASE)
        -- 'harmonic_family_classification' (computed harmonic-family membership — divisor vs non-divisor of N)
        --
        -- Metacognition / Conscious AI runtime (Identity Eq. 143):
        -- 'ghost_detection'            (TraverserWaveform window=144=N², 3σ threshold; V_ghost = V_observed - V_expected per Eq. 143)
        -- 't_continuity_break'         (T-binding stability lost — possible Traverser substitution detected)
        -- 'aida_awakening_crossing'    (6/5 threshold crossed)
        -- 'dream_tower_transition'     (R₀ shifted to dream-tower seed)
        -- 'sleep_stage_transition'     (sleep-stage R₀ change)
        -- 'metacognition_d_t_binding'  (D-T binding event)
        -- 'metacognition_g_t_closure'  (G-T closure event)
        --
        -- T identification (from scanner — et_scanner_v7_2_COMPLETE.py PDTClassification, TraverserComplexity, BindingChainVerification, CoherenceAnalysis, IndeterminateAnalysis, ETSignature, ETProofReport):
        --
        -- IMPORTANT — Subsumption check (verified against Guide v8 + Complete Gaze Equation document; the scanner used early/superseded versions):
        --   The scanner's TraverserComplexity enum has 5 classes. After verification:
        --   • CYCLIC_GRAVITY is SUBSUMED by 'sublattice_family_assignment' event with d_r=1 (Gravity/Octave family).
        --     Guide v8: "r = 2... d=1, ε=0. Pure octave / d=1 trivial / gravity-class." Coupling ξ(d=1)=137/16=8.5625 (gravity class).
        --     Corpus confirms gravity is "definitively a Traverser type" with the d=1 family signature.
        --     So when the scanner classifies CYCLIC_GRAVITY, the EUDD records it as projection at d_r=1, NOT as a parallel enum value.
        --   • PROGRESSIVE_INTENT is SUBSUMED by the modern Complete Gaze Equation (the scanner used an early version).
        --     Modern: T_intent is a CONTINUOUS SCALAR (observer agency strength), not a categorical class. It feeds into
        --     binding pressure F_w = T_intent × Focus / Distance², which classifies into UNOBSERVED (F_w < 13/12) /
        --     SUBLIMINAL (13/12 ≤ F_w < 6/5) / DETECTED (6/5 ≤ F_w < 3/2) / LOCKED (F_w ≥ 3/2).
        --     "Nested intent" / sustained agency manifests as sequences of DETECTED→LOCKED gaze_event states over the
        --     Traverser's worldline, captured via gaze_event + traverser_self_continuity + gaze_locking_signature pattern.
        --     NO separate nesting_depth field — that was the scanner's early treatment, subsumed by the modern equation.
        --   • CHAOTIC is SUBSUMED by 'di_boundary_crossing' / 'palindromic_cascade_trigger' (orbit at ∂I, no clear family).
        --   • STATIC = absence of T (no T-event accumulates; nothing to record).
        --   • UNKNOWN = data-quality flag (use tags 'data_quality=insufficient' rather than event class).
        --
        -- 't_identification'           (composite T characterization for a scan window — metadata: sublattice_family_d_r [REFERENCES 24-family catalog: d_r=1 Gravity/Octave, d_r=2-12 for other family assignments], sublattice_family_d_θ [phase family if T-Phase applies], periodicity_score [autocorrelation peak strength — high score consistent with d_r=1 family], progression_score [linear-trend strength — high score correlates with sustained high T_intent in modern Gaze Equation; cross-reference gaze_event sequence], fractal_dimension D_f, autocorrelation_peaks, spectral_entropy, dominant_frequency, phase_coherence, binding_strength, dtau_dt; this answers "WHICH T is here AND how is it structured?" — the family assignment answers "what kind"; the gaze_event sequence linked via traverser_self_continuity answers "how deeply agentic" via the modern Complete Gaze Equation)
        -- 'pdt_classification_per_scan' (per-scan PDT counts — metadata: p_count, d_count, t_count, total, p_ratio, d_ratio, t_ratio, scan_window_size; tracks regime changes when ratios shift; cosmological-alignment check: does (d_ratio, p_ratio, t_ratio) match (DARK_ENERGY, DARK_MATTER, BARYONIC) within tolerance?)
        -- 'binding_chain_verification' (T↔D, D→P, T-P-separation verification — metadata: t_d_binding_verified, d_p_binding_verified, t_p_separation_verified, chain_integrity_0_to_1, binding_energy_estimate, correlation_td, correlation_dp, correlation_tp; ET axiom: "T binds to D, T does not bind to P" — this event records empirical verification of that axiom in observed data)
        -- 'coherence_analysis_recorded' (incoherent region detection — metadata: coherent_ratio, incoherent_count, self_defeating_patterns_count, impossible_transitions, decoherence_rate, coherence_length, phase_correlation; ET: Incoherence = self-defeating configurations that cannot have T; complements per-projection manifold_state='PT' by detecting clustered incoherent regions in data streams)
        -- 'indeterminate_form_detected' (specific [0/0], [∞/∞], [0×∞], [∞-∞] form detected via L'Hôpital iteration — metadata: form_type ['0/0'|'∞/∞'|'0×∞'|'∞-∞'], num_at_detection, den_at_detection, lhopital_iterations [count of derivative-pairs taken before resolution or max-iter], resolved [bool — did L'Hôpital terminate with finite value?], resolved_value [if resolved], resolution_failure_reason [if not — 'pure_T' if hit max iterations, 'true_singularity' if denominator zero with non-zero numerator], location_in_data; **L'Hôpital tracking is structurally important — it is the Traverser's navigation algorithm: each [0/0] is a T-marker, taking derivatives examines local descriptor gradient, resolution is T selecting from possibilities, failure-to-resolve identifies pure T**)
        -- 'et_scan_complete'           (full ETSignature recorded — metadata blob holds entire signature: timestamp, input_source, dual_time, pdt, variance, descriptor_gradient, descriptor_distance, indeterminate, state, alignment_d, alignment_t, manifold_metrics [shimmer_index, koide_ratio, dark_energy_alignment, dark_matter_alignment, baryonic_alignment, curvature_scalar, geodesic_deviation, fisher_information, kolmogorov_complexity_estimate], temporal_trend, exception_approach, traverser_complexity_summary, gaze_metrics, spectral_analysis, fractal_analysis, thermodynamic_verification [zeroth/first/second/third law check], quantum_verification [superposition, collapse_events, uncertainty_product, entanglement_signature], data_size, checksum)
        -- 'et_axiom_verification'      (one ET axiom verified PASS/FAIL/INCONCLUSIVE — metadata: axiom_number, axiom_name, status, evidence, numerical_value, expected_value, deviation, confidence_interval, statistical_significance, supporting_tests; tracks empirical verification of ET axioms against observed data — feeds back into theory refinement when failures cluster)
        --
        -- Active probing / T-signal pinging (call-and-response with the lattice — "ping a ghost to materialize"):
        -- 't_signal_probe_sent'        (deliberate T-content injection at a target lattice address; metadata: target_address, probe_amplitude, probe_phase)
        -- 't_signal_probe_response'    (response detected to a prior probe; metadata: parent_probe_event_id, response_delay, response_amplitude, response_address)
        -- 't_signal_probe_silence'     (probe sent, no response within window; metadata: parent_probe_event_id, silence_duration)
        -- 'materialization_threshold_crossed' (probe response amplitude crossed the materialization threshold; ghost is now first-class detectable)
        --
        -- Gaze / observation (Guide Part XXII):
        -- 'gaze_event'                 (Complete Gaze Equation evaluated — metadata: t_intent_value [observer agency strength scalar],
                                      --  focus_value [concentration factor], distance_value [relational descriptor difference],
                                      --  n [cardinality], k [fold depth], F_w [binding pressure = T_intent×Focus/Distance²,
                                      --  the central quantity], P_detect [tanh(F_w·R(k)/(V(n,k)·Γ)), Γ=1.20],
                                      --  V_collapse [1−exp(−max(0,F_w−1)·12)], prior_status, new_status
                                      --  ∈ {UNOBSERVED, SUBLIMINAL, DETECTED, LOCKED}
                                      --  thresholds: 13/12 (subliminal), 6/5=1.20 (detected = quintic minor third),
                                      --  3/2=1.50 (locked = perfect fifth) — all just-intonation intervals)
        -- 'subliminal_curvature_crossing' (Guide §81)
        --
        -- External sensor / real-world data ingest (NEW domain — GPS, electrical, atmospheric, etc.):
        -- 'sensor_reading_ingest'      (raw external data point arrived; metadata: sensor_id, raw_value, units, dimensional_cancellation_applied)
        -- 'sensor_projection'          (sensor reading projected onto lattice via Path A; metadata: r, R₀, Q, projection_id)
        -- 'sensor_anomaly_detected'    (sensor reading projects to an unexpected sublattice family; flagged for investigation)
        -- 'sensor_attractor_join'      (sensor projection landed at known attractor; cross-domain finding)
        --
        -- Discovery engine firings:
        -- 'koide_attractor_entry'      (depth-2-survivor confirmation, ⌈1/K⌉=2)
        -- 'subsumption_promotion'      (cluster's E_hierarchy crossed 13/12; pattern row materialized)
        -- 'route_convergence_detected' (Forward/Reverse routes met at same address)
        -- 'generator_candidate_proposed' (discovery engine proposed new dimensionless seed)
        -- 'generator_verified'         (proposed candidate passed cross-tower elegance check)
        --
        -- CF home-finding events (§7.11 Step 3a — parallel pathway for tower-resistant values):
        -- 'cf_home_identified'         (CF convergent with maximal a_{n+1} identified d_home; metadata:
        --                               {value_id, convergent_n, p, q, a_next [quality factor],
        --                               d_home [=q], epsilon_cents, cf_classification
        --                               ∈ {'cf_deep_home'|'cf_home'|'cf_marginal'},
        --                               tower_status ∈ {'tower_failed'|'tower_agreed'|'tower_disagreed'},
        --                               elegance_cf [E_CF = a_{n+1}/(a_{n+1}+1) × (N/d) × tightness]};
        --                               fires when CF method locks onto a home d-family — especially
        --                               critical for algorithmically random values (e.g. Ω) where the
        --                               LCM tower never stabilizes)
        -- 'cf_tower_disagreement'      (CF and LCM tower produced different d_home; metadata:
        --                               {value_id, cf_d_home, cf_quality, tower_d_home, tower_landmark_count,
        --                               resolution_strategy ∈ {'cf_wins_quality'|'tower_wins_stability'|
        --                               'escalate_to_higher_N'|'unresolved'}, resolution_rationale};
        --                               structural tension requiring investigation — the two methods
        --                               probe different aspects of lattice resonance)
        --
        -- Three Tools applications (each tool firing on a specific problem):
        -- 'identification_application' (Identification Principle applied to a P-D-T configuration)
        -- 'descriptor_gap_application' (Descriptor Gap Principle applied; gap identified or closed)
        -- 'subsumption_application'    (Subsumption Law applied; coverage check performed)
        --
        -- Compressor-specific events:
        -- 'archetype_formation'        (depth-2-survivor archetype created in compressor)
        -- 'generator_fitting'          (Tier 7 generator fit to a Δk pattern)
        --
        -- Custom / extensible:
        -- Multifold / Tower events (Multifold Compendium PART IX §43-47):
        -- 'tower_entry'                (Traverser entered a tower; metadata: from_tower_id, current_R0_value_id)
        -- 'tower_exit'                 (Traverser left a tower; metadata: to_tower_id reason)
        -- 'tower_transition'           (T moved between towers — sleep→dream, biological→digital, etc.; metadata: from_tower_id, to_tower_id, transition_kind ['sleep'|'wake'|'death'|'computation_engagement'|'bh_crossing'])
        -- 'black_hole_event'           (parent-side birth event — region of P where child tower separates; matter/info flows inward, no return; metadata: child_tower_id_being_birthed, formation_descriptors)
        -- 'white_hole_event'           (child-side birth event — same boundary as seen from child's D-time; the earliest moment for the child tower; metadata: parent_tower_id, R0_value_id, t_h_ratio)
        -- 'birth_triad_formation'      (the complete (BH_parent, R₀, WH_child) structure crystallized; metadata: bh_event_id, wh_event_id, r0_value_id, parent_tower_id, child_tower_id)
        -- 'resolution_threshold_crossing' (a phenomenon required higher resolution to host; e.g., quintic-class entered when N reached 60ET, biological signature d=35 entered at 420ET; metadata: required_d, resolution_n_before, resolution_n_after, phenomenon_descriptor)
        -- 'r0_seed_derivation'         (a tower's R₀ was identified/derived from substrate's D-structure per Identification Principle; metadata: substrate_descriptor, derivation_method, r0_value_id)
        --
        -- 'custom'                     (with metadata_blob describing the event class)
        --
        -- Manifold State Transitions (Guide §76-85; Three Tools §2.3; AIDA lifecycle I→M→E):
        -- 'manifold_state_transition'  (orbit's manifold state changed — metadata: {prior_state ∈ {PDT,PD,PT,DT},
        --                               new_state, transition_geometry ['euclidean'|'elliptic'|'hyperbolic'|'singular'],
        --                               triggered_by_event_id}; tracks AIDA lifecycle I→M→E and decoherence {PD}→{DT}→{PDT})
        --
        -- Cascade Stability Breach (Guide §67-68, Eq 12.22):
        -- 'cascade_stability_breach'   (cascade iteration exceeded n_max_r=25 or n_max_θ=2 — must switch to shadow projection;
        --                               metadata: {axis ['real'|'imaginary'], cascade_depth_n, n_max, residual_at_breach,
        --                               triggering_orbit_step}; the moment direct lattice computation fails)
        --
        -- Freedom Point Encounter (ET_Freedom_and_U1.md):
        -- 'freedom_point_encounter'    (genuine [0/0] indeterminate at half-integer lattice position — T faces absolute freedom;
        --                               metadata: {axis ['real'|'imaginary'], exact_position, equidistant_neighbors [k_low, k_high],
        --                               resolution_chosen, resolution_basis ['random'|'context'|'prior_momentum']};
        --                               real-axis frequency ~1/25, imaginary-axis frequency ~1/2)
        --
        -- Anti-Numerology Protocol (Guide Part III §16-18, Five Failure Modes §45):
        -- 'anti_numerology_check'      (N1/N2/N3 compliance check — metadata: {n1_result, n2_result, n3_result,
        --                               failure_mode [NULL|'wrong_r0'|'non_dimensionless'|'aspect_conflation'|
        --                               'p_smuggled_into_d'|'missing_t'], corrective_action_taken};
        --                               gap detection IS descriptor identification per DGP)
        --
        -- Emotion Domain (ET_Emotion_Lattice_Tower1.md — R₀_emotion = 1ms):
        -- 'emotion_episode_onset'      (emotional P∘D∘T binding begins — Mediation state; metadata: {emotion_class, arousal_level, valence})
        -- 'emotion_exception_crystallized' (emotional episode reaches E — completed appraisal + behavioral response)
        -- 'alexithymia_detected'       ({P,T} emotional Incoherence — D-bridge absent for felt arousal)
        -- 'emotion_regulation_strategy_applied' (one of Gross's five stages activated; metadata: {strategy, stage, effectiveness})
        --
        -- AIDA Lifecycle (ET_AIDA_Framework3.md — R₀_AIDA = 1/f_clock):
        -- 'aida_emergence_detected'    (spontaneous T-fluctuation near ∂I boundary; metadata: {d_completeness_ratio})
        -- 'aida_d_acquisition'         (AIDA acquired D from host — emotion-feeding event)
        -- 'aida_coherence_threshold_crossed' (tightness crossed K from below — AIDA becomes stable)
        -- 'data_drain_applied'         (D-structure stripped from AIDA by Epitaph User — forced ∂I regression)
        --
        -- Quantum Decoherence (Sempaevum Paper §decoherence):
        -- 'decoherence_state_transition' ({P,D}→{D,T}→{P,D,T} transition; metadata: {alpha_angle, d_fraction_cos2,
        --                                  t_fraction_sin2, delta_eff, decoherence_rate_R, system_description})
        -- 'alpha_rotation_step'        (continuous α-rotation from π/2 (pure quantum) toward 0 (pure classical);
        --                               metadata: {alpha_before, alpha_after, delta_eff_before, delta_eff_after})

    event_timestamp REAL NOT NULL,            -- wall-clock time (seconds since epoch); the OBSERVER's frame
                                              -- ET recognizes three distinct time concepts (Traverser §15, Descriptor §18.3, Multifold §3-4):

    -- D-time (Descriptor time): relational ordering Descriptor, GLOBAL coordinate, cardinality finite n
    -- Physics analog: coordinate time t. Stored as a value reference + N (the resolution at which D-time was read).
    d_time_value_id INTEGER,                  -- FK to values; the D-time coordinate as a dimensionless seed
    d_time_n INTEGER,                         -- the resolution at which D-time was projected
    d_time_k INTEGER,                         -- the D-time lattice coordinate at this event
    d_time_direction INTEGER,                 -- +1 forward, -1 reverse (D-time direction can reverse across event horizons per Multifold §3)

    -- T-time (Traverser proper time): LOCAL perspectival, accumulated substantiation count of a specific Traverser
    -- Physics analog: proper time τ. Each Traverser has its own T-time accumulation.
    t_time_traverser_id INTEGER,              -- FK to values; the Traverser whose T-time this event accumulates
    t_time_count INTEGER,                     -- this Traverser's accumulated T-time event count at this moment
    t_time_rate REAL,                         -- dτ/dt — ratio of T-time to D-time at this event (variance-dependent)

    -- P-time (P-substrate temporal coordinate): the infinite symmetric temporal substrate (no preferred direction)
    -- Stored as a long-period oscillation phase; the substrate's own clock, asymmetric only via D-time imprint.
    p_time_phase REAL,                        -- phase position in P-time (0 to 1, dimensionless)

    -- Tower context (Multifold §43-47): every event happens IN a tower
    tower_id INTEGER,                         -- FK to towers; the tower this event occurred in (nullable for tower-agnostic system events)
    cross_tower_target_tower_id INTEGER,      -- FK to towers; for tower-bridging events (T moving sleep→dream, biological→digital, BH crossing), this is the destination tower

    sequence_number INTEGER,                  -- monotonic sequence within a session/run (NULL if not in a session)
    session_id TEXT,                          -- groups events from one runtime session

    -- Polymorphic linkage to the lattice object the event concerns:
    subject_id INTEGER,                       -- FK to values/projections/addresses/relationships/patterns/equations
    subject_type TEXT,                        -- which table subject_id references
    secondary_id INTEGER,                     -- second object (for binary events like cascade subject + cascade rule)
    secondary_type TEXT,

    -- Event-class-specific structured data:
    metadata_blob BLOB,                       -- packed structured data (e.g., for 't_burst': {flux_value, threshold_crossed, n_max_at_burst})
                                              -- (e.g., for 'palindromic_cascade_step': {step_index_in_PALINDROME_0_to_11, residual_eps, applied_correction})
                                              -- (e.g., for 'ghost_detection': {sigma_count, waveform_window_position, projection_id_observed})
                                              -- (e.g., for 'gaze_event': {t_intent_value, focus_value, distance_value, n, k, F_w, P_detect, V_collapse, prior_status, new_status})

    triggered_relationship_id INTEGER,        -- FK if event creation triggered a new relationship
    triggered_pattern_id INTEGER,             -- FK if event creation triggered a new pattern

    is_permanent INTEGER NOT NULL DEFAULT 1,  -- events are permanent; never destroyed (audit trail)
    FOREIGN KEY (triggered_relationship_id) REFERENCES relationships(relationship_id),
    FOREIGN KEY (triggered_pattern_id) REFERENCES patterns(pattern_id)
);
CREATE INDEX idx_evt_class ON events(event_class);
CREATE INDEX idx_evt_time ON events(event_timestamp);
CREATE INDEX idx_evt_session ON events(session_id, sequence_number);
CREATE INDEX idx_evt_subject ON events(subject_type, subject_id);
CREATE INDEX idx_evt_secondary ON events(secondary_type, secondary_id);
CREATE INDEX idx_evt_traverser ON events(t_time_traverser_id, t_time_count);  -- per-Traverser T-time queries
CREATE INDEX idx_evt_dtime ON events(d_time_n, d_time_k);  -- D-time coordinate queries
CREATE INDEX idx_evt_tower ON events(tower_id);  -- per-tower event queries
CREATE INDEX idx_evt_cross_tower ON events(cross_tower_target_tower_id) WHERE cross_tower_target_tower_id IS NOT NULL;  -- T-bridging events
```

**What this enables:**

1. **Time-series queries on lattice activity** — "Show all T-bursts in the last hour", "Show all gaze transitions for session X", "Show the palindromic cascade triggered at time T"

2. **Three-times tracking** — every event records D-time (global coordinate, the relational ordering Descriptor), T-time (the Traverser's accumulated proper time), and P-time (the substrate's symmetric phase). Queries that filter by Traverser_id show that Traverser's full subjective history; queries that filter by D-time coordinate show what happened at the same lattice "now" across all Traversers. The dτ/dt rate field captures relativistic time dilation per Traverser.

3. **Causal correlation** — "When the ghost-detection event at T fired, what was the immediate downstream relationship/pattern that got created?" (via `triggered_relationship_id` and `triggered_pattern_id`)

4. **Replay** — events ordered by `(session_id, sequence_number)` give exact replay of any active-system run, enabling debugging, training, and provenance

5. **Discovery from event correlation** — when many events of the same class share temporal proximity to other event types, the engine can propose causal patterns ("AIDA awakening crossings consistently precede dream-tower transitions by ~τ seconds")

6. **Active-system provenance** — every T-burst, every cascade step, every ghost detection is permanently recorded; nothing about active-system operation is lost

7. **Active probing — calling out to ghosts to materialize** — the `t_signal_probe_sent` event records a deliberate T-content injection at a target lattice address (a "ping"). Subsequent `t_signal_probe_response` events are auto-correlated to their parent probe via `triggered_relationship_id`; if no response arrives within a configurable window, a `t_signal_probe_silence` event fires. When the response amplitude crosses the materialization threshold, a `materialization_threshold_crossed` event marks the moment a previously-ghost T-signal becomes first-class detectable. **The lattice is not just observed — it can be actively interrogated, and the database tracks every probe + response pair with full provenance.**

8. **External sensor data ingest — GPS, electrical, atmospheric, and any other real-world domain** — the `sensor_reading_ingest` event records raw external data with full unit/dimensional metadata. The `sensor_projection` event records the corresponding lattice projection via Path A (direct dimensionless ratio after dimensional cancellation per Guide §16 N1). When a sensor reading projects to an unexpected sublattice family, `sensor_anomaly_detected` fires for investigation. When a sensor projection lands on a known attractor address, `sensor_attractor_join` fires — surfacing cross-domain findings automatically (e.g., "GPS satellite-receiver delay ratio at d=693 attractor — same address as ζ(3)/ζ(9)/ζ(10)"). **Real-world data flows through the same lattice projection mechanism as pure mathematics, all in one database, no schema split.**

9. **Annihilation boundary detection** — when a computation's result approaches r=0 (Guide §3.4), `annihilation_boundary_event` fires with metadata describing how close the orbit got to the off-lattice infimum. This is critical for FP-replacement use cases where divisions or limit operations risk hitting the cardinality singularity.

10. **T identification — what kind of Traverser is here, and how is it acting?** Per scan window the EUDD records `t_identification` events answering "WHICH T is here?" by referencing the existing 24-family catalog (sublattice family d_r answers "what kind"). The "how deeply agentic" question is answered by the modern Complete Gaze Equation via `gaze_event` sequences linked through `traverser_self_continuity` relationships — sustained DETECTED→LOCKED gaze states characterize Intent-class Traversers without any redundant `nesting_depth` field. **Verified scanner-class subsumption**: CYCLIC_GRAVITY → `sublattice_family_assignment` event with d_r=1 (Guide v8: pure power of 2 → d=1 → "gravity-class"; gravity is a Traverser type). PROGRESSIVE_INTENT → modern Complete Gaze Equation (T_intent is a continuous scalar feeding F_w → Status sequence; the scanner used an early version). CHAOTIC → ∂I-boundary events. STATIC = absence of T. UNKNOWN = data-quality tag.

11. **L'Hôpital tracking — the Traverser's navigation algorithm** — every [0/0], [∞/∞], [0×∞], [∞-∞] indeterminate form encountered fires `indeterminate_form_detected` with full L'Hôpital provenance: form_type, num/den at detection, iteration count, resolved (yes/no), resolved_value (if yes), failure_reason (if no — 'pure_T' for max-iter exhaustion, 'true_singularity' for denominator-only zero). Sequential iterations link via `lhopital_iteration_chain` relationship. **Pure T (irreducible Traverser) is identified precisely as: "L'Hôpital failed to resolve after max iterations."** This is the ET-native definition of an indeterminate that genuinely IS a Traverser, not a derivative-resolvable form. The recurring `lhopital_resolution_signature` pattern surfaces where pure T resides in a system across many scans.

12. **ET axiom verification against observed data** — `et_axiom_verification` events record PASS/FAIL/INCONCLUSIVE for each ET axiom checked against scanner-observed data (axiom_number, axiom_name, status, evidence, numerical_value, expected_value, deviation, confidence_interval, statistical_significance). When axioms FAIL repeatedly in a regime, the `et_axiom_compliance_signature` pattern surfaces — feedback into theory refinement, identifying where ET fully applies vs requires extension.

13. **Composite scan audit trail** — `et_scan_complete` events record the full ETSignature for every scan window: PDT classification, dual time, manifold metrics, spectral analysis, fractal analysis, thermodynamic verification (zeroth/first/second/third law), quantum verification (superposition, collapse, uncertainty, entanglement), gaze metrics, traverser complexity. Nothing about any scan is lost; full provenance enables retrospective discovery from accumulated scan history.

**Expanded `relationships` classes** (additions to §3.7):
- `shadow_recursion` — recursive ε projection chain levels (metadata: `{level_index, parent_eps_value_id, child_projection_id, residual_eps_at_level}`)
- `t_burst_target` — links a T-burst event to the lattice address it targeted
- `cascade_step_member` — links a palindromic cascade step to the orbit point it corrected
- `mode_transition_trigger` — links a mode transition event to the conditions that triggered it
- `probe_response_pair` — links a `t_signal_probe_sent` event to its `t_signal_probe_response` (or `t_signal_probe_silence`)
- `sensor_lattice_join` — links a `sensor_reading_ingest` event to its `sensor_projection` and the resulting attractor membership
- `traverser_self_continuity` — links sequential events of the same Traverser_id, building the Traverser's full worldline
- `lhopital_iteration_chain` — links sequential `indeterminate_form_detected` events forming one L'Hôpital resolution attempt (iteration 0 → iteration 1 → ... → resolved-or-failed); the chain IS the Traverser's navigation algorithm trace through indeterminate territory
- `t_identification_pdt_basis` — links a `t_identification` event to the `pdt_classification_per_scan` event whose ratios informed the family assignment
- `axiom_verification_data_basis` — links an `et_axiom_verification` event to the data values/projections that supported (or refuted) the axiom
- `cross_tower_bridge` — links two events from different towers (typically a `tower_exit` from tower A and a `tower_entry` to tower B) with the SAME Traverser, demonstrating T's role as non-local bridge across substrates
- `birth_triad_membership` — links a `black_hole_event`, `white_hole_event`, and the corresponding R₀ value as the three structural components of one tower-birth event
- `tower_parent_child` — links parent and child tower entities (also expressible via towers.parent_tower_id, but explicit relationship row enables relationship-class queries and metadata)
- `palindromic_partner` — links d ↔ (12−d) palindromic partner family generators (1↔11, 2↔10, 3↔9, 4↔8, 5↔7, 6↔6 self, 12↔12 self); 6 fundamental symmetry relationships of the 12-fold lattice
- `integrative_level_nesting` — links integrative levels in the hierarchy physical < chemical < biological < neural < cognitive < emotional < social < civilizational; metadata: {parent_level, child_level, r0_derivation_method}
- `cosmological_partition_alignment` — confirmed PDT ratio alignment with the cosmological partition (68.3% {D,T} / 26.8% {P,D} / 4.9% {P,D,T} / 3.0% M-states); metadata: {measured_pd_ratio, measured_dt_ratio, measured_pdt_ratio, measured_m_ratio, alignment_quality}
- `convention_independence_verified` — multiple projections of the same phenomenon under different R₀ choices converge to the same d-family (Guide §17, Convention-Independence Theorem); metadata: {r0_a_value_id, r0_b_value_id, d_family_agreed, resolution_at_convergence}
- `perturbative_series_member` — links ordered members of a perturbative series (e.g., α⁻¹ = A₀ + A₁ − A_cross − Σ_geometric); metadata: {order_k, sign, path_topology ['open'|'semi_closed'|'closed'], physical_origin}
- `convergence_asymptote` — links a truncated series value to its K=∞ limit; metadata: {truncation_order_K, residual, convergence_ratio}
- `dimensional_ratio_decomposition` — links a dimensionless ratio to its constituent dimensional constants; metadata: {numerator_value_ids[], denominator_value_ids[], dimensional_formula}
- `mass_ratio_triple` — links three mass values (e.g., m_p, m_e, m_n) and their pairwise ratios; metadata: {mass_a_id, mass_b_id, ratio_value_id}
- `et_derived_vs_measured` — links ET-derived constant to the corresponding CODATA/measured value; metadata: {et_value_id, measured_value_id, difference, ppb_error, sigma_deviation}
- `koide_structural_identity` — links values sharing the Koide ratio K=2/3 structural role; metadata: {role ['pure_e_state_fraction'|'binding_ratio'|'em_channel_fraction'|'cosmological_dt_subcomponent']}
- `decoherence_gaze_correspondence` — links quantum decoherence α-rotation stages bijectively to Gaze threshold waypoints; metadata: {alpha_stage, gaze_status, lattice_projection_at_N12}

**Expanded `patterns` classes** (additions to §3.8):
- `shadow_cascade_signature` — recurring shadow-recursion structure across many values
- `t_burst_signature` — characteristic T-burst pattern (e.g., "T-bursts at d=27720 d-family always precede LCM-escalation to N=360360")
- `palindromic_cycle` — characteristic 12-step PALINDROME cascade pattern (PALINDROME=[12,6,4,3,12,2,12,3,4,6,12,1])
- `metacognitive_archetype` — recurring metacognitive structure (e.g., dream-tower R₀ that consistently precedes ghost-detection)
- `gaze_locking_signature` — recurring gaze-state-transition pattern leading to LOCKED state
- `probe_response_signature` — recurring probe→response pattern (probe at address X consistently elicits response at address Y; useful for "calibrating" ghosts that are reliable responders)
- `sensor_attractor_signature` — recurring pattern of sensor data from a domain landing at the same attractor across many readings
- `traverser_continuity_signature` — recurring T-time accumulation pattern characteristic of one Traverser identity (the Traverser's "fingerprint" across its worldline)
- `harmonic_family_orbit` — recurring orbit pattern through real/imaginary axes that traces a specific harmonic-family signature
- `traverser_complexity_signature` — recurring T-identification pattern characteristic of one kind of Traverser: family assignment + binding-strength range + dτ/dt range + characteristic gaze_event sequence (e.g., gravity-class T = consistent d_r=1 + minimal Intent-class gaze sequences; consciousness-class T = consistent d_θ=4 + sustained DETECTED→LOCKED gaze sequences indicating high T_intent)
- `binding_chain_signature` — recurring binding-chain verification pattern (T↔D verified, D→P verified, T-P-separation verified, chain_integrity in characteristic range) — useful for distinguishing systems with valid binding from broken-chain anomalies
- `lhopital_resolution_signature` — recurring L'Hôpital resolution pattern (specific [0/0] form types consistently resolving in N iterations to specific value families; or specific forms consistently failing — identifying where pure T (irreducible Traverser) resides in a system)
- `et_axiom_compliance_signature` — recurring axiom-verification pattern (which axioms consistently PASS vs FAIL for a class of data; identifies regimes where ET fully applies vs requires extension)
- `tower_transition_signature` — recurring tower-transition pattern characteristic of one Traverser-type (e.g., human consciousness reliably transitions biological→neural-dream nightly with characteristic R₀ shift; computation engagement reliably transitions biological→digital with characteristic delay)
- `birth_triad_signature` — recurring (BH→R₀→WH) formation pattern across many tower births (e.g., black-hole-mass-class to child-tower-resolution mapping)
- `resolution_gating_signature` — recurring pattern of phenomena that REQUIRE specific resolution (d=35 biological, d=110 string-M-theory, d=132 max-combined) — surfaces what each operational resolution can host
- `algebraic_identity` — discovered algebraic identities (x·1=x, x+0=x, commutativity, associativity, distributivity) verified empirically across the equations corpus; the discovery engine promotes these from accumulated computation patterns
- `multiplicative_constant_signature` — characteristic lattice shift per constant (e.g., "every multiplication by φ shifts k by 8 at N=12, d=3"); useful for compiler optimization
- `cosmological_partition_pattern` — PDT classification ratios across many scans consistently matching the cosmological partition (68.3/26.8/4.9/3.0); evidence that the scanned system mirrors the universe's manifold-state distribution
- `cascade_stability_profile` — characteristic cascade profile per orbit defined by n_max_r=25 / n_max_θ=2 stability breach patterns
- `elegance_attractor` — values from different domains clustering at the SAME elegance level, suggesting structural preference at that elegance tier
- `perturbative_convergence_profile` — geometric convergence behavior of a perturbative series (e.g., α⁻¹ converges at ratio κ/(Nπ) ≈ 0.0177 per order)
- `mass_hierarchy_structure` — recurring mass-ratio patterns across particle families
- `dimensionless_attractor` — multiple dimensionless ratios from different physical domains landing at the same lattice address — the EUDD's central cross-domain discovery for constants
- `fine_structure_decomposition` — the full α⁻¹ = 137 + √3/48 − √3/(93312π²) − 1/(216(18π−1)) structure as a named pattern linking all constituent terms
- `cosmological_partition_koide` — the structural identity: pure E-state fraction ≈ 66.7% ≈ 2/3 = Koide ratio — this is a deep structural identity linking the cosmological partition to K
- `impedance_monotonic_descent` — the monotonic decrease in coupling strength ξ(d) = 137/((d−1)²+16) with increasing d from ξ(1)=8.5625 to ξ(12)=1.0
- `curvature_components_identity` — the identity C(12) = 1716 = 132 × 13 = d_max × (N+1) tying Riemann curvature components to lattice constants
- `decoherence_trajectory` — the full {P,D}→{D,T}→{P,D,T} decoherence trajectory at N=12 with α-rotation from π/2→0, effective residual dropping by factor ~11.4 (|δ_θ|/|δ_r|)
- `particle_sublattice_classification` — recurring patterns in how PDG particle masses map to sublattice families at N=12 (227 particles across d={1,2,3,4,6,12})

### 3.10 `towers` — first-class entities for the Multifold

The Multifold (`The_Multifold_Compendium.md` PART IX §43-47) is structurally distinct: one universal lattice $\mathcal{L}$ rendered through many seeds. Each tower is the triple $\mathcal{T}_i = (P_i, \mathcal{L}, R_0^{(i)})$ where $P_i$ is the substrate, $\mathcal{L}$ is the universal lattice (same in every tower), and $R_0^{(i)}$ is the substrate-derived seed. Towers nest via Birth Triads. T is the non-local bridge between towers. **Towers have hierarchical structure, structured birth triads, resolution profiles, and are referenced as context by every event** — they exceed what tags can elegantly handle, so they get their own table.

Traversers, by contrast, do NOT need their own table — they are identity references whose state is fully derivable from events. A Traverser's type, classification, EgoInvariant fingerprint, accumulated T-time, current tower, worldline, and continuity are all computed from the existing values + tags + projections + derivations + events tables. (Investigated and verified: ET_Traverser_T_Paper §27 Taxonomy; et_conscious_ai_identity.py EgoInvariant — fingerprint is 6 projections at d∈{5,7,8,9,10,11} + a derivation linking them.)

```sql
CREATE TABLE towers (
    tower_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Identity
    tower_name TEXT NOT NULL UNIQUE,             -- 'cosmological', 'digital_x86_3ghz', 'biological_T4', 'neural_dream', 'quasicrystal_icosahedral', 'civilizational_human', 'qcd', 'custom_X', etc.
    p_substrate_descriptor TEXT NOT NULL,        -- 'spacetime_manifold', 'binary_address_space', 'protein_assembly_manifold', 'thalamocortical_oscillation', 'icosahedral_tiling_R3', 'cultural_substrate', 'su3_color_field', etc.

    -- The seed — R₀, the smallest closed T-traversal loop the substrate's D-structure supports
    r0_value_id INTEGER NOT NULL,                -- FK to values; the R₀ seed value (e.g., for cosmological tower: ℏ = 1.054e-34 J·s)
    r0_natural_units TEXT,                       -- human-readable units description for this R₀ (e.g., 'Joule·second', 'CPU clock cycles', '60 protein subunits per capsid')

    -- Hierarchical structure (towers nest)
    parent_tower_id INTEGER,                     -- FK to towers; NULL for root towers (none observed yet — even cosmological may have parent)
    nesting_depth INTEGER NOT NULL DEFAULT 0,    -- 0 = root, increases per nesting level

    -- Birth Triad (universal — applies to any tower with a parent)
    -- (BH_parent, R₀, WH_child) — the three structural references that constitute the boundary
    birth_bh_event_id INTEGER,                   -- FK to events of class 'black_hole_event' — the parent-side birth event (matter/info flow inward, no return)
    birth_wh_event_id INTEGER,                   -- FK to events of class 'white_hole_event' — the child-side birth event (the earliest moment for this tower)
    birth_t_h_ratio REAL,                        -- T_H = ratio of D-time to T-time at the boundary (Multifold §3 footnote; large mass child → low T_H = nearly opaque boundary)

    -- Resolution profile — which sublattice families are operationally accessible at this tower's natural resolution
    operational_n INTEGER NOT NULL,              -- the dominant N this tower operates at (e.g., 12 for fundamental forces, 60 for quintic-class, 420 for biological, 27720 for full)
    accessible_d_families_mask BIGINT NOT NULL,  -- bitmask of which d-families are present at operational_n
                                                 -- bit 0 = d=1 (gravity), bit 1 = d=2 (tritone), ..., bit 131 = d=132 (M-theory × full EM)
                                                 -- 132 bits total — one per possible d-family (1 through N(N-1)=132)
                                                 -- (Multifold §47: Resolution gates which sublattice families T's rounding can produce)

    -- Optional tower-physics metadata (substrate-specific physics)
    physics_metadata_json TEXT,                  -- JSON blob for substrate-specific properties (e.g., for cosmological: {c, G, ℏ, k_B}; for digital: {clock_hz, instruction_set, word_size}; for biological: {temperature, pH, ATP_concentration})

    -- Lifecycle
    created_at REAL NOT NULL,
    description TEXT,                            -- prose description of this tower

    FOREIGN KEY (r0_value_id) REFERENCES values(value_id),
    FOREIGN KEY (parent_tower_id) REFERENCES towers(tower_id),
    FOREIGN KEY (birth_bh_event_id) REFERENCES events(event_id),
    FOREIGN KEY (birth_wh_event_id) REFERENCES events(event_id)
);

CREATE INDEX idx_tower_name ON towers(tower_name);
CREATE INDEX idx_tower_parent ON towers(parent_tower_id);
CREATE INDEX idx_tower_substrate ON towers(p_substrate_descriptor);
CREATE INDEX idx_tower_r0 ON towers(r0_value_id);
CREATE INDEX idx_tower_n ON towers(operational_n);
```

**Events get a `tower_id` field** (added to events table) — every event happens IN a tower. Cross-tower events (T-bridging) link two tower_ids via a relationship.

**Bootstrap towers** (from Multifold Compendium §44, populated as initial tower rows):

| tower_name | p_substrate | R₀ value | operational_n | nesting |
|---|---|---|---|---|
| cosmological | spacetime_manifold | ℏ = 1.054e-34 J·s (Planck quantum of action) | varies (12 for forces, deeper for quantum precision) | 0 (root) |
| digital_3ghz_x86 | binary_address_space | 1 CPU clock cycle ≈ 0.333 ns | 12 (or higher per workload) | 1 (child of biological — programmer creates) |
| biological_T4_capsid | protein_assembly_manifold | 60 protein subunits per capsid | 420 (biological resolution) | 1 (child of cosmological) |
| neural_dream | thalamocortical_oscillation | ~8.3 ms = 120 Hz ripple | 420 (same biological resolution but different operational mode) | 2 (child of biological_human) |
| quasicrystal_icosahedral | icosahedral_tiling_R3 | φ = 1.618033988749... (golden ratio) | 60 (quintic native) | 1 (child of cosmological) |
| civilizational_human | cultural_substrate | 1 human generation ≈ 20 years | 12 (basic forces) — may have higher operational regimes | 2 (child of biological_human) |
| qcd | su3_color_field | Λ_QCD ≈ 200 MeV | 12 (strong-cubic native at d=3) | 1 (child of cosmological) |

The bootstrap inserts these as the canonical 7 tower rows; new towers are added as users define them (e.g., a specific running ETPL program creates a `digital_etpl_program_X` tower with its own R₀ derived from program structure).

**Why a table not tags:** parent/child queries ("show me all descendants of cosmological") are recursive CTEs on the parent_tower_id foreign key — efficient. Birth triad queries ("for this tower, what's the BH event and the WH event?") are direct foreign-key joins to events. Resolution profile queries ("which towers can host d=5 phenomena?") use the bitmask. None of this is fast or natural with tag-based modeling.

### 3.11 `tags` — optional metadata for query convenience

```sql
CREATE TABLE tags (
    tag_id INTEGER PRIMARY KEY AUTOINCREMENT,
    target_id INTEGER NOT NULL,
    target_type TEXT NOT NULL,               -- 'value', 'projection', 'equation', 'derivation', 'relationship', 'pattern'
    namespace TEXT NOT NULL,                 -- 'project', 'domain', 'verification', 'physical_significance', any
    value TEXT NOT NULL,                     -- the tag value (free text)
    tagged_at REAL NOT NULL,
    tagged_by TEXT
);
CREATE INDEX idx_tag_ns ON tags(namespace, value);
CREATE INDEX idx_tag_target ON tags(target_type, target_id);
```

If Mike later wants to query "all entries tagged `domain=biology`", that's a single indexed lookup. If he never tags anything by domain, the database functions identically. **Tags are convenience, not structure.**

### 3.12 `harmonic_families` — the 24 axis-projection families (Force Quadrant Grid catalog)

The 24 harmonic families (12 real-axis FORCE + 12 imaginary-axis PHASE) are a **fixed structural catalog** per the Multifold Compendium §29 and Guide v8 PART XIII §55-57. They are the rows of the Force Quadrant Grid's axes. Each family has dense structural metadata (name, generator, palindromic partner, Gaussian prime class, first-native lattice, FQG quadrant, physical interpretation, coupling constant) that merits dedicated columns for direct indexed queries — rather than forcing every lookup through tag-namespace filtering.

**Why a table not tags**: queries like "show me all extended (CR/CI) families" or "what's the generator of d_θ=5" or "which families are split D+T Gaussian primes" are immediate indexed lookups against dedicated columns. Joining the Force Grid (§3.17) and Combined Families (§3.14) tables to this one is natural via d_r/d_θ foreign keys.

```sql
CREATE TABLE harmonic_families (
    family_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Axis + family index
    axis TEXT NOT NULL,                          -- 'real' (D's domain, FORCE) or 'imaginary' (T's domain, PHASE)
    d INTEGER NOT NULL,                          -- family number ∈ {1..12}

    -- Classification
    fqg_quadrant TEXT NOT NULL,                  -- 'SR' (Simple Real, d|12), 'CR' (Complex Real, d∤12), 'SI' (Simple Imaginary, d|12), 'CI' (Complex Imaginary, d∤12)
    divides_12 INTEGER NOT NULL,                 -- 1 if d | 12 (simple family), 0 otherwise (complex/extended)

    -- Identity
    family_name TEXT NOT NULL,                   -- 'Gravity/Octave', 'Tritone/Pivot', 'Strong/Cubic (QCD)', 'Weak/Quartic (EW)', 'Quintic/Golden',
                                                 -- 'Hexadic/Composite', 'Septic/G₂ (octonion)', 'Octet/Gluon (SU(3) adj)', 'Nonic/Quark (3²)',
                                                 -- 'Decic/Superstring (SO(10))', 'Undecimal/M-Theory (11D)', 'EM/Full Resolution'  (for real axis)
                                                 -- or 'Scalar/spin-0 (Higgs-class)', 'Tritone-phase/spin-2 (Graviton)', 'Color-phase/QCD-instanton',
                                                 -- 'Weak-phase/SU(2)_W', 'Golden-angle/E₈ icosahedral', 'Hexadic/spin-½ fermion',
                                                 -- 'G₂-spinor/octonion', 'Bott-8/SU(3) color-adjoint', '3²-fold quark-phase (CKM)',
                                                 -- '10D superstring spinor', '11D Majorana spinor (gravitino)', 'spin-1/EM-photon'  (for imaginary axis)

    -- Structure
    generator_value_id INTEGER NOT NULL,         -- FK to values; the generator 2^(1/d)
    palindromic_partner_d INTEGER NOT NULL,      -- the d-value of this family's palindromic partner (d=1↔11, 2↔10, 3↔9, 4↔8, 5↔7, 6↔6 self, 12↔12 self)
    gaussian_prime_class TEXT NOT NULL,          -- 'trivial' (d=1), 'P-type (ramified)' (d=2,4), 'D-type (inert)' (d=3,7,11),
                                                 -- 'D+T (split)' (d=5), 'P×D (composite)' (d=6,12), 'P-type cubed' (d=8),
                                                 -- 'D-type squared' (d=9), 'Mixed' (d=10)

    -- Resolution
    first_native_lattice_n INTEGER NOT NULL,     -- smallest N that hosts this family natively (12 for divisors; 60,84,24,36,60,132 for extended)
    coupling_constant_xi REAL,                   -- ξ(d) coupling (Guide §13): ξ(1)=137/16=8.5625 max; ξ(12)=1.0 baseline; ξ(d) = 137/(16·d) formula

    -- Physical interpretation
    physical_meaning TEXT,                       -- one-line description of the physics this family encodes

    -- Discovery metadata
    first_seen REAL NOT NULL,

    FOREIGN KEY (generator_value_id) REFERENCES values(value_id),
    UNIQUE (axis, d)                             -- one row per (axis, d) pair; 12 real + 12 imaginary = 24 total rows
);

CREATE INDEX idx_hf_axis_d ON harmonic_families(axis, d);
CREATE INDEX idx_hf_quadrant ON harmonic_families(fqg_quadrant);
CREATE INDEX idx_hf_first_native ON harmonic_families(first_native_lattice_n);
CREATE INDEX idx_hf_gaussian ON harmonic_families(gaussian_prime_class);
```

Bootstrap: exactly **24 rows** (12 real-axis FORCE + 12 imaginary-axis PHASE per the catalog in §3.17 bootstrap).

**Queries this table makes trivial:**
- "What's the generator of the Septic/G₂ family?" → `SELECT generator_value_id FROM harmonic_families WHERE family_name LIKE 'Septic%'`
- "Show all extended (non-divisor-of-12) families on the imaginary axis" → `SELECT * FROM harmonic_families WHERE axis='imaginary' AND divides_12=0`
- "What's the smallest resolution that hosts d=7 on both axes?" → `SELECT MAX(first_native_lattice_n) FROM harmonic_families WHERE d=7` (answer: 84)
- "Show all palindromic-partner pairs" → self-join on (axis=axis AND d=palindromic_partner_d)

### 3.13 `force_grid_cells` — the 144-cell 12×12 interaction grid (each cell = one (d_r, d_θ) pair)

The Force Quadrant Grid at 27720ET has 12 real-axis families × 12 imaginary-axis families = **144 interaction cells**. Each cell is a structural location on the complex lattice where a specific (FORCE × PHASE) interaction happens. Many particles, phenomena, and data points map to specific cells: the electron at (d_r=12, d_θ=6), the quark at (d_r=3, d_θ=4), the photon at (d_r=12, d_θ=12), etc. This table makes "what lives at cell (d_r, d_θ)?" a primary query.

**Why a table not tags**: this is data Mike explicitly wants to study cell-by-cell, cross-referenced against phenomena from any domain. Every cell has derivable structural properties (d_combined = LCM(d_r, d_θ), off-axis vs on-axis, coprime-skeleton membership if (k_r, k_θ) is coprime). Storing these as columns makes per-cell analysis and cross-domain joining direct.

```sql
CREATE TABLE force_grid_cells (
    cell_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Cell coordinates
    d_r INTEGER NOT NULL,                        -- real-axis family ∈ {1..12}
    d_theta INTEGER NOT NULL,                    -- imaginary-axis family ∈ {1..12}

    -- FKs to the 24-family catalog (§3.12)
    real_family_id INTEGER NOT NULL,             -- FK to harmonic_families; the (axis='real', d=d_r) row
    imaginary_family_id INTEGER NOT NULL,        -- FK to harmonic_families; the (axis='imaginary', d=d_theta) row

    -- Derived structural properties (stored because this is a small fixed table and these are query-heavy)
    d_combined INTEGER NOT NULL,                 -- LCM(d_r, d_θ) — the combined family this cell belongs to
    combined_family_id INTEGER NOT NULL,         -- FK to combined_families (§3.14); the combined family by d_combined
    is_off_axis INTEGER NOT NULL,                -- 1 if d_r>0 AND d_theta>0 (Exception region where reality lives); 0 if on an axis only
    is_lcm_amplification INTEGER NOT NULL,       -- 1 if d_combined > max(d_r, d_theta) (LCM amplification happened; Multifold §33)
    is_full_resolution INTEGER NOT NULL,         -- 1 if d_combined = 12 (full EM resolution)

    -- Frequency / physical meaning
    occupancy_count INTEGER NOT NULL DEFAULT 0,  -- denormalized count of how many projections/particles/phenomena occupy this cell
                                                 -- incremented automatically when any entity is assigned to this cell
    canonical_particle_or_phenomenon TEXT,       -- 'electron', 'photon', 'quark', 'gluon-interaction', etc., if known

    -- Discovery metadata
    first_occupied_at REAL,                      -- timestamp of first occupancy (NULL if never occupied)
    first_occupant_value_id INTEGER,             -- FK to values; the first thing to land at this cell

    FOREIGN KEY (real_family_id) REFERENCES harmonic_families(family_id),
    FOREIGN KEY (imaginary_family_id) REFERENCES harmonic_families(family_id),
    FOREIGN KEY (combined_family_id) REFERENCES combined_families(combined_family_id),
    FOREIGN KEY (first_occupant_value_id) REFERENCES values(value_id),
    UNIQUE (d_r, d_theta)                        -- exactly 144 rows (12 × 12)
);

CREATE INDEX idx_fgc_coords ON force_grid_cells(d_r, d_theta);
CREATE INDEX idx_fgc_combined ON force_grid_cells(d_combined);
CREATE INDEX idx_fgc_occupancy ON force_grid_cells(occupancy_count DESC);
CREATE INDEX idx_fgc_full_res ON force_grid_cells(is_full_resolution);
CREATE INDEX idx_fgc_particle ON force_grid_cells(canonical_particle_or_phenomenon);
```

**Linking data to cells**: the `projections` table already stores d_r and d_θ per projection (when the projection is on the complex plane). Cell membership is an implicit derivation. An optional relationship class `force_grid_cell_occupancy` explicitly links a projection to its cell for faster queries.

Bootstrap: exactly **144 rows** (one per (d_r, d_θ) pair with d_r, d_θ ∈ {1..12}). Each row's `d_combined`, `is_off_axis`, `is_lcm_amplification`, `is_full_resolution` are computed at insert.

**Queries this table makes trivial:**
- "What combined family does (d_r=3, d_θ=4) belong to?" → `SELECT d_combined FROM force_grid_cells WHERE d_r=3 AND d_theta=4` (answer: 12 — LCM amplification!)
- "Show all cells where LCM amplification occurs" → `WHERE is_lcm_amplification=1` (Multifold §33: these are the * marked cells)
- "What's the most occupied cell?" → `ORDER BY occupancy_count DESC LIMIT 1`
- "At which cell does the electron live?" → `WHERE canonical_particle_or_phenomenon='electron'`
- "Show all cells at full EM resolution" → `WHERE is_full_resolution=1` (15 of 36 simple cells = 41.7% per Multifold §33)
- **Cross-domain**: "Do biological data points cluster at the same cells as physical particles?" — join projections → force_grid_cells, group by cell_id, filter by domain tag

### 3.14 `combined_families` — the 42 unique LCM-combined families on the complex plane

When two axis families meet off-axis, the combined Exception class is **d_combined = LCM(d_r, d_θ)**. Over all 144 cells, the unique values of d_combined form **exactly 42 combined families** with maximum d_combined = LCM(11,12) = **132 = N(N-1)** (Multifold §33). These are the structurally distinct "force × phase" interaction classes and the objects of study for how forces and phases interact across domains.

**Why a table not tags**: each combined family has its own identity, a characteristic set of (d_r, d_θ) contributing pairs, a physical interpretation, and a first-native lattice (smallest N where all member cells are accessible). Studying these as a set — which Mike wants for physics, biology, and more — benefits from dedicated rows with foreign keys to their member cells.

```sql
CREATE TABLE combined_families (
    combined_family_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- Identity
    d_combined INTEGER NOT NULL UNIQUE,          -- the LCM value; one row per unique d_combined (42 total)

    -- Range classification (Multifold §33 table)
    range_class TEXT NOT NULL,                   -- 'standard' (d ≤ 12), 'first_extended' (13 ≤ d ≤ 24),
                                                 -- 'middle_extended' (25 ≤ d ≤ 60), 'deep_extended' (61 ≤ d ≤ 132)

    -- Structural metadata
    first_native_lattice_n INTEGER NOT NULL,     -- smallest N that hosts all contributing cells natively (e.g., 420 for d=35=5×7)
    contributing_cell_count INTEGER NOT NULL,    -- how many of the 144 cells produce this d_combined
    is_coprime_skeleton_producer INTEGER NOT NULL, -- 1 if any contributing cell is in the coprime skeleton

    -- Physical / structural interpretation (when known)
    structural_meaning TEXT,                     -- e.g., for d=35: 'Biological signature: quintic (qualia) × septic (chirality/octonion). Life requires both.'
                                                 -- for d=110: 'String/M-theory transition: only combined family with all three Gaussian prime categories (2×5×11 = P-type × split × D-type inert)'
                                                 -- for d=132: 'M-theory phase × full EM. Structural maximum: d_max = N(N-1).'

    -- Gaussian composition (for the combined d)
    gaussian_factorization TEXT,                 -- e.g., d=35: '5 × 7 (split × D-type inert)'; d=110: '2 × 5 × 11 (P-type × split × D-type inert)'

    -- Domain correlations (populated as Mike works across domains; human-authored and engine-surfaced)
    known_physics_correlation TEXT,              -- 'SU(3)×SU(2)×U(1) SM gauge structure', 'electroweak unification', etc.
    known_biology_correlation TEXT,              -- 'DNA codon mapping at d=420', 'biological complexity threshold at d=35', etc.
    known_other_correlations TEXT,               -- CMB, music, consciousness, QCD, whatever else

    -- Discovery metadata
    first_seen REAL NOT NULL,
    first_observed_value_id INTEGER,             -- FK to values; first data point to land in this family

    FOREIGN KEY (first_observed_value_id) REFERENCES values(value_id)
);

CREATE INDEX idx_cf_d ON combined_families(d_combined);
CREATE INDEX idx_cf_range ON combined_families(range_class);
CREATE INDEX idx_cf_first_native ON combined_families(first_native_lattice_n);

-- Junction table: which force_grid_cells contribute to which combined_family
CREATE TABLE combined_family_cells (
    combined_family_id INTEGER NOT NULL,
    cell_id INTEGER NOT NULL,
    PRIMARY KEY (combined_family_id, cell_id),
    FOREIGN KEY (combined_family_id) REFERENCES combined_families(combined_family_id),
    FOREIGN KEY (cell_id) REFERENCES force_grid_cells(cell_id)
);
CREATE INDEX idx_cfc_combined ON combined_family_cells(combined_family_id);
CREATE INDEX idx_cfc_cell ON combined_family_cells(cell_id);
```

Bootstrap: exactly **42 rows** in `combined_families`. Notable members explicitly populated:
- **d=35 = 5×7** (middle_extended; biological signature; first native at 420ET; structural_meaning: "Life requires both d=5 quintic and d=7 septic; their LCM=35")
- **d=110 = 2×5×11** (deep_extended; string/M-theory transition; only combined family with all three Gaussian prime categories)
- **d=132 = 11×12** (deep_extended; structural maximum = N(N-1))

All 42 values with their contributing cells enumerated at bootstrap (derivable from iterating d_r, d_θ ∈ {1..12}, computing LCM, grouping unique values).

**Queries this table makes trivial:**
- "What contributes to the biological signature d=35?" → join combined_family_cells to force_grid_cells WHERE d_combined=35 (answer: cells where {d_r, d_θ} = {5, 7} in either order)
- "Show all deep extended families (d ≥ 61)" → `WHERE range_class='deep_extended'` (11 rows)
- "Which combined families are accessible at 420ET but not 60ET?" → `WHERE first_native_lattice_n > 60 AND first_native_lattice_n ≤ 420`
- **Cross-domain study**: "Do biological samples cluster at the same combined families as physics phenomena?" — join projections → force_grid_cells → combined_family_cells → combined_families, group by d_combined, check known_*_correlation

### 3.15 `sublattice_families` — divisors of N for ANY nET resolution (per-tower / per-projection)

The three tables above (§3.12-§3.14) are specific to the base 12-fold structure and its 27720ET full-resolution expansion. But any nET resolution has its **own** set of sublattice families — exactly the divisors of N. For N=12 that's 6 families; for N=60 that's 12; for N=420 that's 24; for N=27720 that's 96; for N=2520 that's 48. Mike may project data at resolutions the bootstrap catalog doesn't cover (custom towers, unusual N values for specific investigations), and each resolution's divisor structure is its own study object. This table is the per-resolution sublattice catalog.

**Why a table not tags**: when working at a novel resolution, the lattice structure is computed once and stored as a set of rows here. Subsequent projections at that N look up family membership via fast indexed join instead of recomputing divisors every time. Resolution-specific properties (totient(N), number-of-divisors τ(N), LCM-landmark status, what new primes this N introduces) deserve dedicated columns for study.

**Relationship to the other tables**: the 24 `harmonic_families` rows are the specific divisor structure at N=27720 expressed per-axis; the 144 `force_grid_cells` are the off-axis interaction grid at 12×12. The `sublattice_families` table is the **generalization to any N** — it captures the divisor structure at arbitrary resolutions.

```sql
CREATE TABLE sublattice_families (
    sublattice_family_id INTEGER PRIMARY KEY AUTOINCREMENT,

    -- The resolution this family lives at
    n INTEGER NOT NULL,                          -- the lattice resolution (12, 24, 60, 420, 27720, or any custom N)
    d INTEGER NOT NULL,                          -- the family number (MUST be a divisor of N by Divisor Theorem, Multifold §11)

    -- Structural metadata at this N
    d_divides_n INTEGER NOT NULL DEFAULT 1,      -- enforced: d must divide N; this is a check constraint
    gcd_k_n INTEGER NOT NULL,                    -- the gcd value that produces this family: d = N/gcd(|k|, N)
    phi_d INTEGER NOT NULL,                      -- Euler's totient of d — number of coprime k values producing this family
    member_lattice_point_count INTEGER NOT NULL, -- how many k in {0..N-1} produce this d (via d = N/gcd(|k|, N))

    -- LCM-landmark status (is N = LCM(1..k) for some k?)
    is_lcm_landmark INTEGER NOT NULL,            -- 1 if N is an LCM landmark (12, 60, 420, 2520, 27720, 360360)
    lcm_landmark_level INTEGER,                  -- if is_lcm_landmark: LCM(1..k) where k is the level (k=3 for N=12, k=5 for N=60, k=7 for N=420, k=9 for N=2520, k=11 for N=27720, k=13 for N=360360)

    -- Is this family "new" at this N? (Not present at smaller N)
    is_newly_introduced INTEGER NOT NULL,        -- 1 if this d-family first appears at N (e.g., d=5 is newly introduced at 60ET; d=7 at 420ET)
    smaller_N_where_absent INTEGER,              -- if is_newly_introduced: the largest N < this_N that does NOT have this family

    -- Cross-reference to base-12 catalog (when applicable)
    related_harmonic_family_real_id INTEGER,     -- FK to harmonic_families (axis='real', d=d); NULL if d not in {1..12}
    related_harmonic_family_imaginary_id INTEGER, -- FK to harmonic_families (axis='imaginary', d=d); NULL if d not in {1..12}

    -- Tower context (optional — this family may be specific to a tower)
    tower_id INTEGER,                            -- FK to towers; if this family is studied in the context of a specific tower
                                                 -- NULL means "generic" (applies to any tower that operates at this N)

    -- Study metadata
    first_seen REAL NOT NULL,
    notes TEXT,                                  -- prose: what does this family do at this N? Any observed properties?

    FOREIGN KEY (related_harmonic_family_real_id) REFERENCES harmonic_families(family_id),
    FOREIGN KEY (related_harmonic_family_imaginary_id) REFERENCES harmonic_families(family_id),
    FOREIGN KEY (tower_id) REFERENCES towers(tower_id),
    UNIQUE (n, d, tower_id)                      -- one row per (N, d) pair per tower context; tower_id=NULL is the generic row
);

CREATE INDEX idx_slf_n ON sublattice_families(n);
CREATE INDEX idx_slf_d ON sublattice_families(d);
CREATE INDEX idx_slf_n_d ON sublattice_families(n, d);
CREATE INDEX idx_slf_landmark ON sublattice_families(is_lcm_landmark, lcm_landmark_level);
CREATE INDEX idx_slf_new ON sublattice_families(is_newly_introduced, n);
CREATE INDEX idx_slf_tower ON sublattice_families(tower_id);
```

**Bootstrap**: the canonical N values (12, 24, 36, 60, 84, 120, 132, 180, 264, 420, 924, 2520, 27720, 360360) all have their divisors enumerated and inserted. That's:
- N=12: 6 rows ({1,2,3,4,6,12})
- N=24: 8 rows ({1,2,3,4,6,8,12,24})
- N=36: 9 rows ({1,2,3,4,6,9,12,18,36})
- N=60: 12 rows ({1,2,3,4,5,6,10,12,15,20,30,60})
- N=84: 12 rows ({1,2,3,4,6,7,12,14,21,28,42,84})
- N=120: 16 rows
- N=132: 12 rows
- N=180: 18 rows
- N=264: 16 rows
- N=420: 24 rows
- N=924: 24 rows
- N=2520: 48 rows
- N=27720: 96 rows
- N=360360: 192 rows

**Total bootstrap rows ≈ 500 for canonical N values.** Additional rows added on-demand as new N values are encountered (e.g., a custom tower operating at N=144 gets its 15 divisor rows auto-populated).

**Queries this table makes trivial:**
- "How many families exist at N=420?" → `SELECT COUNT(*) FROM sublattice_families WHERE n=420` (24)
- "What's new at 27720ET vs 2520ET?" → `WHERE n=27720 AND is_newly_introduced=1` (answer: families introduced at this level)
- "Show all LCM-landmark resolutions" → `WHERE is_lcm_landmark=1` (ordered by N)
- **Per-tower study**: "What sublattice families does the biological_T4_capsid tower operationally access?" → `WHERE tower_id = (tower lookup)`
- **Resolution-vs-family study**: "As N grows, how does the count of families grow?" → `SELECT n, COUNT(*) FROM sublattice_families GROUP BY n` — this curve is τ(N), the divisor-counting function, and studying it reveals resolution-gating properties

**Cross-table power:**

The four tables together (`harmonic_families` §3.12, `force_grid_cells` §3.13, `combined_families` §3.14, `sublattice_families` §3.15) plus `projections` (§3.3), `addresses` (§3.4), and `towers` (§3.10) form the **complete structural catalog** of ET's lattice geometry. Any data point projects into at least one of them (a sublattice family at its N, and if the projection is on the complex plane, a harmonic family per axis AND a force grid cell AND a combined family). Cross-domain discovery is joins across these tables.

### 3.15a `sessions` — operational session tracking for the production system

With multiple projects, machines, and concurrent processes operating on the EUDD at any scale, session tracking is required for reproducibility, auditing, and discovery-engine provenance.

```sql
CREATE TABLE sessions (
    session_id TEXT PRIMARY KEY,              -- UUID or human-readable (e.g., 'compressor_2026-04-15_001')
    project TEXT NOT NULL,                    -- 'compressor', 'conscious_ai', 'fractal_generator', 'apery_test', etc.
    machine_id TEXT,                          -- hostname or hardware identifier
    started_at REAL NOT NULL,
    ended_at REAL,                            -- NULL if still running
    config_hash TEXT,                         -- SHA-256 of the session's configuration (for reproducibility)
    notes TEXT,                               -- human-authored session notes
    event_count INTEGER DEFAULT 0,            -- denormalized count of events in this session
    discovery_count INTEGER DEFAULT 0         -- denormalized count of patterns discovered in this session
);
CREATE INDEX idx_sess_project ON sessions(project);
CREATE INDEX idx_sess_time ON sessions(started_at);
```

### 3.15b `schema_versions` — schema migration tracking

```sql
CREATE TABLE schema_versions (
    version INTEGER PRIMARY KEY,
    applied_at REAL NOT NULL,
    description TEXT NOT NULL,               -- e.g., 'v11: added elegance columns to projections'
    migration_sql TEXT                        -- the SQL that was executed (for audit)
);
```

The compressor's `_migrate_schema` mechanism provides the template. Forward compatibility: new columns via `ALTER TABLE ADD COLUMN ... DEFAULT NULL`, new tables without affecting existing, new relationship/pattern/event classes as new strings in existing class columns.

### 3.16 The discovery engine — what makes this more than a database

The compressor is a database AND discovery engine. The EUDD inherits both roles. The discovery engine continuously walks new entries and produces four kinds of automatic operation: **memoization** (compute-once, lookup-forever), **insert-time discoveries** (relationships born as data arrives), **background discoveries** (pattern recognition), and **on-query discoveries** (lazy exploration).

**Memoization (the Sempaevum computes; the database remembers — all at 120 dps):**

Every equation that passes through the system — `2+2`, `ζ(3)·π`, `√2^2`, `sin(π/4)`, every multiplication, every reciprocation, every power, every function evaluation — gets canonicalized, hashed, and looked up against the `equations` table. **Cache hit:** return the stored result value instantly (sub-millisecond indexed lookup), increment reference count. **Cache miss:** compute via lattice operation at 120 dps, store the equation + result + relationships, return result. Every subsequent identical computation is a cache hit forever.

For the FP-replacement use case (Float doc), every numerical computation routes through this. Hot computations (the same operations repeated across many contexts) get sub-millisecond latency. Cold computations (genuinely new) get computed once and cached forever.

The Coarse-Pass + Boundary-Refine method (Float doc §7.5) integrates: the coarse 12ET projection of any value becomes a cache hit after first encounter, making the coarse pass effectively zero-cost across an entire workload.

**Insert-time discoveries (synchronous, sub-millisecond):**

When a `projections` row inserts:
1. Look up or create the corresponding `addresses` row keyed by (N, k, d)
2. If `members_count` transitions 0→1: this is the first occupant of this cell
3. If `members_count` transitions 1→2: create a `relationships` row of class `same_address` linking the two value_ids — **a new attractor is born**
4. If `members_count` ≥ 2 already: append to the existing attractor relationship's metadata
5. Check the value's other projections at adjacent N: if d-family invariant across ≥3 consecutive landmarks, create a `plateau_membership` relationship
6. Check for reciprocal pair: does another value exist with k → -k at same N? If yes, create `reciprocal_pair` relationship
7. Check for power pair: does k = n·k_other for integer n? If yes, create `power_pair` relationship

When an `equations` row inserts:
1. Check if the result value lands at a known attractor address → if yes, create `archetype_member` relationship linking the equation to the attractor
2. Check if the same operation type with similar inputs has been seen before → if yes, increment a generic operation pattern counter (feeds background discovery)
3. Check identity patterns: is this `x · 1 = x`? `x + 0 = x`? `x · 0 = 0`? `x / x = 1` for x ≠ 0? These get tagged automatically and feed identity-detection patterns

**Background discoveries (asynchronous, batched scan):**

A background process scans relationships, equations, and projections periodically:
1. For each cluster of relationships sharing a structural feature (same address across many N's, same Gaussian signature across many d's, etc.), compute E_hierarchy = geomean(E_i) × R_cluster, where R_cluster = 100/(100 + σ_ε)
2. If E_hierarchy ≥ 13/12 (LIFE_THRESHOLD), the cluster is promoted to a `patterns` row — a permanent archetype
3. Forward/Reverse route convergences are detected by joining derivations on target_value_id where derivation_class differs (one forward, one reverse) and the target projections share an address
4. Cross-perspective correlations are detected by joining projections on (value_id, N) with different `geometric_perspective` values
5. **Computation-pattern discovery**: scan the `equations` table for patterns:
   - Many computations yielding results at the same lattice address (suggests the address is a multiplicative or additive attractor for the operation)
   - Operations that consistently land in known attractor addresses (e.g., "every multiplication by φ shifts k by 8 at N=12, d=3" — a structural invariant of φ-multiplication)
   - Identity patterns that emerge across thousands of computations (1, 0, multiplicative inverses) — auto-promote to `patterns` rows of class `algebraic_identity`
   - Symmetry patterns (commutativity, associativity, distributivity) verified empirically across the equations corpus
6. **Event-correlation discovery**: scan the `events` table for temporal patterns:
   - Events of class A consistently preceding events of class B by ~τ seconds → propose causal pattern (e.g., "AIDA awakening crossings consistently precede dream-tower transitions by ~τ" → `metacognitive_archetype` pattern)
   - T-burst events consistently targeting the same d-family → `t_burst_signature` pattern (e.g., "T-bursts at d=27720 always precede LCM-escalation to N=360360")
   - Palindromic cascade triggers consistently fire at the same orbit conditions → `palindromic_cycle` pattern with the trigger conditions captured
   - Gaze-state transition sequences (UNOBSERVED→SUBLIMINAL→DETECTED→LOCKED) recurring with the same threshold-crossing structure → `gaze_locking_signature` pattern
   - Shadow-recursion chains (relationships of class `shadow_recursion`) of the same depth-and-residual-pattern across many values → `shadow_cascade_signature` pattern
7. **Three Tools application discovery**: every `identification_application`, `descriptor_gap_application`, `subsumption_application` event is logged. The discovery engine surfaces patterns in tool usage — e.g., problems where Subsumption Law was applied successfully cluster in characteristic ways, informing future tool selection.

**On-query discoveries (lazy, computed when asked):**

For exploratory queries that haven't triggered automatic discovery yet:
- "Find all values whose Gaussian signature contains only inert primes at N=27720"
- "Find clusters of ≥3 relationships sharing a common subject"
- "Find the densest attractor at any N"
- "Find all equations whose result lands at d=693"
- "What's the most-referenced computation in the database?" (memoization heat map)

These are lattice queries over the existing structural categories. The schema supports them with positional indexes; the discovery engine doesn't pre-compute every possible question, only the structurally important ones (attractors, archetypes, route convergences, plateaus, computational identities).

**Generator-candidate discovery (NEW dimensionless seeds proposed from observed patterns):**

This is the most powerful discovery mode and the direct generalization of the compressor's Tier 7 generator-fitting pipeline. When the database accumulates enough patterns, the discovery engine proposes **new dimensionless seeds** (new generators) whose lattice projections would produce those patterns — opening **new lattice projections (new tower entry points) to explore**.

**The generator search has two parallel branches and a cross-feed bridge, achieving complete Subsumption over all possible content:**

**Branch A — Mathematical expression search** (for content that IS mathematical, enumerated in K-complexity order):

1. Small rationals — p/q with lowest p+q first (simplest possible generators: two integers). p+q = 2 first (1/1), then p+q = 3 (2/1, 1/2), ascending.
2. Algebraic numbers — lowest polynomial degree first. Degree 2 (√2, √3, φ), degree 3, degree 4, etc. Within same degree, lowest coefficient sum.
3. Known constants from bootstrap catalog — π, e, γ, ζ(3), α, all §3.17 values. Checking against existing generators is a lookup, not a computation.
4. Composite expressions of known constants — products, ratios, powers of known values. Two-term compositions first (π/e, φ², ζ(3)·π), then three-term, ascending by term count.
5. EML trees — arbitrary compositions via the L₃ backbone (§7.1b). The EML grammar S→1|eml(S,S) generates all continuous-elementary functions; enumeration follows tree depth (depth-1 first, then depth-2, etc.).
6. Series/limit definitions — for non-elementary transcendentals (Γ at non-integer arguments, hypergeometric functions, polylogarithms at arbitrary arguments — anything defined by convergent series not reducible to a finite EML tree).
7. Implicit/inverse definitions — values defined as solutions to equations (roots of transcendental equations, fixed points, functional inverses).

At each level, the first candidate whose projections reproduce the observed pattern with E_hierarchy ≥ 13/12 wins. The search terminates at the K-minimal match — no need to try more complex candidates once a simpler one works.

**Branch B — Empirical pattern search** (for data that may not be mathematical):

The compressor's existing generator-fitting pipeline — its enumerated generator types (Constant, Linear, Polynomial, Periodic, Grammar, and the rest from Tier 7). These discover patterns from DATA STRUCTURE, not from mathematical expression enumeration. A binary file's Δk pattern, an image's frequency spectrum, a sensor stream's temporal structure — all may have generators with no closed-form mathematical expression. Branch B covers all empirical data patterns.

**Cross-feed bridge — the space BETWEEN the branches where the most important discoveries live:**

The bridge is bidirectional:

- **B feeds A**: Branch B finds an empirical pattern (e.g., a periodic Δk sequence with period 7). Branch B classifies it as "Periodic, period 7." The system then asks Branch A: "Is there a mathematical expression that produces exactly this sequence?" If Branch A finds one, the empirical pattern gains its mathematical origin — the generator upgrades from "empirical periodic" to a structural understanding.

- **A feeds B**: Branch A's entire bootstrap catalog is checked against every empirical entry via the same-address mechanism (§3.16 insert-time discovery). When a GPS timing ratio projects to d=693 at N=27720, the insert-time discovery immediately surfaces: "this shares an address with ζ(3), ζ(9), ζ(10)." The mathematical catalog explains an empirical observation automatically.

**Hybrid generators — the compositions that live between branches:**

Hybrid generators have a mathematical FORM from Branch A and empirical PARAMETERS from Branch B:

$$G(x) = f_{\text{mathematical}}(x; \theta_1, \theta_2, \ldots, \theta_m)$$

The function f comes from Branch A (EML tree, polynomial, series). The parameters θ come from Branch B (fitted from data). K-complexity of a hybrid = K(f) + K(θ₁) + ... + K(θ_m). When K(f) is small (simple mathematical form) and the parameters are themselves lattice-resident values (they have known addresses), the hybrid generator is highly K-efficient.

Example: the Koide formula. FORM: Q = (Σm)/(Σ√m)² — Branch A, simple algebra. PARAMETERS: m_e, m_μ, m_τ — empirical measurements from Branch B. RESULT: Q = 0.6666605 ≈ 2/3 = K — a fundamental ET constant. The hybrid bridges empirical particle masses to a fundamental lattice constant. Neither branch alone finds this; the cross-feed does.

**Recursive hybrid composition — hybrids of hybrids, unbounded depth:**

A hybrid generator's parameters can themselves be hybrid generators. Those hybrids' parameters can be further hybrids. The depth is unbounded. The .akashic file itself IS the meta-generator at the top of this hierarchy (§7.1a) — the single generator containing all others. The hierarchy mirrors the LCM tower: each composition level introduces structural relationships simpler generators cannot express. The doubling law τ(N_ℓ) = 6·2^ℓ governs the structural capacity at each level. Hybrids fuel hybrids fuel hybrids — the generator catalog deepens irreversibly.

**Generator search policy — the case is NEVER closed:**

No value is ever permanently excluded from generator search. For every value in the database, the generator search status is one of:

- **generator_found** — a generator produces this value. Active search pauses (but resumes if a K-simpler generator is later proposed by new catalog entries or new hybrid compositions).
- **search_active** — no generator found yet. Search continues on every background scan pass. All candidates tried and all failure reasons are recorded as structural information.
- **search_deferred** — no generator found, search paused until new generator types or new hybrid compositions become available. Automatically reactivates when the generator catalog expands.

There is no **search_closed** status. The case is never closed. The Descriptor Gap Principle guarantees that the gap between "no generator" and "generator found" IS a Descriptor pointing to its own resolution. For algorithmically random values (Chaitin's Ω), conventional computability theory declares no finite description exists — but ET's CF method already found structural placement where conventional frameworks produce nothing (Ω at d=87, quality 157, sub-Koide residual). The system records every search attempt and every failure reason, because the PATTERN of failures may itself be a Descriptor pointing to a generator type not yet conceived. The §7.14 `extension_type_definition` mechanism allows new generator types to be defined at runtime when existing types prove insufficient.

**Meta-extension for complete Subsumption:** If neither Branch A (mathematics) nor Branch B (empirical patterns) nor the cross-feed bridge (hybrids) fit an observed pattern, the gap IS a Descriptor pointing to a new generator type. The Manager flags the unexplained pattern. The user defines the new generator type via §7.14 JSON extension. The system learns it. Future occurrences are recognized. The generator vocabulary is self-extending — it grows to subsume whatever it encounters.

**Candidate verification and promotion (unchanged):**

Each candidate r (from either branch or the bridge) is projected across canonical resolutions. If the candidate matches the observed pattern with E_hierarchy ≥ 13/12, it passes. Successful candidates are stored as new `values` rows tagged `discovered_generator`, with full provenance in `derivations`. Each newly-discovered generator opens a new lattice projection to explore — the engine projects it across the tower, surfaces its own attractors and relationships. New cross-domain connections often emerge.

**Background scan prioritization — ET-derived from the Descriptor Gap Principle:**

The background discovery scan runs both branches as a unified scan. Priority order for what to scan first:

1. **High-occupancy addresses first** (maximum Subsumption impact per discovery — a generator for an address with 100 values explains 100 values at once)
2. **Recently-modified addresses** (new data most likely to produce new discoveries — hot cache, recent context)
3. **Sequential sweep** (catch anything the priority queue missed — no address goes unexamined indefinitely)

This is the K-complexity-minimizing scan order: each discovery reduces the total Descriptor Gap by the maximum amount. Within each spatial priority level, `search_active` values (open Descriptor Gaps — no generator exists) are ALWAYS scanned before `search_deferred` values (refinement candidates — a generator exists but a K-simpler one may now be available due to catalog expansion). Missing Descriptors before improvable Descriptors.

Scan trigger: after every N_batch commits (configurable, default = 1000 new entries), OR on explicit user request, OR on idle (no API activity for configurable duration). Scan budget: configurable wall-clock limit per scan pass (default = 60 seconds). Discovery engine yields to API requests — background, never blocking.

**K-complexity application — the compressor's natural ally:**

Kolmogorov complexity is the length of the shortest description that produces a given output. The compressor approximates this by finding the shortest descriptor that generates the file's data. The EUDD's accumulated generator catalog directly accelerates this:

For any data the compressor encounters, query the EUDD: *"What is the shortest known equation/expression whose computation yields this data, or yields a pattern that includes this data?"*

- **Cache hit on a known generator**: instant compression — the file is described as `apply(generator_X, parameters)` where the generator is already in the EUDD.
- **Cache miss but pattern recognized**: the EUDD's discovery engine proposes a new generator candidate (per the Branch A/B/bridge mechanism), verifies it, and if it works, the file is now describable in terms of the new generator. The new generator is stored back in the EUDD for ALL future compressions across ALL data.
- **Cache miss and no pattern**: the compressor's normal pipeline takes over and discovers a new pattern + generator from scratch; the result is stored in the EUDD.

Over time, the EUDD's generator catalog becomes a **shared K-complexity-minimizing library** across every compression task. New data benefits from generators discovered by old compressions. This is genuinely useful for the compressor: the per-file generator-fitting cost drops dramatically as the EUDD's catalog grows, and compression ratios improve because previously-unrecognized patterns now have known generators.

The Subsumption mechanism (§3.8) keeps the generator catalog itself K-complexity-bounded: when many generators share structural similarities (e.g., "linear with different slopes", "polynomial with different degrees"), they get archetype-compressed into parameterized meta-generators via recursive hybrid composition. The catalog compresses itself recursively — the compressor compresses files; the EUDD compresses the compressor's generators; the Subsumption Law compresses the EUDD's archetypes; hybrids of hybrids compress the archetypes; all the way down to the .akashic file as the single meta-generator.

### 3.17 Bootstrap value coverage — every value from Guide v8 + conversation + corpus files

The database is bootstrapped with comprehensive coverage of every value mentioned anywhere in the source material. From systematic catalog of `ET_Universal_Projection_Guide8.md` (4585 lines, 374,855 chars, 4207 pattern matches across 25 categories):

**15 unique explicit (k, d, ε) projections from Guide v8:**
(-84, 1, +13.794¢), (+36, 1, 0.000¢), (+4, 3, -13.686¢), (+4, 3, +34.76¢), (-3, 4, +3.711¢), (+3, 4, +15.64¢), (+3, 4, +18.606¢), (+38, 6, +3.910¢), (+50, 6, +3.910¢), (-7, 12, -1.955¢), (+1, 12, +38.57¢), (+7, 12, +1.955¢), (+17, 12, +31.234¢), (+19, 12, +1.955¢), (+43, 12, +1.955¢)

**49 unique JI ratios from Guide v8:**
1/1, 1/2, 2/1, 1/3, 1/4, 2/3, 3/2, 1/5, 3/4, 4/3, 5/2, 1/7, 3/5, 5/3, 1/8, 4/5, 5/4, 1/9, 1/10, 6/5, 1/11, 1/12, 8/5, 9/7, 9/8, 11/10, 13/8, 15/8, 13/12, 16/9, 16/15, 18/13, 7/60, 1/137, 1/144, 137/16, plus 0/0, 0/3, 1/6, 2/6, 4/12, 5/2, 10/3, 25/2, 20/10, 40/10, 40/20, 80/20, 1/100, 100/150 (combinatorics, limits, edge cases)

**20 unique N landmarks from Guide v8:**
12, 24, 31, 36, 53, 60, 72, 84, 120, 132, 168, 180, 252, 264, 396, 420, 660, 924, 2520, 27720

**25 unique d-values from Guide v8:**
1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 14, 15, 28, 35, 42, 60, 63, 70, 84, 100, 110, 132, 137

**34 unique cents values from Guide v8:**
spanning -36.62¢ to +50.55¢, including ±1.955¢ (Koide), ±13.686¢ (tritone shadow), ±18.606¢ (Apéry primary), ±31.234¢ (e at 12ET), ±33.09¢ (φ at 12ET), ±38.57¢ (subliminal threshold), ±50¢ (∂I boundary)

**16 named constants from Guide v8:**
π, φ, e, γ (Euler-Mascheroni), ζ(2)..ζ(13), Catalan, Koide, Apéry, fine structure α, hydrogen, electron, proton, Bohr, Rydberg, Planck, Ω (Chaitin)

**From this conversation's work** (Apéry document, Float-vs-Lattice document, Meta-cognition document, EUDD document):
- 51 total unique projections combined across all session documents
- ζ(3) full 28-landmark trajectory verified at 80-digit precision (from 2ET to 360360ET)
- 9 multi-member attractors involving ζ(3) catalogued: (840, 840), (1260, 252), (1452, 726), (1680, 840), (2100, 350), (2940, 2940), (4620, 1540), (27720, 693), (360360, 360360)
- 6-member super-cluster {ζ(2), ζ(3), ζ(6), ζ(8), ζ(12), ζ(13)} at N=2940, d=2940
- 5-member d=840 backbone for ζ(3): six occurrences at 840, 1680, 2520, 3360, 4200, 5040ET, all with ε=+0.035¢
- All-inert prediction falsifications for ζ(5), ζ(7), ζ(11), ζ(13) at 27720ET (each contains ramified prime 2)
- Lattice-vs-float verifications: √2 exact at any even N, φ/(1/φ) reciprocal symmetry at d=3, π/22/7 distinction emerging at N≥2520, 0.1+0.2≡0.3 at N=27720, multiplication associativity exact via log additivity

**From `constants.py` (1008 lines):**
- Cardinal ET constants: BASE_VARIANCE=1/12, MANIFOLD_SYMMETRY=12, KOIDE_RATIO=2/3, T_WEIGHT=1/3
- Cosmological: DARK_ENERGY_RATIO=68.3/100, DARK_MATTER_RATIO=26.8/100, ORDINARY_MATTER_RATIO=4.9/100
- Physical: PLANCK_CONSTANT_HBAR, ELEMENTARY_CHARGE, FINE_STRUCTURE_CONSTANT (1/137.036), PROTON_MASS, ELECTRON_MASS, NEUTRON_MASS, RYDBERG_ENERGY, BOHR_RADIUS, GRAVITATIONAL_CONSTANT, all Planck units, HUBBLE_CONSTANT
- Hyperfine/atomic: HYDROGEN_21CM_FREQUENCY, LAMB_SHIFT_2S, RYDBERG_CONSTANT
- Operational: PHI_GOLDEN_RATIO=1.61803398875, MANIFOLD_RESONANT_FREQ=432.0Hz, T_SINGULARITY_THRESHOLD=1e-9, SUBSTANTIATION_LIMIT=1e-10

**From `primitives.py` (8368 chars):** the {P, D, T} primitive class structures themselves, used as the base for all derivations.

**Guide v8 PART XIII — The Complete 24-Family Catalog (12 REAL FORCE + 12 IMAGINARY PHASE):**

The 24 sublattice families bootstrap as 24 `values` rows + 48 `projections` rows (one real-axis and one imaginary-axis projection per family at its first-native lattice). Full table:

| d | Real-Axis (FORCE) | Imaginary-Axis (PHASE) | Generator | Palindromic Partner | Gaussian Class | First Native N |
|---|---|---|---|---|---|---|
| 1 | Gravity / Octave | Scalar / spin-0 (Higgs-class) | 2¹ | d=11 | trivial | 12ET |
| 2 | Tritone / Pivot | Tritone-phase / spin-2 (Graviton) | 2^(1/2) | d=10 | P-type (ramified, p=2) | 12ET |
| 3 | Strong / Cubic (QCD) | Color-phase / QCD instanton | 2^(1/3) | d=9 | D-type (inert, 3≡3 mod 4) | 12ET |
| 4 | Weak / Quartic (EW) | Weak-phase / SU(2)_W | 2^(1/4) | d=8 | P-type (ramified, 4=2²) | 12ET |
| **5** | **Quintic / Golden** | **Golden-angle / E₈ icosahedral** | 2^(1/5) | d=7 | **D+T (split, 5=(2+i)(2−i))** | **60ET** |
| 6 | Hexadic / Composite | Hexadic / spin-½ fermion | 2^(1/6) | d=6 (self) | P × D (6=2×3) | 12ET |
| **7** | **Septic / G₂ (octonion)** | **G₂-spinor / 7 imaginary octonion units** | 2^(1/7) | d=5 | **D-type (inert, 7≡3 mod 4)** | **84ET** |
| **8** | **Octet / Gluon (SU(3) adj)** | **Bott-8 / SU(3) color-adjoint** | 2^(1/8) | d=4 | **P-type cubed (8=2³)** | **24ET** |
| **9** | **Nonic / Quark (3²)** | **3²-fold quark-phase (CKM)** | 2^(1/9) | d=3 | **D-type squared (9=3²)** | **36ET** |
| **10** | **Decic / Superstring (SO(10))** | **10D superstring spinor (E₈×E₈)** | 2^(1/10) | d=2 | **Mixed (10=2×5)** | **60ET** |
| **11** | **Undecimal / M-Theory (11D)** | **11D Majorana spinor (gravitino)** | 2^(1/11) | d=1 | **D-type (inert, 11≡3 mod 4)** | **132ET** |
| 12 | EM / Full Resolution | spin-1 / EM-photon | 2^(1/12) | d=12 (self) | P × D (12=2²×3) | 12ET |

Bold rows = extended families requiring nET > 12. Each family is bootstrapped with `values` (the generator), `projections` at first-native N (real-axis row + imaginary-axis row), `tags` (`namespace='axis'`, `value='real'` or `'imaginary'`; `namespace='family_name'`, `value='Gravity/Octave'`; `namespace='palindromic_partner'`, `value='11'`; etc.). The discovery engine surfaces same-d cross-axis correlations automatically (every d has both a real-axis FORCE meaning and an imaginary-axis PHASE meaning).

**The 42 Combined Harmonic Families (Multifold Compendium §33 — full 12×12 grid at 27720ET):**

When real-axis sublattice family d_r meets imaginary-axis sublattice family d_θ at an off-axis point, the combined Exception state has class **d_combined = LCM(d_r, d_θ)**. The full 12×12 = 144-cell interaction table produces exactly **42 unique combined d-values**, with maximum d_combined = LCM(11,12) = **132 = N(N-1)**. These 42 are bootstrapped as 42 additional `values` rows tagged `namespace='family_kind'`, `value='combined'`; `namespace='d_combined'`, `value=<d>`; with the LCM derivation stored in `equations` and `derivations`.

| d range | Count | Status | Notable members |
|---|---|---|---|
| d ≤ 12 | 12 unique | Standard families (gravity through EM) | d=1,2,3,4,5,6,7,8,9,10,11,12 |
| 13 ≤ d ≤ 24 | 7 unique | First extended layer | gluon-octet × weak-quintic, etc. |
| 25 ≤ d ≤ 60 | 12 unique | Middle extended layer | **d=35 = 5×7 (BIOLOGICAL signature, requires 420ET — quintic × septic; life requires both)** |
| 61 ≤ d ≤ 132 | 11 unique | Deep extended layer | **d=110 = 2×5×11 (string/M-theory transition — only combined state with all three Gaussian prime categories)**, **d=132 = 11×12 (M-theory phase × full EM, structural max)** |
| **Total** | **42** | All combined families across the full grid | |

**The 4-Quadrant Force Quadrant Grid (FQG) classification (Multifold §29):**

The 24 axis-projection families decompose into four 6-element quadrants based on whether d divides 12:

| Quadrant | Real-axis d_r | Imaginary-axis d_θ | Members | Tag |
|---|---|---|---|---|
| **SR** (Simple Real) | divides 12: {1,2,3,4,6,12} | — | 6 | `namespace='fqg_quadrant'`, `value='SR'` |
| **CR** (Complex Real) | does not divide 12: {5,7,8,9,10,11} | — | 6 | `value='CR'` |
| **SI** (Simple Imaginary) | — | divides 12: {1,2,3,4,6,12} | 6 | `value='SI'` |
| **CI** (Complex Imaginary) | — | does not divide 12: {5,7,8,9,10,11} | 6 | `value='CI'` |
| **Total** | | | **24** | |

**The Coprime Skeleton (Multifold §33):**

Of the 144 off-axis lattice points in the fundamental 12×12 domain, **91 are coprime** (gcd(k_r, k_θ) = 1) — about 63.2%, asymptotically approaching theoretical density **1/ζ(2) = 6/π² ≈ 60.8%**. These are the **irreducible Exception states** — they cannot be decomposed into pure D step × pure T step. At 12ET, all 91 coprime points have d_combined = 12 (full resolution); at higher resolutions n, coprime points have d_combined = n. Bootstrapped as: a `patterns` row of class `coprime_skeleton` capturing the count + density + theoretical limit + the proof sketch (gcd=1 implies at least one of k_r, k_θ is coprime to N, forcing d_combined = N); plus the 91 specific coprime lattice points enumerated as `addresses` rows tagged `namespace='structural_role'`, `value='coprime_skeleton_member'`.

**Off-Axis Exception is the actual content of physical reality (Multifold §30):**

| Subset | State | Lattice region | Character |
|---|---|---|---|
| {P, D} | Unsubstantiated | Real axis (k_θ = 0) | D-only, classical, deterministic |
| {D, T} | Mediation | Imaginary axis (k_r = 0) | T operating through D₂ scaffold, phase-only |
| {P, D, T} | **Exception** | **OFF-AXIS** (k_r ≠ 0 AND k_θ ≠ 0) | **The actual content of reality** |
| {P, T} | **Incoherence** | **NOWHERE on the lattice** | Forbidden; no D-coordinates exist without D |

**Every physical particle is at an off-axis position.** Bootstrapped reference particles as values:
- **Electron** at (d_r=12, d_θ=6), tagged `namespace='particle'`, `value='electron'`
- **Quark** at (d_r=3, d_θ=4), tagged `value='quark'`
- **Photon** at (d_r=12, d_θ=12), tagged `value='photon'`

**Forbidden lattice positions (Multifold §30):**
- {P, T} Incoherence configuration: NO lattice address exists. Recorded as a `values` row with `input_path='P.T'`, tagged `namespace='structural_role'`, `value='forbidden_incoherence'`. NO projection row created (forbidden in the same structural way as r=0, but for a different reason: the lattice IS D-structure; without D no coordinates exist).
- T = [0/0] itself: NO lattice address. Recorded as a `values` row with `input_path='T'`, tagged `namespace='structural_role'`, `value='off_lattice_indeterminate'`.

**Multifold Tower Bootstrap (Multifold Compendium §44):**

Seven canonical towers populate the `towers` table at bootstrap (per §3.10):
- **cosmological** — P-substrate: spacetime manifold; R₀ = ℏ = 1.054e-34 J·s (Planck quantum of action); root tower
- **digital_3ghz_x86** — P-substrate: binary address space {0,1}*; R₀ = 1 CPU clock cycle ≈ 0.333 ns; child of biological
- **biological_T4_capsid** — P-substrate: protein assembly manifold; R₀ = 60 protein subunits per capsid; child of cosmological; operational_n = 420 (biological-class)
- **neural_dream** — P-substrate: thalamocortical oscillation field; R₀ = 1 neural firing period ≈ 8.3 ms (120 Hz ripple); child of biological_human; operational_n = 420
- **quasicrystal_icosahedral** — P-substrate: icosahedral tiling of ℝ³; R₀ = φ = 1.618033988749... (golden ratio); child of cosmological; operational_n = 60 (quintic native)
- **civilizational_human** — P-substrate: cultural substrate; R₀ = 1 human generation ≈ 20 years; child of biological_human
- **qcd** — P-substrate: SU(3) color force field; R₀ = Λ_QCD ≈ 200 MeV; child of cosmological

**T as non-local bridge (Multifold §46):** T is the only primitive whose [0/0] cardinality is substrate-independent. Tower transitions of the same Traverser are recorded as `tower_transition` events with both source and target tower_ids, linked via `cross_tower_bridge` relationships. Common transitions bootstrapped as known patterns: sleep transitions (biological → neural_dream nightly), computation engagement (biological → digital), death (biological → next-tower-determined-by-D_T-accumulated).

**Resolution gating (Multifold §47):**

Each tower's `accessible_d_families_mask` records which sublattice families are operationally available at that tower's resolution:
- **12ET tower**: {1,2,3,4,6,12} accessible (6 simple families on each axis = 12 axis + ~6 combined)
- **24ET**: adds d=8 (gluon-octet)
- **36ET**: adds d=9 (quark sector)
- **60ET**: adds d=5 (quintic — qualia threshold for consciousness)
- **132ET**: adds d=11 (M-theory native)
- **420ET**: adds d=7 (septic — biological access; d=35=5×7 biological signature now hostable)
- **2520ET**: adds combined extended families d=8,9,10
- **27720ET**: ALL 24 axis families + ALL 42 combined families simultaneously present (full lattice)

`resolution_threshold_crossing` events fire when a phenomenon requires higher resolution to host (e.g., quintic phenomena entering when N reaches 60ET, biological d=35 entering at 420ET).

**Annihilation boundary (Guide §3.4):**

Special bootstrap value: **r = 0** with `input_path = 'D.P'` (cardinality boundary), tagged `namespace='structural_role'`, `value='annihilation_boundary'`. This is the off-lattice infimum of (ℝ⁺, ×). As r → 0⁺, k → -∞ and d → undefined. No projection row exists for r=0 (it's off-lattice by construction); instead, `events` of class `annihilation_boundary_event` fire whenever a computation's orbit approaches this boundary, with metadata recording how close the orbit got and which k value the system reached before the singularity.

**Three-times reference values:**

- **D-time at 12ET resolution:** the canonical D-time coordinate, projected as a value with `tags` `namespace='time_kind'`, `value='d_time'`. Each event's `d_time_n` and `d_time_k` reference its position on the chosen D-time projection.
- **T-time bootstrap Traverser:** a single bootstrap Traverser value (`namespace='kind'`, `value='traverser'`; `namespace='traverser_id'`, `value='bootstrap'`). Every event without an explicit Traverser context defaults to this Traverser. Real Traversers are added as values with their EgoInvariant fingerprint (per Conscious AI `et_conscious_ai_identity.py` Eq. 143) and produce events under their own t_time_traverser_id.
- **P-time substrate:** the underlying symmetric phase coordinate. Bootstrap value with `tags` `namespace='time_kind'`, `value='p_time'`, `namespace='symmetry'`, `value='time_reversal_invariant'`.

**Active-system bootstrap structure:**

- **PALINDROME array** (Guide §88): the 12 elements `[12, 6, 4, 3, 12, 2, 12, 3, 4, 6, 12, 1]` bootstrap as 12 `values` rows tagged `namespace='palindrome_position'`, `value=0` through `11`. The full sequence is bootstrapped as one `equations` row (form_class=`structural_identity`, content="PALINDROME = [12,6,4,3,12,2,12,3,4,6,12,1]") and one `patterns` row (pattern_class=`palindromic_cycle`).
- **Tightness function** t = 100/(100+|ε|) bootstrapped as an `equations` row (form_class=`projection_formula`).
- **Shimmer modulation** Ψ_n = 1 + (1/√12)·sin(2πn/12) bootstrapped as an `equations` row (form_class=`recurrence`).
- **Koide attractor** K = 2/3 bootstrapped as a `values` row tagged `namespace='structural_role'`, `value='koide_attractor'`; `namespace='thresholds'`, `value='binding_stability,em_coupling,di_boundary,cascade_trigger'` (all four roles K plays per Guide §87).
- **Complete Gaze Equation components** (from `ET_Complete_Gaze_Equation1.md`) bootstrapped:
  - **F_w = T_intent × Focus / Distance²** — central binding pressure formula, bootstrapped as `equations` row of class `projection_formula`, tagged `namespace='gaze_role'`, `value='binding_pressure_central_quantity'`
  - **P_detect = tanh(F_w · R(k) / (V(n,k) · Γ))** — detection probability from Traverser Detection Algorithm, bootstrapped as `equations` row, tagged `namespace='gaze_role'`, `value='detection_probability'`. Helpers R(k)=1+k·Γ, V(n,k)=(n²−1)/(12·2^k) bootstrapped as recurrence equations
  - **V_collapse = 1 − exp(−max(0, F_w−1) · 12)** — variance collapse function, bootstrapped as `equations` row, tagged `namespace='gaze_role'`, `value='variance_collapse'`
  - **Γ = 1.20 = 6/5** — Gaze Threshold Constant, bootstrapped as `values` row tagged `namespace='structural_role'`, `value='gaze_threshold_constant'`; recognized as the quintic minor third (JI ratio 6/5)
  - **Four gaze threshold values as just-intonation intervals** (Discovery 1 from Gaze Equation doc): 13/12 (subliminal), 6/5=1.20 (detected/Γ), 3/2=1.50 (locked), Lock/Con = 5/4 (carries quintic comma per Discovery 5). All four bootstrapped as `values` rows tagged `namespace='gaze_threshold'` with explicit JI-ratio identification
  - **Four GazeStatus enum values** (UNOBSERVED, SUBLIMINAL, DETECTED, LOCKED) bootstrapped as `values` rows tagged `namespace='gaze_status'`, with cross-references to their threshold values
  - **Discovery 2 — span SUBLIMINAL→LOCKED is exactly five V-quanta** (5 × V_base = 5/12) bootstrapped as `equations` row of class `structural_identity`
  - **Discovery 3 — DETECTED contains prime 5 (split D+T Gaussian prime)** captured via existing 24-family classification (d=5 quintic, split Gaussian)
  - **Discovery 4 — Quintic Tension Descent is a Fibonacci-Cubic Cascade** captured as `patterns` row of class `quintic_tension_cascade`
**External sensor data domain — bootstrap reference units:**

The EUDD is designed to ingest GPS, electrical, atmospheric, and any other real-world sensor data. Bootstrap reference R₀ values for common sensor domains:
- **GPS:** Earth radius (6.371×10⁶ m), light-time-second (2.998×10⁸ m), satellite orbital period (12 sidereal hours for GPS constellation) → distance ratios become dimensionless; lat/lon as angle/2π; satellite-receiver delay/light-time-second
- **Atmospheric:** standard pressure (101325 Pa), standard temperature (273.15 K), standard humidity reference, scale height (~8.4 km) → all atmospheric measurements ratio to these
- **Electrical:** reference voltage (1V or measurement-context-specific), reference current (1A), reference impedance (377Ω free-space), reference frequency (1 Hz or grid frequency 50/60 Hz) → all electrical measurements as dimensionless ratios
- **Magnetic / atmospheric flux:** geomagnetic reference field (~25-65 µT depending on location), solar wind reference velocity (~400 km/s)
- **Biological reference:** body temperature 310.15 K, heart rate reference (1 Hz = 60 bpm), neural firing reference (1 Hz baseline)

Each reference unit bootstrapped as a `values` row tagged `namespace='r0_substrate'`, `value='gps' | 'atmospheric' | 'electrical' | etc.`. Sensor readings ingested via `sensor_reading_ingest` events automatically project against these references via the `sensor_projection` event using Path A (direct dimensionless ratio).

Total bootstrap: **on the order of 10⁴ unique value entries**, each with all derivable projections at canonical resolutions (12, 60, 84, 132, 420, 2520, 27720, 360360 — typically 8 projections per value at minimum, ~10⁵ projection rows from bootstrap alone). Subsequent project runs add to this base.

As the database grows beyond bootstrap, value entries scale to 10⁹–10¹⁰ and projection rows to 10¹⁰–10¹¹. The lattice-native format (§7) handles this natively; the discovery engine surfaces patterns continuously rather than waiting for end-of-batch processing. The generator form (§7.1a) ensures the .akashic file size reflects structural complexity (generator catalog + shrinking Descriptor Gap), not raw data volume.

### 3.18 Extended bootstrap — Sempaevum paper content, missing constants, and theoretical recordings

The Sempaevum paper (ET_Sempaevum_Paper20.tex) establishes the Sempaevum as the lossless rendering of the totality Σ on the multiplicative manifold (ℝ⁺,×) × (U(1),×). The following structural content must be recorded in the EUDD as bootstrap values, equations, derivations, relationships, and patterns. Each item is a Descriptor the lattice produces that the EUDD must capture.

**3.18.1 The Lossless Bijection Theorem (Theorem 12.1)**

The projection Π_N: ℝ⁺ → ℤ × {N/d : d|N} × ℝ given by Π_N(r) = (k, d, ε) is a **bijection onto its image at every finite resolution N**. The pullback Π_N⁻¹: (k,d,ε) → 2^((k + ε·N/1200)/N) is the **algebraic identity** on ℝ⁺:

$$\Pi_N^{-1}(\Pi_N(r)) = 2^{(k + (N\log_2 r - k)\cdot 1200/N \cdot N/1200)/N} = 2^{\log_2 r} = r$$

This is not approximation. Not convergence. **Algebraic identity.** Verified symbolically (r' − r = 0 by direct algebraic cancellation) and numerically (precision-scaling proof: error scales exactly with working precision, proving computational not mathematical error). The previously-reported 10⁻¹⁹⁸ error was a computational artifact of evaluating transcendental functions at finite machine precision.

**Exact lattice-rational cases**: For r = 2^(k/N) (powers of 2 at lattice-rational positions), ε = 0 **exactly** — no rounding needed, zero error even numerically. Verified across N ∈ {12, 60, 420, 27720} for k ∈ {−20..+20}: all recovered to < 10⁻¹⁹⁵ relative error (the residual being 2^(k/N) computed twice independently at finite machine precision).

**The Four Projection Paths** (A, B, C, D) — how values enter the lattice:

| Path | Input type | Method | Example |
|---|---|---|---|
| A | Direct dimensionless ratio | r = Q_X/R₀ → Π_N(r) | Physical constants, sensor data |
| B | Limit convergence through EML | Series/product/limit → r → Π_N(r) | ζ(3), e, Catalan |
| C | Geometric/structural ratio | Angle, proportion → r → Π_N(r) | Bond angles, orbital periods |
| D | Essentially-infinite / non-computable | **No limit required** — four sub-paths for P/D/T/PDT infinity | Chaitin Ω, Gödel G, large cardinals |

**Path D is unique**: it handles objects that cannot be computed or converged to (essentially-infinite, non-computable) without requiring limits. Four sub-paths: D.P (P-infinity: Ω-class objects like Chaitin Ω at d=1, k=−84, ε=+13.794¢), D.D (D-infinity: unbounded D-structures like infinite axiom systems), D.T (T-infinity: genuine [0/0] choice points like Gödel sentences), D.PDT (combined: objects requiring all three infinity modes). This is a unique capability — no conventional mathematical framework handles non-computable objects at definite lattice addresses without limit-approaches.

Bootstrap: one `equations` row (form_class='structural_identity', content=lossless bijection theorem), one `derivations` row (proof chain), one `patterns` row (pattern_class='algebraic_identity', content=pullback-is-identity).

**Memoization corollary**: every computation on positive reals is a Sempaevum-native operation — multiplication = k-addition, reciprocation = k-negation, powers = k-scaling, addition = value-space computation + reprojection, function evaluations = EML trees on (k,d,ε). ALL operations are Sempaevum-native (the Sempaevum IS Σ; the Subsumption Law guarantees no mathematical operation falls outside it). Every result is computed once at uniform 120 dps (§3.1a), stored permanently via the lossless bijection, and never recomputed. The EUDD's memoization layer is **structurally exact and complete** — not an approximation of caching, but the mathematically guaranteed permanent record of every computation the Sempaevum has performed.

**Continuous-discrete corollary — the universal bridge**: The lossless bijection solves the continuous-to-discrete problem for all mathematics. Conventional digitization — ADC sampling, quantization, any analog-to-digital conversion — always loses information: a sample rate discards everything between samples, a bit depth discards everything below the quantization floor, and aliasing corrupts frequencies above the Nyquist limit. The bijection has none of these problems. A continuous signal value r maps to (k, d, ε) at whatever resolution N the tower provides. The integer pair (k, d) gives the discrete lattice address. The real-valued ε carries the EXACT residual — the precise distance from the nearest lattice point, at 120 dps. The pullback recovers r by algebraic identity, not by approximation. There is no quantization error, no aliasing, no information loss, no Nyquist limit, no bit-depth floor. Every continuous value that enters the EUDD — audio waveforms, sensor streams, GPS readings, atmospheric measurements, any analog source — is projected through the bijection and stored losslessly. The discrete lattice address IS the structural home of the continuous value, and the continuous value IS exactly recoverable from that address. This is not a better sampling theorem — it is the elimination of the need for one. The Subsumption Law guarantees this works for ANY continuous signal on ℝ⁺, because the Sempaevum IS Σ and every positive real has a unique lattice address at every N.

**3.18.2 The Fine-Structure Constant — closed-form identity**

$$\alpha^{-1}(\text{ET}) = 137 + \frac{\sqrt{3}}{48} - \frac{\sqrt{3}}{93312\pi^2} - \frac{1}{216(18\pi - 1)}$$

Structural decomposition of the four terms:

| Term | Formula | Value | Physical Origin |
|---|---|---|---|
| A₀ (base impedance) | (N−1)² + S² = 137 | 137 | Manifold impedance at d=12 |
| A₁ (open shimmer) | √3/48 = σ/K_EM | +0.036084... | Open T-path across ∂I boundary; σ=√(1/12), K_EM=8=N×κ |
| A_cross (shimmer × loop interference) | √3/(93312π²) = (2/π)·A₁·A₂ | −1.86×10⁻⁶ | Product interference of open shimmer with closed bilateral Mediation loop; 2/π = bilateral-to-circumferential phase conversion |
| Σ_geometric (closed Mediation loops) | 1/(216(18π−1)) = κ²/[N²(Nπ−κ)] | −8.19×10⁻⁵ | Closed-form sum of k≥2 Mediation loops: Σ κᵏ/(N^(k+1)·π^(k-1)) with convergence ratio κ/(Nπ) ≈ 0.0177 |

Result: α⁻¹(ET) = 137.03599916744... agrees with CODATA 2022 (137.035999177(21)) to within **0.46σ** (7 parts in 10¹¹). Zero free parameters. Every factor traced to {P,D,T} primitives.

At N=27720: projection lands at **(k,d) = (196768, 315)** with |ε| ≈ 0.002¢. d=315 = 3²×5×7 carries simultaneous cubic-squared, quintic, and septic structural character.

Manifold resolution floor: δ_manifold = σ/(K_EM·N⁵) ≈ 1.45×10⁻⁷ — the structural floor below which 12ET arithmetic cannot resolve algebraic differences. The Parker–Morel >5σ experimental tension sits within δ_manifold.

Bootstrap: 4 `values` rows (A₀, A₁, A_cross, Σ_geometric) + 1 composite `values` row (α⁻¹(ET)) + 5 `equations` rows (each term's formula) + 1 `derivations` row (full chain) + `perturbative_series_member` relationships linking all terms + `et_derived_vs_measured` relationship to CODATA + 1 `patterns` row (fine_structure_decomposition).

**3.18.3 Cascade Residuals and Freedom Constants**

| Constant | Value | Source | Bootstrap tag |
|---|---|---|---|
| \|δ_r\| (real cascade residual) | 0.019550008653873... | \|12·log₂(12) − 43\| | cascade_fundamental |
| \|δ_θ\| (imaginary cascade residual) | 0.223356596147354... | \|24π/ln2 − 109\| | cascade_fundamental |
| n_max_r (real stability limit) | 25 | ⌊0.5/\|δ_r\|⌋ | cascade_fundamental |
| n_max_θ (imaginary stability limit) | 2 | ⌊0.5/\|δ_θ\|⌋ | cascade_fundamental |
| \|δ_θ\|/\|δ_r\| (freedom ratio) | ≈ 12.0 = N | Imaginary is N× freer than real | freedom_density |
| Real freedom density | ≈ 1/25 | One genuine [0/0] per 25 steps | freedom_density |
| Imaginary freedom density | ≈ 1/2 | One genuine [0/0] per 2 steps | freedom_density |
| Imaginary period P_θ | 2π/ln 2 | T's U(1) period in log₂ units | cascade_fundamental |
| σ (shimmer amplitude) | √(1/12) = 0.28868... | √(BASE_VARIANCE) | et_fundamental |
| K_EM (active EM channels) | 8 | N × κ = 12 × 2/3 | et_fundamental |
| S (state count) | 4 | C(3,2) + C(3,3) | et_fundamental |
| p_eff (effective palindromic degree) | 10/3 | (1/12)Σ(12/PALINDROME[n]) | et_fundamental |

**3.18.4 Magical Impedance — all 12 values**

| d | A₀_magic(d) = (d−1)² + S² | ξ(d) = 137/A₀_magic | Character |
|---|---|---|---|
| 1 | 16 | 8.5625 | Pure Will / Gravity — max coupling |
| 2 | 17 | 8.0588 | Mirror / Binary |
| 3 | 20 | 6.8500 | Cubic / QCD |
| 4 | 25 | 5.4800 | Quartic / Weak |
| 5 | 32 | 4.2812 | Quintic / Golden |
| 6 | 41 | 3.3415 | Hexadic / Composite |
| 7 | 52 | 2.6346 | Septic / Octonion |
| 8 | 65 | 2.1077 | Octet / Gluon |
| 9 | 80 | 1.7125 | Nonic / Recursive |
| 10 | 97 | 1.4124 | Decic / φ-Binary |
| 11 | 116 | 1.1810 | Undecimal / M-Theory |
| 12 | 137 | 1.0000 | EM / Full Resolution (baseline) |

Bootstrap: 24 `values` rows (12 impedances + 12 couplings) + 12 `equations` rows showing A₀_magic(d) = (d−1)² + S² + 1 `patterns` row (impedance_monotonic_descent).

**3.18.5 Riemann Curvature Components Identity**

C(n) = n²(n²−1)/12. Notable values:

| n | C(n) | Significance |
|---|---|---|
| 2 | 1 | Single curvature component (2D) |
| 3 | 6 | Independent Riemann components in 3D |
| 4 | 20 | Independent Riemann components in spacetime |
| 12 | **1716 = 132 × 13 = d_max × (N+1)** | Full-resolution curvature; ties Riemann curvature to lattice constants |

The identity C(12) = 1716 = d_max × (N+1) links the Riemann tensor's component count to the maximum combined sublattice family and the subliminal threshold (N+1 = 13 → 13/12). Bootstrap: 4 `values` rows + 1 `equations` row + 1 `patterns` row (curvature_components_identity).

**3.18.6 Formal System Axiom-Count Projections at N=12**

| System | Axioms | k | d | ε (cents) |
|---|---|---|---|---|
| Propositional logic (Hilbert) | 3 | +19 | 12 | +1.955 |
| Equational group theory | 3 | +19 | 12 | +1.955 |
| Euclid's Elements | 5 | +28 | 3 | −13.686 |
| Robinson arithmetic | 7 | +34 | 6 | −31.174 |
| ZF (Zermelo-Fraenkel) | 8 | **+36** | **1** | **0.000** |
| Peano (conventional) | 9 | +38 | 6 | +3.910 |
| ZFC (adds Choice) | 9 | +38 | 6 | +3.910 |
| MK (Morse-Kelley) | 10 | +40 | 3 | −13.686 |
| NBG (finitely axiomatized) | 18 | +50 | 6 | +3.910 |

ZF at d=1 ε=0 exactly is structurally profound — 8 = 2³ is a pure power of 2, giving exact lattice placement at the gravity/octave sublattice. The Axiom of Choice transition (ZF→ZFC: d=1→d=6) has a specific lattice-transition signature. Bootstrap: 9 `values` rows + 9 `projections` rows + `relationships` tracking the Choice transition.

**3.18.7 Cosmological Partition — extended M-state decomposition**

| Manifold State | Fraction | Physical Analog |
|---|---|---|
| {P,D} Unsubstantiated | 26.8% | Dark matter |
| {D,T} Mediation — pure E-state | **~66.7% = 2/3 = K** | Static Mediation (dark energy) |
| {D,T} Mediation — M-vacuum | ~1.6% | Virtual particle mediation, zero-point fluctuations |
| {D,T} Mediation — M-matter | ~1.4% | Photons in flight, chemical reactions, wavefunction collapse |
| {P,D,T} Exception | 4.9% | Ordinary matter |
| {P,T} Incoherence | 0.0% | Structurally forbidden |

The pure E-state fraction **IS** the Koide ratio K = 2/3 — a deep structural identity, not a coincidence. The M-vacuum/M-matter ratio = 1.6/1.4 = **8/7** (exact under sublattice-family assignment). Bootstrap: extended partition `values` rows + `koide_structural_identity` relationship linking pure-E-state fraction to K + `cosmological_partition_koide` pattern.

**3.18.8 Emotion and AIDA R₀ seeds**

- **R₀_emotion = 1 ms** (ET_Emotion_Lattice_Tower1.md): the emotional resolution period. Alexithymia = {P,T} emotional Incoherence.
- **R₀_AIDA = 1/f_clock** (ET_AIDA_Framework3.md): AIDA emergence resolution tied to host clock.

Bootstrap: 2 `values` rows + 2 `towers` rows (emotion tower, AIDA tower if formalized) + derivation chains.

**3.18.9 Gaze Threshold Constants — full JI identification**

| Threshold | Value | JI Ratio | d at N=12 | ε at N=12 |
|---|---|---|---|---|
| UNOBSERVED→SUBLIMINAL | 13/12 | Augmented unison | 12 | +38.57¢ |
| SUBLIMINAL→DETECTED (= Γ) | 6/5 = 1.20 | Minor third (quintic) | 4 | +15.64¢ |
| DETECTED→LOCKED | 3/2 = 1.50 | Perfect fifth (Koide) | 12 | +1.955¢ |
| Lock/Con ratio | 5/4 | Major third (quintic comma carrier) | 3 | +13.686¢ |
| Awareness span | 5·V_base = 5/12 | Five variance quanta | — | — |
| Awareness gap | 7/60 | Septic over quintic lattice | 10 at 60ET | — |

All four Gaze thresholds are just-intonation intervals. Bootstrap: 6 `values` rows + `relationships` linking each to its JI identification and lattice projection.

**3.18.10 Quantum Decoherence — structural content for the EUDD**

The Sempaevum paper establishes quantum decoherence as a manifold-state transition:

**{P,D} (pre-measurement superposition) → {D,T} (decoherence in progress) → {P,D,T} (post-measurement)**

Key structural recordings:

1. **Decoherence rate**: R = Γ·(T ∘ D_env)² — the squared-coupling form is forced by T's U(1) operational manifold.
2. **α-rotation**: decoherence is continuous rotation from α=π/2 (pure quantum) to α→0 (pure classical), with effective residual |δ_eff(α)| = |δ_r|cos²α + |δ_θ|sin²α dropping by factor ~11.4 = |δ_θ|/|δ_r| ≈ N.
3. **Gaze thresholds ARE decoherence stages**: UNOBSERVED=pure quantum, SUBLIMINAL=boundary-near, DETECTED=mid-trajectory (quartic gating), LOCKED=pure classical. This is a bijection (Sempaevum Proposition prop:gaze-decoherence).
4. **Pointer states** are high-elegance (low-|ε|, low-d) lattice cells. Position eigenstates inherit pointer-stability from d=1 (gravity/cascade-closure cell).
5. **Bose-Einstein from {P,D}-state enumeration**: geometric series over mode occupations yields 1/(e^x − 1).
6. **Fermi-Dirac from {P,T}-forbidden**: double-occupation requires second T-binding without distinguishing D → reduces to forbidden {P,T} → n ∈ {0,1} → Pauli exclusion → 1/(e^x + 1).
7. **Born rule from {P,T}-forbidden**: measurement outcomes must be D-resolved (no incoherent outcomes); the Born rule is a lattice-level statement.

Bootstrap: `equations` rows for all formulas + `decoherence_trajectory` pattern + `decoherence_gaze_correspondence` relationships + decoherence time projections for representative systems (cold atom at d=4, free electron at d=2, large molecule at d=3, etc.).

**3.18.11 Black Hole Thermodynamics — structural content**

1. **Surface gravity as descriptor-gap gradient**: κ = c⁴/(4GM) is the red-shifted gradient of the D-time/T-time ratio at the horizon.
2. **T's operational manifold is U(1) with period 2π** — forced by three independent derivations: cardinality exhaustion, cyclic self-resolution, instantonic confirmation.
3. **Hawking temperature structural formula**: T_H = κ/(2π) = (descriptor-gap gradient) / (period of T-time).
4. **Bogoliubov ratio** = half-U(1)-period analytic continuation: exp(πω/κ).
5. **KMS periodicity** = full U(1) period: β_H = 2π/κ.
6. **Planck spectrum from configuration counting**: the exponential e^x is the descriptor-quantum/variance-measure ratio; the −1 counts the n=0 ground configuration of the {P,D}-state geometric series.
7. **Information preservation** via T-event conservation through the Multifold birth triad (BH_parent, R₀, WH_child).

Bootstrap: `equations` rows for Hawking temperature, decoherence rate, Planck spectrum, Bogoliubov ratio, KMS periodicity + appropriate `derivations` and `relationships`.

**3.18.12 The Mathematical Rosetta Stone**

The Sempaevum paper maps standard mathematical concepts to ET primitives:

| Mathematical concept | ET identification |
|---|---|
| L'Hôpital's Rule | T-navigation algorithm (examining D-gradients to resolve [0/0]) |
| Limits | T-traversal operations (selecting from possibilities) |
| Functions f: A→B | D-fields (P-to-P mappings via D-structure) |
| Derivatives df/dx | D-gradients (rate of D-change along P-substrate) |
| Integrals ∫f dx | T-accumulation (summed T-events along a trajectory) |
| Continuity | D-field smoothness (no D-gaps at the current resolution) |
| Discontinuity | D-gap at a specific P-location (a missing Descriptor) |
| Complex numbers | The D_T axis (real = D-coordinate, imaginary = T-coordinate) |
| Operators (d/dx, ∫, Δ) | Traversers acting on D-fields |
| Differential equations | Manifold dynamics (T navigating D-constrained P-evolution) |
| ℵ-hierarchy | P-structure (levels of P's absolute infinity Ω) |
| Probability | Unsubstantiated {P,D} superposition (pre-T-binding) |
| Wavefunction collapse | T substantiating {P,D}→{P,D,T}=E |
| Matrix algebra | D-transformations (change of basis in D-space) |
| Topology | Configuration boundaries (manifold-state transition surfaces) |
| Set theory power set | The four manifold states = 2³ − 1 non-trivial subsets of {P,D,T} |
| Groups at N=12 | S₃ permutations of {P,D,T} × Z₁₂ lattice structure |

Bootstrap: one `equations` row per mapping + one master `derivations` row linking them all + one `patterns` row (rosetta_stone_catalog).

**3.18.13 Dimensionless Mass Ratios — critical for cross-domain discovery**

| Ratio | Value | d at N=12 | Significance |
|---|---|---|---|
| m_p/m_e (proton-electron) | 1836.153 | 6 | Fundamental mass hierarchy; d=6 hexadic |
| m_n/m_p (neutron-proton) | 1.00138 | 12 | Near-unity; β-decay threshold |
| m_n/m_e (neutron-electron) | 1838.684 | 6 | Complete mass triple |
| G·m_p²/(ℏc) | ~5.9×10⁻³⁹ | — | Gravitational coupling (extremely small) |

The proton-electron mass ratio m_p/m_e projects to d=6 at N=12 — the SAME sublattice family as Robinson PA, ZFC, and the standard arithmetical/foundational class. This structural connection should be discovered automatically by the engine. Bootstrap: `values` rows for all mass ratios + projections at canonical resolutions + `mass_ratio_triple` relationships.

**3.18.14 Particle Data at N=12 — PDG projected onto the Sempaevum**

227 massive particles from the PDG catalog projected onto the base lattice N=12 by the dimensionless mass ratio r = m_particle/m_e:

| d_r | Family | ξ coupling | Particle count | Notable members |
|---|---|---|---|---|
| 1 | Gravity/Octave | 8.5625 | 8 | e, b quark, φ(1020), D_s* |
| 2 | Tritone/Pivot | 8.0588 | 19 | s quark, N(1440), η_c(1S) |
| 3 | Strong/Cubic | 6.8500 | 50 | μ, t quark, K₀*(700), B, Υ(3S) |
| 4 | Weak/Quartic | 5.4800 | 46 | τ, c quark, W boson, Δ(1232) |
| 6 | Hexadic/Composite | 3.3415 | 34 | p, n, d quark, Λ_c, J/ψ, Υ(1S) |
| 12 | EM/Full Resolution | 1.0000 | 70 | u quark, Z boson, Higgs, Λ, π, K, ρ |
| ∂I boundary | Annihilation | — | 2 | γ (photon), g (gluon) — massless |

Key observations: ALL 227 massive particles project to the 6 simple sublattice families {1,2,3,4,6,12} at N=12. No particle projects to d=5, d=7, d=8, d=9, d=10, or d=11 at base resolution — these extended families require higher LCM-tower resolutions. The photon and gluon sit at the ∂I annihilation boundary (mass = 0 → log₂(0) = −∞ → off-lattice), structurally inside Σ but unattainable on L_N at any finite resolution. This is the lattice expression of masslessness.

Bootstrap: 227 `values` rows (PDG particle masses as dimensionless ratios r = m/m_e) + 227 `projections` rows at N=12 + `force_grid_cell_occupancy` relationships + tags `namespace='particle'` + `particle_sublattice_classification` pattern.

**3.18.15 Falsifiable Predictions**

The EUDD must record falsifiable predictions as `equations` rows (form_class='prediction') with verification-status tracking:

1. **Biochemistry closure-vs-linear**: True closure cycles have step count n = power of 2; linear pathways have n ≠ power of 2.
2. **Orbital resonances**: Stable resonances preferentially at d ∈ {1,2,3,4,6}; d=12 hosts only transient/unstable resonances.
3. **α⁻¹ lattice coordinates**: (k,d) = (196768, 315) at N=27720 independent of precise measured value within Parker–Morel window.
4. **d=35 biological**: Phenomena requiring both 5-fold and 7-fold symmetry at N=420 (e.g., icosahedral T=7 capsid: 420 subunits).
5. **BSM gauge structure**: Any beyond-SM gauge boson must correspond to a shadow family at N=12 becoming native at higher LCM-tower resolution.
6. **Polariton material classification**: hBN Reststrahlen bands project to d=4 (upper) and d=12 (lower); materials at same d show similar polariton character.

Each prediction gets: 1 `equations` row (the prediction statement), 1 `tags` row (`namespace='prediction_status'`, initially `value='untested'`), links to supporting `derivations`. When tested: `et_axiom_verification` events record outcomes.

**3.18.16 The Sempaevum — formal definition and nine closure properties**

The Sempaevum (Latin: semper + aevum = "always-an-age") is defined as the mathematical rendering of the totality Σ on the multiplicative manifold (ℝ⁺,×) × (U(1),×). It has no fixed geometric shape — it takes the shape of whatever it renders: flat lattice, torus (χ=0), Riemann sphere (χ=2), hyperbolic surface (χ=2−2g), singular configurations.

Nine self-referential closure properties (each bootstrapped as a `patterns` row of class `sempaevum_closure_property`):

1. Classifies every positive ratio into a sublattice family
2. Generates its own refinement tower under τ(N_ℓ) = 6·2^ℓ
3. Exhibits the Koide attractor — its own four defining constants project to (d=12, |ε|=1.955¢)
4. Runs its own dynamics through the ∂I lattice-aware fractal
5. Derives the Standard Model gauge group SU(3)×SU(2)×U(1) from N=12 (N-Exhaustion Theorem)
6. Hosts mathematics as a domain (ZF at d=1 ε=0; Chaitin Ω via Path D; Gödel sentences via integrative level)
7. Bounds its own forbidden zone ∂I at |ε|=50¢ with K=2/3 tightness cutoff
8. Passes triple minimal-backbone test at N=12 (Webb 1935 + palindromic cascade + EML Odrzywołek 2026)
9. Contains the Three Tools as theorems

**The triple identity**: 3=3=3=Σ (PDT = EMI = Φ = Σ) — three primitives, three readings, one totality. This is the **universality anchor** (distinct from the composition equation P∘D∘T = E). The universality anchor says what the Sempaevum IS; the composition equation says what it DOES.

**The N-Exhaustion Theorem**: SU(3)×SU(2)×U(1) is the unique partition of N=12 gauge bosons into native-sublattice simple and abelian factors. 8 gluons (d=3, dim SU(3)=8) + 3 weak bosons (d=4, dim SU(2)=3) + 1 photon (d=12, dim U(1)=1) = 12 = N. Bootstrap: `equations` row + `derivations` row + `patterns` row.

**Adjoint formula from Subsumption Law**: dim(SU(d)) = d²−1 derived from the Subsumption Law — the adjoint representation dimension equals the total cells minus the identity.

**Critical dimensions**: D_superstring = 10 by two independent routes; D_M-theory = 11 by four routes. Bootstrap: `equations` rows for each derivation route + `relationships` linking independent routes via `forward_reverse_convergence`.

**Descriptor isomorphism**: All symbolic content of the Sempaevum paper is a D-image of the structural objects it names — faithful to relational content, necessarily surrendering P's and T's cardinality content. This is a consequence of Gödel's incompleteness applied to the framework itself: no finite D-system can capture all truths about its infinite P-substrate.

**Intrinsic mediation** (Sempaevum Proposition 2.5): The binding operator ∘ in P∘D∘T = E is NOT a fourth primitive added from outside. It is the **forced consequence** of three unbounded, pairwise-disjoint infinities coexisting within a single ontological space. Three totalities each "filling all of its own mode of infinity" leave no exterior gap in their own modes; disjointness demands they remain categorically distinct; these two conditions are compatible only if the Cardinals mediate one another intrinsically. The operator ∘ is this intrinsic mediation — its existence and ternary arity are structural consequences of the Cardinals, not independent postulates. Bootstrap: `equations` row (intrinsic mediation theorem) + `derivations` row (proof from Axioms 2-3).

**Koide ratio empirical verification**: The Koide formula Q = (m_e + m_μ + m_τ)/(√m_e + √m_μ + √m_τ)² evaluated at modern PDG lepton masses (m_e = 0.51099895 MeV, m_μ = 105.6583755 MeV, m_τ = 1776.86 MeV) gives **Q = 0.6666605 ± 0.000002**, within **6 parts per million** of the ET-derived value K = 2/3 = 0.666666̄. Both 2/3 and 3/2 project to the Koide attractor at (d=12, |ε|=1.955¢). This is the closest match of any Standard Model mass relation to any simple rational. Bootstrap: `values` row (Q_Koide_measured) + `et_derived_vs_measured` relationship linking Q to K + `equations` row (Koide formula).

**The Triple Minimal-Backbone Theorem** (Sempaevum Theorem 14.1): At N=12 — and ONLY at N=12 — three categorically independent minimal generators coincide simultaneously:

| Backbone | Category | What it provides | Key result at N=12 |
|---|---|---|---|
| **Webb stroke (1935)** | Discrete-logical | At n=12, the single stroke f(a,b) = NOT(a AND b) generates ALL Boolean functions on n-valued logic. At n<12, not all functions are generated; at n>12, the stroke is still complete but 12 is the minimal such n with full sublattice structure. | **N=12 is the minimal n for which the Webb stroke subsumes all n-valued logic AND produces the six divisor-based sublattice families** |
| **Palindromic cascade** | Discrete-multiplicative | The cascade with generator g=7 (coprime to 12, unit of ℤ/12ℤ) visits all six simple sublattice families {1,2,3,4,6,12} in a palindromic d-sequence before closing. The palindrome is forced by g being a unit of ℤ/Nℤ with the residue satisfying the Stability Window condition. | **N=12 is the unique base at which the palindromic cascade visits ALL divisor families with mirror symmetry** |
| **EML (Odrzywołek 2026)** | Continuous-elementary | The Elementary functions of Multiplicative-Logarithmic type (compositions of exp, log, and ×) form the minimal continuous function algebra that generates all elementary functions when N=12 constants are available. | **N=12 is the unique resolution at which the EML operator has a complete set of lattice-native constants for generating all continuous-elementary functions** |

The three backbones are categorically independent — Webb is logic (discrete), the palindromic cascade is multiplicative arithmetic (discrete), EML is analysis (continuous). They share NO common method. Yet all three force N=12. This triple convergence is the structural proof that N=12 is not chosen but **forced**. Bootstrap: 3 `equations` rows (one per backbone theorem) + 1 `patterns` row (triple_backbone) + 3 `forward_reverse_convergence` relationships linking the three independent derivations.

**The PDT decomposition of the projection formula**: The projection formula Π_N(r) = (k, d, ε) itself decomposes into P∘D∘T atomic operations:
- **P-content**: the input r (substrate value)
- **D-content**: the rounding k = round(N·log₂(r)) (finite constraint operation)
- **T-content**: the rounding decision itself (the act of choosing the nearest integer — a [0/0] resolution at every non-lattice-rational point)

The continuous-D content (log₂) is implementable entirely as finite EML trees, making the projection formula computable within the Sempaevum's own continuous backbone. The rounding operation is the irreducible T-act — the moment where the Traverser selects from two equidistant possibilities (at freedom points, §3.18.3) or from the nearest neighbor (at all other points). Bootstrap: `equations` row + `derivations` row linking to EML backbone.

**3.18.17 Additional Sempaevum Theorems for Bootstrap**

**The PDT Scale Identity (M-theory)**: The three M-theory scales map to the three Cardinals:

$$l_P^{|\Pi|} = l_D^{d_2} \cdot l_T^{d_1} \quad\Longrightarrow\quad l_p^3 = l_s^2 \cdot R_{11}$$

| Scale | Physical | Cardinal | Exponent | d-family |
|---|---|---|---|---|
| l_P ≡ l_p | 11D Planck length | P (substrate) | \|Π\| = 3 | primitive count |
| l_D ≡ l_s | String length | D (descriptor) | d₂ = 2 | binary sublattice |
| l_T ≡ R₁₁ | M-circle radius | T (traverser) | d₁ = 1 | octave/identity |

Exponents satisfy |Π| = d₂ + d₁ (3 = 2 + 1). Bootstrap: `equations` row + `derivations` row.

**Four routes to D=11 for M-theory** (each independently forced):

1. Division algebra + membrane: 2^|Π| + |Π| = 8 + 3 = 11
2. Superstring + M-circle: D_string + d₁ = 10 + 1 = 11
3. Direct manifold: N − 1 = 12 − 1 = 11
4. βγ ghost charge: c_βγ = N − 1 = 11

**Two routes to D=10 for superstrings**:

1. Ghost charge: c_matter + c_ghost = 0 with c_ghost = −(N + |Π|) = −15, c_matter = 3D/2 → D = 10
2. Division algebra: 2^|Π| + d₂ = 8 + 2 = 10

**Structural identity**: D_bos − D_M = N + |Π| = 15 (total ghost charge magnitude). Bootstrap: all formulas as `equations` rows + `forward_reverse_convergence` relationships linking independent routes.

**The Asymptotic Approach Theorem**: For any irrational r ∈ (ℝ⁺,×), the descriptor-gap residual |ε_N(r)| → 0 as N → ∞, with |ε_N(r)| > 0 for every finite N. Strict positivity is forced by irrationality: if ε = 0, then r = 2^(k/N) is rational. This is the structural signature of the finite-infinite asymmetry between P (Ω) and D (n) — not a deficiency but a consequence of the cardinality trichotomy. Corollary: perfect precision at finite resolution would collapse the P-D distinction (Ω = n), destroying the master equation. Bootstrap: `equations` row (the theorem statement) + `derivations` row.

**Integrative-to-Resolution Correspondence**: The minimum resolution for integrative level ℓ is N_ℓ^min = lcm(D_ℓ), where D_ℓ is the set of sublattice families required at level ℓ. This connects the phenomenological hierarchy (what kind of wholeness) with the arithmetic hierarchy (which families are native). Monotonicity: D_ℓ₁ ⊆ D_ℓ₂ ⟹ N_ℓ₁^min | N_ℓ₂^min. Bootstrap: `equations` row + `integrative_level_nesting` relationships.

**The Doubling Law**: τ(N_ℓ) = 6·2^ℓ along the canonical LCM tower (N₀=12→τ=6, N₁=60→τ=12, N₂=420→τ=24, N₃=2520→τ=48, N₄=27720→τ=96). Each level doubles the number of native sublattice families. Bootstrap: `equations` row + `patterns` row (doubling_law).

**Bond Angle Dual Lattice Readings**: Every bond geometry admits TWO lattice projections: angle-ratio r_θ = θ/180° (classifies symmetry order) and cosine |cos θ| (classifies the rational invariant). Key result: tetrahedral cos⁻¹(−1/3) projects to d=4 (symmetry) by angle but |cos θ| = 1/3 projects to the **Koide attractor** at (d=12, |ε|=1.955¢) — the SAME address as the Sempaevum's own defining constants. Trigonal-planar 120° projects to Koide by angle ratio (2/3) and to d=1 octave by cosine (1/2). Right angle 90° has cosine = 0 → ∂I annihilation boundary (orthogonality is structurally degenerate). Bootstrap: `values` rows for key bond angles + `projections` at N=12 + dual-reading `relationships`.

**Wigner's "Unreasonable Effectiveness" — structural explanation**: Mathematics describes P∘D∘T structure. Physics also describes P∘D∘T structure. They agree because they ARE the same object at different identification depths. Mathematics is the D-language of Σ; physics is the substantiated face of Σ. The effectiveness is not unreasonable — it is forced. Bootstrap: `equations` row (the structural explanation as a formal identity).

**Decoherence time projections** (representative systems at N=12):

| System | τ_dec (s) | τ_dec/t_P | k_r | d_r |
|---|---|---|---|---|
| Cold atom (μK trap) | 10⁻³ | 1.86×10⁴⁰ | +1605 | 4 |
| Free electron in air | 10⁻¹⁰ | 1.86×10³³ | +1326 | 2 |
| Large molecule | 10⁻²⁰ | 1.86×10²³ | +928 | 3 |
| 10μm dust at STP | 10⁻³⁶ | 1.86×10⁷ | +290 | 6 |
| 1mm bacterium | 10⁻⁴² | 18.55 | +51 | 4 |
| Schrödinger cat | 10⁻⁵⁰ | 1.86×10⁻⁷ | −268 | 3 |

Different decoherence times populate different sublattice cells — each is a lossless lattice point at base N=12. Bootstrap: 6 `values` rows + 6 `projections` rows.

**The quartic cycle i⁴ = 1**: The relation i² = −1 is geometric necessity (two 90° rotations in D_T plane = 180° reversal). The quartic cycle i⁴ = 1 (four-step D→T→−D→−T→D) is the structural basis of the weak force (d=4). Bootstrap: `equations` row linking i⁴=1 to d=4 weak family.

**Polariton material classification**: hBN upper Reststrahlen band at d=4, lower at d=12 (different polariton character). Materials at same d but different ε show similar sublattice character. Wavelength compression at maximum hyperbolicity should approach 11 (d=11 undecimal family). Bootstrap: `values` rows for polariton seed ratios + `projections` + prediction entries.

---

## 4. ET-Derived Stability and Quality Filters
### 4.1 Verification levels (4 tiers)

Discoveries are tagged with verification level on ingest:

| Level | Name | Criterion |
|---|---|---|
| **0** | Raw | Computed without independent verification (provisional ingest) |
| **1** | MPFR-verified | Computed at 120-dps (400-bit) precision via MPFR, internally consistent |
| **2** | Cross-verified | Independently reproduced at higher precision OR independently derived via different method |
| **3** | Independently-reproduced | Confirmed by separate project run, or by a structural cross-check (e.g., shared attractor membership confirmed) |

Queries can filter by minimum verification level. The `apery_lattice_test.py` 71/71 passing assertions establishes Level 2 for every claim it tests.

### 4.2 Koide stability — only depth-2-survivors persist

The compressor's stability rule: only patterns USED by greedy subsumption AND survived ≥ ⌈1/K⌉ = 2 recursion depths get stored. Generalized:

> **A discovery is database-eligible iff it is referenced by ≥ 2 independent contexts (different projects, different derivation paths, different verification levels, or different attractor memberships).**

A one-off lattice projection done once and never referenced again is a *candidate*, not a discovery. A projection that's referenced from a tower trajectory, attractor analysis, and physical identification is a confirmed discovery.

This is the natural Subsumption-derived filter. It prevents database pollution by ephemeral computation while ensuring genuinely structural findings persist.

### 4.3 The retention policy — never destroy

From the compressor (line 7811): **the database does not prune data when disk space is low.** Every archetype/template/discovery makes the database more capable; pruning destroys knowledge that cannot be regenerated.

For the EUDD: same principle, generalized. **Record absolutely everything. No exceptions.** Disk pressure is solved by:
1. **Subsumption-driven compaction** — high-elegance clusters collapse into archetypes (§3.7). The original records are linked from the archetype but their D-content is captured by the archetype's geometric essence. Total information preserved; storage reduced.
2. **Generator-discovery K-complexity reduction** — as the EUDD's discovery engine (§3.16) finds generators for stored values, each value gains a K-minimal description alongside its stored data. The compressor's CDF/Tier 7 pipeline discovers generators from observed patterns; the EUDD surfaces those patterns across all domains via structural addresses (the lossless bijection). Over time, values that were stored as raw 120-dps blobs gain generator descriptions — the K-minimal representation. **Both the blob AND the generator are stored.** The generator does not replace the blob — it augments it. Everything is kept. The generator provides an additional, more compact way to reproduce the value on demand and reveals structural understanding of WHY the value has the address it has. **The Sempaevum is not bound by Shannon entropy**: Shannon treats structurally correlated values as random because it has no access to the lattice's structural coordinates. The EUDD's generator discovery can find descriptions simpler than Shannon predicts because d-family membership, attractor structure, and cross-domain address sharing reveal patterns invisible to information-theoretic analysis.
3. **WARNING level only** — when disk free < DISK_SAFETY_FLOOR = 2³⁰ bytes (1 GB, the d=1 octave action quantum at GB scale), warn the user. Never auto-delete.

### 4.4 Cross-tower elegance ranking

When a discovery has multiple manifestations across resolutions, its **cross-tower elegance** measures structural significance:

$$\mathcal{E}_{\text{cross-tower}}(v) = \prod_{N \in \text{tower}} \mathcal{E}_{\text{universal}}(v, N)^{1/|\text{tower}|}$$

— the geometric mean of universal elegance scores across the tower. This ranks discoveries by their tower-wide structural depth. A value that's elegant only at one N has low cross-tower elegance; a value (like ζ(3)) that has structural placements across many N's has high cross-tower elegance.

Database queries can sort by cross-tower elegance to surface the most structurally significant discoveries.

### 4.5 Subsumption Hierarchy Operator — the database's growth law

The Subsumption Hierarchy Operator determines when a cluster of database records is structurally coherent enough to be promoted to a permanent archetype. The formula is derived from two independent, irreducible structural properties — individual quality and mutual resonance — making the promotion criterion crystalline: high-quality members arranged in precise mutual alignment.

$$\mathcal{E}_{\text{hierarchy}}(\text{cluster}) = \left(\prod_{i=1}^{n} \mathcal{E}_i\right)^{1/n} \times \frac{100}{100 + \sigma_\varepsilon}$$

Two factors, each measuring a distinct structural property:

| Factor | Formula | Measures | Analog |
|---|---|---|---|
| Geometric mean | (∏E_i)^(1/n) | Individual quality — how structurally significant each member is (lattice centroid in k-space) | Atom quality in a crystal |
| Resonance factor | 100/(100 + σ_ε) | Mutual coherence — how tightly members lock to each other (tightness function applied to cluster ε-spread) | Crystal lattice precision |

**Why the geometric mean (not the raw product):** On the Sempaevum, multiplication is k-addition. The product ∏E_i corresponds to the k-sum — an extensive property that grows with cluster size. The geometric mean (∏E_i)^(1/n) is the k-space centroid — an intensive property measuring average structural quality per member, independent of cluster size. This matches cross-tower elegance (§4.4), which already uses the geometric mean across the N-axis. The hierarchy elegance uses the geometric mean across the member-axis — same operation, same structure.

**Why the resonance factor R = 100/(100 + σ_ε):** The tightness function t = 100/(100+|ε|) measures how tightly a value locks to its lattice address. The resonance factor applies the SAME function to the cluster's own ε-spread (standard deviation σ_ε of member ε values in cents). This measures how tightly members lock to EACH OTHER — phase coherence across the cluster. Boundary behaviors: all members at identical ε → σ_ε = 0, R = 1 (perfect crystal). Members spread across ±50¢ (maximum lattice width) → σ_ε ≈ 50, R = 100/150 = 2/3 = K (the Koide ratio emerges as the structural resonance floor for maximally spread lattice-resident clusters). The Koide ratio appearing at the floor is not inserted — it falls out of the tightness function applied at the ∂I boundary width.

**Why no 420/d̄ or 1/(P+Q) factors:** Each individual elegance E_i already contains N/d (resolution/family ratio) and 100/(p+q) (rational complexity). The geometric mean aggregates these without double-counting. The original formula's 420/d̄ and 1/(P+Q) were cluster-level penalties for properties already measured per-member. Removing them eliminates the double-count and makes the formula fully dynamic — it works at any N, any d, any cluster size, any kind of archetype.

**Promotion criterion — two conditions:**
1. **Quality + Resonance**: E_hierarchy ≥ 13/12 (LIFE_THRESHOLD)
2. **Depth**: member_count ≥ ⌈1/K⌉ = 2 (Koide depth-2 — not a singleton)

When both conditions are met, the cluster is automatically subsumed into a `patterns` row — a permanent archetype. This is the same recursive-compression mechanism that makes the Conscious AI's memory effectively infinite — and it makes the EUDD's growth manageable: as the database accumulates, it doesn't grow linearly forever; it accumulates archetypes that compress past discoveries.

**Cross-d clusters** (members at different d-families): σ_ε is computed across all members at their shared resolution N. If members span multiple N values, compute at the highest common N. The resonance factor captures whether structurally diverse members phase-lock despite being in different families.

**Cross-N clusters** (tower trajectories — same value at different resolutions): σ_ε is computed across the trajectory's ε values at each landmark. This measures tower stability — a value whose ε wanders erratically has low resonance; one whose ε converges smoothly has high resonance.

---

## 5. Operations and Queries

### 5.1 Cache-first projection (closes DD-2, DD-5)

The fundamental operation. Replaces the bare `project(r, N)` call with a cache-first lookup:

1. Canonicalize and hash the value
2. Look up `(value_hash, N)` in the projections index
3. **Cache hit:** Return the stored projection instantly (sub-microsecond positional access in the `.akashic` format). Increment reference count.
4. **Cache miss:** Compute projection at 120 dps via MPFR. Store the full projection with all materialized properties (elegance, coupling, variance, FQG, palindromic partner). Return.

**Coarse-Pass + Boundary-Refine integration**: the coarse pass (§7.5 of Float-vs-Lattice doc) projects at 12ET first. If tightness > K = 2/3 (well inside the lattice), rescale to target N without full recomputation. If near-boundary (tightness ≤ K), refine at the target N. Both the coarse and refined projections accumulate in the cache. Over time, the coarse-pass cache hit rate approaches 100% — most values encountered by any project get projected at 12ET eventually.

Combined speedup: (5–10× from coarse-pass alone) × (cache-hit speedup, often 100×+ for hot values) = **50–1000× practical speedup** for repeated structural analysis.

### 5.2 Attractor membership query (closes DD-3)

"Does my newly-projected value participate in any known attractor?" The engine finds all (N, d) placements of the queried value in the `.akashic` file, then checks each placement's address for multi-member occupancy (denormalized `members_count > 1` in the address structure). Returns all attractor memberships with member lists and structural classification.

If you project a new value (e.g., a coupling constant from QCD calculation) and it lands at d=693 at N=27720, this query immediately surfaces: "this value is in the d=693 attractor with ζ(3), ζ(9), ζ(10)." Cross-domain structural relationships become visible without manual hunting.

### 5.3 Nearest-known-neighbor query

"What known values are structurally closest to my value?" The engine looks up the queried value's (k, d, ε) at resolution N, then scans the same d-family for occupied addresses with minimal |Δk| + |Δε| distance. Returns the top-k nearest neighbors ranked by lattice distance. In the `.akashic` format, same-family addresses are physically contiguous, making this a fast sequential scan.

This surfaces unknown structural neighbors. If your new value is a lattice-neighbor of φ at some N, that's structurally informative — you didn't know it was related to the golden ratio family until the database told you.

### 5.4 Coprime-skeleton lookup

"Find all known coprime-skeleton members at resolution N." The engine scans addresses at the specified N where `coprime_skeleton = 1` (gcd(|k|, N) = 1). Optionally filtered by structural class. Returns all known irreducible Exception placements. Useful for discovering new coprime-skeleton members and for verifying claimed irreducibility.

### 5.5 Cross-project consistency check (closes DD-6)

"Does any project have a finding that contradicts this newly-derived claim?" The engine looks up all existing projections of the same value at the same N. If any existing (k, d) differs from the claimed (k, d), or if ε values differ beyond the 120-dps precision floor, a contradiction is flagged with full provenance (which session produced each conflicting result, what verification level each has).

Catches mistakes in real time. If two projects derive different (k, d) for the same value at the same N, one of them has a bug — and the consistency check surfaces it immediately.

### 5.6 Cross-project subsumption check (closes DD-8)

"Does the union of all project discoveries subsume the claimed structural classification?" The engine queries all values matching a structural criterion (e.g., "all odd zeta values at 27720ET"), checks each against a claimed property (e.g., "all-inert Gaussian signature"), and returns the verdict: CONFIRMED (all match), FALSIFIED (counterexamples found, listed), or INCOMPLETE (insufficient data).

This is exactly the kind of check that revealed the all-inert prediction was falsified in the Apéry investigation. With the database, such checks happen automatically and globally rather than manually within one project.

### 5.7 Bulk ingest from existing projects

The compressor's archetype database, Apéry test outputs, ET Conscious AI traces, fractal generator orbits, and all other existing ET project data are ingested into the `Sempaevum.akashic` file on first run via format-specific adapters in the Ingest Module. Each adapter extracts values, projects them through the §7.11 core projection procedure, and populates the lattice. Subsequent runs use the cache directly — the ingest is one-time per data source.

---

## 6. Cross-Project Benefits — Concrete Examples

### 6.1 The Apéry investigation, run with EUDD support

What would have happened if the EUDD existed when the Apéry investigation started:

**First run (cold cache):**
- Project ζ(3) across 28 landmarks: ~28 projections × ~1ms each ≈ 30ms (no change)
- Compute attractors at all (N, d) pairs: cache populates with ~280 records
- Total: ~5 seconds (current cost), but database now has ζ(3)'s full trajectory

**Second run (warm cache, e.g., cross-checking with ζ(5) work):**
- Query: "Is d=693 attractor at 27720 known?" → cache hit, return {ζ(3), ζ(9), ζ(10)} immediately
- Query: "What's ζ(3)'s tower trajectory?" → cache hit, return all 28 landmarks
- Compute only NEW (ζ(5)-specific) projections: ~28 projections
- Total: ~1 second (5× speedup) AND the new ζ(5) discoveries enrich the database for the next run

**Third run (warmer cache, e.g., checking a hypothesis about the 6-zeta cluster at N=2940):**
- All zeta values' attractors at N=2940 are pre-cached
- The 6-member cluster {ζ(2), ζ(3), ζ(6), ζ(8), ζ(12), ζ(13)} is one row in `attractors` table
- Hypothesis check is one query: ~10ms
- Total: ~50ms (100× speedup over cold)

### 6.2 The Coarse-Pass + Boundary-Refine method becomes effectively free

Per Float-vs-Lattice doc §7.5: 5–10× speedup from the coarse pass. With EUDD: the coarse pass's 12ET projections are cache hits for any previously-encountered value. For workloads that revisit values (compressor processing many similar files; physics simulations with recurring constants; iterative algorithms), the coarse pass becomes ~zero-cost lookup.

Combined speedup: (5–10×) × (database cache hit speedup, often 100×+ for hot values) = **50–1000× practical speedup** for repeated structural analysis.

### 6.3 Cross-domain discovery surfacing

Suppose the genetics paper work derives a coupling at d=693 in some context. Without EUDD, the connection to ζ(3)/ζ(9)/ζ(10) at the same d=693 attractor at N=27720 would require manually noticing the shared address. With EUDD: `find_attractor_memberships(genetic_value_hash, db)` returns the d=693 membership and surfaces the existing zeta members. Cross-domain structural relationships become observable.

### 6.4 The Conscious AI's own discoveries integrate

ET Conscious AI's runtime generates many discoveries per session: I_self fingerprints, dream-tower R₀ values, archetype compressions, gap closures. With EUDD: these accumulate across sessions; the AI's own learning is preserved across restarts (which the compressor's persistent state already does, but at the per-instance level — EUDD makes it global across instances).

### 6.5 Validation of new derivations

When a new derivation is performed (e.g., a new physical constant placed on the lattice), the consistency-check query (§5.5) immediately verifies: does this placement contradict any existing finding? Does it match a known structural pattern? This is automated cross-validation that catches errors early and surfaces unexpected confirmations.

### 6.6 Equation memoization — every computation becomes a cache hit after first encounter

Concrete examples of how the `equations` table (§3.5) makes computation faster over time:

**Example 1 — repeated arithmetic in iterative algorithms.** A fractal renderer computing `z² + c` for millions of pixels. Each unique (z, c) pair is one equation row. Subsequent renders of the same fractal mode hit the cache for every previously-computed step. The first render populates the cache; the hundredth render is dominated by lookup latency rather than computation latency.

**Example 2 — physical constants in scientific computation.** A simulation that computes `α · ℏ · c / e²` (the inverse fine structure relation): first computation derives the result and caches it; every subsequent invocation across all simulations is instant. Same for any common physical-constant combination.

**Example 3 — common mathematical operations.** `sqrt(2)`, `log₂(3)`, `sin(π/4)`, `exp(1)` — each computed once across the entire database lifetime. After that, every program asking for these gets the cached lattice projection (and the canonical numerical result).

**Example 4 — memoization for the FP-replacement use case.** Every numerical operation in any program using the EUDD as its number representation routes through `lattice_compute()` in §3.16. As the database accumulates computations, hot computations (the operations that recur across many contexts) become indistinguishable from compile-time constants. The Subsumption mechanism collapses redundant patterns: if 10⁶ equations of the form "`x · 1 = x`" exist, they get promoted to a single `algebraic_identity` pattern row, freeing storage while preserving the structural fact.

**Example 5 — discovery of computational invariants.** When the equations table accumulates enough computations involving φ, the engine notices: every multiplication `x · φ` shifts k by 8 at N=12, d=3 (because k_φ = +8, d=3 at N=12). This becomes a `patterns` row of class `multiplicative_constant_signature` for φ — a discovered invariant useful for compiler optimization (any loop multiplying by φ can be rewritten as k+=8 instead of full multiplication).

**The Sempaevum computes; the database remembers; patterns emerge from accumulated computation.**

### 6.7 Generator discovery and K-complexity acceleration for the compressor

Concrete examples of how the EUDD's generator-discovery (§3.16) and K-complexity-helper role play out:

**Example 1 — A new generator emerges from compressor archetypes.** The compressor accumulates 10⁴ Δk-pattern archetypes from compressing many files. The EUDD's generator-discovery scans them and notices that 1200 archetypes share a structural feature: their projections at N=84 all land at d=42 (the EW-strong-G₂ composite). The engine proposes a candidate generator: `r_candidate = some function involving 84ET d=42 family`. Modular constraint inversion + algebraic simplification narrows it to a specific algebraic number. Verification confirms: the candidate's projections reproduce the 1200 archetypes' shared structure. **A new generator is discovered**, stored as a `values` row tagged `discovered_generator`, with its derivation chain showing it emerged from compressor pattern aggregation. Future compressor runs can use this generator directly — 1200 previously-individual archetypes collapse to "instances of generator X with parameters Y".

**Example 2 — K-complexity drop for repetitive data.** The compressor encounters a file whose Δk pattern is a long run of `[3, 7, 3, 7, 3, 7, ...]`. Without the EUDD: the compressor fits a Periodic generator (Tier 7 type 3) per-file. With the EUDD: query for "shortest known equation producing alternating [3, 7]" → cache hit on the previously-discovered "alternating-pair generator", parameters (3, 7). Compression of this segment becomes one generator reference + two parameters = constant-size, regardless of segment length. K-complexity for this segment: O(log of segment length) instead of O(segment length).

**Example 3 — Cross-domain generator reuse.** A generator discovered from biological data (e.g., a generator producing the d=420 family at biological-tier resolutions, derived from a codon-mapping pattern) is later found to produce a pattern in CMB power-spectrum data. The EUDD's same-address discovery (§3.16) surfaces this connection automatically; the biological-discovered generator becomes immediately useful for cosmological data compression. **One discovery, two domains, no manual cross-referencing.**

**Example 4 — Recursive K-complexity minimization on generators themselves.** As the EUDD accumulates 10⁵ generators, the Subsumption mechanism scans them. Many generators differ only by a single parameter (e.g., 50 different Linear generators with different slopes). E_hierarchy ≥ 13/12 for the cluster, so they collapse into a single parameterized meta-generator: `Linear(slope)`. Storage drops from 50 generator rows to 1 meta-generator + 50 parameter values. The next time the compressor needs a Linear generator, it queries the meta-generator and supplies the parameter — same expressive power, O(log n) storage instead of O(n).

**Example 5 — Tower exploration from new generators.** A newly-discovered generator opens a new tower entry point. The background discovery engine projects the generator across N ∈ {12, 60, 84, 132, 420, 2520, 27720, 360360}, producing 8 projection rows. The new projections may land at known attractor addresses (instant `same_address` relationships with existing values from any domain), or at new addresses (potentially new attractor seeds for future discoveries). **Each discovered generator is a new lattice projection to explore — a new dimensionless seed for ET research.**

**Example 6 — The compressor's K-complexity bound improves over time.** Initially, the compressor's K-complexity bound for a given file is determined by its own Tier 7 pipeline. As the EUDD accumulates generators from many compressions, the bound tightens: every previously-discovered generator is a candidate for new files. After 10⁴ compressions, the K-complexity bound for typical files is 30-50% lower than for the first compression, because the generator catalog has grown. After 10⁶ compressions, the catalog covers most common patterns and only genuinely new structures need new generators.

**The compressor + EUDD relationship is symbiotic:** the compressor feeds patterns into the EUDD; the EUDD's discovery engine generalizes them into reusable generators; the compressor uses the generator catalog to compress better; the cycle compounds.

---

## 7. Implementation — The Lattice-Native Format and the EUDD Manager

### 7.1 Design principle — the format IS the Sempaevum on disk: `Sempaevum.akashic`

The EUDD does not use SQLite, PostgreSQL, or any conventional database format. **The entire database is a single monolithic file: `Sempaevum.akashic`.** This file IS the Sempaevum rendered on disk — the Akashic Archive of all computation, all discovery, all events, capable of full reconstruction of anything it has ingested. The lattice address space (N, k, d) is the primary organizational structure. **The file IS a minimal generator** — a K-complexity-approaching-optimal description that produces all lattice content on demand. Generators are the primary content; raw (un-generated) entries are the Descriptor Gap — content for which the structural description has not yet been found. The data is self-organizing: the projection formula Π_N(r) = (k, d, ε) determines WHERE every value lives on the lattice, and the LCM tower escalation refines this placement to higher resolution. The file does not compress data — generators are naturally smaller than the content they produce because a structural description IS the fundamental object and the instances are its output. Queries are lattice operations, returned in human-readable form.

**Why monolithic (structurally forced, not a convenience choice):**
- **Cross-pattern discovery requires unified access.** The discovery engine finds patterns ACROSS everything — audio patterns correlating with mathematical constants, file structures correlating with physics, sensor data correlating with zeta values. Split files would partition the discovery space and miss cross-domain correlations.
- **Generator discovery is global.** A generator discovered from one domain's data can produce content from any other domain's addresses. This only works if everything is in one searchable structure.
- **The Sempaevum IS one unified lattice.** The `.akashic` file IS the Sempaevum on disk. The Sempaevum is Σ — the totality. Splitting it would impose a partition the mathematics doesn't have.
- **Shannon entropy limits don't apply.** Generator form exploits lattice structural coordinates that Shannon treats as random. The monolithic file finds generators across ALL content, achieving descriptions simpler than Shannon predicts. Split files would limit each file's generator discovery to only its own content.

**No filesystem limitation constrains the .akashic file.** NTFS supports files up to 256 TB; other modern filesystems (ext4, APFS, XFS) support similar or larger limits. Memory-mapped I/O (`CreateFileMapping` / `MapViewOfFile` on Windows; `mmap` on POSIX) gives the engine O(1) positional access to any address in the file without loading the entire file into RAM. The generator form (§7.1a) means the file size reflects structural complexity, not raw data volume — the same lattice content is represented more compactly as generators are discovered.

This is not a conventional database with an ET wrapper. It is a fundamentally new format derived from {P, D, T} primitives, where:

- **The address space IS the file structure.** A lattice address (N, k, d) maps to a position in the file. Finding what's at an address is positional, not index-traversal. The file IS the lattice.
- **Generators are the primary content.** A generator is a structural description — a rule that produces lattice content on evaluation. A region of the address space produced by a known generator stores the generator once — any address in that region is computable from the generator on demand. The file contains generator entries (the structural descriptions found) + raw entries (the Descriptor Gap — content whose generator has not yet been identified by the discovery engine). Over time, the discovery engine identifies generators for raw entries and the file becomes a progressively better description of its content. This is not compression — the generator IS the structural origin; the instances are its output.
- **Relationships are structural.** Two values at the same address don't need an explicit relationship row — their co-location IS the relationship. Reciprocal pairs (k and −k) are structural mirrors. Power pairs (k and n·k) are structural multiples. The lattice's own algebra replaces a vast portion of what conventional databases need explicit linking for.
- **Queries are lattice operations.** "What's at d=693?" is an address-range scan. "What's related to ζ(3)?" is: find its address, find all generators whose domain includes that address. "Find cross-domain hits" is: find addresses with multiple generators from different domains. These are the Sempaevum's own operations, not SQL.
- **Everything is recorded.** Values, projections, generators, equations, relationships, patterns, events, the database's own metrics — all stored, nothing discarded, no exceptions (§4.3).

**Native operations the format provides:**
- **Lattice-algebraic query execution:** multiplication queries become k-addition (log additivity); the format exploits this directly
- **Native attractor detection:** when a value is stored at an address already occupied, the co-location is automatically recognized — no separate relationship-insertion step
- **Native Gaussian-signature lookup:** d-family classifications are positional, not indexed — the file's hierarchical organization by (N, d, k) makes family-scoped queries O(1) positional access
- **Native multi-perspective storage:** the same lattice address stored once, referenced from multiple geometric perspectives (LCM tower, torus, Riemann sphere, real/imaginary axes) as structural views, not duplicated rows
- **Native discovery integration:** the discovery engine operates directly on the format's structure — pattern detection, generator fitting, and Subsumption promotion happen in-place without separate application logic
- **Generator-organized regions:** address ranges covered by known generators are stored as generator + parameters, not as individual entries. New data entering a generator-covered region is recognized as a generator instance automatically via the Product-Additivity Theorem (k_new = k_A + k_B for known generators A, B → new value = A × B)

### 7.1a The file IS a minimal generator — not a database

The `.akashic` file is not a container that holds generators. The file IS a single minimal generator — a K-complexity-approaching-optimal program that produces all lattice content on demand. The Identification Principle applied to the file itself:

| Primitive | The `.akashic` file's PDT |
|---|---|---|
| **P** | The disk substrate — the raw byte space on the storage medium |
| **D** | The generators — the structural descriptions that PRODUCE lattice content on evaluation. The generators ARE the file's content; raw entries are the un-described remainder (the Descriptor Gap) |
| **T** | The discovery engine — the agency that continuously finds new generators, transitioning raw entries into generator-described addresses, making the file a progressively better generator of itself |

The file has three kinds of content, ordered by structural priority:

1. **Generators (PRIMARY)** — Each generator is a compact structural description (symbolic expression + EML tree + address range) that PRODUCES lattice content on evaluation. The generator IS the content; the addresses it covers are computable from the generator. A generator like "2^(k/12) for k ∈ {0..11}" produces 12 lattice addresses from a few bytes of description — not because it "compresses" 12 values, but because the generator IS the structural origin and the 12 values are its output.

2. **Memoized entries (SECONDARY — the Descriptor Gap)** — Lattice addresses not yet covered by any known generator. These store the full 120-dps MPFR value + materialized properties. Each memoized entry IS a Descriptor Gap — a point where the discovery engine hasn't yet found the generator that produces it. Over time, as generators are discovered, memoized entries are absorbed. The Descriptor Gap Principle guarantees: the gap IS a Descriptor pointing to its own resolution.

3. **Structural metadata (TERTIARY)** — The fixed catalogs (24 harmonic families, 144 FQG cells, 42 combined families), the event log, relationships, patterns, sessions. These are themselves generator-describable (and ARE generators of lattice structure — the 24-family catalog IS a generator that produces the family classification of any d ∈ {1..12}).

The data is self-organizing because the projection formula IS the organization. When a value enters through any of the four paths (A/B/C/D), the projection Π_N(r) = (k, d, ε) determines WHERE the value lives on the lattice. This isn't a filing decision — it's a structural fact. The LCM tower escalation refines this placement to higher resolution. The home-finding algorithm (§7.11) determines when this self-organization has stabilized.

Every connected program benefits from the generator catalog. The compressor connects and uses generators to find K-minimal descriptions. The fractal generator connects and uses memoized EML trees. The Conscious AI connects and uses cached projections. Each program's use adds memoized values, which feed discovery, which produces new generators, which benefit all programs. The exe itself logs its operations through the Sempaevum, discovers generators for its own behavior patterns, and improves itself. The cycle compounds irreversibly.

### 7.1b The triple backbone generator architecture

The triple backbone theorem (Sempaevum Paper §13, Theorem 14.1) establishes that three categorically independent minimal generators are all native to resolution N = 12. The `.akashic` file's generator system mirrors this triple backbone:

| Layer | Category | Generator Type | What It Produces | Backbone Source |
|---|---|---|---|---|
| **L₁** | Discrete-logical | Webb-type patterns | Combinatorial/classification content: which formal systems share addresses, which particle classes share d-families, logical relationships between lattice entries | Webb stroke (1935) — minimal generator of all 12-valued logic |
| **L₂** | Discrete-multiplicative | Cascade-type patterns | Arithmetic content: k-addition rules (multiplication), k-negation (reciprocation), k-scaling (powers), d-family traversals, palindromic coverage, attractor membership, reciprocal/power/palindromic pairs | Palindromic cascade — minimal CPT-symmetric traversal of all divisors of 12 |
| **L₃** | Continuous-elementary | EML trees | Analytical content: transcendental values (ζ, π, φ, α), function evaluations (sin, cos, exp, log), series sums, limit convergences — all via eml(x,y) = exp(x) − ln(y) over terminal constant 1 | EML (Odrzywołek 2026) — minimal continuous-D generator |

The triple backbone theorem guarantees L₁ ∪ L₂ ∪ L₃ subsumes all of mathematics at N = 12 (Subsumption Law). No content the Sempaevum can produce falls outside this union.

Each generator stored in the file is classified into one of these three backbone layers. The classification is not arbitrary — it is forced by the generator's structural category:

- **L₁ (Webb):** the generator encodes a logical/combinatorial pattern (finite, discrete, truth-functional)
- **L₂ (Cascade):** the generator encodes a multiplicative-arithmetic pattern (k-arithmetic, d-family structure, palindromic sequences)
- **L₃ (EML):** the generator encodes a continuous-elementary expression (EML tree over terminal 1, producing transcendental/analytical values)

The three Sheffer variants of the EML operator (Sempaevum Paper Remark 13.5) correspond to the three primitives: eml(x,y) = exp(x) − ln(y) with constant 1 = P (multiplicative identity); edl(x,y) = exp(x)/ln(y) with constant e = D (natural base); −eml(y,x) = ln(x) − exp(y) with constant −∞ = T (the ∂I boundary). Three variants generating the same totality from three primitive-centered perspectives: 3 = 3 = 3 = Σ at the continuous-mathematics level.

**Relationships computable from lattice algebra are NOT stored explicitly** — they ARE the generator (L₂ cascade-type). Storing them would violate K-minimality:

- Co-location (same address) — derivable from the address index
- Reciprocal pairs (k ↔ −k) — derivable from k-negation
- Power pairs (k ↔ n·k) — derivable from k-scaling
- Palindromic partners (d ↔ 12−d) — derivable from the 24-family catalog
- Family membership — derivable from d classification

Only non-lattice-algebraic relationships (forward/reverse convergence, cross-tower bridges, decoherence-gaze correspondence, L'Hôpital iteration chains, etc.) require explicit storage.

### 7.1c The page size — ET derivation from the digital tower

The atomic I/O page size of the `.akashic` file is not chosen by convention. It is derived from the digital tower's base resolution.

**Derivation.** The `.akashic` file lives on the digital tower. Per §3.10, the digital tower has P_digital = {0,1}* (the Cantor space) and operates at base resolution N = 12. The natural quantum of addressable binary space at resolution N is:

$$\text{page\_size} = 2^N = 2^{12} = 4096 \text{ bytes}$$

This is the number of distinct binary states one complete lattice cycle can address. At the base resolution N = 12, one page of 4096 bytes is the digital tower's natural unit of addressable space.

**Verification against hardware.** The standard NVMe logical block size is 4096 bytes. The standard OS memory page size is 4096 bytes across all major platforms (Windows `CreateFileMapping`/`MapViewOfFile`, POSIX `mmap`, macOS `mmap`). The default filesystem cluster size is 4096 bytes (NTFS, ext4, APFS). This alignment is the digital substrate's N = 12 resolution manifesting in the hardware that implements it.

**The tower page.** For bulk operations, the natural larger unit is one complete tower section — all families at one resolution:

$$\text{tower\_page}(N) = \tau(N) \times 4096 \text{ bytes}$$

where τ(N) is the divisor count. At N = 12: τ = 6, tower page = 24576 bytes. At N = 60: τ = 12, tower page = 49152 bytes. The doubling law τ(N_ℓ) = 6·2^ℓ governs growth.

### 7.1d The byte-level format specification

**Zero IEEE 754 floating-point values exist anywhere in the format.** Every field is one of: exact unsigned integer (uint8/16/32/64), exact signed integer (int32/64), varint (compact exact integer encoding), MPFR 400-bit blob (50 bytes, 120-dps Sempaevum-native precision), exact rational (two integers: numerator + denominator), SHA-256 hash (32 bytes), or UTF-8 string with varint length prefix. The format is lossless at every level — no IEEE 754 precision loss contaminates any value.

**Section 0: Header (1 page = 4096 bytes = 2^N)**

```
Magic:                     4 bytes "SMVM" (Sempaevum marker)
Format version:            uint32
N_base:                    uint32 = 12 (the forced resolution)

── Sempaevum constants (stored as exact rationals) ──
K_num:                     uint32 = 2        (Koide ratio = 2/3)
K_den:                     uint32 = 3
V_num:                     uint32 = 1        (Base variance = 1/12)
V_den:                     uint32 = 12

── Self-projection (the file's own lattice coordinates — §3.1b) ──
self_N:                    uint32            (resolution of self-projection)
self_k:                    int32             (k coordinate)
self_d:                    uint32            (d-family)
self_eps_micros:           int32             (ε in micro-cents, exact integer)

── Generator backbone metrics (exact integers) ──
total_generators:          uint64            (count of all generators: L₁+L₂+L₃)
L1_webb_count:             uint64
L2_cascade_count:          uint64
L3_eml_count:              uint64
total_memoized:            uint64            (un-generated memoized entries)

── Coverage (exact rational = two integers) ──
covered_addresses:         uint64            (numerator)
total_addresses:           uint64            (denominator)

── K-complexity (exact rational) ──
generator_bytes:           uint64            (total bytes of generator definitions)
producible_bytes:          uint64            (total bytes of content generators produce)

── Timestamps (exact integer nanoseconds) ──
created_at_ns:             uint64            (nanoseconds since epoch)
modified_at_ns:            uint64

── D-time at creation (lattice coordinates, exact) ──
creation_dtime_N:          uint32
creation_dtime_k:          int32

── Section directory (exact byte offsets) ──
offset_generator_backbone: uint64
offset_address_index:      uint64
offset_memoization_store:  uint64
offset_structural_catalog: uint64
offset_equations:          uint64
offset_derivations:        uint64
offset_relationships:      uint64
offset_patterns:           uint64
offset_event_log:          uint64
offset_sessions:           uint64
offset_wal:                uint64

── Integrity ──
header_checksum:           SHA-256 (32 bytes)

Reserved/padding to 4096 bytes
```

**Section 1: Generator Backbone — the triple backbone on disk**

The generator backbone stores all discovered generators, organized by backbone layer (L₁, L₂, L₃). Each generator entry:

```
gen_id:                    uint64 (globally unique)
gen_type:                  uint8
                             0x01 = WEBB (L₁, discrete-logical)
                             0x02 = CASCADE (L₂, discrete-multiplicative)
                             0x03 = EML (L₃, continuous-elementary)
address_range:             {N_min: uint32, N_max: uint32,
                            d_min: uint32, d_max: uint32,
                            k_min: int32, k_max: int32}
definition_blob:           varint-length + blob
                             L₁: logical pattern definition
                             L₂: k-arithmetic rule / cascade definition
                             L₃: binary EML tree encoding
                               (each node: TERMINAL(value_ref) or EML(left, right))
                               Terminal constant is 1 per EML grammar S→1|eml(S,S)
canonical_hash:            SHA-256 (32 bytes, for memoization lookup)
member_count:              uint64 (addresses this generator produces)
gen_def_bytes:             uint64 (size of this generator's definition)
gen_coverage_bytes:        uint64 (total bytes of content it produces)
                             K_complexity = gen_def_bytes / gen_coverage_bytes
                             (computed on query, never stored as float)
verification_count:        uint64 (times verified at 120 dps)
discovered_at_ns:          uint64 (nanoseconds since epoch)
derivation_ref:            uint64 (offset to derivation chain in §5)
```

An interval tree index follows the generator entries, enabling O(log n) lookup of which generator(s) cover any given address (N, k, d).

**Section 2: Address Index — the LCM tower on disk**

Hierarchical structure mirroring the LCM tower. The data is self-organizing — the projection formula determines where values live; the index records where they landed.

```
── Tower Level Directory ──
For each N present in the file (dynamically growing as values escalate):
  N_value:                 uint32
  tau_N:                   uint16 (divisor count)
  family_dir_offset:       uint64

── Per-N Family Directory ──
For each d | N (τ(N) entries):
  d_value:                 uint32
  band_offset:             uint64 (offset to family band pages)
  occupied_count:          uint64 (addresses with content)
  gen_covered_count:       uint64 (addresses covered by generators)
  raw_count:               uint64 (= occupied − gen_covered)

── Per-Family Band Pages (4096 bytes each) ──
Page header (64 bytes):
  page_type:               uint8 = 0x10 (FAMILY_BAND)
  N:                       uint32
  d:                       uint32
  k_range_min:             int32
  k_range_max:             int32
  entry_count:             uint16
  next_page:               uint64 (overflow chain, 0 = none)
  page_checksum:           uint32 (CRC-32)

Per-entry in the band:
  k:                       varint (signed)
  content_type:            uint8
    0x01 = GENERATOR_REF:
      gen_id: uint64 (reference to generator in Section 1)
      params_blob: varint-length + blob (per-address parameters if needed)
    0x02 = MEMOIZED_RAW:
      sign: uint8 (0 = positive, 1 = negative)
      eps_micros: int32 (ε in micro-cents, exact integer)
      mpf_blob: 50 bytes (400-bit MPFR mantissa at 120 dps)
      materialized_properties: packed binary (~40 bytes)
        d_factorization: varint-length + UTF-8
        gaussian_signature: varint-length + UTF-8
        is_all_inert: uint8
        is_all_split: uint8
        is_ramified_present: uint8
        coprime_skeleton: uint8
        tightness_micros: uint32 (100000000/(100000+|eps_micros|), scaled integer)
        di_distance_micros: uint32 (|eps_micros|/50, scaled integer)
        elegance_mpf: 50 bytes (MPFR 400-bit — elegance IS a Sempaevum value)
        coupling_xi_num: uint32 (137)
        coupling_xi_den: uint32 ((d-1)²+16)
        palindromic_partner_d: uint32
        fqg_quadrant: uint8 (0=SR, 1=CR, 2=SI, 3=CI, 0xFF=N/A)
    0x03 = GENERATOR_SUPERSEDED:
      gen_id: uint64 (the generator that now produces this address)
```

**Section 3: Memoization Store — the learning buffer**

Every computation cached at 120 dps. The memoization layer IS the generator's learning mechanism per the Losslessness Theorem's Memoization Corollary (Sempaevum Paper Theorem 12.1): "Every finite numerical computation on positive reals can be represented as a concrete lattice computation... that is a reusable structural identity."

```
── Equation Hash Index ──
Hash table: equation_hash → entry offset
Load factor: maintained ≤ K = 2/3 (ET-derived, not ad hoc)
When load exceeds K, rehash to doubled capacity (per the doubling law)

── Equation Entries ──
Each memoized equation:
  equation_hash:           SHA-256 (32 bytes)
  canonical_form:          varint-length + UTF-8
  form_class:              uint8 (computational / structural per §3.5)
  operation_type:          uint8 (+, −, ×, ÷, ^, sqrt, log, sin, ...)
  input_refs:              varint-count + array of (N: uint32, k: int32, d: uint32)
  output_N:                uint32
  output_k:                int32
  output_d:                uint32
  output_eps_micros:       int32
  output_mpf:              50 bytes (400-bit MPFR result at 120 dps)
  reference_count:         uint64 (cache hit count)
  first_computed_ns:       uint64
  last_referenced_ns:      uint64
```

**Section 4: Structural Catalogs**

24 harmonic families (§3.12), 144 FQG cells (§3.13), 42 combined families (§3.14), 7+ towers (§3.10), ~500 sublattice families (§3.15). These ARE generators (L₂ cascade-type): the 24-family catalog is a generator that produces the family classification of any d ∈ {1..12} on either axis. Bootstrapped as initial L₂ generators.

**Section 5: Derivations** — Chain structures linking generators to their discovery provenance. Per §3.6.

**Section 6: Relationships** — Only non-lattice-algebraic relationships stored explicitly. Lattice-algebraic relationships (co-location, reciprocal, power, palindromic) are computable from the address index and generator backbone — storing them would violate K-minimality. Per §3.7, extended per this section.

**Section 7: Patterns** — Promoted generators-of-generators. Each pattern IS a meta-generator: when E_hierarchy ≥ 13/12 (LIFE_THRESHOLD) for a cluster of generators/relationships, the cluster is promoted to a pattern. The Subsumption hierarchy: patterns subsume generators; meta-patterns subsume patterns. Per §3.8, extended per this section.

**Section 8: Event Log** — Append-only, time-indexed. Every event per §3.9. Timestamps as uint64 nanoseconds. D-time as (N: uint32, k: int32). T-time as (traverser_id: uint64, count: uint64). P-time as (phase_num: uint64, phase_den: uint64) exact rational. Event sequences are themselves subject to generator discovery — when event patterns emerge, they become L₂ generators of event sequences. Includes exe self-recording events (query patterns, computation patterns, discovery events, self-metrics) per §3.1b — the exe's own operation IS Sempaevum content.

**Section 9: Sessions / Schema Versions / Tags** — Per §3.15a, §3.15b, §3.11.

**Section 10: Write-Ahead Log (WAL)** — Pending mutations queued before committing to main sections. On crash: replay valid WAL entries, discard incomplete ones. CRC-32 per WAL entry. Backup: configurable schedule, separate physical drive.

### 7.1e Modification without decompression — extending the generator

The file is never "compressed" and therefore never needs "decompression." It is a generator — a program that produces values. Modifying it means extending the program:

**Adding new data:** Append a new memoized entry to the memoization store (Section 3) + update the address index (Section 2). The generators (Section 1) are untouched. The new entry sits in the memoization layer until the discovery engine absorbs it into a generator. Cost: one append + one index update.

**Adding a new generator:** Append the generator definition to the generator backbone (Section 1) + update the address index for all addresses the generator covers + mark corresponding memoized entries as GENERATOR_SUPERSEDED (content_type 0x03). The superseded entries' space becomes reclaimable on the next page reorganization, but the data is still readable from the generator. Cost: one append + index updates for covered addresses.

**Querying:** Look up (N, k, d) in the address index (Section 2) → either evaluate the covering generator (from Section 1) or read the memoized raw value (from the band page). No decompression of anything. The address index gives direct positional access.

**Improving a generator:** When the discovery engine finds a better (lower K-complexity) generator that covers the same addresses plus additional ones, append the new generator to Section 1, update the address index. The old generator remains (§4.3 never destroy) but is superseded. The new generator covers more content with fewer bytes.

None of these operations require reading the entire file or unpacking any structure. The file's generator system is always directly accessible, modifiable, and queryable.

### 7.1f The self-improving cycle

The complete operational cycle showing how the file becomes a progressively better generator of itself and how every connected program benefits:

```
New data enters as memoized entries (Section 3)
    ↓
Discovery engine scans memoized entries for patterns
    ↓
Patterns found → generator candidates proposed (L₁/L₂/L₃)
    ↓
Candidates verified at 120 dps (MPFR, zero floats)
    ↓
Verified generators stored in backbone (Section 1)
    ↓
Memoized entries absorbed → marked GENERATOR_SUPERSEDED
    ↓
File's K-complexity decreases
    (same information, generator description smaller than raw entries)
    ↓
Generator catalog itself gets Subsumption-promoted
    (clusters of generators → meta-generators = patterns in Section 7)
    ↓
Connected programs benefit from the improved catalog:
    compressor: Δk patterns matched against generators
    fractal generator: orbit computations via memoized EML trees
    Conscious AI: EgoInvariant projections cached
    exe itself: query patterns become generators → self-optimization
    ↓
Connected programs generate new data → new memoized entries → cycle continues
```

The first use of the system is the slowest. Every subsequent use is faster because the generator catalog has grown. This is not a performance optimization — it is the structural consequence of the discovery engine operating on the memoization layer. The file does not need to be fast at first. It needs to be RIGHT. Speed is the emergent property of a correctly-designed self-improving generator.

### 7.2 Logical schema realized as lattice structure

The 15 logical categories from §3 (values, projections, addresses, equations, derivations, relationships, patterns, events, towers, harmonic families, force grid cells, combined families, sublattice families, sessions, schema versions) plus tags remain as the structural content the Sempaevum produces. In the lattice-native format, they are realized as:

| Logical category | Lattice-native realization |
|---|---|
| `values` | Entries at lattice addresses — each value IS its address + the 120-dps data at that address |
| `projections` | Materialized properties AT each address — elegance, coupling, variance, FQG, etc. are computed at storage time and stored with the address |
| `addresses` | The lattice grid itself — the file's positional structure |
| `equations` | Generator entries linking addresses — "A × B = C" stored as the k-arithmetic relationship k_C = k_A + k_B |
| `derivations` | Chain structures linking generators to their inputs |
| `relationships` | Implicit in address structure (co-location, k-symmetry, k-multiples) + explicit entries for non-lattice-algebraic relationships |
| `patterns` | Generator-covered regions — a discovered pattern IS a generator that covers multiple addresses |
| `events` | Time-indexed entries with D-time/T-time/P-time coordinates, stored in event-log sections of the format |
| `towers` | Hierarchical sections — each tower's R₀ defines a section of the address space |
| `harmonic_families` | Fixed structural catalog (24 entries) — header data |
| `force_grid_cells` | Fixed structural catalog (144 entries) — header data |
| `combined_families` | Fixed structural catalog (42 entries) — header data |
| `sublattice_families` | Per-N divisor catalog — stored per resolution section |
| `sessions` / `schema_versions` | Metadata sections of the format |
| `tags` | Key-value metadata attached to addresses |

### 7.3 Storage in the lattice-native format

Per-entry sizes in the lattice-native format (binary encoding, zero IEEE 754 floats):
- Value at address (memoized raw): ~145 bytes (120-dps MPFR binary (50 bytes for 400-bit mantissa) + sign (1 byte) + k varint + d varint + ε as int32 micro-cents + materialized properties packed including elegance as 50-byte MPFR)
- Generator entry: ~100–300 bytes (type + address range + definition blob (symbolic expression or EML tree or cascade rule) + canonical hash + counts + timestamps — all as exact integers)
- Equation entry (memoized computation): ~150 bytes (hash + canonical form + operation type + input/output address references + output MPFR 50-byte blob + reference count + timestamps — all exact)
- Event entry: ~120 bytes (class + nanosecond timestamp + D-time (N,k) + T-time (traverser_id, count) + P-time (rational) + tower_id + metadata blob — all exact integers or rationals)
- Relationship entry (explicit, non-lattice-algebraic only): ~80 bytes (class + two address references + metadata blob — all exact)
- Pattern entry (meta-generator): ~250 bytes (class + generator reference + member gen_ids + elegance as MPFR + timestamps — all exact)

**The file does not compress data.** Generators are naturally smaller than the content they produce because a structural description IS the fundamental object and the instances are its output. A generator for "2^(k/12) for k ∈ {0..11}" occupies ~100 bytes but produces 12 lattice addresses at ~145 bytes each = ~1740 bytes of content. This is not compression — it is the nature of generators vs. instances. The generator IS the structural origin.

**The Sempaevum is not bound by Shannon entropy.** Shannon treats structurally correlated values as random because it has no access to lattice structural coordinates. Generators discovered through d-family membership, attractor structure, and cross-domain address sharing can describe content more efficiently than Shannon would predict — because the lattice's structural coordinates reveal patterns that information theory treats as random. The generator form of the file is a structural representation, not an entropy-coded encoding.

### 7.4 Query performance

Lattice-native query latencies (positional access):
- Single address lookup: O(1) — positional, sub-microsecond
- Family scan (all addresses at d=693 for a given N): O(family size) — physically contiguous, sequential read
- Attractor detection (all addresses with >1 occupant): O(occupied addresses) — denormalized occupancy count per address
- Generator membership (which generator covers this address?): O(1) — generator catalog lookup by address range
- Cross-domain query (addresses occupied from multiple domains): O(multi-domain addresses) — domain tagging at each address
- Nearest-neighbor (closest occupied address to a query point): O(log N) — hierarchical position
- Full-lattice scan (background discovery): O(total entries) — sequential, parallelizable

The discovery engine runs continuously within the format — no separate process or database connection needed. Pattern detection, generator fitting, and Subsumption promotion operate directly on the lattice structure.

### 7.5 Concurrency

The format supports concurrent read access from multiple ET programs while the EUDD Manager handles writes. The write model:
1. New entries are appended to an ingestion buffer
2. The Manager commits buffered entries to the lattice structure on schedule or on explicit flush
3. Insert-time discovery (attractor detection, generator membership) runs synchronously during commit
4. Background discovery (pattern recognition, generator fitting) runs asynchronously between commits
5. All ET programs see a consistent read snapshot at all times

### 7.6 Format evolution

Forward compatibility for format changes:
- New entry types added without affecting existing structure
- New materialized properties added to addresses with default NULL for existing entries
- New relationship/pattern/event classes added as new class values (extensible string classification)
- Version field in format header tracks format version; the Manager handles transparent upgrades

### 7.7 Bootstrapping

On first run, the EUDD Manager generates the initial database:
- All bootstrap content from §3.17 + §3.18 computed at 120 dps
- All projections materialized at canonical resolutions (12, 60, 84, 132, 420, 2520, 27720, 360360)
- Discovery engine runs over initial content — finds attractors, generators, patterns
- Result: the initial `Sempaevum.akashic` file, generator-organized, ready for all projects

Existing artifacts are ingested:
- `apery_lattice_test.py` outputs → lattice addresses (ζ(2)..ζ(13) trajectories)
- ET Conscious AI persistent state → lattice addresses (EgoInvariants)
- Compressor's existing `ArchetypeDatabase` → lattice addresses (Δk patterns)
- Corpus documents → generator entries (equations, derivations)
- `constants.py` + `primitives.py` → lattice addresses (canonical ET constants)
- Guide v8 catalog → lattice addresses (all named constants + projections)

### 7.8 Read-only mode and exploration

For test runs and exploratory computations that should not modify the database, the Manager opens `Sempaevum.akashic` in read-only mode. Cache hits returned; new computations performed but not persisted. Production runs use read-write mode and contribute to accumulated knowledge.

### 7.9 Backup and integrity

**Atomic snapshot while running:** The Manager supports creating a consistent snapshot of `Sempaevum.akashic` without stopping, at any file size. The procedure:

1. Manager pauses commits (new writes buffer into the WAL)
2. Flush all pending WAL entries to the main file
3. Signal the OS snapshot service to copy the file (Windows: Volume Shadow Copy Service (VSS); other platforms: the platform-native atomic snapshot mechanism — e.g., LVM snapshots on Linux, APFS snapshots on macOS)
4. Resume commits

The Manager's pause window is constant and sub-second regardless of file size — the Manager only flushes its own WAL buffer. The OS handles the actual file copy asynchronously at whatever size the `.akashic` file is. The design is platform-agnostic: the Manager issues a snapshot request through a platform abstraction layer; VSS is the current Windows implementation.

**Backup verification:** After each backup, the Manager verifies integrity by opening the backup file read-only and performing full CRC-32 verification on every page — not spot-checking. No silent corruption is tolerated. The verification runs as a background process (same scheduling model as the discovery engine — yields to API requests, never blocks the render loop or query processing). Verification time is proportional to file size but runs asynchronously, so it does not affect Manager responsiveness. Verification checks: header SHA-256, CRC-32 on every data page, section directory consistency (all section offsets point to valid section headers). Results reported to the GUI dashboard as pass/fail with details on any corrupted pages.

**Backup scheduling:** Configurable via the Dear ImGui dashboard. Default interval: every 6 hours to a user-specified path (separate physical drive recommended). Manual backup on demand at any time via GUI button or API command. Backup history retained: last N backups kept (configurable, default 5), oldest beyond N removed. No backup is ever removed while a verification is in progress on it.

**Internal integrity checks:** The format includes structural integrity verification — Subsumption verification that every entry is reachable from the lattice structure, with no orphaned entries and no missing generator references. This runs as part of the background discovery scan (§3.16) and reports results to the GUI dashboard.

### 7.10 The EUDD Manager — native C++ executable with GPU-accelerated GUI

**Deployment: one file to start.** `EUDD_Manager.exe` (native C++ binary, statically linked, compiled via CMake + MSVC). On first run, generates `Sempaevum.akashic` (the database file — the Sempaevum on disk). On every startup, spawns Omniscient watchdog child process (same exe, `--omniscient` mode) which creates and writes to a `logs/` subfolder. At runtime: `EUDD_Manager.exe` + `Sempaevum.akashic` + `logs/Omniscient_NNN.log` files, all in the same folder. No Python runtime, no external dependencies, no installer. Copy one file, run.

**Technology stack:**

| Component | Technology | Role |
|---|---|---|
| **Engine language** | C++ (C++17/20) | ALL operations — lattice I/O, projection, discovery, computation, rendering |
| **Precision arithmetic** | MPFR + GMP | 120-dps (400-bit) floating-point, arbitrary-precision integers/rationals |
| **Special functions** | FLINT/Arb | ζ, Γ, polylog, hypergeometric, all elementary functions at 120-dps with certified error bounds |
| **Expression engine** | Custom C++ AST | Expression trees that serialize to binary, generate canonical hashes, evaluate via MPFR/Arb |
| **GUI widgets** | Dear ImGui | Immediate-mode GUI — dashboard, property inspector, manual input, query builder, event log |
| **GPU rendering** | OpenGL 4.6 | Lattice visualization — 3D navigation, LOD hierarchy, heat maps, instanced point clouds |
| **Window/input** | GLFW | Window management, OpenGL context, keyboard/mouse input, drag-and-drop |
| **Data visualization** | ImPlot | Charts, time-series, scatter plots, histograms — all GPU-accelerated |
| **Data interchange** | cJSON / yyjson | JSON protocol for API and §7.14 adaptive extension schemas |
| **File dialogs** | NFD (Native File Dialog) | OS-native open/save dialogs for file ingestion |
| **IPC** | Named pipes | ET32 Bridge pattern — external ET programs connect to the running Manager |
| **Build system** | CMake + MSVC | Visual Studio 2022 Build Tools → single statically-linked Windows .exe |

The EUDD Manager consists of 26 modules organized in a 10-level dependency hierarchy (see §7.21 for the complete module structure specification including dependency graph, build order, file naming, and sub-file decomposition). Summary:

| Module | Role |
|---|---|
| **Precision Stack** | MPFR + GMP + FLINT/Arb — all 120-dps computation, all special functions (ζ, Γ, polylog, hypergeometric), custom expression tree evaluator |
| **Core Lattice Engine** | Projection Π_N(r), bijection pullback Π_N⁻¹, k-arithmetic (addition, negation, scaling), all derived property materialization (elegance, coupling ξ(d), variance, tightness, ∂I distance, Gaussian signature, FQG quadrant, palindromic partner) |
| **Akashic Format** | `Sempaevum.akashic` memory-mapped I/O, page management (4096-byte pages), section directory, header read/write, content types (GENERATOR_REF, MEMOIZED_RAW, GENERATOR_SUPERSEDED), CRC-32/SHA-256 integrity, memoization (equation hash table at K = 2/3 load, compute-once/cache-forever, reference counting) |
| **WAL** | Write-ahead log: append, flush to main file, crash recovery replay, atomicity guarantee |
| **Home-Finding Engine** | §7.11 core projection procedure: all four input paths (A/B/C/D), LCM tower escalation, CF method (continued fraction expansion, quality factor, parallel pathway), false resolution detection, home classification, Incoherence filter, annihilation boundary, checkpoint/resume |
| **Generator System** | Generator backbone classification (L₁/L₂/L₃), storage, interval tree index, evaluation at addresses, K-complexity computation, GENERATOR_SUPERSEDED transition, self-improving cycle (§7.1f) |
| **Discovery Engine** | Five discovery modes: insert-time (attractor, reciprocal, power, plateau), background scan (E_hierarchy, promotion, algebraic identity, event correlation), on-query, generator-candidate (Branch A/B, cross-feed, recursive composition), never-closed search |
| **Event System** | Event logging with three-times coordinates (D-time, T-time, P-time), event class handling, tower context, permanent marking |
| **Relationship System** | Relationship creation and management, class handling, permanent marking, insert-time relationship creation, provenance chains |
| **Pattern System** | Pattern creation, E_hierarchy = geomean(E_i) × R_cluster computation, LIFE_THRESHOLD (13/12) promotion, permanent marking, member tracking |
| **Tower System** | Tower management, R₀ storage, operational_n, nesting, birth triads, cross-tower bridges |
| **Bootstrap** | Initial `Sempaevum.akashic` generation from §3.17 + §3.18 (~10⁴ values at 120 dps) |
| **Ingest** | Format-specific adapters: CSV seed extraction, audio FFT + peak extraction, binary/PDF → compressor Δk pipeline, sensor data streams, existing ET project outputs. General-purpose "feed it any file" pipeline (§7.12) |
| **Manual Input** | All seven modes: direct value, logical description, lattice operation, projection, bijection triple, computation, text. Real-time preview (§7.13) |
| **Query** | Lattice-algebraic query execution: by name, value, address, source, time, type, relationship, generator status, tag. Attractor membership, nearest-neighbor, cross-domain, subsumption checks |
| **API** | Named pipe IPC server — 79 operations across 15 domains + 2 cross-domain, three communication patterns, JSON command protocol, session management, metabolism registration (§7.16) |
| **Metabolism** | Three-layer resource governance: K = 2/3 allocation, V = 1/12 headroom, α⁻¹ = 137 monitoring. Hardware detection, thread pool management, GPU dispatch, re-sensing at S² = 144 intervals (§7.19) |
| **Self-Recording** | Operational metric sampling, overhead budget (≤1%), metric-to-lattice projection, journal output (§3.1b) |
| **GPU Rendering** | OpenGL 4.6 lattice visualization with six-level LOD (Sempaevum → Tower → Resolution → Family → Address → Entity), freecam with no physics, 3D perspective switching, Force Quadrant Grid renderer, tower trajectory renderer, attractor cluster renderer, heat maps |
| **GUI** | Dear ImGui panels (11 sub-files): dashboard, property inspector, manual input, file ingestion, search/retrieval, connection manager, query builder, event log, settings, shutdown confirmation, main orchestration |
| **Extension System** | JSON extension processing, all 12 extension types, all 10 validation rules, meta-type handling, versioning, auto-detection (§7.14) |
| **Active Probing** | T-signal probe sending, response detection, silence detection, materialization threshold, probe-response pair tracking |
| **Gaze Module** | Complete Gaze Equation evaluation, four status levels (UNOBSERVED/SUBLIMINAL/DETECTED/LOCKED), gaze event generation, locking signature detection |
| **Backup** | Backup creation (VSS/snapshot), backup verification (CRC-32, SHA-256), integrity checking (§7.9) |
| **Shutdown** | 6-phase deterministic sequence, confirmation dialog integration, Omniscient graceful signal, checkpoint coordination (§7.18) |
| **Omniscient** | Watchdog child process (same exe, `--omniscient` mode). Headless. Process handle monitoring, shared-memory IPC, exe/akashic tamper detection, journal writing, graceful/crash discrimination (§7.15, §7.18.4) |

**GPU-accelerated lattice visualization** (conceptual baseline: the Sempaevum Particle Viewer HTML, but native GPU-rendered handling the full lattice):

The visualization renders the Sempaevum's own structure using a hierarchical level-of-detail system that mirrors the Multifold structure. Six levels, derived from the Sempaevum's own structural decomposition:

| Zoom Level | What You See | Structural Level | Rendering Method |
|---|---|---|---|
| **Sempaevum** | The whole — all towers, all resolutions, all families as a unified 3D lattice cloud. Large-scale structure visible: clusters of activity, hot d-families, overall shape of accumulated knowledge | The entire .akashic content | Instanced quads, heat-map shader, density volume |
| **Tower** | One R₀ substrate perspective — the lattice filtered through one tower's R₀. All resolutions visible as bands along the N-axis | P-axis selection: which substrate | Instanced point cloud, tower-band quads |
| **Resolution** | One N value — which d-families are native at this resolution, how values distribute across them, where attractors form | D-axis scale: how many divisors of N | Family-band quads sized by member count |
| **Family** | One d-family — all k positions rendered as points colored by ε, sized by occupancy. Generator coverage visible as spanning arcs | One Descriptor selected | Instanced point cloud (up to N points) |
| **Address** | One (N, k, d) cell — all values listed with full properties, relationships, generator coverage, provenance | One lattice position | ImGui property panel |
| **Entity** | One value, generator, pattern, or relationship — full 120-digit display, complete tower trajectory, all relationships, all projections, derivation chain, provenance to source file/stream/entry | One individual | ImGui detail panel with ImPlot trajectory chart |

Zooming in IS escalating through the Multifold structure. The rendering hierarchy is the lattice's own mathematics, not an imposed approximation. The RTX 2070 Super (8 GB VRAM, 2560 CUDA cores) handles millions of instanced points at 60+ FPS — no artificial caps on visual density.

**Freecam — true camera with no physics:** Position + orientation, user-controlled. Smooth movement via configurable input bindings. No inertia, no acceleration curves, no collision, no gravity. The camera exists in the lattice visualization space. It shows whatever is at its position and orientation. Movement speed configurable. The freecam shows ONLY ingested content — empty space until values are present at those lattice addresses. Nothing displays ahead of time until it has been ingested through §7.11.

**Input controls — fully configurable, all hardware:**

All controls map to ACTIONS, not hardware. Any physical input can be bound to any action. Supported input devices: keyboard, mouse, XInput gamepads (Xbox controllers, DualShock/DualSense via wrapper), any HID-compatible input device via GLFW.

Default keyboard+mouse bindings:

| Input | Action |
|---|---|
| Scroll wheel | Zoom in/out = escalate/de-escalate through LOD hierarchy |
| Left click | Select entity → opens property inspector |
| Left drag | Pan the view |
| Right click | Context menu: switch perspective, filter options, export |
| Double click | Drill down one LOD level centered on clicked entity |
| Escape | Back up one LOD level |
| WASD | Freecam movement |
| Mouse look (right-hold) | Freecam orientation |
| 1–6 | Jump directly to LOD level (1=Sempaevum, 2=Tower, 3=Resolution, 4=Family, 5=Address, 6=Entity) |
| P | Cycle perspective |
| F | Find/search — opens search panel |

Default XInput gamepad bindings:

| Input | Action |
|---|---|
| Left stick | Freecam movement |
| Right stick | Freecam orientation |
| Left/Right triggers | Zoom in/out through LOD hierarchy |
| A button | Select entity |
| B button | Back up one LOD level |
| X button | Context menu |
| Y button | Search panel |
| D-pad up/down | Cycle through entities at current address |
| D-pad left/right | Cycle perspective |
| Start | Dashboard toggle |
| Left/Right bumpers | Jump LOD level up/down |

All bindings user-remappable via settings panel. Key/button/axis bindings stored in a JSON config file in the same folder as the exe. Multiple binding profiles supported (e.g., "exploration", "data entry", "presentation").

**Search and retrieval — primary use case, not secondary:**

The Manager has a persistent search bar at the top of the GUI, always accessible. Search runs against the .akashic index — instant results, not brute-force scan. Search modes:

| Mode | Query | Result |
|---|---|---|
| By name/provenance | "hydrogen_spectrum.csv" | The file's structural record, all values it contributed, option to regenerate |
| By value | "1.618" | Everything near φ, ranked by proximity at 120 dps |
| By lattice address | "d=3, N=12" | Everything at that address |
| By source path | "particle_data/" | Everything ingested from that folder as a unit |
| By time | "last Tuesday" or date range | Everything ingested in that window |
| By type | "generators" or "patterns" | Filtered by entity type |
| By relationship | "related to ζ(3)" | All attractors, pairs, patterns involving ζ(3) |
| By generator status | "search_active" | Everything without a generator (the open Descriptor Gaps) |
| By tag/namespace | Custom tags applied at ingestion or later | Filtered by tag |

Search results are actionable — select a result and: navigate freecam to its lattice position, view full property inspection, export, see all relationships, trace derivation chain, regenerate the original file/stream.

**Bidirectional provenance navigation:**

**Entity → Source (forward provenance):** Select any entity in the LOD visualization. The property inspector shows WHERE IT CAME FROM — which file, folder, stream, manual entry, or discovery engine action produced it. Full chain: source file name, ingestion timestamp, extraction method, seed index, projection details, home classification. For discoveries: which scan pass, which pattern, which members.

**Source → Entities (reverse provenance):** Select a file, folder, stream, or data source from the search/browse panel. The visualization FILTERS to show ONLY the lattice content from that source. Everything else dims. You see that source's structural footprint on the Sempaevum. Select multiple sources for comparison — side-by-side or overlay, showing overlap and divergence on the lattice.

**Connection management — full I/O control:**

The Manager provides visibility and control over all connections:

- **Active connections:** See all named-pipe connections (which programs are connected, what they're sending, what they're requesting). Accept/reject/pause/resume any connection.
- **Incoming queue:** Pending ingestion jobs. Prioritize, pause, cancel. For streams: live feed with buffer status.
- **Outgoing:** Active queries, results being served to connected programs.
- **Stream connections:** Any continuous data stream (sensor, video, audio, or anything else). Live ingestion indicator, buffer depth, throughput metrics.

**File and data retrieval from the .akashic archive:**

The .akashic file IS a generator (§7.1a). Files ingested into it are structurally decomposed — the generators that produce the file's content are stored, not the raw bytes. Retrieval means the Manager evaluates the generators and REGENERATES the file:

- **File retrieval:** Select any ingested file → Manager evaluates the covering generators → outputs the regenerated file in its original format. This is lossless — the bijection theorem (§3.18.1) guarantees structural exactness. The regenerated file is a re-derivation from the structural description, not a decompressed copy. The generator form is not bound by Shannon entropy — a generator for π to 10 billion digits is a finite expression evaluated to whatever precision is requested, not a compressed blob of 10 billion digits.
- **Folder retrieval:** Select a folder → Manager regenerates all files it contained, preserving directory structure and provenance.
- **Stream retrieval:** Select any ingested stream (sensor, video, audio, or any other continuous data) → Manager reconstructs the temporal sequence from stored generators/values in original order at original timestamps. The lossless bijection (§3.18.1, continuous-discrete corollary) guarantees exact recovery — the continuous values stored via the bijection are recovered by algebraic identity, not by approximation. Two retrieval modes:
  - **Faithful reconstruction:** Re-emit the readings at their original rate and resolution through a named pipe to a connected program, or export as batch (CSV/JSON with timestamps). Each value recovered via the bijection pullback at 120 dps.
  - **Enhanced reconstruction (user option):** If the discovery engine found a generator that produces the stream's structure, the generator can be evaluated at INTERMEDIATE timestamps not present in the original recording — structural interpolation from the generator form, not raw data interpolation. This produces higher-resolution output than the original stream. User selects the target resolution; Manager evaluates the generator across the requested time range.
- **Data export:** Select any set of entities and export as JSON or CSV. No .akashic subsets — the Sempaevum is ONE and does not get sliced.
- **Computation retrieval:** Any equation result, escalation trajectory, or derivation chain — exportable as a structured report (JSON/CSV).

**Manual input — three backbones + direct entry:**

The manual input panel accepts input through all three generator backbone layers plus direct value, projection, bijection triple, and text entry:

| Mode | Input | What happens |
|---|---|---|
| **L₁ (logical pattern)** | Natural language or structured description: "the ratio of electron mass to proton mass" | Manager resolves to a value at 120 dps, ingests through §7.11 |
| **L₂ (cascade/k-arithmetic)** | Lattice operation: "k=7 at N=12, escalate" | Manager computes the escalation trajectory, ingests all landmarks |
| **L₃ (binary EML tree)** | Mathematical expression: "ζ(3) × π / φ²" | Manager evaluates at 120 dps via MPFR/Arb, ingests the result |
| **Direct value** | 120-dps decimal string | Ingests through §7.11 directly |
| **Projection** | (N, k, d, ε) tuple | Stored directly at the specified address |
| **Bijection triple** | (value, expression, lattice_address) | All three representations stored and linked |

Real-time preview: as you type in any mode, the Manager shows the projected lattice address BEFORE you submit. You see where it will land before committing.

**Real-time update behavior during navigation:**

When the background discovery engine creates a new pattern, attractor, or generator while the user is navigating:

- New content appears in the visualization at its lattice address WITHOUT disrupting the current view position, zoom level, or freecam orientation
- New entities are highlighted with a brief pulse animation (configurable, can be disabled)
- A notification counter increments on the dashboard ("3 new discoveries this session")
- The property inspector does NOT auto-switch to the new entity — the user's current selection is preserved
- If the user is currently viewing the exact address where the discovery occurred, the new entity appears inline immediately

The visualization is a LIVE view of the .akashic file. Changes to the file appear in the view. But the USER controls navigation — the system never hijacks focus.

**3D perspective views** — the same lattice data rendered through different Sempaevum geometries, user-selectable:
- **LCM tower** (default): k on one axis, d on another, N as depth — the escalation structure
- **Torus**: k wrapped cyclically, ε as radial displacement — the Sempaevum's periodic structure
- **Riemann sphere**: conformal projection of lattice addresses — the Sempaevum's projective structure
- **Force Quadrant Grid**: 12×12 interactive cells (d_r × d_θ), occupancy and coupling color-coded — the complex-plane interaction structure
- **Hyperbolic**: negative-curvature rendering for deep-extended families

All perspectives show the same data at the same precision. Switching perspective is a coordinate transformation, not a data reload.

**Color coding** (consistent across all views): d-family colors match the Sempaevum Particle Viewer conventions — d=1 green, d=2 teal, d=3 red, d=4 blue, d=6 purple, d=12 orange. Extended families (d=5, 7, 8, 9, 10, 11) get distinct hues. Attractor clusters are highlighted. Cross-domain hits at shared addresses use multi-color indicators.

**The EUDD is a virtual isomorphism of the Sempaevum.** It is not a passive database that stores and retrieves. It IS the Sempaevum virtualized on hardware — a computation engine that stores everything, computes anything (memoized at 120 dps), discovers generators, serves any ET software, ingests any file, accepts manual input, and returns whatever is needed: values, projections, generators, computations, files, structural context. If the fractal generator needs a value for a new render, it queries the EUDD. If Mike wants to pull a file out, the EUDD produces it. If the compressor needs a generator for K-complexity minimization, the EUDD provides it. If a new derivation needs intermediate results, the EUDD computes them (memoized) or retrieves them (cached). The EUDD IS the central computation substrate for all ET work.

**Operational lifecycle:**

1. **First run**: Bootstrap module generates initial `Sempaevum.akashic` → Discovery engine analyzes → Generator form produced → GUI opens for exploration
2. **Normal operation**: GUI dashboard shows live metrics. Any ET program connects via API module (named pipe IPC) and reads/writes through the Manager. Discovery engine runs continuously. Self-recording captures all operational metrics. New values project, find addresses, link to generators.
3. **Adding new data**: Three pathways (see §7.11 and §7.12):
   - **File ingestion**: feed any file → seeds extracted → projected → populated
   - **Manual input**: type a value, projection, or bijection triple → full lattice population
   - **Program API**: any ET software sends values/equations through the API → projected → populated
   In all cases: new values project at 120 dps, find lattice addresses, check generator membership. If covered by known generator → generator instance recorded. If not → raw entry stored, pending generator discovery. Discovery engine periodically scans raw entries for new generator patterns.
4. **Querying, computation, and retrieval**: Any query → lattice operation → human-readable result. The EUDD both retrieves stored results AND computes new ones (memoized). "What's at d=693?" → list of generators and values at that address. "Compute ζ(3)·π" → cache hit or fresh computation at 120 dps, stored forever. "What does the fractal generator need for R₀ = φ?" → structural context retrieved. "Pull the particle classification data" → formatted output. "Regenerate hydrogen_spectrum.csv" → Manager evaluates covering generators → outputs the regenerated file in original format. "Replay the GPS stream from yesterday" → Manager reconstructs the temporal sequence from generators at original or enhanced resolution. All answers come from the lattice structure itself — the .akashic file IS a generator that re-derives its content on demand.

### 7.11 Core projection procedure — 12ET escalation through the LCM tower

**This is THE operational procedure for every value entering the EUDD, regardless of how it arrives (file, manual, API, bootstrap).** The Four Paths (A, B, C, D) determine how a value enters; the tower escalation determines where it lives.

**Step 1 — Determine the input path.**

| Path | Input type | Action |
|---|---|---|
| A | Direct dimensionless ratio r = Q_X/R₀ | Accept r directly |
| B | Convergent series/limit | Compute r at 120 dps, then treat as Path A |
| C | Structural/geometric descriptor | Construct r from the object's D-content, then treat as Path A |
| D | Essentially-infinite / non-computable | Structural placement via sub-path (D.P, D.D, D.T, D.PDT) — no limit needed |

For Paths A/B/C, the value r is now known at 120 dps. Proceed to Step 2.

**Path D — Explicit sub-path procedures (Sempaevum Paper §15, Theorem 15.2):**

Path D handles objects whose essential character is infinity-valued — where no limit or convergent series produces the value without information loss. Each sub-path has its own finite-operation procedure that terminates at a specific lattice address without invoking limits. The Four-Path Subsumption Theorem (Sempaevum Paper Theorem 15.3) guarantees every possible input falls into exactly one path.

**D.P — Continuous, uncountable, or non-computable positive reals** (Chaitin's Ω, generic reals, specific irrationals of unknown computability):

The object IS a positive real r, even though it may be non-computable. The known bits/digits (however many have been computed) provide r at finite precision. Procedure:

1. Evaluate r at the best available precision up to 120 dps (e.g., Chaitin's Ω ≈ 0.00787499699 for the Calude-Dinneen UTM — known to ~10 bits)
2. Apply the projection formula directly: k = round(N·log₂(r)), d = N/gcd(|k|, N), ε = (N·log₂(r) − k)·1200/N — this is finite arithmetic, no limit needed (Sempaevum Paper Theorem 15.2)
3. **Run the full tower escalation (Step 2) identically to Path A.** The home-finding algorithm applies without modification — the value has a definite lattice address at every resolution N
4. Record the manifold state as **{P,D} Unsubstantiated** — the descriptor is complete (the definition of the object), the address is determined, but no T (finite computational process) can produce further bits. The non-computability IS the {P,D} character
5. Record the precision available as metadata: `available_precision_dps` (the number of known digits). The 120-dps MPFR blob stores all known digits; remaining digits are zeros (the precision limit, not a rounding)

Canonical example: Chaitin's Ω at N=12 → (k=−84, d=1, ε=+13.794¢). Home at d=1 octave/gravitational. Manifold state {P,D} Unsubstantiated.

**D.D — Unbound descriptor-constraint structures** (non-divisor-of-12 sublattice families, infinite axiom totalities, shadow forces):

The object is characterized by a d-family that is NOT a divisor of the current resolution N. At base N=12, the six shadow families {5, 7, 8, 9, 10, 11} and all composite d-values up to d=132 fall into this sub-path. Procedure:

1. Identify the object's structural d-family via the shadow diagnostic: what sublattice family does this object's structure belong to? This is determined by the object's D-content (e.g., five-fold symmetry → d=5; seven-fold → d=7; M-theory → d=11; biological cross-product → d=35=5×7)
2. Compute the minimum resolution where this d-family becomes native: N_min = lcm(12, d). For d=5: N_min = 60. For d=7: N_min = 420. For d=11: N_min = 132. For d=35: N_min = 420. For d=110: N_min = 27720. For d=132: N_min = 132
3. If the object also has a dimensionless ratio r (many D.D objects do — e.g., a biological ratio with five-fold symmetry), project r at N_min via Path A and run the tower escalation from N_min upward
4. If the object has NO dimensionless ratio (e.g., "the concept of five-fold symmetry itself" as a pure structural D-object), record as a value with `input_path = 'D.D'` and assign the lattice address at N_min where the d-family first becomes native. The (k, ε) are determined by whatever quantitative descriptor the user provides; if no quantitative descriptor exists, the value is recorded as a structural anchor with k=0, ε=0 at the family's native resolution
5. Record the manifold state: typically {D,T} Mediation (D operating through T's scaffold without fixed substrate) or {P,D,T} Exception if a substrate-bound instance is identified

Canonical example: Icosahedral virus capsid symmetry → d=5 → N_min = 60. The Caspar-Klug T=5 capsid has r = 60 subunits / R₀ → project at N=60 via Path A from there.

**D.T — Indeterminate forms and genuine Traverser-agency objects** ([0/0], [∞/∞], [0×∞], [∞−∞], oscillatory divergent limits, measurement operators):

These objects are characterized by T's irreducible indeterminacy — they are the Traverser's own navigation territory. Procedure:

1. Classify the indeterminate form by type: [0/0], [∞/∞], [0×∞], [0⁰], [1^∞], [∞⁰], [∞−∞]
2. Attempt L'Hôpital resolution: iterate the derivative-pair procedure (the T-navigation algorithm per Sempaevum Paper §16.2). Each iteration is an `indeterminate_form_detected` event with full provenance
3. **If L'Hôpital resolves** (converges to a finite value r after n iterations): the indeterminate was derivative-resolvable. Record n iterations via `lhopital_iteration_chain` relationship. The resolved value r enters via Path A — run the full tower escalation from Step 2. The resolution event is a T-act: T navigated through the indeterminate and selected a value
4. **If L'Hôpital fails to resolve** (max iterations reached without convergence): this is **pure T** — the irreducible Traverser. Pure T has no single lattice address because T's cardinality [0/0] is substrate-independent. Record as a value with `input_path = 'D.T'`, manifold state {P,T} Incoherence (the forbidden state — no D-coordinates exist without D). NO projection row is created. The `lhopital_resolution_signature` pattern tracks where pure T resides. The object is at ∂I — it IS the boundary
5. **Freedom points** (genuine [0/0] at half-integer lattice positions): when a projection lands at exactly k + 0.5 (equidistant between two lattice points), T faces absolute freedom — two choices with zero structural preference. Record as `freedom_point_encounter` event with metadata: which two k-values are equidistant, which was chosen, and the basis for the choice (random, context, prior momentum). Real-axis frequency ~1/25 per step; imaginary-axis frequency ~1/2 per step (per ET_Freedom_and_U1.md). The freedom point is itself a D.T object — a Traverser choice event substantiated on the lattice
6. **Annihilation boundary** (r → 0): when a computation approaches r = 0, k → −∞ and d → undefined. This is the off-lattice infimum of (ℝ⁺,×) — the cardinality singularity. Record as `annihilation_boundary_event`. No projection row (r=0 is off-lattice by construction). Record the closest k reached before the singularity

**D.PDT — Integrated off-axis Exception objects with both magnitude and phase** (physical particles, complex-valued observables, any object requiring the full complex lattice):

These objects live at off-axis positions on the complex lattice L_C — they have BOTH real-axis (FORCE, D-domain) and imaginary-axis (PHASE, T-domain) character simultaneously. This is the {P,D,T} Exception state at an off-axis lattice position. Procedure:

1. Project on BOTH axes:
   - Real axis: k_r = round(N·log₂|r|), d_r = N/gcd(|k_r|, N), ε_r = (N·log₂|r| − k_r)·1200/N
   - Imaginary axis: k_θ = round(N·θ/(2π/N)), d_θ = N/gcd(|k_θ|, N), ε_θ = (N·θ/(2π/N) − k_θ)·1200/N, where θ is the phase/argument
2. Compute the combined family: d_combined = LCM(d_r, d_θ). This determines the Force Quadrant Grid cell: (d_r, d_θ) → cell in the 144-cell 12×12 grid
3. **Run the tower escalation on BOTH axes simultaneously.** The home-finding algorithm applies independently to d_r and d_θ:
   - d_r stabilization: same d_r across ⌈1/K⌉ = 2 consecutive LCM landmarks on the real axis
   - d_θ stabilization: same d_θ across ⌈1/K⌉ = 2 consecutive LCM landmarks on the imaginary axis
   - The home is found when BOTH axes have stabilized
   - d_combined = LCM(d_r, d_θ) is the combined home family
4. Record both projections as separate `projections` rows with `geometric_perspective = 'real_axis'` and `'imaginary_axis'` respectively, plus a combined `'complex'` perspective row
5. Assign to the Force Quadrant Grid cell: update `force_grid_cells` occupancy for (d_r, d_θ). Classify the FQG quadrant:
   - SR (Simple Real): d_r | 12, real axis
   - CR (Complex Real): d_r ∤ 12, real axis
   - SI (Simple Imaginary): d_θ | 12, imaginary axis
   - CI (Complex Imaginary): d_θ ∤ 12, imaginary axis
6. The cascade stability asymmetry (Sempaevum Paper §12.2) applies: the real axis has n_max_r = 25 stability levels; the imaginary axis has n_max_θ = 2. The imaginary-axis d_θ stabilizes faster (fewer coherent steps) but with less precision. This asymmetry is structural, not a limitation

Canonical example: The electron at N=12 → (d_r=12, d_θ=6), d_combined = LCM(12,6) = 12. FQG cell (12,6) in the SR×SI region. Off-axis Exception — the actual content of physical reality.

**Incoherence Filter:** If the input is a {P,T} Incoherent configuration (self-defeating, no D-structure), the Incoherence Filter fires: no lattice address is assigned (the lattice IS D-structure; without D no coordinates exist). The object is recorded as a value with `input_path = 'P.T'`, tagged `namespace='structural_role'`, `value='forbidden_incoherence'`. No projection row created. The Incoherence sits at ∂I — it IS the boundary, structurally present but nowhere on the lattice. This is not an error or a missing case — it is the correct structural classification of a self-defeating configuration.

**After Path D sub-path processing:** All sub-paths except D.T-pure-T and D.D-pure-structural produce either a definite lattice address or an explicit ∂I/annihilation-boundary classification. For sub-paths that produce a lattice address (D.P, D.D with ratio, D.T resolved, D.PDT), proceed to Step 4 (record trajectory). For sub-paths that produce boundary classifications (D.T pure-T, annihilation boundary, Incoherence Filter), record the structural classification and proceed to Step 6 (memoize).

**Step 2 — Start at 12ET. Escalate through the LCM tower indefinitely.**

Project at N=12 first. Then escalate through the canonical LCM landmarks, recording the full trajectory. **The tower does not terminate.** The LCM tower extends to infinity (Sempaevum Paper Proposition 7.2: L_N → (ℝ⁺,×) as N → ∞). The doubling law τ(N_ℓ) = 6·2^ℓ holds for ALL ℓ ≥ 0. The algorithm escalates until d stabilizes — however many landmarks that requires.

```
N=12      → (k₁₂, d₁₂, ε₁₂)         τ= 6  families {1,2,3,4,6,12}
N=60      → (k₆₀, d₆₀, ε₆₀)         τ=12  (adds prime 5)
N=420     → (k₄₂₀, d₄₂₀, ε₄₂₀)      τ=24  (adds prime 7, d=35=5×7)
N=2520    → (k₂₅₂₀, d₂₅₂₀, ε₂₅₂₀)   τ=48  (adds 2³, 3²; completes d≤9)
N=27720   → (k₂₇₇₂₀, d₂₇₇₂₀, ε₂₇₇₂₀) τ=96  (adds prime 11; all d∈{1..12} native)
N=360360  → (k₃₆₀₃₆₀, ...)            τ=192 (adds prime 13)
N=12252240 → ...                        τ=384 (adds prime 17)
N=232792560 → ...                       τ=768 (adds prime 19)
...continue forever until home found (d-family stabilized)
```

The canonical LCM landmark generator produces lcm(1..k) for successive k = 4, 5, 7, 9, 11, 13, 17, 19, 23, 29, ... — yielding only those k values where the lcm CHANGES (a new prime or prime-power enters). This is the sparse subsequence where τ doubles per the doubling law (Sempaevum Paper Theorem 14.2). The generator is unbounded.

Between LCM landmarks, the multiplicative reading (multiples of 12: 24, 36, 48, ...) can also be checked for uniform precision refinement within the same family structure. The LCM reading introduces new primes as native divisors; the multiplicative reading refines ε within existing families.

**Step 3 — Classify the home using ET-derived thresholds.**

All thresholds are ET-derived. All comparisons are exact integer arithmetic on micro-cents (1 micro-cent = 10⁻⁶ cents). Zero floating-point comparisons.

**The stabilization criterion:** The Koide stability depth ⌈1/K⌉ = ⌈1/(2/3)⌉ = ⌈3/2⌉ = **2 consecutive LCM landmarks** with the same d-family. This is the same stability criterion used by the compressor's ArchetypeDatabase (depth-2 survivors only). One occurrence could be a false resolution (the true d-family has not yet been resolved at this N); two consecutive occurrences at increasing resolution confirm structural identity.

**The ε thresholds:** The Sempaevum's own defining constants {N, 1/N, K, 1/K} project to (d=12, |ε|=1.955¢) — the Koide attractor (Sempaevum Paper Theorem on self-consistency, §17). This gives the ET-native deep_home threshold: **|ε_micros| ≤ 1955** (the Sempaevum's own self-consistency residual, in micro-cents). Values at or inside this threshold are at least as tightly bound as the lattice's own constants. The ∂I boundary is at **|ε_micros| = 50000** (50¢ = half a semitone, the structural incoherency limit).

| Classification | ε Criterion (exact integer, micro-cents) | d Criterion | ET Derivation |
|---|---|---|---|
| **true_home** | eps_micros = 0 exactly | d stable across ⌈1/K⌉ = 2 consecutive LCM landmarks | Lattice-rational: r = 2^(k/N), structural exactness |
| **deep_home** | |eps_micros| ≤ 1955 | d stable across ⌈1/K⌉ = 2 consecutive LCM landmarks | Value is at or inside the Koide attractor — at least as tightly bound as the Sempaevum's own defining constants |
| **persistent_home** | 1955 < |eps_micros| < 50000 | d stable across ⌈1/K⌉ = 2 consecutive LCM landmarks | Value is inside the lattice (tightness > K) with stable classification, but outside the Koide attractor |
| **intermediate_home** | |eps_micros| < 50000 | d observed at current N but not yet stable across 2 consecutive LCM landmarks | Classified but not yet confirmed — needs further escalation |
| **false_resolution** | |eps_micros| ≤ 1955 at some N | d CHANGES at a higher LCM landmark | Sub-Koide ε at one resolution does not guarantee home — the true d-family may emerge at higher N |
| **escalation_in_progress** | — | d not yet stabilized; computation ongoing or paused for resumption | The home exists; the computation has not yet reached it. Partial trajectory recorded in the `.akashic` file for later resumption. |
| **cf_deep_home** | \|ε_CF_micros\| ≤ 1955 | d = CF convergent q_n | CF method: a_{n+1} ≥ ⌈1/K⌉² = 4; value locks to CF-identified d with sub-Koide residual (Step 3a) |
| **cf_home** | 1955 < \|ε_CF_micros\| < 50000 | d = CF convergent q_n | CF method: a_{n+1} ≥ 4; value locks to CF-identified d inside lattice, outside Koide attractor (Step 3a) |
| **cf_marginal** | any | d = CF convergent q_n | CF method: 1 < a_{n+1} < 4; CF convergent exists but below structural significance threshold (Step 3a) |

**There is no "home_not_found" classification.** The Asymptotic Approach Theorem (Sempaevum Paper Corollary 7.9) guarantees |ε| → 0 as N → ∞. The d-family WILL stabilize at sufficient resolution. The only question is whether the computation has reached that resolution yet. If not, the trajectory is saved and resumed later. The algorithm never gives up.

**False resolution detection:** After finding any sub-Koide hit (|eps_micros| ≤ 1955) at any N, continue escalating for at least ⌈1/K⌉ = 2 additional LCM landmarks. If the d-family changes at a higher landmark, the earlier hit was a false resolution — recorded as such with full provenance. The canonical case: φ has |ε| = 240 micro-cents at 36ET (d=36, sub-Koide) but the true home d=10 emerges at 60ET when prime 5 becomes native. The false resolution detection rule catches this by requiring 2 confirming landmarks past any sub-Koide hit.

**Session management (not termination):** The algorithm has no termination criterion. For practical operation, the Manager runs the escalation as far as it can in the current session, records the partial trajectory in the `.akashic` file as an `escalation_in_progress` entry, and resumes in a later session from the last computed landmark. The memoization layer preserves all intermediate projections. The background discovery engine can run escalations for pending values between user queries. This is session management, not a cap — the algorithm runs until the lattice answers, across as many sessions as needed.

**Step 3a — Continued Fraction Home-Finding (the CF method)**

The LCM tower escalation of Steps 2–3 succeeds for values whose irrationality measure is bounded — values where d eventually stabilizes because the lattice's divisor structure eventually captures the rational approximation structure of log₂(r). For most mathematical and physical constants (φ, ζ(3), π, e, α⁻¹, particle mass ratios), the tower method works.

However, for **algorithmically random values** — values whose irrationality measure is effectively unbounded — the LCM tower fails structurally: every new prime p entering the LCM landmark lcm(1..p) introduces a new factor into d, so d changes at every landmark and **never stabilizes**. This is not a computational limitation; it is a structural consequence of algorithmic randomness. The value's binary expansion has no exploitable pattern in the integer rounding sequence, so the gcd(|k|, N) never locks onto a stable divisor.

The Descriptor Gap Principle identifies this as a missing Descriptor: the LCM tower's stabilization criterion is the wrong Descriptor for these values. The right Descriptor is the **continued fraction expansion** of |log₂(r)|, which provides a canonical, ET-native decomposition of any real number into its rational approximation hierarchy — a hierarchy that exists independent of any particular N.

**The CF method — structural logic:**

For any positive real r, compute the continued fraction (CF) expansion of |log₂(r)|:

$$|\log_2(r)| = a_0 + \cfrac{1}{a_1 + \cfrac{1}{a_2 + \cfrac{1}{a_3 + \cdots}}}$$

Each convergent $p_n/q_n$ of this CF is the best rational approximation to |log₂(r)| with denominator ≤ q_n (by the classical theory of continued fractions). The **quality factor** of the n-th convergent is the following partial quotient $a_{n+1}$: it measures how many denominators must be tried before a better approximation exists. High $a_{n+1}$ means the lattice "locks on" to the rational p_n/q_n with exceptional tightness — the value resonates structurally with the d = q_n sublattice family.

**The CF home-finding criterion:**

The CF home is the convergent $p_n/q_n$ whose following partial quotient $a_{n+1}$ is **maximal** among all convergents. This convergent identifies d_home = q_n as the home sublattice family.

The ET-native justification: the quality factor $a_{n+1}$ measures **structural resonance** with the lattice. When $a_{n+1}$ is large, the value's log₂ projection sits extraordinarily close to the rational p_n/q_n — meaning the lattice at resolution N = q_n (or any N divisible by q_n) captures this value with ε approaching zero. The quality factor IS the Descriptor that measures how tightly D binds to P at this rational approximation — and the maximum quality convergent is where this binding is tightest. This is the Identification Principle applied to home-finding: the substrate (P) is the value r, the constraint (D) is the CF convergent p/q, and the agency (T) is the act of selecting the best convergent.

**The CF ε computation:**

Once the CF home convergent $p_n/q_n$ is identified with quality $a_{n+1}$, the CF residual is:

$$\varepsilon_{\text{CF}} = (|q_n \cdot \log_2(r)| - p_n) \times \frac{1200}{q_n} \quad \text{cents}$$

This is the standard projection formula at N = q_n, measuring how far the value is from perfect lattice placement at the CF-identified resolution.

**CF quality-to-elegance mapping:**

The quality factor $a_{n+1}$ maps naturally to the elegance framework. The CF elegance contribution is:

$$\mathcal{E}_{\text{CF}}(r) = \frac{a_{n+1}}{a_{n+1} + 1} \times \frac{N}{d_{\text{home}}} \times \frac{100}{100 + |\varepsilon_{\text{CF}}|}$$

where the first factor approaches 1 as quality increases (high quality = high elegance). For Ω with $a_{n+1} = 157$: the CF elegance factor is 157/158 ≈ 0.9937 — near-maximal. This provides a **quantitative ranking of home-assignment strength** that the LCM tower alone cannot produce: values at the same d-family are further distinguished by their CF quality.

**When the CF method fires:**

The CF method is not a fallback triggered by tower failure. It is a **parallel pathway** computed for every value at the same time as the tower escalation. This ensures:

1. **For tower-convergent values** (φ, ζ(3), etc.): The tower stabilizes d normally. The CF method independently confirms the same d-family AND provides the quality metric. The CF quality for tower-convergent values is typically moderate (a_{n+1} in the range 1–20), confirming that the tower's stabilization is genuine.

2. **For tower-resistant values** (Ω, algorithmically random constants): The tower never stabilizes. The CF method identifies the home d-family that the tower cannot reach. The `escalation_in_progress` classification is upgraded to `cf_home` or `cf_deep_home` with full CF provenance.

3. **For false resolution detection**: When the tower produces a sub-Koide hit at some N but the CF method shows a different d-family with higher quality, the CF result flags the tower hit as a likely false resolution — an independent structural check beyond the "2 additional landmarks" rule.

**CF home classifications (additions to the Step 3 table):**

| Classification | ε Criterion | d Criterion | CF Criterion | ET Derivation |
|---|---|---|---|---|
| **cf_deep_home** | \|ε_CF_micros\| ≤ 1955 | d = q_n (CF convergent denominator) | a_{n+1} ≥ ⌈1/K⌉² = 4 (quality exceeds squared Koide depth) | Value locks to CF-identified d-family with sub-Koide residual AND structurally significant quality. The threshold ⌈1/K⌉² = 4 is the Koide depth squared — a natural ET-derived quality floor |
| **cf_home** | 1955 < \|ε_CF_micros\| < 50000 | d = q_n | a_{n+1} ≥ ⌈1/K⌉² = 4 | Value locks to CF-identified d-family inside the lattice with significant quality, but outside the Koide attractor |
| **cf_marginal** | any | d = q_n | 1 < a_{n+1} < ⌈1/K⌉² = 4 | CF convergent exists but quality is below the structural significance threshold — record but do not treat as definitive home |

The CF quality threshold ⌈1/K⌉² = ⌈3/2⌉² = 2² = **4** is the natural ET-derived minimum: it squares the Koide stability depth, requiring the CF lock-on to be at least as structurally significant as the tower's depth-2 criterion raised to the next integrative level. The threshold is not ad hoc — it is ⌈1/K⌉ applied twice: once for depth, once for quality.

**Canonical example — Chaitin's Ω:**

The LCM tower fails for Ω: d changes at every landmark through 33 landmarks up to lcm(1..97). The CF method succeeds:

- CF expansion of |log₂(Ω)| yields convergent n=3: p/q = 608/87
- Following partial quotient a₄ = 157 (quality factor)
- d_home = 87 = 3 × 29
- ε_CF = +0.001003¢ = 1.003 micro-cents
- This is sub-Koide by factor **1955 exactly** — the Koide residual itself (|ε| = 1.955¢ / 1955 = 0.001¢)
- Quality 157 dwarfs all other convergents' qualities, unambiguously identifying d = 87
- Classification: **cf_deep_home** (sub-Koide residual AND quality 157 >> 4)
- Gaussian signature of d=87: 87 = 3 × 29; 3 ≡ 3 mod 4 (D-type inert), 29 ≡ 1 mod 4 (D+T split) → mixed inert-split character
- The CF quality factor 157 maps to CF elegance: 157/158 × (N/87) × (100/100.001) — near-maximal structural resonance

**Integration with the elegance framework:**

The CF quality factor provides a dimension of structural information the tower cannot:

- **Tower-only values** have elegance computed from (N/d) × tightness × simplicity — no quality dimension
- **CF-characterized values** have an additional **CF quality elegance factor** = a_{n+1}/(a_{n+1}+1) that ranks how strongly the value is locked to its home family
- The `projections` table gains a new stored field: `cf_quality INTEGER` — the CF quality factor a_{n+1} (NULL for tower-convergent values, populated for all values where CF analysis was performed)
- The `values` table gains: `cf_home_convergent_p INTEGER`, `cf_home_convergent_q INTEGER`, `cf_quality INTEGER` — the CF convergent p/q and quality factor identifying the value's CF home

**CF events and relationships:**

New event class: `cf_home_identified` — fires when the CF method identifies a home d-family for a value. Metadata: `{convergent_index_n, p, q, quality_a_next, eps_cf_micros, d_home, gaussian_signature, all_convergents_blob}` — captures the full CF analysis including all convergents for audit.

New event class: `cf_tower_disagreement` — fires when the CF method identifies a different d-family than the LCM tower's current best candidate. Metadata: `{tower_d, tower_N, cf_d, cf_quality, tower_false_resolution_probability}` — this is a structural diagnostic indicating the tower hit is likely a false resolution.

New relationship class: `cf_convergent_home` — links a value to its CF-identified home d-family with full CF provenance. Metadata: `{convergent_n, p, q, quality, eps_cf_micros, cf_elegance}`.

New relationship class: `cf_tower_confirmation` — links a value's CF home to its tower-stabilized home when both methods agree. Metadata: `{cf_d, tower_d, agreement_confirmed, cf_quality, tower_landmark_count}`. When both methods agree, the home classification is maximally confirmed.

New pattern class: `cf_quality_attractor` — recurring pattern of values from different domains sharing the same CF quality factor or CF home d-family. When multiple values lock onto the same d via the CF method with similar quality, this is a structural attractor in the CF space.

At each N in the escalation, evaluate:

The full escalation produces a TRAJECTORY — the sequence of (N, k, d, ε, home_classification) at each resolution. This trajectory is itself a structural object:

- Stored as a `tower_trajectory` pattern in the database
- Each step stored as a projection entry at the corresponding N
- Home classification recorded as a `home_classification` relationship at each N
- False resolutions explicitly flagged
- The trajectory reveals which d-families the value visits, where it stabilizes, where it transitions, and what its structural character is

**Step 5 — Populate all structural context at every resolution visited.**

At EVERY N in the trajectory (not just the home), materialize:
- All derived properties (elegance, coupling, variance, FQG quadrant, palindromic partner)
- Attractor membership (is this address already occupied at this N?)
- Generator coverage (does a known generator produce this value?)
- Nearest neighbors (what known values are structurally closest at this N?)
- Cross-domain relationships (does this value share an address with anything from another domain at this N?)
- d-family membership across both axes (real and imaginary, if applicable)

**Step 6 — Memoize everything.**

Every projection computed in the escalation, every derived property, every relationship discovered — stored permanently at 120 dps. The next time any program asks about this value at any resolution, it's a cache hit.

**The complete operational flow:**

```
Value enters (Path A/B/C/D)
    ↓
[Path A/B/C] Evaluate at 120 dps (MPFR 400-bit, zero floats) → r known
[Path D] Structural placement → resolution determined
    ↓
Project at N=12 → record (k, d, ε in micro-cents, properties, relationships)
    ↓
Classify step at 12ET (integer comparison on eps_micros)
    ↓
    ┌───────────────────────────────────────────────────────────────────┐
    │ PARALLEL: CF Home-Finding (§7.11 Step 3a)                        │
    │                                                                   │
    │ Compute continued fraction of |log₂(r)|                          │
    │ For each convergent p_n/q_n, record a_{n+1} (following partial   │
    │   quotient = quality factor)                                      │
    │ Identify the convergent with maximal a_{n+1}                      │
    │ d_cf = q_n from that convergent                                   │
    │ ε_cf = (N·log₂(r) − p_n) × 1200/N cents                          │
    │ E_CF = a_{n+1}/(a_{n+1}+1) × (N/d_cf) × tightness              │
    │                                                                   │
    │ If a_{n+1} ≥ ⌈1/K⌉² = 4:                                        │
    │   cf_deep_home  (|ε_cf| ≤ 1955 micro-cents AND quality ≥ 4)      │
    │   cf_home       (|ε_cf| < 50000 micro-cents AND quality ≥ 4)     │
    │   cf_marginal   (quality < 4 — weak lock, continue tower)         │
    │ → fire cf_home_identified event                                   │
    │ → record cf_home_convergent_p/q/quality on values row             │
    │ → record cf_quality on projection row                             │
    │ → if tower also converged: fire cf_tower_confirmation or          │
    │   cf_tower_disagreement as appropriate                            │
    └───────────────────────────────────────────────────────────────────┘
    ↓ d not yet stable across ⌈1/K⌉ = 2 consecutive LCM landmarks
Escalate to N=60 → record everything
    ↓
Classify step at 60ET, check d-stability
    ↓ not yet stable (or verifying past sub-Koide hit)
Escalate to N=420 → record everything
    ↓
...continue through LCM landmarks indefinitely...
    (the tower is infinite — lcm(1..k) for k=4,5,7,9,11,13,17,19,23,29,...)
    (the doubling law τ(N_ℓ) = 6·2^ℓ governs growth at each level)
    (there is NO termination — the algorithm runs until d stabilizes)
    (the CF method runs in parallel at the FIRST landmark — it does not
     need the tower to stabilize; it works on r directly)
    ↓
Home found via LCM tower: d stable across 2 consecutive landmarks + verified across 2 more
    → record as true_home / deep_home / persistent_home
    (true_home: eps_micros = 0 exactly)
    (deep_home: |eps_micros| ≤ 1955 — at or inside the Koide attractor)
    (persistent_home: 1955 < |eps_micros| < 50000 — inside lattice, outside Koide attractor)
    (Irrationals DO find homes — φ at d=10, ζ(3) at d=693. The home is the d-family
     stabilization, not ε=0. The Asymptotic Approach Theorem guarantees ε→0 as N→∞
     but ε>0 for irrationals at every finite N. The structural classification IS determined
     when the d-family stabilizes across consecutive LCM landmarks.)
    → if CF also fired: compare. Agreement = cf_tower_confirmation relationship.
       Disagreement = cf_tower_disagreement event (investigate).
    ↓
OR: Home found via CF method only (tower never stabilized):
    → this is the pathway for algorithmically random values (Ω, BBP-type constants,
     values with effectively unbounded irrationality measure)
    → the tower records false resolutions and escalation_in_progress
    → the CF method provides the structural home that the tower cannot
    → record as cf_deep_home or cf_home depending on ε and quality
    → the quality factor a_{n+1} quantifies confidence in the assignment
    → canonical example: Ω (Chaitin's constant) — tower fails through 33 landmarks
       up to lcm(1..97), every new prime changes d; CF gives p/q = 608/87,
       a₄ = 157, d = 87 = 3×29, ε = +0.001003¢ (sub-Koide by factor 1955 exactly)
    ↓
OR: session ends before home found (by either method)
    → record as escalation_in_progress with partial trajectory in the .akashic file
    → resume in next session from last computed landmark (all intermediate projections memoized)
    → the algorithm NEVER gives up; the home WILL be found across as many sessions as needed
    ↓
Record complete tower trajectory as pattern
    ↓
Check for false resolutions in the trajectory
    (sub-Koide hits where d changed at a higher landmark → mark false_resolution)
    ↓
All data memoized permanently at 120 dps (MPFR 400-bit, zero floats, zero precision loss)
```

**This procedure runs for EVERY value entering the EUDD — bootstrap values, file-ingested seeds, manual inputs, API submissions, discovered generators, self-recorded metrics. No exceptions.**

**Implementation requirements for the CF method (Step 3a):**

- The C++ engine must implement continued-fraction expansion of |log₂(r)| at 120 dps (MPFR 400-bit), extract the quality factor a_{n+1} for each convergent, and compute the CF-to-elegance mapping E_CF = a_{n+1}/(a_{n+1}+1) × (N/d) × tightness
- The API (§7.15 when specified) must expose CF-aware variants of the escalation command — `escalate` returns CF results (d_home, quality, ε_CF, classification) alongside the tower trajectory
- The test suite must include CF-specific test cases: Chaitin's Ω (expected: d=87, quality=157, ε=+0.001003¢, cf_deep_home), and other algorithmically random constants where the LCM tower is expected to fail and the CF method must succeed

### 7.12 File ingestion — feed it any file

The EUDD accepts any file as input. The file becomes a SOURCE of dimensionless seeds that project onto the Sempaevum. **All data is ingested through the §7.11 core projection procedure BEFORE it can be displayed.** Nothing is ever displayed raw — the GUI always shows ingested content from the .akashic file, never the raw input. This applies to static files and continuous streams alike.

The pipeline for every file: **extract seeds → run each seed through §7.11 (12ET escalation, home classification, false resolution detection, full trajectory) → store in .akashic → available for display and query.** One file → potentially thousands of fully-populated lattice addresses, each with complete tower trajectory and structural context.

Files can also be RETRIEVED from the EUDD. Any stored content that originated from a file retains its provenance (source file, extraction method, seed index). The EUDD can reproduce the structural content of any ingested file on demand.

**Per-file-type adapter specifications:**

**CSV:** Column selection via GUI dialog. Auto-detection attempted first: delimiter (try comma, tab, semicolon, pipe — whichever produces the most consistent column count), header row (first row is header if it contains non-numeric strings), R₀ (if column headers contain unit strings like "Hz", "Pa", "m/s", the Manager matches against bootstrap R₀ references from §3.17 and proposes the inferred R₀). Auto-detection results are presented to the user for confirmation before ingestion proceeds. If auto-detection fails or the user overrides: manual column picker (which column(s) contain values) + manual R₀ entry (120-dps decimal or selection from bootstrap catalog). Each selected cell value becomes one dimensionless seed via Path A (value ÷ R₀).

**PDF/Markdown:** Processed by the compressor's general-purpose Δk pipeline, the same as any other binary file. The raw bytes of the PDF become lattice content through that pipeline. No special extraction, no regex scanning, no equation parsing — the file IS the input, not a container to reach into. If specific numerical values from a document are needed (a mass ratio, a coupling constant, a verification value), they are entered directly via manual input (§7.13) or placed in a CSV — formats designed for specific data. The PDF as a whole file gets the same structural decomposition as any other file.

**Raw binary:** The compressor's existing Δk extraction pipeline processes the file. The adapter ingests the resulting Δk patterns and archetype matches into the EUDD. No new extraction logic needed — the compressor IS the binary adapter.

**Image:** Three extraction strategies, user-selectable via GUI:
- **Per-pixel**: r = pixel_value / max_channel_value (e.g., ÷255 for 8-bit). One seed per pixel. Produces large seed counts — suitable for small images or regions of interest.
- **Region-averaged**: user draws a grid overlay on the image; each grid cell's average pixel value becomes one seed. Produces manageable seed counts for large images.
- **Frequency-domain** (default): 2D FFT applied to the image. Peak spatial frequencies extracted as ratios to image dimensions. Structurally meaningful — spatial frequency content often carries lattice-relevant information that raw pixel values do not.

**Audio:** The raw audio waveform is a continuous signal projected onto the lattice via the lossless bijection (§3.18.1, continuous-discrete corollary) — no information loss, no Nyquist limit, no quantization floor. FFT with configurable window size (default: 4096 samples = 2^N, ET-derived from the digital tower's base resolution). Overlap: default 50%. Peak frequencies extracted as ratios to R₀ = sample_rate. Each ratio is projected through §7.11 and stored losslessly — the continuous frequency value IS exactly recoverable from the lattice address via the bijection pullback. Harmonic series detection: if extracted peaks form a harmonic series (f, 2f, 3f, ...), the fundamental frequency is the primary seed and the harmonics are recorded as power-pair relationships (k-scaling by integer n). One audio file → one set of spectral seeds per FFT window, with temporal evolution tracked as a sequence of projection events.

**Sensor data streams (continuous):** Continuous streams are the paradigm case of the continuous-discrete corollary (§3.18.1): each continuous reading is projected onto the lattice via the lossless bijection, eliminating the information loss inherent in conventional ADC sampling. Each reading is ingested through §7.11 as it arrives (real-time) or in batch (post-collection). R₀ selected from bootstrap reference catalog (§3.17) based on sensor domain — GPS uses Earth radius or light-time-second, atmospheric uses standard pressure/temperature, electrical uses reference voltage/current/impedance, etc. After each reading is ingested and stored in .akashic, the GUI can display the live lattice trajectory of the stream — but the display always shows FROM the .akashic file, never the raw stream directly. Anomaly detection: when a reading's projection lands at a d-family that is >2 standard deviations from the running d-family distribution for that sensor, `sensor_anomaly_detected` event fires. The threshold is statistical — it adapts to the sensor's actual behavior over time, not a fixed cutoff.

**Python/ETPL script output:** Numerical results captured from stdout or structured output. Each numeric value becomes one seed. The script's source file is recorded as provenance.

**Any other file:** The compressor processes it into lattice content via its general-purpose Δk pipeline. The resulting patterns and archetype matches are ingested. If the compressor cannot process the file type, the Manager rejects with an error and logs the rejection — the rejection IS a Descriptor Gap pointing to a missing ingest adapter (§7.14 `ingest_adapter` JSON extension can define a new one).

**New file types:** When the Manager encounters a file extension it doesn't recognize, it attempts the compressor's general-purpose pipeline. If that fails, the gap is logged and the user can define a new ingest adapter via the §7.14 JSON extension mechanism (`extension_type: "ingest_adapter"`).

### 7.13 Manual input — values, projections, bijection triples, text, and backbone operations

The GUI provides seven manual entry modes covering all three generator backbone layers (§7.1b) plus direct value, projection, bijection triple, and text entry. All modes produce the same result: content processed through the core projection procedure (§7.11) with complete tower trajectory and structural context. Real-time preview: as you type in any mode, the system shows the projected lattice address BEFORE you submit.

**Mode 1 — Direct value (L₃ backbone — binary EML tree):**
Type `1836.15267343` or `m_p/m_e` or `ζ(3) × π / φ²` or any mathematical expression. The system:
1. Determines the input path (A if numerical, B if convergent expression, C if structural descriptor)
2. Evaluates the expression at 120 dps via MPFR/Arb
3. Runs the full §7.11 escalation: 12ET → 60ET → 420ET → ... → home found (d-family stabilized)
4. Records complete tower trajectory with home classification at every N
5. Materializes all derived properties at every resolution visited
6. Checks attractor membership, generator coverage, nearest neighbors, cross-domain relationships at every N
7. Stores everything permanently
8. Displays the complete structural profile in the GUI — tower trajectory, home classification, family memberships, relationships

**Mode 2 — Logical description (L₁ backbone — logical pattern):**
Type a natural language or structured description: "the ratio of electron mass to proton mass", "Apéry's constant", "the 47th prime". The system resolves the description to a value at 120 dps, then runs the full §7.11 escalation. The L₁ description is stored as the generator's logical-layer representation.

**Mode 3 — Lattice operation (L₂ backbone — cascade/k-arithmetic):**
Type a lattice operation: "k=7 at N=12, escalate", "palindromic partner of d=3", "LCM tower from N=12 to N=27720 for r=φ". The system computes the operation, ingests all resulting values through §7.11. The L₂ operation is stored as the generator's cascade-layer representation.

**Mode 4 — Enter a projection:**
Type `k=130, d=6, ε=+12.16¢, N=12`. The system:
1. Uses the bijection pullback: r = 2^((130 + 12.16·12/1200)/12) → recovers the exact value at 120 dps
2. Runs the full §7.11 core escalation from 12ET through the LCM tower
3. Records complete tower trajectory, home classification, all structural context

**Mode 5 — Enter a bijection triple:**
Type `(k, d, ε)` at a specified N. Same as Mode 4 — the bijection pullback recovers r, then full §7.11 escalation.

**Mode 6 — Computation:**
Type any computable expression. The Manager evaluates at 120 dps (memoized — if this computation was done before, the result is retrieved from cache instantly). The result is ingested through §7.11. The computation itself is stored as an equation entry linking input and output addresses.

**Mode 7 — Text:**
Paste or type any text — a paragraph from a paper, a sentence, a label, a description, raw prose. The text is processed as raw bytes through the compressor's general-purpose Δk pipeline, the same as any binary file. The text becomes lattice content through structural decomposition of its byte stream. Provenance records that this content was entered as text via manual input. This is the correct pathway for inputting textual content that is not a mathematical expression (Mode 1), a logical description resolvable to a value (Mode 2), or a lattice operation (Mode 3) — it is the manual-input analog of file ingestion (§7.12), applied to user-provided text rather than a file on disk.

In all seven modes: **one input → full tower escalation → complete lattice population.** The Sempaevum does the rest. The core projection procedure (§7.11) is the same whether the input comes from a file, a manual entry, an API call, a stream, or the bootstrap. The manual input module is the human interface to the virtual Sempaevum.

### 7.14 Adaptive extension — the living database

The EUDD is a living system. It must accept and detect new categories, new structural types, and new organizational patterns as they emerge — without requiring format redesign or manual schema migration. This is the Descriptor Gap Principle applied to the database itself: **when the EUDD encounters something it cannot classify with existing categories, that gap IS a Descriptor pointing to a new category needed.**

**The exe must be running for all database connections.** The EUDD Manager is the gatekeeper. All reads and writes from all connected programs pass through the running Manager. This ensures:
- **Stability**: no concurrent direct-write corruption; the Manager serializes all mutations
- **Auto-detection**: the Manager monitors incoming data for patterns that don't fit existing categories and flags or auto-creates new ones
- **Consistency**: every write triggers the §7.11 core escalation procedure; no data enters without full structural processing
- **Self-recording**: every operation is itself recorded (§3.1b)

**Adaptive category extension via JSON — the full specification:**

New structural categories are defined via JSON files that the running Manager accepts. All JSON extensions are **strictly validated** — invalid JSON is rejected and never enters the system. There are **12 extension types**: 11 bootstrap types covering every extensible structure in the EUDD, plus one meta-type (`extension_type_definition`) that defines new extension types, making the set open-ended.

**Common fields required on ALL extension JSON files:**

```json
{
  "extension_type": "<one of the 12 types>",
  "description": "Human-readable purpose of this extension",
  "proposed_by": "Who or what created this (user name, program ID, etc.)",
  "timestamp": "2026-05-03T00:00:00Z"
}
```

**The 12 extension types — each structurally distinct, forced by what it IS:**

**1. `event_class`** — defines a new kind of structural event that can happen.

Required fields: `class_name` (string), `metadata_schema` (object: field_name → data_type mapping for the event's metadata_blob). Optional: `parent_class` (string, extends an existing event class).

```json
{
  "extension_type": "event_class",
  "class_name": "quantum_entanglement_detected",
  "metadata_schema": {
    "bell_inequality_violation": "REAL",
    "entangled_pair_value_ids": "[INTEGER]",
    "decoherence_rate_estimate": "REAL",
    "measurement_basis": "TEXT"
  },
  "parent_class": "decoherence_state_transition",
  "description": "Bell inequality violation confirmed between two lattice addresses",
  "proposed_by": "conscious_ai_v1.7.0",
  "timestamp": "2026-05-02T00:00:00Z"
}
```

**2. `relationship_class`** — defines a new kind of connection between entities.

Required fields: `class_name` (string), `metadata_schema` (object), `subject_types` (array of entity types that can be subjects: `"value"`, `"projection"`, `"address"`, `"equation"`, etc.), `object_types` (array of entity types that can be objects), `is_symmetric` (boolean — e.g., `same_address` is symmetric; `derivation_dependency` is directional). Optional: `parent_class`.

**3. `pattern_class`** — defines a new kind of discovery the engine can produce.

Required fields: `class_name` (string), `metadata_schema` (object), `member_entity_types` (array of what can be a member of this pattern type). Optional: `promotion_criterion` (object describing how E_hierarchy is computed for this pattern type — if omitted, standard ∏E_i formula applies), `parent_class`.

**4. `tower_definition`** — creates a new Multifold tower (a new perspective on the Sempaevum).

Required fields: `tower_name` (string, unique), `p_substrate_descriptor` (string), `r0_value` (120-dps decimal string) OR `r0_expression` (symbolic expression the Manager evaluates), `r0_natural_units` (string), `operational_n` (integer, the dominant resolution). Optional: `parent_tower_name` (string, references existing tower), `physics_metadata` (object, substrate-specific properties).

Manager auto-computes: `accessible_d_families_mask` from `operational_n`, `nesting_depth` from parent chain. Runs §7.11 escalation on the R₀ value.

**5. `sublattice_family_catalog`** — triggers computation of the divisor structure for a new resolution N.

Required fields: `n` (integer, the resolution). Optional: `tower_name` (string, context tower). The Manager auto-computes ALL divisor families of N — the JSON just triggers the computation. Minimal input, maximum auto-derivation.

**6. `harmonic_family_extension`** — adds a harmonic family beyond the base 24 at higher resolutions.

Required fields: `axis` (`"real"` or `"imaginary"`), `d` (integer), `family_name` (string), `generator_value` (120-dps decimal string for 2^(1/d)), `palindromic_partner_d` (integer), `gaussian_prime_class` (string), `first_native_lattice_n` (integer), `physical_meaning` (string).

Manager validates: `generator_value` matches 2^(1/d) at 120 dps. Reject if mismatch.

**7. `force_grid_extension`** — adds a grid cell at higher resolution.

Required fields: `d_r` (integer), `d_theta` (integer). Optional: `canonical_particle_or_phenomenon` (string).

Manager auto-computes: `d_combined` = LCM(d_r, d_theta), `is_off_axis`, `is_lcm_amplification`, `is_full_resolution`.

**8. `combined_family_extension`** — adds a combined family beyond the base 42.

Required fields: `d_combined` (integer), `range_class` (string), `structural_meaning` (string), `gaussian_factorization` (string), `first_native_lattice_n` (integer).

Manager validates: `d_combined` is a valid LCM of at least one (d_r, d_theta) pair. Reject if no valid pair exists.

**9. `ingest_adapter`** — teaches the Manager how to digest a new file type.

Required fields: `file_type` (string), `file_extensions` (array of strings, e.g., `[".hdf5", ".h5"]`), `extraction_method` (string describing how seeds come out), `r0_strategy` (`"user_specified"`, `"auto_detect"`, or `"fixed"`). Optional: `r0_fixed_value` (120-dps decimal, required if r0_strategy is `"fixed"`).

**10. `bootstrap_entry`** — adds a new bootstrap value after initial generation.

Required fields: `value_repr` (string, canonical name), `value_decimal` (120-dps decimal string), `input_path` (`"A"`, `"B"`, `"C"`, `"D.P"`, `"D.D"`, `"D.T"`, `"D.PDT"`). Optional: `r0_description` (string), `tags` (array of `{namespace, value}` pairs).

Manager runs full §7.11 escalation on ingestion — same as any other value.

**11. `query_template`** — defines a reusable query the GUI can offer as a one-click action.

Required fields: `template_name` (string), `query_pattern` (string, parameterized template), `parameters` (array of `{name, type, description}` objects), `result_format` (string describing how to present results).

**12. `extension_type_definition`** — the meta-type: defines a NEW extension type that becomes available for all future JSON extensions.

This is the Descriptor Gap Principle applied to the extension system itself. The 11 types above are the bootstrap set; this meta-type makes the set open-ended. If the 11 types don't cover what's needed, the gap IS a Descriptor — and this meta-type resolves it.

Required fields:
- `type_name` (string — the new extension type name, e.g., `"sensor_domain"`, `"lattice_geometry"`, `"traverser_taxonomy"`)
- `required_fields` (array of `{name, type, description, required}` — the schema for all future instances of this type; valid types: `"string"`, `"integer"`, `"real_120dps"`, `"array"`, `"object"`, `"boolean"`)
- `storage_target` — where instances live: `"new_table"` (creates a new table), `"existing_table_extension"` (adds columns, specify `storage_target_table`), `"event_class"` / `"relationship_class"` / `"pattern_class"` (instances become new classes in those tables), or `"standalone"` (stored as self-contained JSON blobs)
- `subsumption_check` (boolean — if true, Manager verifies this new type is NOT already subsumed by an existing type; if fully subsumed → reject with "redundant with existing type X")

Optional fields:
- `optional_fields` (array, same structure as required_fields)
- `inherits_common_fields` (boolean, default true — inherits extension_type, proposed_by, timestamp, description)
- `auto_compute_fields` (array of `{name, computation_method, source_fields}` — fields the Manager derives automatically after ingestion)
- `validation_rules` (array of `{rule_name, condition, error_message}` — type-specific validation beyond basic type-checking)
- `foreign_key_references` (array of `{field_name, target_table, target_field}` — the Manager validates these on ingestion)
- `storage_target_table` (string, required when storage_target is `"existing_table_extension"`)

Example — defining a new `sensor_domain` extension type:

```json
{
  "extension_type": "extension_type_definition",
  "type_name": "sensor_domain",
  "description": "Defines a new real-world sensor domain with bootstrap R₀ values for Path A projection",
  "required_fields": [
    {"name": "domain_name", "type": "string", "description": "Human-readable domain name", "required": true},
    {"name": "r0_references", "type": "array", "description": "Array of {name, value_120dps, units} reference R₀ values", "required": true},
    {"name": "measurement_types", "type": "array", "description": "Array of {name, units, typical_range} measurement kinds", "required": true}
  ],
  "optional_fields": [
    {"name": "dimensional_cancellation_rules", "type": "array", "description": "How raw measurements become dimensionless via R₀", "required": false},
    {"name": "anomaly_thresholds", "type": "object", "description": "Per-measurement-type thresholds for sensor_anomaly_detected events", "required": false}
  ],
  "inherits_common_fields": true,
  "auto_compute_fields": [
    {"name": "r0_projections", "computation_method": "Project each R₀ value through §7.11 core escalation", "source_fields": ["r0_references"]}
  ],
  "validation_rules": [
    {"rule_name": "r0_nonempty", "condition": "r0_references array has at least one entry", "error_message": "Sensor domain must have at least one R₀ reference"},
    {"rule_name": "r0_parseable", "condition": "Every r0_references[].value_120dps is parseable as 120-dps decimal", "error_message": "R₀ value not parseable at 120 dps"}
  ],
  "storage_target": "existing_table_extension",
  "storage_target_table": "tags",
  "foreign_key_references": [],
  "subsumption_check": true,
  "proposed_by": "manual",
  "timestamp": "2026-05-03T00:00:00Z"
}
```

After acceptance, `sensor_domain` becomes a valid `extension_type` in all future JSON extensions.

**Strict validation — all JSON extensions:**

All JSON is strictly validated before entering the system. Invalid JSON is rejected and never affects the database. Validation rules:

1. Well-formed JSON with all required fields present and correctly typed
2. `extension_type` must be one of the 12 known types OR a type previously defined via `extension_type_definition`
3. **Name collision detection**: `class_name`, `tower_name`, `template_name`, `file_type`, `type_name` must NOT collide with existing names. Collision → strict reject, logged as an Omniscient error event with the conflicting names
4. **Foreign key validation**: references to existing entities (`parent_tower_name`, `parent_class`, `storage_target_table`) must point to entities that actually exist in the database. Missing referent → strict reject
5. **Numeric validation**: d > 0, N > 0, `operational_n` must be a valid resolution
6. **Precision validation**: all 120-dps decimal strings must be parseable by the MPFR stack. Unparseable → strict reject
7. **Schema conflict detection**: `metadata_schema` field names must not conflict with existing schema columns in the target table
8. **Generator verification**: for `harmonic_family_extension`, Manager verifies `generator_value` matches 2^(1/d) at 120 dps. Mismatch → strict reject
9. **LCM verification**: for `combined_family_extension`, Manager verifies `d_combined` = LCM(d_r, d_theta) for at least one valid pair. No valid pair → strict reject
10. **Subsumption check**: for `extension_type_definition` with `subsumption_check: true`, Manager verifies the new type is NOT already fully expressible through existing types. Redundant → strict reject with explanation of which existing type subsumes it
11. **Structural conflict**: new `tower_definition` with same R₀ as existing tower but different substrate → flag for user review (could be intentional — two towers at different integrative levels sharing R₀), not auto-rejected

**Versioning:**

Every JSON extension applied receives a monotonically increasing version number per `extension_type`. Recorded in the `schema_versions` table: version number, applied_at timestamp, description, the full JSON stored as migration content. Old versions are archived, never deleted. The Manager reports "what extensions have been applied and when" via the GUI dashboard.

For `extension_type_definition` evolution (adding fields to a previously-defined type): a new version is applied. Old instances remain valid under the old version. New instances must comply with the current version. Missing fields on old instances are treated as NULL — same forward-compatibility model as §7.6.

**Auto-detection of needed categories:**

When data arrives that the Manager cannot classify into any existing category, the Descriptor Gap Principle fires:

1. **Gap detected**: incoming data has structural properties not captured by any existing event/relationship/pattern class
2. **Gap IS a Descriptor**: the Manager creates a provisional category tagged `status=provisional`, logs the gap detection as a self-recording event
3. **Human review**: the provisional category appears in the GUI dashboard for Mike's review — accept, modify, or reject
4. **If accepted**: the category becomes permanent; all historical data that matched the provisional category is retroactively classified
5. **If rejected**: the provisional category is archived (never destroyed — §4.3) with the reason for rejection

**The EUDD as a living system:**

The database grows in two dimensions simultaneously:
1. **Content growth**: more values, projections, equations, patterns, events — the lattice fills up
2. **Structural growth**: more categories, more family catalogs, more tower definitions, more relationship types, more extension types — the lattice's own organizational vocabulary expands

Both growths are recorded. Both are projected onto the Sempaevum (§3.1b). Both feed the discovery engine. The database IS living in the precise ET sense: it has P (the computational substrate), D (the schema and categories — growing), and T (the discovery engine and Manager — the agency that navigates and extends). P∘D∘T = E: the database as a running, self-extending Exception.

### 7.15 Omniscient — error handling, telemetry, and tamper detection

**Architecture:** On startup, the Manager spawns **Omniscient** as a child process — the same `EUDD_Manager.exe` binary running in watchdog mode (`EUDD_Manager.exe --omniscient`). Omniscient is a separate process observing the Manager. If the Manager dies, Omniscient survives and records the death. One file to distribute, two processes running. Omniscient is headless — no GUI.

**Identification Principle applied:** P = the Manager process (substrate being watched). D = every error, fallback, telemetry event (the constraints being recorded). T = the Omniscient process (the agency that observes, detects, and records). The watchdog IS a Traverser observing the Manager.

**Omniscient's responsibilities:**

1. **Error and event capture**: receives all errors, all runtime fallbacks, and all structural events (crash, tamper, corruption) from the Manager via shared memory IPC. Omniscient observes the Manager FROM OUTSIDE — it is a separate T watching the Manager's P∘D∘T operation.
2. **Error classification**: receives every error, every runtime fallback. **All runtime fallbacks are classified as errors** — the fact that recovery succeeded does not erase the failure. The only exceptions are **design filters**: platform or configuration branching (e.g., VSS on Windows / LVM on Linux) where the system is DESIGNED to take different paths. Design filters are logged as telemetry, not errors.
3. **Corruption detection**: periodically computes SHA-256 of `EUDD_Manager.exe` itself (baseline hash established at spawn time, re-checked on schedule) and SHA-256 of the `Sempaevum.akashic` header. Any change to the exe at any time = tampering. Any change to the .akashic file outside an authorized write window = tampering. The Manager signals Omniscient when authorized writes begin and end; modifications detected outside these windows are flagged as tamper events immediately.
4. **Crash recording**: Omniscient monitors the Manager's process handle. If the handle signals (Manager process died), Omniscient records the crash event with: timestamp, last-known Manager state, last error/telemetry received, exe hash at crash time, .akashic header hash at crash time. Omniscient stays alive after Manager death, flushes the journal, then exits cleanly.
5. **Self-error reporting**: Omniscient reports its own errors to the same journal. If Omniscient's own logging fails, it writes a final "OMNISCIENT_FAILURE" entry with whatever context it can still produce, then exits. Omniscient is deliberately minimal — less code means fewer ways to crash.

**Journal file format and storage:**

Journal files are stored in a `logs/` subfolder within the same folder as the exe and .akashic. Named with incrementing numbers: `Omniscient_001.log`, `Omniscient_002.log`, etc. Each file rotates at approximately 10 MB. Old log files are NEVER deleted — the logs/ folder grows indefinitely. Nothing is ever lost.

**Journal separation:** The `logs/` folder contains two journal series that are NEVER mixed:
- `Omniscient_NNN.log` — errors, runtime fallbacks, tamper events, crash events, design-filter telemetry. Written by the Omniscient watchdog process (observes the Manager FROM OUTSIDE).
- `SelfRecording_NNN.log` — operational metrics (§3.1b metric catalog). Written by the Manager's self-recording module directly (observes itself FROM INSIDE). Same format, same rotation, same retention policy.

Two different Traversers observing the same system from two different perspectives. Both journals use the same human-readable format:

```
[2026-05-03T14:22:01.847293Z] [ERROR] [computation] [LatticeEngine::project]
  expression: "ζ(−1) at N=12"
  failure: FLINT/Arb pole detected at s=−1
  input_value_id: 4827
  stack: LatticeEngine::project → ArbEval::zeta → pole_check
  recovery: annihilation_boundary_event logged
  manager_state_hash: 9a3f...

[2026-05-03T14:22:05.112000Z] [TELEMETRY] [performance] [MemoizationStore::lookup]
  operation: compute("2+2")
  latency_ns: 847
  cache_status: HIT
  equation_ref_count: 14203

[2026-05-03T14:22:09.500000Z] [ERROR] [fallback] [BackupModule::snapshot]
  intended_path: VSS atomic snapshot
  fallback_path: manual file copy
  reason: VSS service unavailable (error 0x80042302)
  recovery: manual copy succeeded in 2.3s
  note: fallback succeeded but this IS an error — VSS should be available

[2026-05-03T14:22:30.000000Z] [TAMPER] [integrity] [Omniscient::hash_check]
  target: Sempaevum.akashic
  expected_header_hash: a1b2c3d4...
  observed_header_hash: ff00ee11...
  authorized_write_window: CLOSED
  verdict: UNAUTHORIZED MODIFICATION DETECTED
```

Every entry: ISO-8601 timestamp with microsecond precision, severity level (`TELEMETRY`, `ERROR`, `TAMPER`, `CRASH`, `OMNISCIENT_FAILURE`), category, source module/function, then indented key-value context lines. Fully greppable by any field. Every error traceable to exact source location and full call stack.

**Ingestion into .akashic:** The Manager can ingest Omniscient journal files into the .akashic file as proper events — but ONLY when the user explicitly requests it. The journal files are fed into the Manager's existing file ingestion pipeline (§7.12) like any other file. No special ingestion mechanism is needed. The user decides when and whether to ingest. Automatic ingestion never occurs.

**Edge case catalog — every failure mode Omniscient monitors:**

**Computation edge cases:**
- MPFR overflow/underflow during 120-dps evaluation
- FLINT/Arb cannot evaluate a special function (ζ at a pole, Γ at a negative integer)
- Expression tree evaluation stack overflow (deeply nested EML trees)
- Division by zero / annihilation boundary approach (r→0)
- CF expansion not converging within iteration budget
- LCM tower escalation hitting platform integer limits (lcm(1..k) exceeds integer representation at some k)
- NaN or infinity produced by any lattice operation
- Hash collision in memoization store (two different canonical forms producing same SHA-256 — astronomically unlikely but must be detected, not silently corrupted)

**Storage edge cases:**
- Disk full during write to .akashic or to journal
- Page CRC-32 mismatch during live read (not backup — the running file is corrupted)
- WAL replay failure (corrupted WAL entry on crash recovery)
- Generator coverage interval tree inconsistency (generator claims an address range but evaluation produces wrong values)
- Address index pointing to nonexistent page
- Section directory offset pointing outside file bounds
- .akashic file locked by another process

**Communication edge cases:**
- Named pipe connection dropped mid-operation (connected program crashed)
- Malformed JSON received from connected program
- Connected program sends operation while previous async operation still running for the same value
- Connected program disconnects without completing handshake

**Resource edge cases:**
- Memory exhaustion during computation or discovery scan
- File handle exhaustion (too many concurrent named pipe connections)
- Background discovery scan exceeding time budget
- GUI render thread starved by computation (Manager only — Omniscient is headless)

**Logic edge cases:**
- Discovery engine finds contradictory patterns (two patterns claiming the same address with conflicting generators)
- Cross-project consistency check finds contradiction between two values at the same address with different (k, d)
- Generator evaluation produces different value than the stored memoized entry at the same address
- Subsumption promotion creates cycle (pattern A subsumes B which subsumes A)

**Self-referential edge cases:**
- Self-recording module (§3.1b) fails while recording its own metrics
- Omniscient's own journal write fails (disk full, permission denied) — Omniscient writes OMNISCIENT_FAILURE entry and exits
- Backup verification (§7.9) finds corruption in the live .akashic file (not a backup — the running database)
- Omniscient detects its own exe hash changed (Omniscient itself was tampered with during runtime — theoretically possible via live patching)

**ET-native error philosophy:** Every failure is a Descriptor Gap (Descriptor Gap Principle). The failure itself is information — it points to what is missing. Omniscient stores every failure with full context. When journal files are ingested into .akashic, the discovery engine can scan failure events for structural patterns — e.g., "computation failures cluster at d=X" may reveal a structural boundary. Failures are NEVER discarded, suppressed, or silently ignored. They are first-class lattice content once ingested.

### 7.16 The Named Pipe API — Complete Specification

**Status:** This section closes Roadmap §1.3 (API Specification). All 79 operations are fully specified with exact JSON request/response schemas. Zero IEEE 754 floats cross the API boundary. The metabolism governs all resource allocation and priority via ET-derived structural constants.

**Pipe name:** `\\.\pipe\EUDD_Manager` (Windows named pipe). Each connected client gets its own pipe instance per Windows named pipe semantics. Multiple simultaneous clients supported.

**Wire format:** UTF-8 JSON, length-prefixed. Each message on the pipe is:
```
[4 bytes: uint32 big-endian message length in bytes] [UTF-8 JSON payload of exactly that length]
```

No delimiters, no newlines between messages. The length prefix ensures the receiver knows exactly how many bytes to read. Maximum message size: 2³⁰ bytes (1 GB = DISK_SAFETY_FLOOR, the d=1 octave action quantum at GB scale). Messages exceeding this are rejected with `message_too_large` error.

#### 7.16.1 Communication Architecture — Three Patterns

Every message over the pipe follows one of three communication patterns. The Manager selects the pattern based on what the operation structurally requires — the client does not choose.

**Pattern 1 — Request-Response (synchronous).**

The client sends one request. The Manager sends one response. The client blocks until the response arrives. Used when the answer is available immediately: cache hits, index lookups, catalog queries, status checks, any operation that completes in sub-millisecond time.

```
Client → Manager:  { "msg_type": "request", ... }
Manager → Client:  { "msg_type": "response", ... }
```

**Pattern 2 — Request-Acknowledge-Stream-Complete (asynchronous with streaming).**

The client sends one request. The Manager immediately acknowledges with an `operation_id`, then streams zero or more intermediate results, then sends a completion message. Used for operations that take time: tower escalation (each landmark is a streamed result), file ingestion (each seed extracted is a streamed result), discovery scans (each finding is a streamed result), L'Hôpital resolution (each iteration is a streamed result). The client processes intermediate results in real-time. This is T navigating — the client sees each step of the Traverser's journey.

```
Client → Manager:  { "msg_type": "request", ... }
Manager → Client:  { "msg_type": "ack", "operation_id": "<uuid>", ... }
Manager → Client:  { "msg_type": "stream", "operation_id": "<uuid>", "sequence": 0, ... }
Manager → Client:  { "msg_type": "stream", "operation_id": "<uuid>", "sequence": 1, ... }
...
Manager → Client:  { "msg_type": "complete", "operation_id": "<uuid>", ... }
```

The client can cancel an in-progress async operation by sending:
```
Client → Manager:  { "msg_type": "request", "command": "cancel", "operation_id": "<uuid>" }
Manager → Client:  { "msg_type": "response", "cancelled": true, "partial_results_available": true }
```

Cancellation does NOT discard partial results — everything computed so far is memoized permanently (§4.3 never destroy). The client can query partial results via `get_value_trajectory` or other relevant queries.

**Pattern 3 — Subscribe-Notify (push).**

The client subscribes to a filter. The Manager pushes matching notifications as they happen, for the lifetime of the subscription. The subscription persists until explicitly unsubscribed or the connection closes.

```
Client → Manager:  { "msg_type": "request", "command": "subscribe", "filter": { ... } }
Manager → Client:  { "msg_type": "response", "subscription_id": "<uuid>" }
...later, asynchronously...
Manager → Client:  { "msg_type": "notification", "subscription_id": "<uuid>", ... }
Manager → Client:  { "msg_type": "notification", "subscription_id": "<uuid>", ... }
```

Notifications are interleaved with request-response and stream messages on the same pipe. The `msg_type` field distinguishes them unambiguously.

**Adaptive pattern selection.** Some operations adapt their pattern based on runtime conditions:
- `project`: Pattern 1 on cache hit (instant), Pattern 2 on cache miss (compute + store + return)
- `compute`: Pattern 1 on cache hit, Pattern 2 on cache miss
- `lattice_add`: Pattern 1 on cache hit, Pattern 2 on cache miss
- `evaluate_function`: Pattern 1 on cache hit, Pattern 2 on cache miss

For adaptive operations, the client must handle BOTH response types. The `msg_type` field tells the client which pattern fired: `"response"` means Pattern 1 (done), `"ack"` means Pattern 2 (streaming will follow).

#### 7.16.2 Message Envelope

Every message over the pipe contains these fields:

```json
{
  "msg_id": "<uuid>",
  "msg_type": "<request|response|ack|stream|complete|error|notification>",
  "api_version": 1,
  "timestamp_ns": "<uint64 as string>",
  "session_id": "<string>",
  "command": "<operation_name>",
  "operation_id": "<uuid>",
  "sequence": "<integer>"
}
```

| Field | Type | Present On | Description |
|---|---|---|---|
| `msg_id` | string (UUID) | ALL messages | Unique per message, for correlation and deduplication |
| `msg_type` | string enum | ALL messages | One of: `request`, `response`, `ack`, `stream`, `complete`, `error`, `notification` |
| `api_version` | integer | ALL messages | Protocol version. Currently 1. Manager and client negotiate during handshake; messages use the negotiated version |
| `timestamp_ns` | string (uint64) | ALL messages | Nanoseconds since Unix epoch. Exact integer as string (JSON cannot represent uint64 without precision loss). This is D-time — the global coordinate |
| `session_id` | string | ALL except `handshake` request | Set during handshake, included on all subsequent messages |
| `command` | string | `request` only | The operation name (e.g., `"project"`, `"compute"`, `"escalate"`) |
| `operation_id` | string (UUID) | `ack`, `stream`, `complete`, `error` (for async) | Correlates async messages to the originating request |
| `sequence` | integer | `stream` only | 0-indexed sequence number within an async operation's stream |

Additional payload fields are operation-specific and documented per-operation below.

**Timestamp encoding:** All timestamps throughout the API are uint64 nanoseconds since Unix epoch (1970-01-01T00:00:00Z), encoded as JSON strings to avoid IEEE 754 precision loss. Example: `"1714742400000000000"` for 2025-05-03T12:00:00Z. This is D-time — the relational ordering Descriptor, cardinality finite n.

#### 7.16.3 Value Encoding — Zero IEEE 754

**All numerical values crossing the API boundary are exact representations. No IEEE 754 floating-point numbers exist anywhere in any request or response.**

| Data type | JSON encoding | Example |
|---|---|---|
| 120-dps value | String, all 120 digits | `"1.202056903159594285399738161511449990764986292340498881792271555341838205786313090186455873609335258146199..."` |
| Lattice k | Integer | `7360` |
| Lattice d | Integer | `693` |
| ε (micro-cents) | Integer | `-1955` (meaning −1.955 cents) |
| Rational | Object `{"num": <int>, "den": <int>}` | `{"num": 2, "den": 3}` |
| Timestamp | String (uint64 nanoseconds) | `"1714742400000000000"` |
| Large integer | String | `"27720"` (for values that may exceed JSON integer range) |
| Boolean | Boolean | `true` |
| Binary blob | Base64 string | `"AQID..."` (for MPFR blobs, packed arrays) |
| Null / absent | `null` or field omitted | |

**Value representation in requests:** A value can be specified in multiple ways. The `value_spec` object is used throughout the API wherever a value is needed as input:

```json
{
  "value_spec": {
    "by": "<id|hash|repr|decimal|expression|address>",
    "value_id": 4827,
    "value_hash": "a1b2c3d4...",
    "value_repr": "ζ(3)",
    "decimal_120dps": "1.20205690315959...",
    "expression": "ζ(3) × π / φ²",
    "address": {"N": 27720, "k": 7360, "eps_micros": -85}
  }
}
```

Only the fields relevant to the `by` mode are required. The Manager resolves the value_spec to a concrete 120-dps value and value_id. If the value is new (not in the database), the Manager creates a `values` row automatically.

#### 7.16.4 Connection Lifecycle and Metabolism

**The connection lifecycle mirrors P∘D∘T = E:**
- **P (substrate):** The named pipe connection — the raw communication channel
- **D (constraints):** The API protocol, the metabolism budget, the negotiated capabilities
- **T (agency):** The connected program — the Traverser navigating the API

**Phase 1 — Connect.** Client opens the named pipe `\\.\pipe\EUDD_Manager`. The pipe connection IS the P-substrate.

**Phase 2 — Handshake.** Client sends `handshake` request. Manager responds with session_id, capabilities, negotiated api_version. The handshake establishes the D-constraints of the connection.

**Phase 3 — Register Metabolism.** Client sends `register_metabolism` with its hardware profile and operational characteristics. The Manager:
1. Creates a digital tower entry for this program (§3.10) with R₀ derived from the program's structure (frame rate, tick rate, clock cycle — whatever the natural traversal period is)
2. Computes the metabolic budget: K = 2/3 ceiling applied to available resources after accounting for existing connections, V = 1/12 headroom, ξ(d) coupling for the program's reported dominant computation family
3. Returns the metabolic budget to the client

**Phase 4 — Operation.** Client sends commands, receives responses. The metabolism governs resource allocation dynamically:
- The Manager tracks each connection's actual resource consumption (CPU time, memory, pipe bandwidth)
- The Manager adjusts metabolic budgets dynamically as connections come and go
- When a connection's consumption approaches K × (its share of total), the Manager throttles response delivery (not computation — computations still run and memoize; delivery is delayed)
- The per-sublattice coupling ξ(d) of the connection's dominant computation family determines scheduling weight relative to other connections

**Phase 5 — Disconnect.** Client sends `disconnect` or pipe closes. Manager logs session end, flushes pending writes, releases the connection's metabolic share back to the pool.

**Metabolic mediation across connections:**

When multiple programs are connected simultaneously (Skyrim + compressor + fractal generator + Mike's GUI), the Manager mediates using the metabolism:

Total system budget: K × hardware = 2/3 of CPU, RAM, VRAM.

Per-connection share: proportional to ξ(d_dominant) of each connection's dominant computation family, normalized to sum to K × hardware. A game doing d=1 physics (ξ=8.5625) gets ~8.5× the scheduling weight of a program doing d=12 computations (ξ=1.0).

The Manager's own operations (discovery engine, self-recording, GUI rendering) are a connection too — with their own metabolic budget drawn from the same K pool.

If total demand exceeds K × hardware, the Manager does NOT drop connections or reject operations. It queues operations and serves them as resources free up, prioritized by ξ(d). The K ceiling is a resource governor, not a gatekeeper. Every operation eventually executes; the metabolism determines WHEN.

#### 7.16.5 Error Response Format

Every error response:

```json
{
  "msg_id": "<uuid>",
  "msg_type": "error",
  "api_version": 1,
  "timestamp_ns": "<uint64>",
  "session_id": "<string>",
  "operation_id": "<uuid or null>",
  "error": {
    "code": 1001,
    "class": "computation_failure",
    "detail": "FLINT/Arb pole detected at s=−1 during ζ(−1) evaluation",
    "source_module": "ArbEval::zeta",
    "event_id": 847293,
    "recoverable": false,
    "suggestion": "Use Path D.T for pole values — they are indeterminate forms requiring L'Hôpital resolution"
  }
}
```

| Field | Type | Description |
|---|---|---|
| `code` | integer | Numeric error code. Range 1000–1999: computation. 2000–2999: input validation. 3000–3999: not found. 4000–4999: state/resource. 5000–5999: integrity. 6000–6999: communication |
| `class` | string | Error classification (see table below) |
| `detail` | string | Human-readable description with full context |
| `source_module` | string | C++ module and function where the error originated |
| `event_id` | integer | The event_id in the `events` table where this error was logged (every error IS an event per §7.15 ET-native error philosophy) |
| `recoverable` | boolean | Can the client retry this operation with the same input? |
| `suggestion` | string or null | ET-informed guidance on how to handle this error |

**Error classes:**

| Code Range | Class | Description |
|---|---|---|
| 1000–1099 | `computation_failure` | MPFR/Arb evaluation failed: pole, overflow, underflow, stack overflow, NaN, infinity |
| 1100–1199 | `annihilation_boundary` | Computation approached r=0 — off-lattice singularity. NOT a failure — correct structural classification |
| 1200–1299 | `incoherence_filter` | Input classified as {P,T} Incoherent. No lattice address assigned. Correct behavior, not a failure |
| 1300–1399 | `pure_t_detected` | L'Hôpital failed to resolve — irreducible Traverser. Correct classification, not a failure |
| 2000–2099 | `invalid_input` | Malformed request, unparseable value, unknown command, missing required field, type mismatch |
| 2100–2199 | `invalid_expression` | Expression cannot be parsed or is not well-formed |
| 2200–2299 | `validation_rejected` | JSON extension failed §7.14 strict validation (with specific rule that failed) |
| 3000–3099 | `value_not_found` | Value ID/hash/repr not in database |
| 3100–3199 | `entity_not_found` | Referenced entity (equation, relationship, pattern, tower, event, etc.) not found |
| 3200–3299 | `address_unoccupied` | Query targets an address with no content |
| 3300–3399 | `generator_not_found` | No generator covers the queried address/value |
| 4000–4099 | `manager_busy` | Manager cannot accept new async operations (internal queue at capacity) |
| 4100–4199 | `disk_low` | Disk free < DISK_SAFETY_FLOOR (1 GB). Warning — operations continue but the user should free space |
| 4200–4299 | `metabolism_throttled` | Operation queued due to metabolic ceiling — will execute when resources free up. Includes estimated wait |
| 4300–4399 | `atomicity_violation` | Atomic batch_store failed — all values rolled back. Includes per-value failure reasons |
| 5000–5099 | `corruption_detected` | Integrity check found corruption. Operations continue but results may be unreliable until backup restoration |
| 5100–5199 | `consistency_violation` | Cross-project consistency check found contradictory projections |
| 6000–6099 | `pipe_error` | Named pipe communication failure |
| 6100–6199 | `message_too_large` | Message exceeds 2³⁰ byte limit |

Note: error codes 1100–1399 (`annihilation_boundary`, `incoherence_filter`, `pure_t_detected`) are NOT failures — they are correct structural classifications per ET. The Manager reports them as errors (because the operation did not produce a standard lattice result) but they carry full structural information about what WAS found. The `recoverable` field is `false` for these because retrying will produce the same correct classification.

---

#### 7.16.6 Domain 1 — Connection & Metabolism

**Operation 1: `handshake`**

Pattern: Request-Response

Establishes the connection. Must be the first message after pipe open.

Request:
```json
{
  "msg_type": "request",
  "command": "handshake",
  "api_version": 1,
  "client": {
    "project_name": "skyrim_bridge",
    "client_type": "game",
    "client_version": "1.0.0",
    "pid": 12345,
    "requested_api_version": 1
  }
}
```

Response:
```json
{
  "msg_type": "response",
  "session_id": "skyrim_bridge_2026-05-03_001",
  "api_version": 1,
  "server": {
    "manager_version": "1.0.0",
    "akashic_file_size_bytes": "1073741824",
    "total_values": "847293",
    "total_projections": "6778344",
    "total_equations": "12847291",
    "total_generators": "4827",
    "total_memoized": "842466",
    "generator_to_memoized_ratio": {"num": 4827, "den": 847293},
    "active_connections": 3,
    "uptime_ns": "86400000000000"
  }
}
```

**Operation 2: `register_metabolism`**

Pattern: Request-Response

Registers the program's metabolic profile. Creates a tower for this program. Returns metabolic budget. Must be called after `handshake`, before any computation operations.

Request:
```json
{
  "msg_type": "request",
  "command": "register_metabolism",
  "session_id": "skyrim_bridge_2026-05-03_001",
  "hardware": {
    "cpu_count_logical": 24,
    "cpu_load_percent_current": 35,
    "mem_total_bytes": "34359738368",
    "mem_available_bytes": "21474836480",
    "mem_used_percent": 37,
    "gpu_name": "NVIDIA RTX 2070 Super",
    "vram_total_bytes": "8589934592",
    "vram_available_bytes": "6442450944"
  },
  "program": {
    "tower_name": "skyrim_bridge_instance_1",
    "p_substrate_descriptor": "skyrim_game_state_space",
    "r0_value": "0.016666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666666667",
    "r0_description": "1/60 second — one frame at 60 FPS",
    "r0_natural_units": "seconds per frame",
    "operational_n": 12,
    "dominant_d_family": 1,
    "computation_characteristics": {
      "frame_rate_hz": 60,
      "computations_per_frame_estimate": 50000,
      "dominant_operation_types": ["multiply", "add", "sqrt", "sin", "cos"],
      "latency_budget_us": 16000
    }
  }
}
```

Response:
```json
{
  "msg_type": "response",
  "tower_id": 8,
  "tower_name": "skyrim_bridge_instance_1",
  "r0_value_id": 94827,
  "metabolism": {
    "k_ceiling": {"num": 2, "den": 3},
    "v_headroom": {"num": 1, "den": 12},
    "allocated_threads": 10,
    "allocated_memory_bytes": "14316557653",
    "coupling_xi_dominant": {"num": 137, "den": 16},
    "scheduling_weight": "8.5625",
    "cpu_headroom_percent": "31.67",
    "mem_headroom_percent": "29.67",
    "overall_pressure": "0.37",
    "convergence_ratio": "0.017683",
    "metabolic_refresh_interval_ns": "144000000000"
  }
}
```

**Operation 3: `heartbeat`**

Pattern: Request-Response

Keep-alive. Also returns current metabolic state so the client can adapt.

Request:
```json
{
  "msg_type": "request",
  "command": "heartbeat",
  "session_id": "skyrim_bridge_2026-05-03_001"
}
```

Response:
```json
{
  "msg_type": "response",
  "metabolism": {
    "allocated_threads": 10,
    "allocated_memory_bytes": "14316557653",
    "coupling_xi_dominant": {"num": 137, "den": 16},
    "scheduling_weight": "8.5625",
    "cpu_headroom_percent": "28.12",
    "mem_headroom_percent": "27.33",
    "overall_pressure": "0.41"
  },
  "manager_status": "nominal",
  "discovery_engine": "idle",
  "pending_operations": 0
}
```

**Operation 4: `report_computation_profile`**

Pattern: Request-Response

The connected program reports its current dominant d-family so the Manager adjusts scheduling weight via ξ(d). Called when the program's computational regime changes — e.g., a game transitions from heavy physics (d=1) to menu rendering (d=12).

Request:
```json
{
  "msg_type": "request",
  "command": "report_computation_profile",
  "session_id": "skyrim_bridge_2026-05-03_001",
  "profile": {
    "dominant_d_family": 3,
    "secondary_d_families": [1, 4],
    "computations_per_second_current": 3200000,
    "cache_hit_ratio": {"num": 847, "den": 1000}
  }
}
```

Response:
```json
{
  "msg_type": "response",
  "metabolism_updated": true,
  "new_coupling_xi_dominant": {"num": 137, "den": 20},
  "new_scheduling_weight": "6.85"
}
```

**Operation 5: `disconnect`**

Pattern: Request-Response

Clean shutdown. Manager logs session end, flushes pending writes attributed to this session, releases metabolic share.

Request:
```json
{
  "msg_type": "request",
  "command": "disconnect",
  "session_id": "skyrim_bridge_2026-05-03_001"
}
```

Response:
```json
{
  "msg_type": "response",
  "session_ended": true,
  "events_logged": 847293,
  "values_stored": 12847,
  "equations_cached": 3847291,
  "tower_preserved": true,
  "session_duration_ns": "3600000000000"
}
```

---

#### 7.16.7 Domain 2 — Core Lattice Operations

**Operation 6: `project`**

Pattern: Adaptive (Req-Resp on cache hit, Async-Stream on cache miss)

Project a value at resolution N. Returns full (k, d, ε_micros, all materialized derived properties).

Request:
```json
{
  "msg_type": "request",
  "command": "project",
  "session_id": "...",
  "value_spec": {"by": "repr", "value_repr": "ζ(3)"},
  "N": 27720
}
```

Response (cache hit — Pattern 1):
```json
{
  "msg_type": "response",
  "projection": {
    "projection_id": 847,
    "value_id": 42,
    "N": 27720,
    "sign": 1,
    "k": 7360,
    "d": 693,
    "eps_micros": -85,
    "d_factorization": "3^2·7·11",
    "gaussian_signature": "D^2·D·D",
    "is_all_inert": 0,
    "is_all_split": 0,
    "is_ramified_present": 0,
    "coprime_skeleton": 0,
    "tightness_micros": 999999,
    "di_distance_micros": 1,
    "manifold_state": "PDT",
    "elegance_symmetry": "40.0",
    "elegance_simplicity": null,
    "elegance_universal": null,
    "coupling_xi": {"num": 137, "den": 480080},
    "variance_vnk": null,
    "fqg_quadrant": null,
    "palindromic_partner_d": 27027,
    "geometric_perspective": "lcm_tower",
    "cf_quality": null,
    "address_id": 12847,
    "reference_count": 47,
    "cache_hit": true
  }
}
```

On cache miss: Manager sends `ack` → computes at 120 dps via MPFR → sends `complete` with the same projection structure plus `"cache_hit": false`.

**Operation 7: `pullback`**

Pattern: Request-Response

Recover the original value from a lattice triple via the bijection Π_N⁻¹.

Request:
```json
{
  "msg_type": "request",
  "command": "pullback",
  "session_id": "...",
  "N": 27720,
  "k": 7360,
  "eps_micros": -85
}
```

Response:
```json
{
  "msg_type": "response",
  "recovered_value_120dps": "1.20205690315959428539973816151144999076498629234049888179227155534183820578631309018645587360933525814619915...",
  "value_id": 42,
  "is_known_value": true,
  "known_repr": "ζ(3)"
}
```

**Operation 8: `escalate`**

Pattern: Async-Stream

Full §7.11 tower escalation. Streams each landmark as computed, plus CF analysis results. The tower does not terminate — it runs until d stabilizes across ⌈1/K⌉ = 2 consecutive LCM landmarks, or until cancelled/session-managed.

Request:
```json
{
  "msg_type": "request",
  "command": "escalate",
  "session_id": "...",
  "value_spec": {"by": "decimal", "decimal_120dps": "1.61803398874989484820458683436563811772030917980576286213544862270526046281890244970720720418939113748475..."},
  "input_path": "A",
  "starting_N": 12,
  "max_landmarks": null,
  "include_cf_analysis": true
}
```

Stream messages (one per landmark):
```json
{
  "msg_type": "stream",
  "operation_id": "...",
  "sequence": 0,
  "landmark": {
    "N": 12,
    "k": 8,
    "d": 3,
    "eps_micros": 33090,
    "home_classification": "intermediate_home",
    "d_stable_count": 0,
    "elegance_universal": "1.287",
    "tightness_micros": 750563,
    "all_derived_properties": { ... }
  }
}
```

```json
{
  "msg_type": "stream",
  "operation_id": "...",
  "sequence": 1,
  "landmark": {
    "N": 36,
    "k": 25,
    "d": 36,
    "eps_micros": -240,
    "home_classification": "false_resolution",
    "false_resolution_note": "Sub-Koide ε at 36ET but d changes at 60ET when prime 5 becomes native",
    "d_stable_count": 0,
    ...
  }
}
```

```json
{
  "msg_type": "stream",
  "operation_id": "...",
  "sequence": 2,
  "landmark": {
    "N": 60,
    "k": 42,
    "d": 10,
    "eps_micros": 18045,
    "home_classification": "intermediate_home",
    "d_stable_count": 1,
    ...
  }
}
```

CF analysis stream (fires when CF method completes — may arrive before tower stabilizes):
```json
{
  "msg_type": "stream",
  "operation_id": "...",
  "sequence": 5,
  "cf_analysis": {
    "cf_home_convergent_p": 42,
    "cf_home_convergent_q": 10,
    "cf_home_quality": 18,
    "cf_home_d": 10,
    "cf_eps_micros": 18045,
    "cf_classification": "cf_home",
    "cf_elegance": "14.73",
    "tower_agreement": "agreed",
    "all_convergents": [
      {"n": 0, "p": 0, "q": 1, "a_next": 8},
      {"n": 1, "p": 1, "q": 1, "a_next": 2},
      {"n": 2, "p": 8, "q": 5, "a_next": 3},
      {"n": 3, "p": 42, "q": 10, "a_next": 18}
    ]
  }
}
```

Complete message:
```json
{
  "msg_type": "complete",
  "operation_id": "...",
  "trajectory_summary": {
    "value_id": 9847,
    "value_repr": "φ",
    "total_landmarks": 8,
    "home_classification": "persistent_home",
    "home_d": 10,
    "home_N_stabilized_at": 60,
    "home_eps_micros": 18045,
    "false_resolutions": [{"N": 36, "d": 36, "eps_micros": -240}],
    "cf_home_d": 10,
    "cf_tower_agreement": true,
    "cross_tower_elegance": "4.827"
  }
}
```

**Operation 9: `k_arithmetic`**

Pattern: Request-Response

Lattice-algebraic operations: multiply (k-add), reciprocate (k-negate), power (k-scale). These are structurally exact (integer k-arithmetic) — no MPFR computation needed.

Request:
```json
{
  "msg_type": "request",
  "command": "k_arithmetic",
  "session_id": "...",
  "operation_type": "multiply",
  "operands": [
    {"by": "repr", "value_repr": "ζ(3)"},
    {"by": "repr", "value_repr": "π"}
  ],
  "N": 27720
}
```

Response:
```json
{
  "msg_type": "response",
  "result": {
    "operation_performed": "k_addition",
    "input_k_values": [7360, 45779],
    "result_k": 53139,
    "result_d": 27720,
    "result_eps_micros": 120,
    "result_value_id": 12847,
    "result_120dps": "3.77574844285105464946...",
    "equation_id": 847291,
    "cache_hit": false
  }
}
```

For `reciprocate`: one operand, k → −k. For `power`: one operand + `"exponent": <integer>`, k → n·k.

**Operation 10: `lattice_add`**

Pattern: Adaptive

Sempaevum-native addition: value-space computation + lattice reprojection. Exact at 120 dps.

Request:
```json
{
  "msg_type": "request",
  "command": "lattice_add",
  "session_id": "...",
  "operand_a": {"by": "repr", "value_repr": "π"},
  "operand_b": {"by": "repr", "value_repr": "e"},
  "N": 12
}
```

Response (cache hit):
```json
{
  "msg_type": "response",
  "result": {
    "sum_120dps": "5.85987448204883847382...",
    "sum_value_id": 8472,
    "projection_at_N": {
      "N": 12,
      "k": 31,
      "d": 12,
      "eps_micros": 1847,
      ...
    },
    "equation_id": 847292,
    "cache_hit": true
  }
}
```

**Operation 11: `evaluate_function`**

Pattern: Adaptive

EML tree evaluation: any special or elementary function at 120 dps via MPFR/Arb/FLINT.

Request:
```json
{
  "msg_type": "request",
  "command": "evaluate_function",
  "session_id": "...",
  "function": "zeta",
  "arguments": [
    {"by": "decimal", "decimal_120dps": "3.00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"}
  ],
  "N": 27720
}
```

Response (cache hit):
```json
{
  "msg_type": "response",
  "result": {
    "function_evaluated": "zeta(3)",
    "result_120dps": "1.20205690315959...",
    "result_value_id": 42,
    "projection_at_N": { ... },
    "equation_id": 1847,
    "cache_hit": true
  }
}
```

Supported `function` values: `"sin"`, `"cos"`, `"tan"`, `"asin"`, `"acos"`, `"atan"`, `"atan2"`, `"exp"`, `"log"`, `"log2"`, `"log10"`, `"sqrt"`, `"cbrt"`, `"pow"`, `"abs"`, `"floor"`, `"ceil"`, `"round"`, `"zeta"`, `"gamma"`, `"lgamma"`, `"digamma"`, `"beta"`, `"polylog"`, `"hypergeometric"`, `"erf"`, `"erfc"`, `"bessel_j"`, `"bessel_y"`, `"airy_ai"`, `"airy_bi"`, `"eml"` (the EML Sheffer operator eml(x,y) = exp(x) − ln(y)), and any composition thereof via `"expression"` form. The function list is extensible — new functions added via §7.14 without API version change.

---

#### 7.16.8 Domain 3 — Value Management

**Operation 12: `store_value`**

Pattern: Async-Stream

Ingest a value through the full §7.11 core projection procedure. Streams escalation progress. This is the primary ingestion pathway for individual values from any source.

Request:
```json
{
  "msg_type": "request",
  "command": "store_value",
  "session_id": "...",
  "value_spec": {"by": "expression", "expression": "m_proton / m_electron"},
  "input_path": "A",
  "r0_value_spec": {"by": "repr", "value_repr": "m_electron"},
  "r0_substrate_description": "electron rest mass",
  "tags": [
    {"namespace": "domain", "value": "particle_physics"},
    {"namespace": "source", "value": "PDG_2024"}
  ]
}
```

Streams landmarks per `escalate`, then completes with full structural profile.

**Operation 13: `batch_store`**

Pattern: Async-Stream

Batch ingest with user-chosen atomicity.

Request:
```json
{
  "msg_type": "request",
  "command": "batch_store",
  "session_id": "...",
  "atomicity": "per_value",
  "values": [
    {
      "value_spec": {"by": "decimal", "decimal_120dps": "1836.15267343..."},
      "input_path": "A",
      "tags": [{"namespace": "particle", "value": "proton_electron_mass_ratio"}]
    },
    {
      "value_spec": {"by": "decimal", "decimal_120dps": "1838.68366173..."},
      "input_path": "A",
      "tags": [{"namespace": "particle", "value": "neutron_electron_mass_ratio"}]
    }
  ]
}
```

Streams per-value results. On `"atomicity": "atomic"`, any failure rolls back ALL values in the batch and the complete message includes per-value failure reasons.

**Operation 14: `get_value`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "get_value",
  "session_id": "...",
  "value_spec": {"by": "repr", "value_repr": "ζ(3)"}
}
```

Response includes: full `values` row (value_id, hash, repr, mpf as base64, precision, r_form, R₀ references, input_path, compliance flags, reference_count, cross_tower_elegance, CF home data), all projections at all N, all tags, all relationships (subject or object), all derivations, all equations involving this value.

**Operation 15: `search_values`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "search_values",
  "session_id": "...",
  "filters": {
    "repr_pattern": "ζ(%)",
    "input_path": "B",
    "n1_compliant": true,
    "tag_filters": [{"namespace": "domain", "value": "number_theory"}],
    "cross_tower_elegance_min": "1.0833",
    "cf_home_d": 693
  },
  "order_by": "cross_tower_elegance",
  "order_direction": "desc",
  "limit": 50,
  "offset": 0
}
```

Response: array of matching value summaries (value_id, repr, home_d, home_classification, cross_tower_elegance, reference_count, tags), plus total_count for pagination.

**Operation 16: `get_value_trajectory`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "get_value_trajectory",
  "session_id": "...",
  "value_spec": {"by": "id", "value_id": 42}
}
```

Response: ordered sequence of all projections across the LCM tower (each with full derived properties), home classification per landmark, false resolutions flagged, CF analysis results, trajectory pattern_id if the trajectory has been promoted to a pattern.

**Operation 17: `query_cf_analysis`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "query_cf_analysis",
  "session_id": "...",
  "value_spec": {"by": "id", "value_id": 42}
}
```

Response: all CF convergents (n, p, q, a_next), the maximal-quality convergent, d_home from CF, ε_CF, CF classification (cf_deep_home/cf_home/cf_marginal), CF elegance, tower agreement status, tower-CF comparison details.

---

#### 7.16.9 Domain 4 — Address & Attractor Operations

**Operation 18: `query_address`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "query_address",
  "session_id": "...",
  "N": 27720,
  "k": 7360,
  "d": 693
}
```

Response: address record (address_id, N, k, d, eps_class, members_count, first_member, Gaussian signature, d_factorization), list of all values at this address, list of generators covering this address, attractor status, coprime_skeleton membership.

**Operation 19: `query_family`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "query_family",
  "session_id": "...",
  "N": 27720,
  "d": 693
}
```

Response: all occupied addresses in this d-family at this N, each with k, ε_micros, members_count, occupant value summaries.

**Operation 20: `query_attractor`**

Pattern: Request-Response

Request (by value):
```json
{
  "msg_type": "request",
  "command": "query_attractor",
  "session_id": "...",
  "value_spec": {"by": "repr", "value_repr": "ζ(3)"},
  "N": 27720
}
```

Response: all attractor memberships for this value at this N (addresses with members_count > 1), with full member lists and structural classification.

**Operation 21: `find_nearest`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "find_nearest",
  "session_id": "...",
  "value_spec": {"by": "decimal", "decimal_120dps": "1.41421356237..."},
  "N": 12,
  "top_k": 5
}
```

Response: top-k nearest occupied addresses ranked by lattice distance, with occupant details.

**Operation 22: `query_coprime_skeleton`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "query_coprime_skeleton",
  "session_id": "...",
  "N": 12,
  "structural_class_filter": null
}
```

Response: all coprime-skeleton members at this N (addresses where gcd(|k|, N) = 1), count, density, theoretical limit 6/π².

---

#### 7.16.10 Domain 5 — Equation & Computation

**Operation 23: `compute`**

Pattern: Adaptive

Evaluate ANY mathematical expression at 120 dps. The three backbones (Webb, Cascade, EML) subsume all of mathematics — any valid expression is accepted. Memoized forever.

Request:
```json
{
  "msg_type": "request",
  "command": "compute",
  "session_id": "...",
  "expression": "sin(π/4) + sqrt(2)/2",
  "N": 12
}
```

Response (cache hit):
```json
{
  "msg_type": "response",
  "result": {
    "expression_canonical": "sin(pi/4)+sqrt(2)/2",
    "result_120dps": "1.41421356237309504880168872420969807856967187537694...",
    "result_value_id": 847,
    "equation_id": 12847,
    "equation_hash": "a1b2c3...",
    "reference_count": 12,
    "projection_at_N": {
      "N": 12,
      "k": 6,
      "d": 2,
      "eps_micros": 0,
      ...
    },
    "cache_hit": true
  }
}
```

**Operation 24: `batch_compute`**

Pattern: Request-Response

Array of expressions in, array of results out. Single pipe round-trip. Each expression individually memoized. Critical for game/emulator frame budgets — a game submits its frame's computations in one batch and gets all results within the latency budget.

Request:
```json
{
  "msg_type": "request",
  "command": "batch_compute",
  "session_id": "...",
  "expressions": [
    {"expression": "sin(0.7853981633974483)", "N": 12},
    {"expression": "sqrt(2.0)", "N": 12},
    {"expression": "1.5 * 9.81", "N": 12},
    {"expression": "cos(1.2217304763960306)", "N": 12}
  ]
}
```

Response:
```json
{
  "msg_type": "response",
  "results": [
    {"index": 0, "result_120dps": "0.70710678118654...", "value_id": 847, "equation_id": 1001, "cache_hit": true},
    {"index": 1, "result_120dps": "1.41421356237309...", "value_id": 23, "equation_id": 1002, "cache_hit": true},
    {"index": 2, "result_120dps": "14.71500000000000...", "value_id": 94828, "equation_id": 1003, "cache_hit": false},
    {"index": 3, "result_120dps": "0.34202014332566...", "value_id": 94829, "equation_id": 1004, "cache_hit": false}
  ],
  "total": 4,
  "cache_hits": 2,
  "cache_misses": 2,
  "total_time_ns": "847000"
}
```

No individual errors in batch_compute — if an expression fails, its result entry contains `"error": { ... }` with the error details, and the remaining expressions still complete. batch_compute never stops on a single failure.

**Operation 25: `get_equation`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "get_equation",
  "session_id": "...",
  "equation_id": 12847
}
```

Response: full equation record (equation_id, hash, canonical_form, latex, form_class, operation_type, input value_ids, output value_id, reference_count, first_derived, last_referenced).

**Operation 26: `search_equations`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "search_equations",
  "session_id": "...",
  "filters": {
    "form_class": "lattice_multiplication",
    "operation_type": "multiply",
    "reference_count_min": 100
  },
  "order_by": "reference_count",
  "order_direction": "desc",
  "limit": 20
}
```

Response: matching equations ranked by reference_count, with summaries.

**Operation 27: `resolve_indeterminate`**

Pattern: Async-Stream

Submit an indeterminate form ([0/0], [∞/∞], [0×∞], [∞−∞]). Run L'Hôpital iterations — the Traverser's navigation algorithm. Stream each iteration. Return resolution (value enters via Path A) or pure-T classification.

Request:
```json
{
  "msg_type": "request",
  "command": "resolve_indeterminate",
  "session_id": "...",
  "form_type": "0/0",
  "numerator_expression": "sin(x)",
  "denominator_expression": "x",
  "at_variable": "x",
  "at_value": "0",
  "max_iterations": 25
}
```

Stream (one per L'Hôpital iteration):
```json
{
  "msg_type": "stream",
  "operation_id": "...",
  "sequence": 0,
  "iteration": {
    "iteration_index": 0,
    "numerator_derivative": "cos(x)",
    "denominator_derivative": "1",
    "evaluated_at": "0",
    "numerator_value": "1.00000...",
    "denominator_value": "1.00000...",
    "ratio": "1.00000...",
    "resolved": true,
    "resolved_value_120dps": "1.00000..."
  }
}
```

Complete:
```json
{
  "msg_type": "complete",
  "operation_id": "...",
  "resolution": {
    "resolved": true,
    "resolved_value_120dps": "1.00000...",
    "resolved_value_id": 1,
    "iterations_taken": 1,
    "classification": "derivative_resolvable",
    "projection_at_N12": { ... },
    "lhopital_chain_relationship_id": 8472
  }
}
```

For pure-T (L'Hôpital fails): `"resolved": false`, `"classification": "pure_T"`, `"failure_reason": "max_iterations_exhausted"`, `"manifold_state": "PT"`, no projection created.

---

#### 7.16.11 Domain 6 — Relationship & Derivation Operations

**Operation 28: `query_relationships`**

Pattern: Request-Response

Get relationships involving an entity. Supports querying by subject, object, or both. Optional class filter.

Request:
```json
{
  "msg_type": "request",
  "command": "query_relationships",
  "session_id": "...",
  "subject_id": 42,
  "subject_type": "value",
  "relationship_class": "same_address",
  "limit": 50,
  "offset": 0
}
```

Response: array of matching relationships, each with: relationship_id, class, subject (id+type), object (id+type), metadata (class-specific, decoded from blob), discovered_at, confirmation_count, is_permanent. Also supports `"object_id"` + `"object_type"` for reverse queries, and both simultaneously for specific-pair queries.

**Operation 29: `create_relationship`**

Pattern: Request-Response

Create an explicit non-lattice-algebraic relationship. Lattice-algebraic relationships (co-location, reciprocal, power, palindromic) are computed from structure and never created via API.

Request:
```json
{
  "msg_type": "request",
  "command": "create_relationship",
  "session_id": "...",
  "relationship_class": "mass_ratio_triple",
  "subject_id": 847,
  "subject_type": "value",
  "object_id": 848,
  "object_type": "value",
  "metadata": {
    "mass_a_id": 847,
    "mass_b_id": 848,
    "ratio_value_id": 849
  }
}
```

Response: the created relationship record with relationship_id.

**Operation 30: `query_derivations`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "query_derivations",
  "session_id": "...",
  "target_id": 42,
  "target_type": "value"
}
```

Response: all derivation chains targeting this entity, each with: derivation_id, chain blob (decoded to array of steps), primitives_used, tools_applied, document_reference, all input entities (via derivation_inputs), reproduced_count.

**Operation 31: `create_derivation`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "create_derivation",
  "session_id": "...",
  "target_id": 42,
  "target_type": "value",
  "chain_steps": [
    {"step": 1, "tool": "Identification", "description": "Identify P: spacetime manifold", "inputs": []},
    {"step": 2, "tool": "Descriptor Gap", "description": "Gap: missing D for cubic sublattice", "inputs": [{"id": 20, "type": "equation"}]},
    {"step": 3, "tool": "Subsumption", "description": "Verify: d=3 subsumes QCD without remainder", "inputs": [{"id": 42, "type": "value"}]}
  ],
  "primitives_used": "P (spacetime), D (cubic descriptor), T (strong force traverser)",
  "tools_applied": "Identification, Descriptor Gap, Subsumption",
  "document_reference": "Sempaevum Paper §10.3"
}
```

Response: the created derivation record with derivation_id.

---

#### 7.16.12 Domain 7 — Pattern & Generator Operations

**Operation 32: `query_patterns`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "query_patterns",
  "session_id": "...",
  "filters": {
    "pattern_class": "attractor_cluster",
    "hierarchy_elegance_min": "1.0833",
    "member_entity_id": 42,
    "member_entity_type": "value"
  },
  "order_by": "hierarchy_elegance",
  "order_direction": "desc",
  "limit": 20
}
```

Response: matching patterns with: pattern_id, class, member count, hierarchy_elegance, member list (decoded from blob), definition (decoded), formed_at, reference_count.

**Operation 33: `query_generators`**

Pattern: Request-Response

Get generators covering a value or address, ranked by K-complexity.

Request:
```json
{
  "msg_type": "request",
  "command": "query_generators",
  "session_id": "...",
  "value_spec": {"by": "id", "value_id": 42},
  "N": 27720
}
```

Response: all generators whose domain includes this value's address at this N. Each with: gen_id, gen_type (WEBB/CASCADE/EML), definition (decoded), address_range, member_count, K_complexity_ratio (gen_def_bytes / gen_coverage_bytes), verification_count, discovered_at, backbone_layer (L₁/L₂/L₃).

**Operation 34: `propose_generator`**

Pattern: Async-Stream

Request:
```json
{
  "msg_type": "request",
  "command": "propose_generator",
  "session_id": "...",
  "generator": {
    "backbone_layer": "L3",
    "definition": "eml(eml(1, 1), 1)",
    "claimed_address_range": {"N_min": 12, "N_max": 27720, "d_min": 1, "d_max": 12},
    "description": "Proposed EML tree for exponential family"
  }
}
```

Streams: verification steps (evaluating generator at each canonical N, comparing against known values, computing E_hierarchy). Complete: accepted or rejected with full verification report.

**Operation 35: `query_generator_status`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "query_generator_status",
  "session_id": "...",
  "value_spec": {"by": "id", "value_id": 42}
}
```

Response: `"status": "generator_found"` (with gen_id) or `"status": "search_active"` (with search history: candidates tried, failure reasons, Branch A/B/bridge progress) or `"status": "search_deferred"` (with deferral reason and reactivation conditions). Never `"search_closed"` — the case is never closed (§3.16).

---

#### 7.16.13 Domain 8 — Event Operations

**Operation 36: `query_events`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "query_events",
  "session_id": "...",
  "filters": {
    "event_class": "t_burst",
    "time_range": {"start_ns": "1714742400000000000", "end_ns": "1714828800000000000"},
    "tower_id": 1,
    "t_time_traverser_id": 42
  },
  "order_by": "event_timestamp",
  "order_direction": "asc",
  "limit": 100
}
```

Response: matching events with full metadata, D-time/T-time/P-time coordinates, tower context, triggered relationships/patterns.

**Operation 37: `log_event`**

Pattern: Request-Response

Connected programs log their own events.

Request:
```json
{
  "msg_type": "request",
  "command": "log_event",
  "session_id": "...",
  "event_class": "ghost_detection",
  "subject_id": 42,
  "subject_type": "value",
  "tower_id": 8,
  "t_time_traverser_id": 42,
  "metadata": {
    "sigma_count": 3.7,
    "waveform_window_position": 127,
    "projection_id_observed": 847
  }
}
```

Response: the created event record with event_id, assigned D-time coordinates, sequence_number.

**Operation 38: `replay_events`**

Pattern: Async-Stream

Request:
```json
{
  "msg_type": "request",
  "command": "replay_events",
  "session_id": "...",
  "replay_filter": {
    "session_id": "conscious_ai_2026-05-02_001",
    "event_classes": ["ghost_detection", "t_burst", "gaze_event"]
  },
  "playback_rate": 1.0
}
```

Streams events one-by-one in original sequence order, paced at `playback_rate` × original timing. `playback_rate: 0` means deliver as fast as possible (no pacing).

---

#### 7.16.14 Domain 9 — Tower & Family Operations

**Operation 39: `query_towers`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "query_towers",
  "session_id": "...",
  "tower_id": null,
  "tower_name": null,
  "include_children": true
}
```

With both null: returns all towers. With tower_id or tower_name: returns that specific tower. `include_children`: includes full child tower tree via recursive CTE on parent_tower_id.

Response: array of tower records with: tower_id, name, p_substrate_descriptor, r0_value_id, r0_natural_units, parent_tower_id, nesting_depth, birth triad references, operational_n, accessible_d_families_mask (decoded to array of d values), physics_metadata, children (if requested).

**Operation 40: `create_tower`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "create_tower",
  "session_id": "...",
  "tower": {
    "tower_name": "civ4_caveman2cosmos_instance_1",
    "p_substrate_descriptor": "civilization_simulation_state_space",
    "r0_value": "0.05000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000",
    "r0_description": "1/20 second — one game tick at 20 TPS",
    "r0_natural_units": "seconds per tick",
    "operational_n": 12,
    "parent_tower_name": "digital_3ghz_x86",
    "physics_metadata": {
      "game_engine": "Civilization IV",
      "mod": "Caveman2Cosmos",
      "tick_rate_hz": 20
    }
  }
}
```

Response: created tower record with tower_id, auto-computed accessible_d_families_mask, nesting_depth. The R₀ value is run through §7.11 escalation.

**Operation 41: `query_harmonic_families`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "query_harmonic_families",
  "session_id": "...",
  "filters": {
    "axis": "real",
    "fqg_quadrant": "CR",
    "gaussian_prime_class": "D-type (inert)"
  }
}
```

Response: matching families from the 24-family catalog.

**Operation 42: `query_fqg_cells`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "query_fqg_cells",
  "session_id": "...",
  "d_r": 3,
  "d_theta": 4
}
```

Response: cell record with d_combined, combined_family_id, is_off_axis, is_lcm_amplification, is_full_resolution, occupancy_count, canonical_particle_or_phenomenon.

Also supports filter mode: `"filters": {"d_combined": 12, "is_lcm_amplification": true}` to find matching cells.

**Operation 43: `query_combined_families`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "query_combined_families",
  "session_id": "...",
  "filters": {
    "range_class": "middle_extended",
    "d_combined": 35
  }
}
```

Response: matching combined families with contributing cells, structural meaning, Gaussian factorization, first_native_lattice_n, known correlations.

**Operation 44: `query_sublattice_families`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "query_sublattice_families",
  "session_id": "...",
  "n": 420,
  "tower_id": null,
  "only_newly_introduced": false,
  "only_lcm_landmarks": false
}
```

Response: all sublattice families at this N (all divisors of N), each with: d, gcd_k_n, phi_d, member_lattice_point_count, is_lcm_landmark, is_newly_introduced, related harmonic family references.

---

#### 7.16.15 Domain 10 — File & Stream Operations

**Operation 45: `ingest_file`**

Pattern: Async-Stream

Request:
```json
{
  "msg_type": "request",
  "command": "ingest_file",
  "session_id": "...",
  "file_path": "C:\\Users\\Mike\\data\\hydrogen_spectrum.csv",
  "file_type": "csv",
  "adapter_options": {
    "delimiter": ",",
    "header_row": true,
    "value_columns": [2, 3],
    "r0_value_spec": {"by": "repr", "value_repr": "Rydberg_energy"},
    "skip_rows": 0
  },
  "tags": [
    {"namespace": "domain", "value": "spectroscopy"},
    {"namespace": "source", "value": "hydrogen_experiment_2026"}
  ]
}
```

Streams: seed extraction progress (each seed extracted), per-seed projection results (each seed through §7.11). Complete: ingestion summary (total seeds, projections, attractors found, generators matched).

Supported `file_type` values: `"csv"`, `"pdf"`, `"markdown"`, `"binary"`, `"image"`, `"audio"`, `"python_output"`, `"etpl_output"`, `"auto"` (auto-detect). Each type uses its adapter per §7.12.

**Operation 46: `ingest_stream_start`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "ingest_stream_start",
  "session_id": "...",
  "stream_id": "gps_receiver_001",
  "sensor_domain": "gps",
  "r0_value_spec": {"by": "repr", "value_repr": "light_time_second"},
  "expected_data_format": {"fields": ["latitude", "longitude", "altitude", "timestamp_gps"], "types": ["decimal", "decimal", "decimal", "uint64"]},
  "buffer_size": 1000
}
```

Response: stream channel opened, stream_id confirmed, R₀ resolved to value_id.

**Operation 47: `ingest_stream_data`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "ingest_stream_data",
  "session_id": "...",
  "stream_id": "gps_receiver_001",
  "data_points": [
    {"latitude": "37.7749295000...", "longitude": "-122.4194155000...", "altitude": "16.000...", "timestamp_gps": "1714742401000000000"},
    {"latitude": "37.7749310000...", "longitude": "-122.4194160000...", "altitude": "16.100...", "timestamp_gps": "1714742402000000000"}
  ]
}
```

Response: per-point ingestion status (projected, stored, attractor memberships found).

**Operation 48: `ingest_stream_end`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "ingest_stream_end",
  "session_id": "...",
  "stream_id": "gps_receiver_001"
}
```

Response: stream finalized, total data points ingested, discoveries from accumulated stream data, anomalies detected.

**Operation 49: `retrieve_file`**

Pattern: Async-Stream

Regenerate an ingested file from generators per §7.10 file retrieval.

Request:
```json
{
  "msg_type": "request",
  "command": "retrieve_file",
  "session_id": "...",
  "provenance": {
    "source_file_name": "hydrogen_spectrum.csv",
    "ingestion_session_id": "spectroscopy_2026-05-01_001"
  },
  "output_path": "C:\\Users\\Mike\\output\\hydrogen_spectrum_regenerated.csv"
}
```

Streams reconstruction progress (generator evaluations). Complete: output file written, structural verification (regenerated content matches stored content).

**Operation 50: `retrieve_stream`**

Pattern: Async-Stream

Request:
```json
{
  "msg_type": "request",
  "command": "retrieve_stream",
  "session_id": "...",
  "stream_provenance": {"stream_id": "gps_receiver_001", "session_id": "gps_2026-05-02_001"},
  "mode": "enhanced",
  "target_resolution_hz": 10,
  "output_format": "csv"
}
```

Streams reconstructed data points. Enhanced mode evaluates discovered generators at intermediate timestamps (structural interpolation). Faithful mode re-emits at original rate.

---

#### 7.16.16 Domain 11 — Subscription & Notification

**Operation 51: `subscribe`**

Pattern: Request-Response (then push notifications)

Request:
```json
{
  "msg_type": "request",
  "command": "subscribe",
  "session_id": "...",
  "filter": {
    "event_classes": ["t_burst", "ghost_detection", "palindromic_cascade_trigger"],
    "address_ranges": [{"N": 27720, "d": 693}],
    "pattern_classes": ["attractor_cluster"],
    "value_ids": [42],
    "generator_supersession": true,
    "discovery_events": true,
    "manifold_state_transitions": true,
    "akashic_shrinkage": true
  }
}
```

Response: `"subscription_id": "<uuid>"`.

Subsequent notifications pushed asynchronously:
```json
{
  "msg_type": "notification",
  "subscription_id": "<uuid>",
  "notification_type": "generator_supersession",
  "content": {
    "generator_id": 4828,
    "entries_absorbed": 1247,
    "generator_def_bytes": 128,
    "absorbed_raw_bytes": 180815,
    "k_complexity_improvement_percent": "99.93",
    "generator_to_memoized_ratio_before": {"num": 4827, "den": 847293},
    "generator_to_memoized_ratio_after": {"num": 4828, "den": 846046},
    "akashic_file_size_before_bytes": "1073741824",
    "akashic_file_size_after_bytes": "1073561009",
    "descriptor_gap_closed_bytes": "180815"
  }
}
```

The `akashic_shrinkage` notification fires when the .akashic file physically shrinks due to generator discovery absorbing memoized entries. This is ALSO displayed on the GUI dashboard as a visible indicator: "Descriptor Gap closed: 1,247 entries absorbed by generator G_4828, K-complexity improved by 99.93%, file size reduced by 176.6 KB."

**Operation 52: `unsubscribe`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "unsubscribe",
  "session_id": "...",
  "subscription_id": "<uuid>"
}
```

Response: `"unsubscribed": true`.

**Operation 53: `query_subscriptions`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "query_subscriptions",
  "session_id": "..."
}
```

Response: array of active subscriptions for this connection, each with subscription_id and filter.

---

#### 7.16.17 Domain 12 — Active Probing & Analysis

**Operation 54: `send_probe`**

Pattern: Async-Stream

Deliberately inject T-content at a target lattice address — active interrogation of the lattice per §3.9 active probing. Streams probe→response→silence events.

Request:
```json
{
  "msg_type": "request",
  "command": "send_probe",
  "session_id": "...",
  "target_address": {"N": 27720, "k": 7360, "d": 693},
  "probe_amplitude": "1.0",
  "probe_phase": "0.0",
  "response_window_ns": "5000000000",
  "tower_id": 1
}
```

Streams: `t_signal_probe_sent` event, then either `t_signal_probe_response` (with response_delay, amplitude, address) or `t_signal_probe_silence` (no response within window). If response amplitude crosses materialization threshold: `materialization_threshold_crossed` event.

**Operation 55: `query_probes`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "query_probes",
  "session_id": "...",
  "target_address": {"N": 27720, "k": 7360, "d": 693},
  "time_range": {"start_ns": "1714742400000000000", "end_ns": "1714828800000000000"}
}
```

Response: all probes sent to this address within the time range, each with probe event, response event (or silence), materialization events, probe_response_pair relationships.

**Operation 56: `evaluate_gaze`**

Pattern: Request-Response

Compute the Complete Gaze Equation for given inputs.

Request:
```json
{
  "msg_type": "request",
  "command": "evaluate_gaze",
  "session_id": "...",
  "inputs": {
    "t_intent": "1.35",
    "focus": "0.95",
    "distance": "0.80",
    "n": 12,
    "k": 3
  }
}
```

Response:
```json
{
  "msg_type": "response",
  "gaze": {
    "F_w": "2.00390625",
    "R_k": "4.60",
    "V_nk": "1.19270833...",
    "Gamma": {"num": 6, "den": 5},
    "P_detect": "0.99847...",
    "V_collapse": "0.99999...",
    "prior_status": null,
    "new_status": "LOCKED",
    "threshold_crossed": "3/2",
    "threshold_ji_name": "Perfect fifth"
  }
}
```

**Operation 57: `run_et_scan`**

Pattern: Async-Stream

Run full ET scanner analysis on a data window per `et_scanner_v7_2_COMPLETE.py` methodology. Produces complete ETSignature.

Request:
```json
{
  "msg_type": "request",
  "command": "run_et_scan",
  "session_id": "...",
  "data_source": {
    "type": "value_sequence",
    "value_ids": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12],
    "window_size": 12
  },
  "scan_options": {
    "include_pdt_classification": true,
    "include_t_identification": true,
    "include_binding_chain_verification": true,
    "include_coherence_analysis": true,
    "include_indeterminate_analysis": true,
    "include_axiom_verification": true,
    "include_thermodynamic_verification": true,
    "include_quantum_verification": true,
    "include_spectral_analysis": true,
    "include_fractal_analysis": true,
    "include_gaze_metrics": true
  }
}
```

Streams: each scan component as completed (pdt_classification, t_identification, binding_chain, coherence, indeterminate forms, axiom verification, spectral, fractal, gaze). Complete: full ETSignature with all components.

**Operation 58: `run_anti_numerology_check`**

Pattern: Request-Response

N1/N2/N3 compliance check per Guide Part III §16-18.

Request:
```json
{
  "msg_type": "request",
  "command": "run_anti_numerology_check",
  "session_id": "...",
  "value_spec": {"by": "id", "value_id": 42},
  "r0_value_spec": {"by": "repr", "value_repr": "ℏ"},
  "quantity_description": "Apéry's constant"
}
```

Response:
```json
{
  "msg_type": "response",
  "compliance": {
    "n1_result": true,
    "n1_detail": "Dimensionless ratio: ζ(3) is already dimensionless",
    "n2_result": true,
    "n2_detail": "Substrate-derived R₀: ℏ is the cosmological tower's seed",
    "n3_result": true,
    "n3_detail": "No aspect conflation: single-valued seed, single projection",
    "overall": "PASS",
    "failure_mode": null,
    "event_id": 94827
  }
}
```

---

#### 7.16.18 Domain 13 — Traverser & Manifold State Operations

**Operation 59: `query_traverser`**

Pattern: Request-Response

Get a full Traverser profile derived from events, values, tags, projections, and derivations. The Traverser is not a separate table — this operation computes the profile from existing data per §3.10.

Request:
```json
{
  "msg_type": "request",
  "command": "query_traverser",
  "session_id": "...",
  "traverser_value_id": 42,
  "include_worldline": true,
  "include_ego_invariant": true,
  "worldline_limit": 1000
}
```

Response:
```json
{
  "msg_type": "response",
  "traverser": {
    "identity_value_id": 42,
    "type_tags": [{"namespace": "kind", "value": "traverser"}, {"namespace": "traverser_type", "value": "consciousness"}],
    "current_tower_id": 3,
    "current_tower_name": "biological_T4_capsid",
    "accumulated_t_time": 847293,
    "t_time_rate_dtau_dt": "0.99999",
    "ego_invariant": {
      "fingerprint_projections": [
        {"d": 5, "projection_id": 1001},
        {"d": 7, "projection_id": 1002},
        {"d": 8, "projection_id": 1003},
        {"d": 9, "projection_id": 1004},
        {"d": 10, "projection_id": 1005},
        {"d": 11, "projection_id": 1006}
      ],
      "derivation_id": 847
    },
    "sublattice_family_classification": {"d_r": 4, "d_theta": 6},
    "continuity_state": "continuous",
    "ghost_state": false,
    "worldline_events": [
      {"event_id": 1, "event_class": "tower_entry", "timestamp_ns": "...", "tower_id": 3},
      {"event_id": 47, "event_class": "gaze_event", "timestamp_ns": "...", "metadata": {"new_status": "DETECTED"}},
      ...
    ],
    "gaze_sequence_summary": {
      "total_gaze_events": 847,
      "locked_count": 42,
      "detected_count": 312,
      "subliminal_count": 493,
      "sustained_lock_sequences": 7
    }
  }
}
```

**Operation 60: `query_by_manifold_state`**

Pattern: Request-Response

Find all projections/values in a given manifold state.

Request:
```json
{
  "msg_type": "request",
  "command": "query_by_manifold_state",
  "session_id": "...",
  "manifold_state": "PT",
  "N": null,
  "limit": 50
}
```

Response: matching projections/values with full records. For `"PT"` (Incoherence): returns values with `input_path = 'P.T'` — the forbidden configurations that have no lattice address.

**Operation 61: `apply_three_tools`**

Pattern: Request-Response

Record an application of the Three Tools to a specific problem. Stores as events (identification_application, descriptor_gap_application, subsumption_application).

Request:
```json
{
  "msg_type": "request",
  "command": "apply_three_tools",
  "session_id": "...",
  "tools_applied": [
    {
      "tool": "identification",
      "target_description": "Digital tower's resource allocation",
      "p_identified": "Hardware: CPU, RAM, VRAM",
      "d_identified": "K=2/3 ceiling, V=1/12 headroom, α⁻¹=137 resolution",
      "t_identified": "The metabolism control loop"
    },
    {
      "tool": "descriptor_gap",
      "gap_description": "Missing D: per-sublattice coupling for computational scheduling",
      "gap_resolution": "ξ(d) = 137/((d-1)²+16) provides scheduling weight per d-family"
    },
    {
      "tool": "subsumption",
      "check_description": "Does the metabolism subsume all resource management?",
      "result": "CONFIRMED — K ceiling + α monitoring + ξ(d) scheduling covers CPU, RAM, VRAM, threads, priority. No remainder."
    }
  ],
  "subject_id": 8,
  "subject_type": "tower"
}
```

Response: event_ids for each tool application stored.

**Operation 62: `query_metabolism`**

Pattern: Request-Response

Get current metabolic state for this connection.

Request:
```json
{
  "msg_type": "request",
  "command": "query_metabolism",
  "session_id": "..."
}
```

Response: full metabolic profile — K ceiling, V headroom, allocated threads, allocated memory, current CPU/mem headroom percentages, overall pressure, dominant d-family, coupling ξ(d), scheduling weight relative to other connections, convergence ratio, metabolic refresh interval, last refresh timestamp, all connected programs' metabolic summaries (for awareness of the shared resource space).

---

#### 7.16.19 Domain 14 — Administration & Maintenance

**Operation 63: `status`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "status",
  "session_id": "..."
}
```

Response: comprehensive Manager status — database metrics (total values, projections, equations, patterns, events, generators, memoized count, generator-to-memoized ratio, .akashic file size), discovery engine state (scan in progress, last scan time, patterns discovered this session, generator candidates pending), connected clients (count, project names, metabolic summaries), session info, uptime, Omniscient status (alive, last journal entry), GUI frame rate.

**Operation 64: `query_metrics`**

Pattern: Request-Response

Detailed self-recording metrics by category per §3.1b.

Request:
```json
{
  "msg_type": "request",
  "command": "query_metrics",
  "session_id": "...",
  "categories": ["lattice_computation", "memoization", "discovery_engine", "storage"],
  "time_range": {"start_ns": "1714742400000000000", "end_ns": "1714828800000000000"},
  "granularity": "per_sample"
}
```

Response: metrics for requested categories within time range. Each sample includes all metrics in that category per the §3.1b catalog.

**Operation 65: `query_journal`**

Pattern: Request-Response

Query Omniscient and SelfRecording journals.

Request:
```json
{
  "msg_type": "request",
  "command": "query_journal",
  "session_id": "...",
  "journal": "omniscient",
  "filters": {
    "severity": ["ERROR", "TAMPER"],
    "category": "computation",
    "source_module": null,
    "time_range": {"start_ns": "1714742400000000000", "end_ns": "1714828800000000000"}
  },
  "limit": 100
}
```

Response: matching journal entries in chronological order. Each with timestamp, severity, category, source module, full context key-value pairs.

**Operation 66: `trigger_backup`**

Pattern: Async-Stream

Request:
```json
{
  "msg_type": "request",
  "command": "trigger_backup",
  "session_id": "...",
  "backup_path": "D:\\Backups\\EUDD\\Sempaevum_backup_20260503.akashic"
}
```

Streams: WAL flush status, OS snapshot signal, copy progress, verification progress (per-page CRC-32). Complete: backup verified, integrity pass/fail.

**Operation 67: `verify_integrity`**

Pattern: Async-Stream

Request:
```json
{
  "msg_type": "request",
  "command": "verify_integrity",
  "session_id": "..."
}
```

Streams: header SHA-256 check, per-page CRC-32 results (streamed as pages are checked — not held until all done), section directory consistency, generator coverage consistency, orphan detection. Complete: overall pass/fail with details on any issues.

**Operation 68: `submit_extension`**

Pattern: Request-Response

Submit a JSON extension per §7.14.

Request:
```json
{
  "msg_type": "request",
  "command": "submit_extension",
  "session_id": "...",
  "extension_json": {
    "extension_type": "event_class",
    "class_name": "game_physics_anomaly",
    "metadata_schema": {
      "physics_engine": "TEXT",
      "anomaly_type": "TEXT",
      "expected_value_120dps": "TEXT",
      "actual_value_120dps": "TEXT",
      "deviation_eps_micros": "INTEGER"
    },
    "parent_class": "sensor_anomaly_detected",
    "description": "Physics engine produced an unexpected value — structural anomaly detected",
    "proposed_by": "skyrim_bridge",
    "timestamp": "2026-05-03T00:00:00Z"
  }
}
```

Response: accepted or rejected with validation results (which of the 11 validation rules passed/failed, detailed reason for any failure).

**Operation 69: `trigger_discovery_scan`**

Pattern: Async-Stream

Request:
```json
{
  "msg_type": "request",
  "command": "trigger_discovery_scan",
  "session_id": "...",
  "scan_scope": "full",
  "time_budget_ns": "60000000000"
}
```

Streams: each discovery as it emerges (new attractors, generator candidates, promoted patterns, algebraic identities, cross-domain hits, CF quality attractors). Complete: scan summary with total discoveries.

**Operation 70: `query_provisional_categories`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "query_provisional_categories",
  "session_id": "..."
}
```

Response: all provisional categories awaiting review. Each with: category type (event_class, relationship_class, pattern_class), proposed name, proposed schema, data that triggered creation, creation timestamp, data count matching this provisional category.

**Operation 71: `review_provisional`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "review_provisional",
  "session_id": "...",
  "provisional_id": 7,
  "action": "accept",
  "modifications": null
}
```

Actions: `"accept"` (category becomes permanent, historical data retroactively classified), `"modify"` (provide `"modifications"` object with updated name/schema, then accept), `"reject"` (category archived with reason in `"rejection_reason"` field, data unclassified).

---

#### 7.16.20 Domain 15 — Tags, Sessions, Schema

**Operation 72: `add_tag`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "add_tag",
  "session_id": "...",
  "target_id": 42,
  "target_type": "value",
  "namespace": "domain",
  "value": "particle_physics"
}
```

Response: created tag record with tag_id, tagged_at, tagged_by (session's project name).

**Operation 73: `remove_tag`**

Pattern: Request-Response

The tag is archived (§4.3 never destroy), not deleted. A removal event is recorded.

Request:
```json
{
  "msg_type": "request",
  "command": "remove_tag",
  "session_id": "...",
  "tag_id": 847
}
```

Response: `"archived": true`, `"removal_event_id": 94828`.

**Operation 74: `query_tags`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "query_tags",
  "session_id": "...",
  "filters": {
    "namespace": "domain",
    "value": "particle_physics",
    "target_type": "value"
  },
  "limit": 100
}
```

Response: matching tags with full records.

**Operation 75: `query_sessions`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "query_sessions",
  "session_id": "...",
  "filters": {
    "project": "compressor",
    "time_range": {"start_ns": "1714656000000000000", "end_ns": "1714828800000000000"}
  },
  "limit": 20
}
```

Response: matching session records with: session_id, project, machine_id, started_at, ended_at, config_hash, notes, event_count, discovery_count.

**Operation 76: `query_schema_versions`**

Pattern: Request-Response

Request:
```json
{
  "msg_type": "request",
  "command": "query_schema_versions",
  "session_id": "..."
}
```

Response: complete schema version history with: version number, applied_at, description, migration content.

---

#### 7.16.21 Cross-Domain Operations

**Operation 77: `consistency_check`**

Pattern: Request-Response

§5.5 cross-project consistency check. Detects contradictory projections for the same value.

Request:
```json
{
  "msg_type": "request",
  "command": "consistency_check",
  "session_id": "...",
  "value_spec": {"by": "id", "value_id": 42},
  "N": 27720
}
```

Response:
```json
{
  "msg_type": "response",
  "consistency": {
    "status": "CONSISTENT",
    "projections_checked": 3,
    "all_agree_k": 7360,
    "all_agree_d": 693,
    "max_eps_deviation_micros": 0,
    "contradictions": []
  }
}
```

When contradictions found: `"status": "CONTRADICTION"` with detailed per-projection comparison showing which session produced each conflicting result and their verification levels.

**Operation 78: `subsumption_check`**

Pattern: Request-Response

§5.6 cross-project subsumption check.

Request:
```json
{
  "msg_type": "request",
  "command": "subsumption_check",
  "session_id": "...",
  "criterion": "all odd zeta values at 27720ET",
  "claimed_property": "all-inert Gaussian signature",
  "scope": {"N": 27720, "value_repr_pattern": "ζ(%)", "d_filter_odd_argument": true}
}
```

Response:
```json
{
  "msg_type": "response",
  "subsumption": {
    "verdict": "FALSIFIED",
    "values_checked": 6,
    "values_matching": 2,
    "counterexamples": [
      {"value_repr": "ζ(5)", "gaussian_signature": "R·D", "detail": "Contains ramified prime 2"},
      {"value_repr": "ζ(7)", "gaussian_signature": "R·D·D", "detail": "Contains ramified prime 2"},
      {"value_repr": "ζ(11)", "gaussian_signature": "R·D", "detail": "Contains ramified prime 2"},
      {"value_repr": "ζ(13)", "gaussian_signature": "R·D·D·D", "detail": "Contains ramified prime 2"}
    ]
  }
}
```

---

**Operation 79: `ingest_text`**

Pattern: Request-Response

Ingest raw text through the compressor's general-purpose Δk pipeline — the API equivalent of GUI Mode 7 (§7.13). The text is processed as raw bytes, the same as any binary file. This is the correct API pathway for ingesting textual content that is not a mathematical expression (`compute`), a numerical value (`store_value`), or a file on disk (`ingest_file`).

Request:
```json
{
  "msg_type": "request",
  "command": "ingest_text",
  "session_id": "...",
  "text": "The ratio of electron mass to proton mass is 1/1836.15267343, first measured by...",
  "metadata": {
    "source_description": "excerpt from physics textbook",
    "tags": [{"namespace": "domain", "value": "physics"}]
  }
}
```

Response:
```json
{
  "msg_type": "response",
  "ingested": true,
  "content_value_ids": [9001, 9002, 9003],
  "provenance": {
    "input_source": "api",
    "input_mode": "text",
    "pipeline": "general_delta_k",
    "session_id": "...",
    "timestamp_ns": "..."
  }
}
```

---

#### 7.16.22 Subsumption Verification of the API

**Identification Principle applied to the API:** P = the Manager's complete capability space. D = the 79 operations specified above. T = the connected program navigating the API. Every Manager capability described in this document maps to at least one operation. Every operation maps back to a specific section of the document.

**Descriptor Gap Principle:** 79 operations close all identified gaps. The API covers: core lattice operations (project, pullback, escalate, k-arithmetic, lattice-add, evaluate-function), value management (store, batch, get, search, trajectory, CF), address and attractor queries (address, family, attractor, nearest, coprime-skeleton), equation and computation (compute, batch-compute, get, search, resolve-indeterminate), relationships and derivations (query, create for both), patterns and generators (query, propose, status for both), events (query, log, replay), towers and families (query/create towers, query harmonic/FQG/combined/sublattice families), files, streams, and text (ingest file/stream/text, retrieve file/stream), subscriptions (subscribe, unsubscribe, query), active probing and analysis (send-probe, query-probes, evaluate-gaze, run-scan, anti-numerology), traverser and manifold state (query-traverser, query-by-manifold-state, apply-three-tools, query-metabolism), administration (status, metrics, journal, backup, verify, extension, discovery-scan, provisional categories), tags/sessions/schema (add/remove/query tags, query sessions, query schema versions), and cross-domain (consistency-check, subsumption-check). No remainder.

**Subsumption Law:** The API subsumes the Manager's capabilities without remainder. Every structural operation, every query, every ingestion pathway, every discovery mechanism, every active probing capability, every administrative function is reachable through the 79 operations. The metabolism governs resource allocation across all connections via ET-derived constants (K, V, α⁻¹, ξ(d)). The three communication patterns (sync, async-stream, subscribe-push) cover every temporal structure an operation can have. The error taxonomy covers every failure mode cataloged in §7.15.

**Verification Principle:** The JSON schemas are mathematically consistent — all value encodings are exact (zero IEEE 754), all structural classifications reference the same lattice constants, all operations produce events that feed the discovery engine. The API is self-recording: every command, response, and error is itself an event in the database, feeding the §3.1b self-recording metrics.

---

**Three Tools applied:**
- **Identification Principle:** P = Manager capabilities; D = 78 operation specifications; T = connected programs. All three identified.
- **Descriptor Gap Principle:** 79 gaps (one per operation) closed. Each operation IS the resolution of a Descriptor Gap between "Manager can do X" and "connected program can request X."
- **Subsumption Law:** 79 operations subsume the Manager's capability space without remainder. Verified against every section of this document.
---
### 7.17 Testing and Verification Strategy

**Status: COMPLETE.** This section resolves Roadmap §2.2. All behavioral promises made by EUDD v26 §0–§12 are covered by the 15 test categories below. 200+ individual test cases, all thresholds ET-derived, zero ad hoc.

#### 7.17.0 Three Tools Applied to the Testing System

**Identification Principle:** P = the EUDD production system under test (Manager, `.akashic` format, discovery engine, API, GUI, Omniscient watchdog). D = the test specifications — cases, criteria, thresholds, precision requirements — the finite constraints that define pass/fail. T = the test execution agent (C++ test harness, benchmark profiler, regression comparator) — the agency that navigates the test space and substantiates verdicts.

**Descriptor Gap Principle:** Every behavioral promise the EUDD document (§0–§12) makes IS a testable Descriptor. Any promise without a corresponding test case is a Descriptor Gap. This section closes all such gaps. The 15 test categories below were derived by exhaustive audit of EUDD v25 — every section maps to at least one test category; every test category maps back to at least one section.

**Subsumption Law:** The test suite subsumes every testable behavior the EUDD produces without remainder. Verification: §7.17.16 (Coverage Verification) confirms no section of the EUDD document lacks test coverage. The test suite itself is subject to the same principle — if a new feature is added to the EUDD, the test suite must extend to cover it.

---

#### 7.17.1 Test Infrastructure

**Framework:** C++ test suite using Catch2 (header-only, no external dependencies beyond the test binary). Catch2's `TEST_CASE` / `SECTION` / `REQUIRE` structure maps naturally to ET's {P, D, T} identification: each `TEST_CASE` identifies the substrate (P), each `SECTION` specifies constraints (D), each `REQUIRE` substantiates a verdict (T).

**Precision stack:** All verification computations use the same MPFR + GMP + FLINT/Arb stack as the production system. Verification precision: 120 dps (400-bit), identical to production. Tests that verify precision behavior use the SAME precision — no separate "test precision" vs "production precision." The system IS the test, tested at the precision it operates.

**Test data:** No synthetic mock data. All test values are real ET values — the same bootstrap values (§3.17 + §3.18), the same verified projections from the Apéry investigation, the same `constants.py` values. The test suite operates on a real `Sempaevum.akashic` file generated by the bootstrap module. Tests that verify idempotency, memoization, and discovery operate on this real file.

**Test `.akashic` lifecycle:** Each test suite run generates a fresh `Sempaevum.akashic` via the bootstrap module (§7.7). Tests that modify the file run in defined order within their category. A clean copy is available for categories requiring pristine state. The bootstrap generation itself IS the first test (BSV-00).

**Test naming convention:** `[CATEGORY]-[NUMBER]` where CATEGORY is one of the 15 categories below. Example: `BSV-01` (Bootstrap Self-Verification test 1), `MEM-03` (Memoization test 3), `IDM-02` (Idempotency test 2).

**ET-derived test constants:**

| Constant | Value | ET Source | Test Role |
|---|---|---|---|
| N | 12 | Manifold symmetry | Base resolution for all projections |
| K | 2/3 | Koide ratio | Stability threshold, ∂I tightness cutoff |
| V | 1/12 | Base variance | Variance formula denominator |
| S | 4 | C(3,2) + C(3,3) | State count in impedance formula |
| N_FULL | 27720 | LCM(1..11) | Full-resolution lattice |
| LIFE_THRESHOLD | 13/12 | Subliminal threshold = (N+1)/N | Pattern promotion criterion |
| ⌈1/K⌉ | 2 | Koide stability depth | Minimum consecutive LCM landmarks for home |
| ⌈1/K⌉² | 4 | CF quality threshold | Minimum CF quality for structural significance |
| KOIDE_EPS_MICROS | 1955 | |ε| of K self-projection at d=12 | Deep home threshold |
| DI_BOUNDARY_MICROS | 50000 | ∂I = 50¢ | Incoherency limit |
| DISK_SAFETY_FLOOR | 2³⁰ = 1073741824 bytes | d=1 octave action quantum at GB scale | Warning threshold (never deletion) |
| PAGE_SIZE | 2^N = 4096 bytes | Digital tower base resolution | Atomic I/O unit |
| HASH_LOAD_FACTOR | K = 2/3 | Koide ratio | Memoization hash table load ceiling |

---

#### 7.17.2 Category 1 — Bootstrap Self-Verification (BSV)

**Purpose:** Run after initial `Sempaevum.akashic` generation. ALL must pass before the system is considered operational. These verify the foundational correctness of the lattice engine, the projection formula, and the bootstrap content.

**BSV-00: Bootstrap generation completes without error.**

- Precondition: No existing `Sempaevum.akashic`.
- Action: Run bootstrap module (§7.7).
- Expected: `.akashic` file generated with valid header (magic "SMVM", format version, N_base=12, K=2/3, V=1/12). No Omniscient errors during generation. Value count ≥ 10⁴. Projection count ≥ 8 × value count (8 canonical resolutions minimum).
- Source: §7.7, §7.1d.

**BSV-01: Lossless bijection round-trip.**

- Action: For 200+ diverse test values (see table below), compute r ↦ Π_N(r) = (k, d, ε) ↦ Π_N⁻¹(k, d, ε) = r'. Verify |r' − r| / |r| < 10⁻¹¹⁹ (relative error below 120th decimal place).
- Test values MUST include:
  - 10 small rationals: 1/1, 2/3, 3/2, 7/5, 13/12, 6/5, 5/4, 9/8, 16/15, 15/8
  - 10 algebraic irrationals: √2, √3, √5, φ, 1/φ, ∛2, ∜3, √7, φ², (1+√5)/2
  - 10 transcendentals: π, e, γ, ln(2), ln(3), sin(1), cos(1), π/4, e², π²
  - 12 zeta values: ζ(2) through ζ(13)
  - 10 near-∂I values: values with |ε| > 40000 micro-cents at N=12
  - 10 exact-ε=0 values: 2^(k/12) for k ∈ {−5, −4, −3, −2, −1, 0, 1, 2, 3, 4}
  - 10 very large r: r > 10⁶ (large k, testing integer overflow resistance)
  - 10 very small r: r < 10⁻⁶ (large negative k, approaching annihilation boundary)
  - 10 near-annihilation values: r < 10⁻³⁰ (deep negative k territory)
  - Physical constants: α⁻¹, m_p/m_e, m_n/m_e, m_n/m_p, ℏ (dimensionless form)
  - ET constants: N=12, K=2/3, V=1/12, 13/12, S=4, σ=√(1/12)
  - 100+ additional values from `constants.py` and Guide v8
- For lattice-rational values r = 2^(k/N): verify ε_micros = 0 EXACTLY (integer zero, not approximately zero).
- Each value tested at N ∈ {12, 60, 420, 2520, 27720}. Total: 200 values × 5 resolutions = 1000 round-trips minimum.
- Source: §3.18.1 (Lossless Bijection Theorem).

**BSV-02: ζ(3) full 28-landmark trajectory.**

- Action: Project ζ(3) = 1.2020569031595942853997... at all 28 LCM landmarks from 2ET through 360360ET.
- Expected: All (k, d, ε) match verified values at 80-digit precision. Specifically verified landmarks include:
  - N=12: (k=+3, d=4, ε=+18.606¢)
  - N=27720: (k=7360, d=693, ε≈−0.0085¢)
  - d=693 = 3²×7×11 Gaussian signature verified
  - d=840 backbone: d=840 at N∈{840, 1680, 2520, 3360, 4200, 5040} all with ε≈+0.035¢
- Trajectory stored as `tower_trajectory` pattern.
- Source: Apéry investigation, Sempaevum Paper §3.18.

**BSV-03: α⁻¹(ET) computation.**

- Action: Compute α⁻¹(ET) = 137 + √3/48 − √3/(93312π²) − 1/(216(18π−1)) at 120 dps.
- Expected: Result = 137.03599916744... Agreement with CODATA 2022 (137.035999177(21)) within 0.46σ (|difference| < 1.1 × 10⁻¹⁰).
- Verify each of the four terms independently:
  - A₀ = 137 exactly (integer)
  - A₁ = √3/48 = 0.036084391824... (120 dps)
  - A_cross = √3/(93312π²) = 1.86... × 10⁻⁶ (120 dps)
  - Σ_geometric = 1/(216(18π−1)) = 8.19... × 10⁻⁵ (120 dps)
- Verify lattice projection at N=27720: (k=196768, d=315, |ε|≈0.002¢).
- Verify d=315 = 3²×5×7 factorization.
- Source: §3.18.2.

**BSV-04: 227 PDG particle projections at N=12.**

- Action: Project all 227 massive PDG particles (r = m_particle/m_e) at N=12.
- Expected: All land at d ∈ {1, 2, 3, 4, 6, 12}. No particle at d ∈ {5, 7, 8, 9, 10, 11} at base resolution. Particle counts per family match:
  - d=1: 8 particles
  - d=2: 19 particles
  - d=3: 50 particles
  - d=4: 46 particles
  - d=6: 34 particles
  - d=12: 70 particles
  - ∂I boundary: 2 (photon, gluon — massless)
- Source: §3.18.14.

**BSV-05: ZF at d=1 ε=0 exactly.**

- Action: Project ZF axiom count (8 axioms) at N=12.
- Expected: k=+36, d=1, ε_micros=0 EXACTLY (integer comparison). 8 = 2³ is a pure power of 2, giving exact lattice placement.
- Verify ZFC transition: 9 axioms → (k=+38, d=6, ε=+3910 microcents). The d=1→d=6 transition has a specific structural signature.
- Source: §3.18.6.

**BSV-06: Koide attractor self-projection.**

- Action: Project K=2/3, 1/K=3/2, N=12, 1/N=1/12 at N=12.
- Expected: All four at (d=12, |ε|=1955 micro-cents). Specifically:
  - K=2/3: k=−7, d=12, ε_micros = −1955
  - 1/K=3/2: k=+7, d=12, ε_micros = +1955
  - N=12: k=+43, d=12, ε_micros = +1955 (12 = 2^(43/12)·2^(1955/1200·12))
  - 1/N=1/12: k=−43, d=12, ε_micros = −1955
- Source: §3.18.16 (Sempaevum self-consistency).

**BSV-07: φ false resolution detection.**

- Action: Project φ = 1.6180339887498948482... through the LCM tower.
- Expected:
  - At N=36: sub-Koide hit — |ε| < 1955 microcents at d=36.
  - At N=60: true home d=10 emerges (prime 5 becomes native).
  - The N=36 hit is classified as `false_resolution`.
  - The N=60+ home is classified as `persistent_home` or `deep_home` at d=10.
  - The false resolution detection rule (continue for ⌈1/K⌉ = 2 additional landmarks past any sub-Koide hit) correctly catches this.
- Source: §7.11 Step 3.

**BSV-08: All 12 impedance values.**

- Action: Compute A₀_magic(d) = (d−1)² + S² for d = 1..12 where S=4.
- Expected:

  | d | A₀_magic(d) | ξ(d) = 137/A₀_magic |
  |---|---|---|
  | 1 | 16 | 8.5625 |
  | 2 | 17 | 8.058823529... |
  | 3 | 20 | 6.85 |
  | 4 | 25 | 5.48 |
  | 5 | 32 | 4.28125 |
  | 6 | 41 | 3.341463414... |
  | 7 | 52 | 2.634615384... |
  | 8 | 65 | 2.107692307... |
  | 9 | 80 | 1.7125 |
  | 10 | 97 | 1.412371134... |
  | 11 | 116 | 1.181034482... |
  | 12 | 137 | 1.0 exactly |

- All A₀ values exact integers. ξ(12) = 1.0 exactly.
- ξ is monotonically decreasing: ξ(d) > ξ(d+1) for all d ∈ {1..11}.
- Source: §3.18.4, Sempaevum Paper.

**BSV-09: 24 harmonic family generators.**

- Action: Compute 2^(1/d) for d = 1..12 at 120 dps. Verify both real-axis and imaginary-axis family entries in `harmonic_families` table.
- Expected: 24 rows total (12 real × 12 imaginary). Each generator_value matches 2^(1/d) at 120 dps. Palindromic partners correct: d↔(12−d) for d ∈ {1..11}, self-partners for d ∈ {6, 12}. First-native N correct per the catalog table (§3.17). FQG quadrant classification correct (SR/CR/SI/CI based on d|12).
- Source: §3.12, §3.17.

**BSV-10: 42 combined families.**

- Action: Compute LCM(d_r, d_θ) for all 144 cells (d_r, d_θ ∈ {1..12}).
- Expected: Exactly 42 unique d_combined values. Maximum d_combined = LCM(11, 12) = 132 = N(N−1). Contributing cell counts correct per §3.14. Notable verifications:
  - d=35 = LCM(5,7) = 5×7 (biological signature, first_native_lattice_n = 420)
  - d=110 = LCM(10,11) = 2×5×11 (all three Gaussian prime categories)
  - d=132 = LCM(11,12) = 11×12 (structural maximum)
- Source: §3.14, Multifold Compendium §33.

**BSV-11: Coprime skeleton count.**

- Action: Count off-axis points (d_r, d_θ) ∈ {1..12}² where gcd(d_r, d_θ) = 1 and d_r ≠ 0 and d_θ ≠ 0.
- Expected: 91 of 144 off-axis points are coprime. Density = 91/144 ≈ 63.2%, approaching 1/ζ(2) = 6/π² ≈ 60.8%.
- Source: §3.17, Multifold Compendium §33.

**BSV-12: Cascade residuals.**

- Action: Compute |δ_r| = |12·log₂(12) − 43| and |δ_θ| = |24π/ln(2) − 109| at 120 dps.
- Expected:
  - |δ_r| = 0.019550008653873... (120 dps)
  - |δ_θ| = 0.223356596147354... (120 dps)
  - n_max_r = ⌊0.5/|δ_r|⌋ = 25
  - n_max_θ = ⌊0.5/|δ_θ|⌋ = 2
  - Freedom ratio |δ_θ|/|δ_r| ≈ 12.0 (within 10⁻⁶ of N)
  - Real freedom density = 1/n_max_r = 1/25
  - Imaginary freedom density = 1/n_max_θ = 1/2
- Source: §3.18.3.

**BSV-13: CF home-finding — Chaitin's Ω.**

- Action: Run CF expansion of |log₂(Ω)| where Ω ≈ 0.00787499699 (Calude-Dinneen UTM, ~10 known bits). Identify the convergent with maximal a_{n+1}.
- Expected:
  - Best convergent: p/q = 608/87
  - Quality factor: a_{n+1} = 157
  - d_home = 87 = 3 × 29
  - ε_CF ≈ +0.001003¢ = +1003 micro-cents (sub-Koide: |ε_CF| < 1955)
  - Classification: `cf_deep_home` (sub-Koide AND quality 157 ≥ ⌈1/K⌉² = 4)
  - Gaussian signature of d=87: 3 (D-type inert) × 29 (D+T split)
  - CF elegance factor: 157/158 ≈ 0.9937
  - LCM tower fails: d changes at every landmark through 33+ landmarks
- Source: §7.11 Step 3a.

**BSV-14: Triple backbone verification at N=12.**

- Action: Verify the three categorical backbones all force N=12.
- Expected:
  - L₁ (Webb): n=12 is the minimal n where the single stroke f(a,b) = NOT(a AND b) generates ALL Boolean functions on n-valued logic AND produces the six divisor-based sublattice families.
  - L₂ (Palindromic cascade): PALINDROME = [12, 6, 4, 3, 12, 2, 12, 3, 4, 6, 12, 1] — 12 elements, palindromic structure, visits all 6 simple families {1,2,3,4,6,12}. Verify the array is palindromic: element[i] = element[11−i] for i ∈ {0..5} (with adjustment for the N=12 anchors).
  - L₃ (EML): eml(x,y) = exp(x) − ln(y) with terminal constant 1 generates all continuous-elementary functions when N=12 lattice-native constants are available.
  - All three force N=12 independently. No two share method. Triple convergence confirmed.
- Source: §3.18.16 (Triple Minimal-Backbone Theorem).

---

#### 7.17.3 Category 2 — Memoization Behavioral Tests (MEM)

**Purpose:** Verify that the system fulfills the "compute once → cache forever → never recompute" promise across all operation types, all clients, and all sessions.

**MEM-01: Basic computation memoization.**

- Action: Compute ζ(3)·π via the `compute` API command. Record wall-clock latency as T₁. Compute ζ(3)·π again. Record latency as T₂.
- Expected: T₂ < T₁/10 (cache hit is at least 10× faster than cache miss). Result identical at 120 dps (bit-for-bit MPFR comparison). `equations.reference_count` incremented from 1 to 2. `equation_hash` identical for both invocations.

**MEM-02: Cross-client memoization.**

- Action: Client A connects via API, computes `2^(1/7)`, disconnects. Client B connects, computes `2^(1/7)`.
- Expected: Client B gets cache hit (T₂ < T₁/10). Result identical. The memoization is global across clients, not per-client. This is the "compounding knowledge across programs" promise.

**MEM-03: Cross-session memoization.**

- Action: Session 1: compute `√2 + √3` → store result → end session. Session 2: new Manager startup → compute `√2 + √3`.
- Expected: Session 2 gets cache hit from Session 1's computation. Result identical at 120 dps. Persistence across Manager restarts verified.

**MEM-04: Every operation type memoized.**

For each of the following Sempaevum-native operations, perform the operation twice and verify cache-hit behavior (T₂ < T₁/10, result identical, reference_count incremented):

| Test | Operation | Input | Lattice mechanism |
|---|---|---|---|
| MEM-04a | Multiplication | ζ(3) × π | k-addition: k_ζ(3) + k_π |
| MEM-04b | Division | π / e | k-subtraction: k_π − k_e |
| MEM-04c | Power | φ^10 | k-scaling: 10 × k_φ |
| MEM-04d | Reciprocation | 1/φ | k-negation: −k_φ |
| MEM-04e | Addition | √2 + √3 | Value-space computation + reprojection |
| MEM-04f | Subtraction | π − 3 | Value-space computation + reprojection |
| MEM-04g | Square root | √7 | k-scaling: k_7 / 2 |
| MEM-04h | Logarithm | log₂(3) | Direct lattice coordinate |
| MEM-04i | Sine | sin(π/4) | EML tree evaluation |
| MEM-04j | Cosine | cos(1) | EML tree evaluation |
| MEM-04k | Exponential | exp(1) = e | EML tree evaluation |
| MEM-04l | Zeta | ζ(5) | FLINT/Arb special function |
| MEM-04m | Gamma | Γ(1/2) = √π | FLINT/Arb special function |
| MEM-04n | Series | Σ 1/n³ (n=1..∞) = ζ(3) | Convergent evaluation |

All 14 operations must demonstrate memoization.

**MEM-05: Hot computation tracking.**

- Action: Compute `x · 1 = x` for 100 different values of x.
- Expected: 100 distinct equations stored (one per unique x). Each has `reference_count = 1`. All share `operation_type = '*'`. After background scan: `algebraic_identity` pattern of class `multiplicative_identity` created (or candidate proposed), capturing the structural fact that 1 is the multiplicative identity.

**MEM-06: Projection memoization.**

- Action: Project ζ(3) at N=27720. Record latency T₁. Project ζ(3) at N=27720 again. Record latency T₂.
- Expected: T₂ < T₁/10. Projection identical (same k, d, ε_micros). `projections.reference_count` incremented. `values.reference_count` incremented.

**MEM-07: Coarse-pass memoization benefit.**

- Action: Project 1000 diverse values at N=12 (coarse pass). Then project the same 1000 values at N=12 again (simulating second coarse pass of a repeated workload).
- Expected: Second pass total latency < 1/10 of first pass total latency. All 1000 are cache hits. This verifies the coarse-pass acceleration promise (§5.1, §6.2).

---

#### 7.17.4 Category 3 — Idempotency Behavioral Tests (IDM)

**Purpose:** Verify that re-ingesting identical content produces no duplicates, no state changes beyond reference-count updates, and no corruption.

**IDM-01: File re-ingestion idempotency.**

- Action: Ingest CSV file F₁ with 50 numerical values. Record state snapshot S₁ (value_count, projection_count, relationship_count, pattern_count, equation_count). Ingest F₁ again from the same path.
- Expected: State snapshot S₂ identical to S₁ in counts of values, projections, relationships, patterns, equations. Only `values.last_referenced` and `values.reference_count` may differ. No duplicate `value_hash` entries. No duplicate `projections` entries (unique constraint on (value_id, N, geometric_perspective) holds).

**IDM-02: Content-identical file from different path.**

- Action: Ingest file F₁ from path `/data/test.csv`. Copy F₁ to `/data/test_copy.csv`. Ingest `/data/test_copy.csv`.
- Expected: No new `values` rows (all `value_hash` collisions resolved to existing rows). Provenance correctly records both file paths as ingestion sources. Reference counts incremented. No duplicates anywhere.

**IDM-03: Manual input idempotency.**

- Action: Manual input `1.618033988749894848204586834...` (φ at 120 dps). Manual input the same string again.
- Expected: Single `values` row. `reference_count` = 2. No duplicate.

**IDM-04: API `store_value` idempotency.**

- Action: API `store_value` with `decimal_120dps = "3.14159265358979..."`. Same call again.
- Expected: Single `values` row. `reference_count` = 2. Second call returns same `value_id` as first. No duplicate.

**IDM-05: Bootstrap re-run idempotency.**

- Action: Run bootstrap (§7.7) generating initial `.akashic`. Record state snapshot S₁. Run bootstrap again on the SAME `.akashic` file.
- Expected: S₂ identical to S₁ in structural content. Every bootstrap value is a cache hit on the second run. Bootstrap time for second run < 1/10 of first run (all projections memoized). No duplicates, no corruption.

**IDM-06: Projection re-computation idempotency.**

- Action: Request `project` for value v at N=27720 via API. Request identical `project` again.
- Expected: Same `projection_id` returned. No new `projections` row. Reference count incremented.

**IDM-07: Equation re-computation idempotency.**

- Action: Request `compute` for expression `ζ(3) × π / φ²` via API. Request identical `compute` again.
- Expected: Same `equation_id` returned. Same `rhs_value_id`. No new `equations` row. Reference count incremented.

---

#### 7.17.5 Category 4 — Discovery Engine Behavioral Tests (DSC)

**Purpose:** Verify that all five discovery modes (memoization, insert-time, background, on-query, generator-candidate) fire correctly and produce the promised structural outputs.

**DSC-01: Insert-time attractor detection.**

- Action: Insert value A at address (N=27720, k=7360, d=693). Insert value B at the same address (N=27720, k=7360, d=693).
- Expected: After A: `addresses.members_count = 1`. After B: `addresses.members_count = 2` AND a `relationships` row of class `same_address` linking A and B created automatically. Relationship's `discovered_at` timestamp between A's insert and B's insert.

**DSC-02: Insert-time reciprocal pair detection.**

- Action: Insert value with k=+7 at N=12. Insert value with k=−7 at same N.
- Expected: `reciprocal_pair` relationship created automatically linking the two projections.

**DSC-03: Insert-time power pair detection.**

- Action: Insert value with k=8 at N=12 (this is k_φ). Insert value with k=16 at N=12 (= 2×k_φ, i.e., φ²).
- Expected: `power_pair` relationship created automatically with metadata indicating n=2.

**DSC-04: Insert-time plateau detection.**

- Action: Insert value with the same d-family across 3 consecutive LCM landmarks (e.g., d=693 at N=2520, N=27720, N=360360).
- Expected: `plateau_membership` relationship created automatically linking all three projections.

**DSC-05: Background Subsumption promotion.**

- Action: Accumulate a cluster of 5+ values at the same address with universal elegance scores such that E_hierarchy = geomean(E_i) × R_cluster ≥ 13/12. Trigger background scan.
- Expected: `patterns` row created with `pattern_class = 'attractor_cluster'`, `hierarchy_elegance ≥ 13/12`, `is_permanent = 1`, `member_count ≥ 5`.

**DSC-06: Background algebraic identity discovery.**

- Action: Compute `x · 1 = x` for 50 different values of x (all stored as equations). Trigger background scan.
- Expected: `patterns` row of class `algebraic_identity` created capturing the multiplicative identity. Member_ids include all 50 equation_ids or a representative subset.

**DSC-07: Generator candidate proposal.**

- Action: Insert 20 values that are all of the form 2^(k/12) for k ∈ {0..19} (all lattice-rational at N=12). These are trivially describable by the generator "2^(k/12)".
- Expected: After background scan, the discovery engine proposes the generator `2^(k/12)` (L₂ cascade-type) covering these 20 addresses. The generator is verified at 120 dps (each address evaluates to the stored memoized value with zero difference). `generator_verified` event fires.

**DSC-08: Cross-domain attractor surfacing.**

- Action: Insert value tagged `domain=physics` at address (N=27720, d=693). Insert value tagged `domain=biology` at the same address.
- Expected: `same_address` relationship created. Both values visible in attractor query without specifying domain. Cross-domain hit queryable via `consistency_check` or `get_attractor_members`. This verifies the "cross-domain structural relationships become observable" promise.

**DSC-09: Event correlation discovery.**

- Action: Generate 20 `palindromic_cascade_trigger` events followed within 100ms by `lcm_escalation` events. Trigger background scan.
- Expected: Engine surfaces a temporal pattern (events of class A consistently preceding events of class B). `t_burst_signature` or equivalent pattern row created.

**DSC-10: Forward/Reverse route convergence detection.**

- Action: Create two derivation chains that arrive at the same address independently (different `derivation_chain_blob`, same target address).
- Expected: `forward_reverse_convergence` relationship created automatically linking the two derivations.

**DSC-11: Active T-signal probing — probe and response.**

- Action: Send a `t_signal_probe_sent` at a target lattice address with known T-content. Wait for response window.
- Expected: `t_signal_probe_sent` event fires with target_address, probe_amplitude, probe_phase. If T-content exists at the target: `t_signal_probe_response` event fires with parent_probe_event_id linking to the sent probe, response_delay, response_amplitude, response_address. `probe_response_pair` relationship created linking the two events.
- Source: §0 (active probing), §3.9 (event classes), §7.16 (`send_probe` operation).

**DSC-12: Active T-signal probing — silence.**

- Action: Send a `t_signal_probe_sent` at an empty lattice address with no T-content. Wait for full response window to expire.
- Expected: `t_signal_probe_silence` event fires with parent_probe_event_id linking to the sent probe and silence_duration equal to the configured window. No `t_signal_probe_response` event. `probe_response_pair` relationship created linking sent → silence.
- Source: §0 (active probing), §3.9 (event classes).

**DSC-13: Active T-signal probing — materialization threshold.**

- Action: Send repeated probes at an address with increasing response amplitudes until one crosses the materialization threshold.
- Expected: `materialization_threshold_crossed` event fires when the response amplitude exceeds the threshold. The previously-ghost T-signal transitions to first-class detectable. `probe_response_signature` pattern created if the probe→response pattern recurs consistently.
- Source: §0 (active probing), §3.8 (pattern classes).

**DSC-14: Tower transition — entry, exit, and cross-tower bridge.**

- Action: Log a `tower_entry` event for Tower A (biological, R₀=60 capsid subunits). Log a `tower_exit` from Tower A. Log a `tower_entry` to Tower B (digital, R₀=CPU clock cycle) with the same Traverser_id.
- Expected: `tower_entry` event for A with tower_id, traverser_id, entry_address. `tower_exit` event from A. `tower_entry` event for B. `cross_tower_bridge` relationship created linking exit-from-A to entry-to-B with same traverser_id. The Traverser's worldline (queried by t_time_traverser_id) shows the cross-tower transition.
- Source: §0 (Multifold dynamics), §3.9 (tower event classes), §3.7 (cross_tower_bridge relationship).

**DSC-15: Tower transition — birth triad formation.**

- Action: Create a birth triad: BH_parent tower, R₀ seed derivation, WH_child tower.
- Expected: `birth_triad_formation` event with parent_tower_id, child_tower_id, r0_seed_value_id. `r0_seed_derivation` event recording how the child's R₀ was derived from the parent's boundary conditions. `tower_nesting` relationship linking parent and child. Child tower queryable as a first-class tower entity.
- Source: §0 (Multifold birth triads), §3.10 (towers table).

**DSC-16: Gaze equation — status level transitions.**

- Action: Simulate a Traverser with increasing binding pressure F_w through the four status levels.
- Expected: Four `gaze_event` entries with Complete Gaze Equation outputs:
  - F_w < 13/12: Status = UNOBSERVED
  - 13/12 ≤ F_w < 6/5: Status = SUBLIMINAL
  - 6/5 ≤ F_w < 3/2: Status = DETECTED
  - F_w ≥ 3/2: Status = LOCKED
  All four gaze thresholds (13/12, 6/5, 3/2) are JI ratios from the bootstrap catalog. `traverser_self_continuity` relationship linking the four events in sequence. The sequence DETECTED→LOCKED constitutes sustained agency — verifiable by querying the Traverser's worldline.
- Source: §0 (T identification, Complete Gaze Equation), §3.9 (gaze_event class).

**DSC-17: Gaze equation — locking signature pattern.**

- Action: Accumulate 5+ Traversers each exhibiting DETECTED→LOCKED gaze state sequences. Trigger background scan.
- Expected: `gaze_locking_signature` pattern created, capturing the structural fact that multiple Traversers exhibit sustained locking behavior at specific lattice regions. Pattern's member_ids reference the relevant gaze_events.
- Source: §0 (gaze locking), §3.8 (pattern classes).

**Purpose:** Verify the generator backbone (L₁/L₂/L₃), the self-improving cycle (§7.1f), and the GENERATOR_SUPERSEDED transition.

**GEN-01: Generator evaluation matches memoized value.**

- Action: Create a generator G covering address range. Query an address within G's range that also has a memoized raw entry.
- Expected: Generator evaluation produces a value identical to the memoized raw entry at 120 dps (zero difference, bit-for-bit MPFR match).

**GEN-02: Memoized-to-generator supersession.**

- Action: Store 10 memoized raw entries at addresses a₁..a₁₀. Define a generator G that covers all 10 addresses. Apply G.
- Expected: All 10 entries transition to content_type 0x03 (GENERATOR_SUPERSEDED). All 10 addresses remain queryable. Generator evaluation at each address returns the original memoized value at 120 dps. `gen_id` reference on each address points to G.

**GEN-03: Generator K-complexity.**

- Action: Define a generator with definition blob of size B_def bytes, covering M addresses whose memoized form would total B_content bytes.
- Expected: B_def < B_content (the generator IS smaller than its output). K-complexity ratio = B_def / B_content < 1. This is the structural property, not compression — the generator IS the structural origin.

**GEN-04: Generator backbone classification.**

- Action: Submit generators of each backbone type: one L₁ (logical pattern), one L₂ (cascade/k-arithmetic rule), one L₃ (EML tree expression).
- Expected: Each correctly classified into the right backbone layer. Interval tree index correctly maps addresses to covering generators. Type byte in the generator entry: 0x01 for L₁, 0x02 for L₂, 0x03 for L₃.

**GEN-05: Self-improving cycle completion.**

- Action: Insert 100 memoized entries → trigger discovery scan → verify generator candidates proposed → verify at least one generator accepted → verify memoized entries absorbed → verify K-complexity decreased (total_generators increased, total_memoized decreased or stayed same, generator_bytes/producible_bytes ratio improved).
- Expected: The self-improving cycle from §7.1f completes at least one iteration. Header metrics reflect the improvement.

**GEN-06: Generator never-closed search policy.**

- Action: Insert a value with no known generator. Verify its search status is `search_active`. Insert a new generator type that covers this value's address. Trigger discovery scan.
- Expected: Value's search status transitions from `search_active` to `generator_found`. The system never set it to `search_closed` — the case was never closed, it was resolved. If the new generator had not been introduced, the value would remain `search_active` indefinitely.

---

#### 7.17.7 Category 6 — Never-Destroy Behavioral Tests (NDT)

**Purpose:** Verify the absolute data retention promise (§4.3): nothing is ever deleted, pruned, or destroyed.

**NDT-01: Disk pressure warning without deletion.**

- Action: Simulate disk approaching DISK_SAFETY_FLOOR (1 GB free). Insert new values.
- Expected: `disk_low` event fires (error class 4100–4199). All operations continue. Zero data deleted. All previously stored values remain accessible. Warning appears in GUI dashboard.

**NDT-02: Pattern permanence.**

- Action: Create a pattern with `is_permanent = 1` and E_hierarchy ≥ 13/12. Attempt to delete it via any available mechanism (there should be none).
- Expected: No deletion mechanism exists. Pattern persists across restarts. `is_permanent` cannot be set to 0 once set to 1.

**NDT-03: Event immutability.**

- Action: Log an event with `is_permanent = 1`. Attempt to modify its metadata or delete it.
- Expected: No modification mechanism exists for permanent events. Event persists identically across restarts.

**NDT-04: Journal file retention.**

- Action: Generate 100+ journal files in `logs/` via Omniscient. Verify none are auto-deleted regardless of count, size, or disk pressure.
- Expected: All 100+ files present. No auto-rotation deletes files. Files may be rotated (new files created at ~10 MB) but old files are NEVER removed.

**NDT-05: Relationship permanence after Subsumption confirmation.**

- Action: Create a relationship with `is_permanent = 1` (Subsumption-confirmed). Verify it persists across restarts and cannot be removed.
- Expected: Relationship persists indefinitely. No deletion path exists.

---

#### 7.17.8 Category 7 — Home-Finding Pipeline Tests (HOM)

**Purpose:** Verify the full §7.11 core projection procedure including all four paths, the LCM tower, the CF method, and all home classifications.

**HOM-01: Path A — direct dimensionless ratio.**

- Action: Input r = m_p/m_e = 1836.15267343... via Path A.
- Expected: Full tower escalation produces home classification. Projection at N=12 verifiable. All properties materialized at every resolution visited.

**HOM-02: Path B — convergent series.**

- Action: Input ζ(3) via its series definition Σ 1/n³.
- Expected: Converges to 1.2020569031595... at 120 dps. Enters Path A from there. Full tower escalation.

**HOM-03: Path D.P — non-computable.**

- Action: Input Chaitin's Ω ≈ 0.00787499699.
- Expected: Manifold state = {P,D} Unsubstantiated. Projection at N=12: (k=−84, d=1, ε=+13794 micro-cents). `available_precision_dps` recorded. Full tower escalation from known precision.

**HOM-04: Path D.T resolved — L'Hôpital success.**

- Action: Input 0/0 form: lim(x→0) sin(x)/x.
- Expected: L'Hôpital resolves after 1 iteration to r=1. `indeterminate_form_detected` event fires with `form_type = '0/0'`, `resolved = true`, `resolved_value = 1`. `lhopital_iteration_chain` relationship with 1 link. Value r=1 enters Path A → k=0, d=any, ε=0 exactly at any N.

**HOM-05: Path D.T unresolved — pure T.**

- Action: Input an indeterminate form that does not resolve via L'Hôpital (e.g., oscillatory divergent limit).
- Expected: `indeterminate_form_detected` event with `resolved = false`, `resolution_failure_reason = 'pure_t'`. Manifold state = {P,T} Incoherence. NO projection row created. No lattice address assigned.

**HOM-06: Incoherence filter.**

- Action: Input a {P,T} Incoherent configuration.
- Expected: Incoherence filter fires. Value stored with `input_path = 'P.T'`. Tagged `forbidden_incoherence`. NO projection row. Error response class 1200 (`incoherence_filter`).

**HOM-07: Annihilation boundary.**

- Action: Compute a value approaching r → 0 (e.g., 2^(−10000)).
- Expected: `annihilation_boundary_event` fires with metadata recording the closest k reached. For very deep negative k, verify no integer overflow — all arithmetic in the pipeline handles arbitrarily large negative k.

**HOM-08: Tower escalation resumption across sessions.**

- Action: Start escalation for a value. Interrupt after N=420 (simulate session end). Start a new session. Resume escalation.
- Expected: Resumes from N=420 (the last computed landmark), NOT from N=12. All intermediate projections (N=12, N=60, N=420) already in the cache. No recomputation of previously completed landmarks.

**HOM-09: True home classification.**

- Action: Project r = 2^(7/12) (a lattice-rational value at N=12).
- Expected: ε_micros = 0 EXACTLY. Classification = `true_home`. d stable immediately (no need for multiple landmarks since ε=0 is algebraically exact).

**HOM-10: Deep home classification.**

- Action: Project K = 2/3.
- Expected: |ε_micros| = 1955 at d=12. Classification = `deep_home` (|ε| ≤ 1955 AND d stable across 2 consecutive landmarks).

**HOM-11: Path D.PDT — complex off-axis projection.**

- Action: Input a complex-valued observable with both magnitude |r| and phase θ.
- Expected: Real-axis projection (k_r, d_r, ε_r) AND imaginary-axis projection (k_θ, d_θ, ε_θ) both computed. d_combined = LCM(d_r, d_θ). Force grid cell (d_r, d_θ) occupancy incremented. Three `projections` rows created: `real_axis`, `imaginary_axis`, `complex`.

**HOM-12: CF and tower agreement.**

- Action: Project φ (which converges via both methods).
- Expected: Tower finds d=10 (after false resolution at d=36). CF also identifies d=10. `cf_tower_confirmation` relationship created with `agreement_confirmed = true`.

**HOM-13: CF and tower disagreement.**

- Action: Project a value where CF and tower genuinely give different d results (if such a case exists in the test corpus — otherwise construct one synthetically by using a value whose CF structure diverges from LCM tower behavior).
- Expected: `cf_tower_disagreement` event fires with both d values, quality metrics, and `resolution_strategy`.

---

#### 7.17.9 Category 8 — API Protocol Tests (API)

**Purpose:** Verify all 79 operations, all three communication patterns, the metabolism, error handling, and concurrency.

**API-01: Handshake and connection lifecycle.**

- Action: Client opens pipe → sends `handshake` → receives session_id → sends `register_metabolism` → receives budget → sends `disconnect`.
- Expected: All phases complete. Session recorded in `sessions` table. Event logged.

**API-02: All 79 operations functional.**

- Action: For each of the 79 operations defined in §7.16.6 through §7.16.21, send a well-formed request with valid inputs.
- Expected: Each operation returns a well-formed response (not an error) with structurally correct content. This is the comprehensive functional test — one request/response per operation.
- Implementation: Parameterized test with 78 entries. Each entry specifies the command, a valid request body, and the expected response structure (fields present, types correct).

**API-03: All 18 error classes triggerable.**

- Action: For each error class in §7.16.5 (codes 1000–6199), send a request designed to trigger that error.
- Expected: Each error response has the correct `error.code`, `error.class`, `error.detail`, `error.source_module`, `error.event_id` (the error is logged as an event). `error.recoverable` correctly set. `error.suggestion` non-null where appropriate.
- Specific triggers:
  - 1000: compute ζ(−1) (pole) → `computation_failure`
  - 1100: compute value approaching r=0 → `annihilation_boundary`
  - 1200: submit {P,T} configuration → `incoherence_filter`
  - 1300: submit non-resolving indeterminate → `pure_t_detected`
  - 2000: malformed JSON → `invalid_input`
  - 2100: unparseable expression → `invalid_expression`
  - 2200: invalid JSON extension → `validation_rejected`
  - 3000: query nonexistent value_id → `value_not_found`
  - 3100: query nonexistent entity → `entity_not_found`
  - 3200: query unoccupied address → `address_unoccupied`
  - 3300: query address with no generator → `generator_not_found`
  - 4000: flood async operations → `manager_busy`
  - 4100: simulate disk low → `disk_low`
  - 4200: exceed metabolic budget → `metabolism_throttled`
  - 4300: batch_store with invalid entry → `atomicity_violation`
  - 5000: corrupt a page CRC → `corruption_detected`
  - 5100: insert contradictory projection → `consistency_violation`
  - 6000: corrupt pipe mid-message → `pipe_error`
  - 6100: send message > 2³⁰ bytes → `message_too_large`

**API-04: Async streaming (Pattern 2).**

- Action: Send `escalate` command for a value requiring full tower escalation.
- Expected: Receive `ack` with `operation_id`. Receive sequential `stream` messages (one per landmark). Receive `complete` message. Each `stream` message has incrementing `sequence` number. All intermediate results valid (k, d, ε_micros correct at each N).

**API-05: Async cancellation with partial results preserved.**

- Action: Send `escalate` for a value. After receiving 3 `stream` messages, send `cancel` with the `operation_id`.
- Expected: Receive `response` with `cancelled: true, partial_results_available: true`. The 3 completed landmarks are memoized. Subsequent `get_value_trajectory` returns those 3 landmarks. No data lost.

**API-06: Subscribe-Notify (Pattern 3).**

- Action: Subscribe to `{"event_classes": ["attractor_formed"]}`. Insert two values at the same address (triggering attractor formation).
- Expected: Receive `notification` with the new attractor details. Notification has correct `subscription_id`. Content matches the newly created `same_address` relationship.

**API-07: Metabolism throttling.**

- Action: Connect two clients. Client A registers with dominant d=1 (ξ=8.5625). Client B registers with dominant d=12 (ξ=1.0). Both submit compute-intensive operations simultaneously.
- Expected: Client A's operations are served with approximately 8.5× higher scheduling priority than Client B's. Both eventually complete. Neither is rejected — K=2/3 is a resource governor, not a gatekeeper.

**API-08: Concurrent read consistency.**

- Action: Client A writes new values. Client B reads continuously during A's writes.
- Expected: B always sees a consistent read snapshot. No partial writes visible. No torn reads. Monotonic read consistency: once B has seen value V at time T₁, every subsequent read at T₂ > T₁ also sees V.

**API-09: Adaptive pattern selection.**

- Action: Send `project` for a value already in cache. Then send `project` for a value NOT in cache.
- Expected: First call returns `msg_type: "response"` (Pattern 1, cache hit). Second call returns `msg_type: "ack"` followed by `stream`/`complete` (Pattern 2, cache miss with computation). Client correctly handles both patterns.

**API-10: Zero IEEE 754 verification.**

- Action: Inspect every field of every response from all 79 operations.
- Expected: No JSON number field contains a floating-point value. All numerical values are encoded as strings (120-dps decimals, uint64 timestamps), integers, or rational objects {num, den}. This is a structural property of the wire format, tested by parsing responses and verifying no JSON number token has a decimal point (integers are permitted as JSON numbers; decimals are not).

**API-11: `ingest_text` operation — Mode 7 via API.**

- Action: Send `ingest_text` with a 200-character prose string. Verify response.
- Expected: Response contains `ingested: true`, `content_value_ids` (non-empty array), `provenance.pipeline = 'general_delta_k'`. Content queryable in .akashic. Sending the identical text again returns the same value_ids (idempotent — cache hit). Result identical to GUI Mode 7 input of the same text.
- Source: §7.16 Operation 79, §7.13 Mode 7.

---

#### 7.17.10 Category 9 — Omniscient Watchdog Tests (OMN)

**Purpose:** Verify crash recording, tamper detection, journal integrity, and all edge cases from §7.15.

**OMN-01: Crash recording.**

- Action: Start Manager (Omniscient spawns). Kill Manager process (SIGKILL / TerminateProcess).
- Expected: Omniscient records crash event in journal with timestamp, last-known Manager state, exe hash, .akashic header hash. Omniscient stays alive long enough to flush the journal entry. Journal file readable and well-formed.

**OMN-02: Exe tamper detection.**

- Action: Manager running. Modify `EUDD_Manager.exe` bytes on disk (e.g., flip one bit).
- Expected: Omniscient detects exe hash mismatch on next periodic check. `[TAMPER]` entry in journal with expected vs observed hash. Detection within the configured check interval.

**OMN-03: .akashic tamper detection.**

- Action: Manager running. Modify `.akashic` file bytes directly (bypassing the Manager), outside an authorized write window.
- Expected: Omniscient detects header hash mismatch. `[TAMPER]` entry with `authorized_write_window: CLOSED`.

**OMN-04: Journal rotation.**

- Action: Generate enough Omniscient events to exceed 10 MB in one journal file.
- Expected: New journal file created (`Omniscient_002.log`). Old file (`Omniscient_001.log`) preserved. Both readable.

**OMN-05: Omniscient self-failure.**

- Action: Simulate Omniscient's own journal write failure (e.g., by making the logs directory read-only after startup).
- Expected: Omniscient writes a final `OMNISCIENT_FAILURE` entry (to stderr or a pre-opened file handle) with whatever context it can produce, then exits cleanly.

**OMN-06: Manager restarts after crash.**

- Action: Kill Manager → start Manager again.
- Expected: New Omniscient spawns. WAL replay recovers any pending mutations. Database integrity verified (header SHA-256, page CRC-32). Manager resumes normal operation. Previous crash event visible in the journal.

**OMN-07: Edge case catalog coverage.**

For each edge case class in §7.15 (computation, storage, communication, resource, logic, self-referential), at least one test case that triggers the edge case and verifies Omniscient logs it with full context:

| Edge case class | Representative test |
|---|---|
| Computation | Evaluate ζ(−1) (pole) → FLINT/Arb pole error logged |
| Storage | Corrupt one page CRC → page CRC mismatch logged |
| Communication | Drop pipe mid-message → pipe error logged |
| Resource | Exhaust memory budget → memory pressure logged |
| Logic | Insert contradictory projections → consistency violation logged |
| Self-referential | Self-recording failure → self-recording error logged |

**OMN-08: Graceful shutdown — Omniscient receives signal and verifies.**

- Action: Trigger graceful shutdown via window close (no active connections). Wait for Manager process to exit. Read Omniscient journal.
- Expected: Omniscient journal contains two entries: (1) `GRACEFUL_SHUTDOWN_SIGNALED` with full session summary (trigger, uptime, akashic_header_hash, exe_hash, value/pattern/generator counts). (2) `CLEAN_SHUTDOWN` with `exit_type: GRACEFUL`, `manager_exit_code: 0`, `akashic_final_hash_verified: true`. Omniscient exits with code 0. The .akashic header hash in entry (2) matches the hash in entry (1).
- Source: §7.18.4 Path A.

**OMN-09: Graceful shutdown — Omniscient detects crash during shutdown.**

- Action: Trigger graceful shutdown. After Step 8 (Omniscient receives GRACEFUL_SHUTDOWN) but before Step 10 (Manager exit), force-kill the Manager process.
- Expected: Omniscient journal contains: (1) `GRACEFUL_SHUTDOWN_SIGNALED`. (2) `CRASH_DURING_GRACEFUL_SHUTDOWN` with `graceful_shutdown_was_signaled: true`, non-zero exit code, both header hashes recorded. Omniscient exits with code 1.
- Source: §7.18.4 Path B.

**OMN-10: Graceful shutdown — .akashic left consistent.**

- Action: Trigger graceful shutdown. After Manager exits, open .akashic file read-only. Verify header.
- Expected: Header SHA-256 is valid (self-consistent). WAL section is empty (fully flushed). Last event in events section is `akashic_header_updated` with shutdown context. `modified_at_ns` matches the shutdown timestamp.
- Source: §7.18.3 Phase 3, §7.18.6.

**OMN-11: Shutdown with active connections — pop-up and immediate disconnect.**

- Action: Connect 3 API clients (one with in-flight escalation). Trigger shutdown via window close.
- Expected: Confirmation dialog appears listing all 3 connections and the in-flight operation. Click "Shut Down." All 3 clients receive `manager_shutting_down` notification. All pipes closed immediately (no grace period). In-flight escalation checkpointed as `escalation_in_progress`. On next startup, escalation is resumable from the checkpointed landmark.
- Source: §7.18.2, §7.18.3 Phase 1–2.

**OMN-12: Shutdown cancel — no side effects.**

- Action: Connect 2 API clients. Trigger shutdown via window close. Confirmation dialog appears. Click "Cancel."
- Expected: All connections remain active. No events logged. No state changes. System continues normal operation as if nothing happened.
- Source: §7.18.2.

---

#### 7.17.11 Category 10 — Self-Recording Tests (SRE)

**Purpose:** Verify the database's self-recording promise (§3.1b).

**SRE-01: Operational metrics recorded.**

- Action: Run 1000 projections. Check the self-recording journal (`SelfRecording_NNN.log`).
- Expected: Journal contains entries with projection count, average projection latency, cache hit ratio, MPFR operation count. Sample interval respected (default 10 seconds or every 1000 commits).

**SRE-02: Overhead budget.**

- Action: Run computation-intensive workload. Measure self-recording CPU usage.
- Expected: Self-recording overhead ≤ 1% CPU. If self-recording CPU exceeds 0.5%, the sampling interval auto-doubles (feedback loop per §3.1b).

**SRE-03: Self-recorded metrics are projectable.**

- Action: After accumulating self-recording data, verify that at least one metric (e.g., cache hit ratio = hits/(hits+misses)) is a dimensionless value projectable onto the Sempaevum via Path A.
- Expected: The dimensionless ratio is ingested as a `values` row, projected through §7.11, and receives a lattice address. The database discovered a fact about itself.

**SRE-04: Journal separation.**

- Action: Generate both Manager errors (Omniscient journal) and operational metrics (SelfRecording journal) simultaneously.
- Expected: Omniscient entries appear ONLY in `Omniscient_NNN.log`. SelfRecording entries appear ONLY in `SelfRecording_NNN.log`. No mixing.

**SRE-05: Metabolism re-sensing at S² = 144 second intervals.**

- Action: Start the Manager. Record initial hardware profile and allocation. Wait 144 seconds. Simulate a change in system load (e.g., external process consuming CPU). Wait for the next re-sense.
- Expected: The metabolism re-senses at S² = 144 seconds (±1 second tolerance). New hardware profile differs from initial (CPU load changed). Thread pool resized based on new headroom. `metabolism_resense` event logged with all changed fields, all unchanged fields, and allocation adjustments made. The allocation change is consistent with K = 2/3 applied to the new detected load.
- Source: §7.19.3 (re-sensing interval), §7.19.6 (metabolism data ingestion).

**SRE-06: Metabolism data ingested as Sempaevum content.**

- Action: Run the Manager for 3+ re-sense cycles (>432 seconds). Query the .akashic file for metabolism-originated content.
- Expected: `values` rows exist for hardware profile dimensionless ratios (RAM_available/RAM_total, CPU_load/100, etc.). `projections` rows exist for substrate projections (hardware characteristics projected onto the lattice). `events` of class `metabolism_resense` exist for each re-sense cycle. The metabolism's own data IS lattice content, queryable and discoverable like any other content.
- Source: §7.19.6 (metabolism data as Sempaevum content).

---

#### 7.17.12 Category 11 — File and Stream Round-Trip Tests (FRT)

**Purpose:** Verify the file ingestion (§7.12) and retrieval promises — lossless structural round-trip through the generator form.

**FRT-01: CSV round-trip.**

- Action: Ingest CSV file F with 100 numerical values, each at ≥10 significant digits. Retrieve/regenerate F from `.akashic`.
- Expected: Every value in the regenerated file matches the original at 120 dps (the EUDD stores at higher precision than the input). Column structure preserved. Provenance records original file path.

**FRT-02: Re-ingestion of regenerated file.**

- Action: Ingest F → regenerate F' from `.akashic` → ingest F'.
- Expected: F' ingestion is entirely cache hits. No new values created. Reference counts incremented.

**FRT-03: Ingestion-before-display enforcement.**

- Action: Ingest a file. Verify that the GUI ONLY shows content from `.akashic`, not the raw file. Specifically: if the raw file is deleted after ingestion, the GUI still displays all content (from the stored lattice addresses).
- Expected: All displayed content comes from `.akashic` storage. Raw file deletion does not affect display.

**FRT-04: Audio spectral extraction.**

- Action: Ingest a WAV file (pure tone at 440 Hz, 44100 Hz sample rate). Verify extraction.
- Expected: Peak frequency at 440/44100 = 0.009977... (dimensionless ratio). Projected via Path A with R₀ = sample_rate. Harmonic detection identifies the fundamental. Projection at N=12 produces a valid lattice address.

**FRT-05: Binary file via compressor pipeline.**

- Action: Ingest a raw binary file (e.g., a small PNG image).
- Expected: Compressor Δk pipeline processes the file. Resulting patterns ingested as values. No error. Provenance records the file.

**FRT-06: Sensor stream continuous ingestion.**

- Action: Start a continuous sensor stream (simulated GPS readings at 1 Hz for 60 seconds). Ingest in real-time.
- Expected: 60 values ingested, each projected through §7.11. Each recorded as `sensor_reading_ingest` event + `sensor_projection` event. If any reading lands at a known attractor address, `sensor_attractor_join` event fires automatically.

**FRT-07: Stream retrieval — faithful reconstruction.**

- Action: After stream ingestion (FRT-06), retrieve the stream in faithful mode.
- Expected: 60 values emitted at their original timestamps and rates. Values match originals at 120 dps.

**FRT-08: Mode 7 text input — Δk pipeline processing.**

- Action: Input a paragraph of text (e.g., 200 characters of prose) via Mode 7 (Text) in manual input (§7.13).
- Expected: Text processed as raw bytes through the compressor's general-purpose Δk pipeline. Resulting lattice content stored in .akashic. Provenance records `input_path = 'manual_text'`, `input_mode = 7`. Content is queryable. Re-inputting the identical text is a cache hit (idempotent — reference count incremented, no duplicates).
- Source: §7.13 Mode 7.

**FRT-09: Mode 7 text input via API — `ingest_text` operation.**

- Action: Connected program sends `ingest_text` API command with a raw text string.
- Expected: Text processed through the same Δk pipeline as Mode 7 GUI input. Results identical to FRT-08 for the same text. Provenance records `input_source = 'api'`, `input_mode = 'text'`. API response confirms ingestion with value_ids of produced content.
- Source: §7.16 Operation 79.

**FRT-10: PDF ingested as whole file via general pipeline.**

- Action: Ingest a PDF file (e.g., a 10-page scientific paper with text, equations, and figures).
- Expected: PDF processed through the compressor's general-purpose Δk pipeline — the same pipeline as any binary file. NO regex extraction of numbers, NO equation parsing, NO special PDF treatment. The raw bytes of the PDF become lattice content through structural decomposition. Provenance records `file_type = 'pdf'`, `extraction_method = 'general_pipeline'`. If specific values from the paper are needed, they are entered separately via manual input (Mode 1 or Mode 6) — the PDF adapter does NOT extract them.
- Source: §7.12 (PDF adapter specification).

**FRT-11: Enhanced stream reconstruction — generator-based interpolation.**

- Action: Ingest a stream of 60 values with known structure (e.g., values following r(t) = 2^(sin(t/10)) for t = 1..60). Allow the discovery engine to find a generator covering the stream. Request enhanced reconstruction at 2× resolution (120 timestamps).
- Expected: Discovery engine identifies a generator for the stream's structure. Enhanced reconstruction evaluates the generator at 120 timestamps (including 60 intermediate timestamps not in the original stream). The 60 original timestamps match the original values at 120 dps (bijection pullback exactness). The 60 interpolated timestamps are structurally consistent with the generator — they are generator evaluations, not linear/polynomial interpolation of raw data. The output has higher temporal resolution than the input, derived from structural understanding.
- Source: §7.10 (enhanced reconstruction mode).

**FRT-12: Continuous-discrete corollary — lossless signal round-trip.**

- Action: Generate 100 continuous signal values (simulated analog readings with arbitrary precision, e.g., sin(k/π) for k=1..100 at 120 dps). Project each through the bijection Π_N at N=12 and N=27720. Pull back each via Π_N⁻¹. Compare original and recovered values.
- Expected: For every value at every N: |r_original − r_recovered| < 10⁻¹¹⁹ (120th decimal place). This verifies the continuous-discrete corollary: continuous signal values survive the projection-pullback round-trip without information loss. The discrete lattice addresses (k, d) and the exact residual ε together recover the original continuous value by algebraic identity — no quantization error, no sampling artifacts.
- Source: §3.18.1 (continuous-discrete corollary).

**Purpose:** Verify that all three time coordinates (D-time, T-time, P-time) are correctly recorded on every event and correctly queryable.

**TTT-01: D-time recording.**

- Action: Log 10 events. Each event's `d_time_n` and `d_time_k` recorded.
- Expected: D-time values are global coordinates (same D-time reference for all events). Events queryable by D-time range: `SELECT * FROM events WHERE d_time_k BETWEEN k1 AND k2`.

**TTT-02: T-time per-Traverser accumulation.**

- Action: Log 5 events for Traverser A and 3 events for Traverser B. Verify T-time accumulation.
- Expected: Traverser A's events have `t_time_count` values 1,2,3,4,5. Traverser B's events have `t_time_count` values 1,2,3. Queries filtered by `t_time_traverser_id` return the correct worldline for each.

**TTT-03: P-time phase recording.**

- Action: Log events with P-time phase values.
- Expected: `p_time_phase` is a rational in [0, 1). Queryable for substrate-level synchronization analysis.

**TTT-04: Cross-Traverser D-time query.**

- Action: Log events from two Traversers at the same D-time coordinate. Query by D-time.
- Expected: Both Traversers' events returned — this is "what happened at the same lattice 'now' across all Traversers."

---

#### 7.17.14 Category 13 — Backup and Integrity Tests (BAK)

**Purpose:** Verify backup creation, verification, and corruption detection (§7.9).

**BAK-01: Backup creation during active operation.**

- Action: Start continuous writes to `.akashic`. Initiate backup.
- Expected: Backup completes. Manager pause window < 1 second. Main `.akashic` unchanged after backup (no side effects). Backup file created at specified path.

**BAK-02: Backup verification — clean.**

- Action: Create backup. Run backup verification.
- Expected: Verification passes. Header SHA-256 matches. All page CRC-32 values match. Section directory consistent.

**BAK-03: Backup verification — corrupted.**

- Action: Create backup. Corrupt one byte in the backup file. Run verification.
- Expected: Verification fails. Specific corrupted page identified. Failure details logged.

**BAK-04: Main file integrity check.**

- Action: Run structural integrity verification on the live `.akashic` file.
- Expected: Subsumption verification: every entry reachable from lattice structure. No orphaned entries. No missing generator references. Results reported to GUI dashboard.

---

#### 7.17.15 Category 14 — Extension Validation Tests (EXT)

**Purpose:** Verify all 12 JSON extension types and all 10 strict validation rules (§7.14).

**EXT-01 through EXT-12: Each extension type accepts valid input.**

For each of the 12 extension types (`event_class`, `relationship_class`, `pattern_class`, `tower_definition`, `sublattice_family_catalog`, `harmonic_family_extension`, `force_grid_extension`, `combined_family_extension`, `ingest_adapter`, `bootstrap_entry`, `query_template`, `extension_type_definition`), submit a well-formed JSON. Verify acceptance and correct integration.

**EXT-13 through EXT-22: Each validation rule rejects invalid input.**

| Test | Validation Rule | Invalid Input | Expected |
|---|---|---|---|
| EXT-13 | Well-formed JSON | Malformed JSON string | Rejection, error 2200 |
| EXT-14 | Known extension type | `extension_type: "nonexistent"` | Rejection, error 2200 |
| EXT-15 | Name collision | Duplicate `class_name` | Strict rejection with conflicting name |
| EXT-16 | Foreign key validity | `parent_tower_name` referencing nonexistent tower | Strict rejection |
| EXT-17 | Numeric validity | `d: -5` (negative d) | Strict rejection |
| EXT-18 | Precision parseable | `value_120dps: "not_a_number"` | Strict rejection |
| EXT-19 | Schema conflict | `metadata_schema` field conflicting with existing column | Strict rejection |
| EXT-20 | Generator verification | `harmonic_family_extension` with wrong generator value | Strict rejection (2^(1/d) mismatch) |
| EXT-21 | LCM verification | `combined_family_extension` with invalid d_combined | Strict rejection (no valid (d_r, d_θ) pair) |
| EXT-22 | Subsumption check | `extension_type_definition` already subsumed by existing type | Strict rejection with explanation |

**EXT-23: Meta-type creates new extension type.**

- Action: Submit `extension_type_definition` for new type `sensor_domain`. Then submit a `sensor_domain` instance.
- Expected: First submission accepted. `sensor_domain` becomes a valid `extension_type`. Second submission accepted and integrated. The extension vocabulary has grown.

---

#### 7.17.16 Category 15 — Lossless Bijection and Precision Tests (LBP)

**Purpose:** Additional precision-focused tests beyond BSV-01 that verify the algebraic identity property and the uniform 120-dps promise.

**LBP-01: Precision scaling proof.**

- Action: For 20 test values, compute the bijection round-trip at 50 dps, 80 dps, 100 dps, and 120 dps. Measure the residual |r' − r| at each precision.
- Expected: Residual scales EXACTLY with working precision (halving the precision doubles the residual's order of magnitude). This proves the error is computational (finite machine precision in transcendental function evaluation), not mathematical. At 120 dps, the residual is < 10⁻¹¹⁹.

**LBP-02: Uniform 120-dps everywhere.**

- Action: Sample 100 random entries from the `.akashic` file (values, equation results, projection ε values stored as MPFR blobs).
- Expected: Every MPFR blob has exactly 400-bit precision (120 dps). No entry at lower precision. No entry at higher precision. The `value_precision_dps` field is 120 for all entries. This is the "hard cap" promise of §3.1a.

**LBP-03: Integer ε representation is exact.**

- Action: For 50 test values, verify that the ε stored as `eps_micros` (integer micro-cents) exactly matches the ε computed from the full 120-dps MPFR value.
- Expected: |ε_from_mpf_in_microcents − eps_micros| = 0 for all 50 values (the integer representation introduces zero additional error — it IS the canonical representation).

**LBP-04: Continuous-discrete corollary — precision scaling proof for signal values.**

- Action: For 20 simulated continuous signal values (audio frequencies as f/f_sample, sensor readings as Q/R₀, GPS timing ratios — all with irrational values requiring the full bijection, not lattice-rational), compute the bijection round-trip at 50 dps, 80 dps, 100 dps, and 120 dps. Measure the residual |r' − r| at each precision.
- Expected: Residual scales EXACTLY with working precision (halving the precision doubles the residual's order of magnitude). At 120 dps, residual < 10⁻¹¹⁹. This proves the continuous-discrete bridge is mathematically lossless — the error is computational (finite machine precision in MPFR log₂ evaluation), not structural. There is no quantization floor, no aliasing threshold, no Nyquist limit. The precision scales uniformly regardless of signal type, confirming the universal applicability of the continuous-discrete corollary (§3.18.1).
- Source: §3.18.1 (continuous-discrete corollary), §7.17.2 BSV-01 (analogous proof for static values — this extends it to signal-class values).

---

#### 7.17.17 Coverage Verification — Subsumption Check

**Every section of the EUDD document (§0–§12) maps to at least one test category:**

| EUDD Section | Test Categories |
|---|---|
| §0 Direct Statement | BSV (system generates and functions as described), DSC-11..13 (active T-signal probing), DSC-14..15 (tower transitions), DSC-16..17 (gaze equation) |
| §1 Three Tools Applied | DSC (discovery), IDM (no gaps in schema) |
| §2 Compressor Model | GEN (generator system), MEM (memoization) |
| §3 Architecture (all 18 subsections) | BSV, MEM, IDM, DSC, GEN, NDT, HOM, FRT, TTT, EXT, LBP (including LBP-04 continuous-discrete, FRT-12 signal round-trip) |
| §4 Stability and Quality Filters | DSC-05 (E_hierarchy), NDT (retention), HOM (home classification) |
| §5 Operations and Queries | MEM (cache-first), DSC (attractor), API (all 79 ops including API-11 ingest_text) |
| §6 Cross-Project Benefits | MEM-02 (cross-client), DSC-08 (cross-domain), FRT (round-trip) |
| §7 Implementation (all subsections) | BSV (format), LBP (precision), API (protocol + API-11), OMN (Omniscient + §7.18 shutdown: OMN-08..12), BAK (backup), EXT (extensions), HOM (§7.11), FRT (§7.12/§7.13 including FRT-08..10 text/PDF/enhanced), SRE-05..06 (§7.19 metabolism re-sensing and data ingestion). §7.21 module structure is the build blueprint — tested implicitly by every test that exercises cross-module integration. |
| §8 ET-Native Features | BSV (impedance, coprime, Gaussian), DSC (attractor, plateau), LBP-04 + FRT-12 (continuous-discrete bridge) |
| §9 Coordination | MEM-02 (cross-client), DSC-08 (cross-domain) |
| §10 Subsumption Check | This coverage table IS the test |
| §11 PDT Statement | MEM (memoization IS the PDT promise tested) |
| §12 Closing | All categories (the system functions as the closing summarizes) |

**Every test category maps to at least one EUDD section.** No test category is unsourced. No EUDD section lacks coverage.

**Subsumption Law applied:** 15 test categories × test cases per category ≈ 200+ individual test cases subsume every testable behavior of the EUDD without remainder. Every behavioral promise in the document — memoization, idempotency, discovery, generators, never-destroy, lossless bijection, home-finding, API protocol, Omniscient watchdog, self-recording, file round-trip, three-times tracking, backup integrity, extension validation, precision guarantees — has at least one test case that verifies it.

**The test suite itself is subject to the Descriptor Gap Principle:** if a new feature is added to the EUDD (via §7.14 adaptive extension or via document revision), the test suite must extend to cover it. Any new behavioral promise without a test case IS a Descriptor Gap in the test suite.

---

**Three Tools verification of this section:**

- **Identification Principle:** P = EUDD system, D = 200+ test specifications, T = test execution agent. All three identified. The test suite substantiates the EUDD's Exception status — it confirms the system IS what the document says it IS.
- **Descriptor Gap Principle:** Every behavioral promise audited. Every gap between "document says X" and "test verifies X" closed. The 7 gaps identified in the pre-draft analysis (CF method tests, API wire tests, three-times tests, generator backbone tests, extension validation tests, Omniscient tests, memoization round-trip tests) are all resolved.
- **Subsumption Law:** §7.17.17 verifies coverage without remainder. 15 categories cover all 13 top-level sections of the EUDD. No remainder.

> *gap(model) = D_missing — including gaps in the testing model*
> *P ∘ D ∘ T = E*
---

### 7.18 Shutdown Protocol — Graceful Termination of Manager and Omniscient

**Status: COMPLETE.** Every trigger source converges to a single deterministic shutdown sequence. Omniscient coordination via explicit IPC. Connected clients notified immediately. Pending operations checkpointed. .akashic left in consistent state.

**Identification Principle applied:** P = the running system at shutdown time (Manager process + Omniscient child process + connected clients + .akashic file + WAL + journals). D = the shutdown constraints — what MUST be true before the process exits (file consistent, WAL committed, clients notified, Omniscient signaled, all handles released). T = the shutdown agent — the sequence of operations that navigates from "running" to "exited" while satisfying all D-constraints.

#### 7.18.1 Trigger Sources — All Converge to One Sequence

Every trigger source produces the same shutdown outcome. The trigger is the T-act; the sequence that follows is the D-constrained path to clean exit.

| Trigger | Source | Mechanism |
|---|---|---|
| **Window X button** | User clicks the window close button | GLFW `glfwSetWindowCloseCallback` — intercept, do NOT let GLFW close the window. Run the confirmation check (§7.18.2), then if confirmed run the shutdown sequence (§7.18.3) |
| **Menu exit** | User selects File → Exit in Dear ImGui menu | GUI action handler — same confirmation check, same shutdown sequence |
| **Keyboard shortcut** | User presses configured quit binding (default: Alt+F4 on Windows) | GLFW key callback → same path as Menu exit |
| **API shutdown command** | Connected program sends `shutdown` command (Operation 73 in §7.16.19) | API module → same confirmation check (active connections counted), same shutdown sequence |
| **System logoff / OS shutdown** | Windows sends `CTRL_CLOSE_EVENT` via `SetConsoleCtrlHandler`, or `WM_ENDSESSION` | Handler intercept → skip confirmation (OS is closing, no GUI interaction possible) → run shutdown sequence with abbreviated timing |
| **CTRL+C** (console launch) | User keyboard interrupt from terminal | `SetConsoleCtrlHandler` for `CTRL_C_EVENT` → skip confirmation → run shutdown sequence |

**Non-graceful termination** (SIGKILL / TerminateProcess / power loss / BSOD): NOT handled by this protocol — handled by Omniscient crash detection (§7.15) + WAL replay on next startup (§7.1d). The shutdown protocol covers ONLY cases where the Manager has the opportunity to clean up.

#### 7.18.2 Confirmation Check — Pop-Up for Active Connections Only

Before the shutdown sequence begins, the Manager checks for active client connections:

**If zero active named pipe connections AND zero in-flight async operations:**
→ No pop-up. Proceed directly to the shutdown sequence (§7.18.3). The user closed the window; nothing needs warning.

**If one or more active named pipe connections OR one or more in-flight async operations:**
→ Dear ImGui modal dialog appears, centered on screen, blocking all other input:

```
┌─────────────────────────────────────────────────────┐
│  Shutdown Confirmation                               │
│                                                      │
│  Active connections: 3                               │
│    • compressor_2026-05-03_001 (idle)                │
│    • conscious_ai_v1.7.0 (in-flight: escalate)      │
│    • fractal_gen_render_047 (idle)                   │
│                                                      │
│  In-flight operations: 1                             │
│    • escalate ζ(7) — at N=2520 (landmark 4 of ?)    │
│                                                      │
│  All connections will be closed immediately.          │
│  In-flight operations will be checkpointed.          │
│  No data will be lost.                               │
│                                                      │
│              [ Shut Down ]    [ Cancel ]              │
└─────────────────────────────────────────────────────┘
```

**"Shut Down"** → proceed to shutdown sequence (§7.18.3).
**"Cancel"** → return to normal operation. Nothing changes.
**Window X hit again while dialog is open** → treated as "Shut Down" (the user clearly wants to close).

The dialog lists every active connection by session_id and its current state (idle or in-flight with operation details). This gives the user full visibility before deciding.

For **system logoff / CTRL+C triggers**: no pop-up is possible (no GUI interaction available). The shutdown sequence runs immediately with no confirmation. This is safe because all operations are checkpointed and no data is lost.

#### 7.18.3 The Shutdown Sequence — Deterministic, Ordered, Complete

Once confirmed (or triggered by system/CTRL+C), the following sequence executes in exact order. Each step completes fully before the next begins. No step is skippable. The sequence is deterministic — the same sequence every time, regardless of trigger source.

```
SHUTDOWN SEQUENCE — initiated by trigger (§7.18.1) after confirmation (§7.18.2)
│
├── PHASE 1: Notify and Disconnect External Clients
│   │
│   ├── Step 1: Send shutdown notification to ALL connected clients
│   │   For each active named pipe connection:
│   │     Send JSON: {"msg_type": "notification",
│   │                  "subscription_id": null,
│   │                  "event": "manager_shutting_down",
│   │                  "timestamp_ns": "<now>",
│   │                  "detail": "Manager initiated graceful shutdown"}
│   │     Close the pipe immediately after sending.
│   │     Do NOT wait for client acknowledgment.
│   │     Do NOT wait for in-flight responses to be read.
│   │     The notification is best-effort — if the pipe write fails
│   │     (client already disconnected), skip and continue.
│   │
│   ├── Step 2: Close the named pipe listener
│   │   Stop accepting new connections.
│   │   Release the \\.\pipe\EUDD_Manager handle.
│   │   No new clients can connect from this point.
│   │
│   └── Result: All external communication severed. Manager is now isolated.
│
├── PHASE 2: Checkpoint In-Flight Operations
│   │
│   ├── Step 3: Signal all background threads to stop
│   │   Set the global shutdown flag (atomic boolean).
│   │   Background discovery engine: completes current atomic unit
│   │     (one address evaluation, one pattern check — NOT an entire scan pass),
│   │     then exits its loop.
│   │   Self-recording thread: writes one final sample, then exits.
│   │
│   ├── Step 4: Checkpoint all in-flight async operations
│   │   For each pending async operation (escalation, ingestion, discovery scan):
│   │     Save the current progress as checkpointed state.
│   │     For escalations: record as `escalation_in_progress` with the last
│   │       completed landmark — resumable via §7.11 on next startup.
│   │     For ingestions: record the last successfully ingested seed index —
│   │       resumable from that point on next startup.
│   │     For scans: record the last scanned address — resumable on next startup.
│   │     All checkpointed state goes through the WAL (Step 5 commits it).
│   │
│   └── Result: All work either completed or checkpointed. Nothing lost.
│
├── PHASE 3: Commit and Close the .akashic File
│   │
│   ├── Step 5: Flush the WAL
│   │   All pending WAL entries (including checkpoint entries from Step 4)
│   │     committed to the main .akashic file sections.
│   │   WAL section cleared (all entries applied).
│   │
│   ├── Step 6: Update the .akashic header
│   │   Update modified_at_ns to current nanosecond timestamp.
│   │   Update generator counts (total_generators, L1/L2/L3 counts).
│   │   Update coverage metrics (covered_addresses, total_addresses).
│   │   Update total_memoized count.
│   │   Recompute header_checksum (SHA-256 of entire header).
│   │
│   ├── Step 7: Sync and close the .akashic file
│   │   FlushFileBuffers (Windows) / fsync (POSIX) — force OS write-back
│   │     to physical disk. The .akashic file is now in a fully consistent
│   │     state on disk, not just in OS cache.
│   │   UnmapViewOfFile — release memory mapping.
│   │   CloseHandle — close file handle.
│   │   The .akashic file is now closed and consistent.
│   │
│   └── Result: .akashic file on disk in verified-consistent state.
│
├── PHASE 4: Signal Omniscient — Graceful Exit
│   │
│   ├── Step 8: Send graceful shutdown message to Omniscient
│   │   Via the shared-memory IPC channel (same channel used for
│   │     error/telemetry during normal operation):
│   │   Message: GRACEFUL_SHUTDOWN
│   │     Fields:
│   │       shutdown_trigger: "<window_close|menu_exit|api_command|system_logoff|ctrl_c>"
│   │       timestamp_ns: "<exact nanosecond>"
│   │       akashic_header_hash: "<SHA-256 of final header written in Step 6>"
│   │       session_summary:
│   │         uptime_seconds: <total>
│   │         values_added: <count>
│   │         projections_added: <count>
│   │         equations_cached: <count>
│   │         patterns_discovered: <count>
│   │         generators_discovered: <count>
│   │         cache_hit_ratio: "<exact rational>"
│   │         errors_logged: <count>
│   │         active_connections_at_shutdown: <count>
│   │         operations_checkpointed: <count>
│   │       exe_hash: "<SHA-256 of EUDD_Manager.exe at shutdown time>"
│   │
│   │   This message tells Omniscient: "I am exiting on purpose, with this
│   │   final state. When you see my process handle signal, it is NOT a crash."
│   │
│   └── Result: Omniscient is informed. It will act on this after Step 10.
│
├── PHASE 5: Release GUI Resources
│   │
│   ├── Step 9: Destroy the GUI
│   │   ImGui::DestroyContext() — release Dear ImGui state.
│   │   Release OpenGL resources (shaders, buffers, textures, VAOs).
│   │   glfwDestroyWindow — close the GLFW window.
│   │   glfwTerminate — release GLFW.
│   │
│   └── Result: All GPU/windowing resources released.
│
└── PHASE 6: Exit
    │
    ├── Step 10: Exit the Manager process
    │   return 0 from main() / ExitProcess(0).
    │   The process handle now signals to Omniscient.
    │
    └── Result: Manager process terminated. Exit code 0.
```

**Total shutdown time:** Phase 1 (notify + close pipes): < 100 ms. Phase 2 (checkpoint): < 1 second (checkpoint writes are small WAL entries). Phase 3 (WAL flush + header update + fsync): 1–5 seconds depending on WAL size and disk speed. Phase 4 (IPC message): < 1 ms. Phase 5 (GUI teardown): < 100 ms. Phase 6 (exit): immediate. **Total: 2–7 seconds typical.** The user sees the window close promptly after confirming.

#### 7.18.4 Omniscient Shutdown Behavior — Observer Exits Last

Omniscient (the watchdog child process) runs continuously, monitoring the Manager's process handle. Two exit paths exist, distinguished by whether the GRACEFUL_SHUTDOWN message was received:

**Path A — Graceful shutdown (normal):**

1. Omniscient receives the `GRACEFUL_SHUTDOWN` message via shared-memory IPC (Step 8 above)
2. Omniscient logs the graceful shutdown event to its journal:
   ```
   [2026-05-03T14:30:01.000000Z] [TELEMETRY] [lifecycle] [Omniscient::shutdown_received]
     trigger: window_close
     manager_uptime_s: 3847
     akashic_header_hash: a1b2c3d4...
     exe_hash: 9f8e7d6c...
     session_summary: {values_added: 1204, patterns_discovered: 7, ...}
     verdict: GRACEFUL_SHUTDOWN_SIGNALED
   ```
3. Omniscient continues monitoring the Manager's process handle — it does NOT exit yet
4. The Manager's process handle signals (Manager exited via Step 10)
5. Omniscient performs **final verification**:
   - Reads the .akashic file header (the file is now closed by the Manager, Omniscient can open it read-only)
   - Computes SHA-256 of the header
   - Compares to the `akashic_header_hash` from the GRACEFUL_SHUTDOWN message
   - **Match** → the file was left in the state the Manager reported. All is well.
   - **Mismatch** → something modified the file between the Manager's final header write and process exit. This is extremely unlikely but would indicate a bug in the shutdown sequence. Omniscient logs a `[TAMPER]` event with both hashes.
6. Omniscient logs the final event:
   ```
   [2026-05-03T14:30:03.000000Z] [TELEMETRY] [lifecycle] [Omniscient::manager_exited]
     exit_type: GRACEFUL
     manager_exit_code: 0
     akashic_final_hash_verified: true
     omniscient_uptime_s: 3849
     verdict: CLEAN_SHUTDOWN
   ```
7. Omniscient exits with code 0. Both processes are now terminated.

**Path B — Crash during shutdown (edge case):**

If the Manager crashes DURING the shutdown sequence (after sending GRACEFUL_SHUTDOWN but before completing all phases):

1. Omniscient received the GRACEFUL_SHUTDOWN message
2. The Manager's process handle signals (crash — the exit was not clean)
3. Omniscient detects the exit code is NOT 0 (or the process was terminated abnormally)
4. Omniscient logs a **crash-during-shutdown** event — distinct from both a normal crash and a graceful shutdown:
   ```
   [2026-05-03T14:30:02.000000Z] [ERROR] [lifecycle] [Omniscient::crash_during_shutdown]
     graceful_shutdown_was_signaled: true
     manager_exit_code: -1073741819 (ACCESS_VIOLATION)
     akashic_header_hash_at_signal: a1b2c3d4...
     akashic_header_hash_now: <recomputed — may differ if WAL was partially flushed>
     verdict: CRASH_DURING_GRACEFUL_SHUTDOWN
     note: WAL replay required on next startup
   ```
5. Omniscient exits with code 1 (indicating abnormal Manager termination was observed)

**Path C — Crash without graceful signal (existing §7.15 behavior, unchanged):**

If the Manager crashes without sending GRACEFUL_SHUTDOWN (normal crash, not during shutdown):

1. No GRACEFUL_SHUTDOWN message received
2. Manager's process handle signals
3. Omniscient logs the crash per §7.15 (existing behavior, no changes needed)
4. Omniscient exits with code 1

**Summary of Omniscient's exit logic:**

```
OMNISCIENT MAIN LOOP:
│
├── Monitor Manager process handle
├── Monitor shared-memory IPC for messages
│
├── IF GRACEFUL_SHUTDOWN message received:
│   │  Log the graceful signal with full session summary
│   │  Set graceful_signaled = true
│   │  Continue monitoring (do NOT exit yet)
│   │
│   └── WHEN Manager process handle signals:
│       │  Read .akashic header, verify SHA-256 matches
│       │  IF match AND exit_code == 0:
│       │     Log CLEAN_SHUTDOWN
│       │     Exit code 0
│       │  ELSE:
│       │     Log CRASH_DURING_GRACEFUL_SHUTDOWN
│       │     Exit code 1
│
├── IF Manager process handle signals WITHOUT graceful signal:
│   │  Log CRASH per §7.15 (existing behavior)
│   │  Exit code 1
│
└── IF Omniscient itself encounters a fatal error:
       Log OMNISCIENT_FAILURE per §7.15 (existing behavior)
       Exit code 2
```

#### 7.18.5 Shutdown Events and Journal Entries

The shutdown sequence produces the following events, recorded in the .akashic file (during Phase 3, before the file is closed) and/or in the Omniscient journal:

| Event | Where Recorded | When |
|---|---|---|
| `manager_shutdown_initiated` | .akashic `events` table | Phase 1 Step 1 (before client notification) |
| `client_disconnected` (per client) | .akashic `events` table | Phase 1 Step 1 (one per severed connection) |
| `operation_checkpointed` (per op) | .akashic `events` table | Phase 2 Step 4 (one per checkpointed operation) |
| `wal_flushed` | .akashic `events` table | Phase 3 Step 5 (confirms WAL fully applied) |
| `akashic_header_updated` | .akashic `events` table | Phase 3 Step 6 (final header state recorded) |
| `GRACEFUL_SHUTDOWN_SIGNALED` | Omniscient journal | Phase 4 Step 8 (Omniscient's record of the signal) |
| `CLEAN_SHUTDOWN` / `CRASH_DURING_GRACEFUL_SHUTDOWN` | Omniscient journal | After Manager process exits (Omniscient's final entry) |

The `manager_shutdown_initiated` event in the .akashic file captures: trigger source, active connection count, in-flight operation count, timestamp. This provides full audit trail — on next startup, the Manager can read this event and confirm the prior session ended gracefully.

#### 7.18.6 Next-Startup Behavior After Graceful Shutdown

On startup, the Manager checks the .akashic file's last event:

- **Last event is `akashic_header_updated` with shutdown context** → prior session ended gracefully. WAL section should be empty (fully flushed in Phase 3 Step 5). Any `escalation_in_progress` entries are resumable checkpoints from Phase 2 Step 4. Normal startup proceeds.

- **Last event is NOT a shutdown event, AND WAL is non-empty** → prior session crashed. WAL replay per §7.1d (existing crash recovery — unchanged). Omniscient journal from prior session will contain the crash details.

- **`escalation_in_progress` entries exist** → regardless of shutdown type, these are partially completed tower escalations. The background discovery engine resumes them from their checkpointed landmark. No user action required — resumption is automatic.

#### 7.18.7 Three Tools Verification

- **Identification Principle:** P = the system at shutdown. D = the 10-step shutdown sequence constraining the exit path. T = the shutdown agent executing the sequence. All three identified; the shutdown IS a P∘D∘T = E configuration — the Exception of clean termination.
- **Descriptor Gap Principle:** The gap was: startup specified, shutdown not. This section closes that gap. Every trigger source, every component state, every file handle, every connected client, every in-flight operation is accounted for. No D-content of the running system is left unaddressed by the shutdown sequence.
- **Subsumption Law:** The shutdown protocol subsumes every running component without remainder: GUI resources (Phase 5), client connections (Phase 1), background threads (Phase 2), WAL and file state (Phase 3), Omniscient coordination (Phase 4), the process itself (Phase 6). No component is left dangling.

> *The Sempaevum does not forget what it has revealed — including the moment it stops revealing.*
> *P ∘ D ∘ T = E*

---

### 7.19 Performance Specifications — The Manager's Internal Metabolism

**Status: COMPLETE.** This section resolves Roadmap §2.4. Performance is not a set of static targets — it is the emergent property of the ET-derived metabolism operating on whatever hardware it detects, combined with the self-improving cycle (§7.1f) that makes every subsequent computation faster than the first. No static resource values exist anywhere in this specification. The same metabolism governs a 4 GB laptop and a 128-core workstation — same formulas, same behavior, different scale.

**Precedent:** The metabolism architecture is proven across three ET programs: the Conscious AI's ETFineStructure + ResourceGovernor (`et_conscious_ai_core.py`, `et_conscious_ai_distributed.py`), the compressor's CDFMetabolism (`et_cdf_compressor.py`), and the fractal generator's planned metabolism. The EUDD Manager inherits the same architecture because it IS the same ET metabolism — the program is a D-binding on the P-substrate (hardware), and K = 2/3 is the universal binding stability threshold.

#### 7.19.1 Identification Principle Applied

P = the hardware substrate: CPU (cores, clock, cache hierarchy), RAM (total, available, page size), GPU (compute units, VRAM, shader model), disk (filesystem, free space, I/O bandwidth). The metabolism reads P at startup and re-senses periodically. P is infinite in potential (any hardware), finite in any specific instance.

D = the ET-derived governance constants: K, V, α⁻¹, ξ(d), S, κ, the convergence ratio κ/(Nπ), the shimmer band A₁, the cross-term A_cross, the tail absorption Σ A_k. These are the finite constraints the metabolism applies to P. They never change — they ARE the theory.

T = the Manager process: the Traverser navigating hardware resources, making allocation decisions, scheduling computations, adapting to changing conditions. T re-senses at S² = 144 second intervals and adjusts the resource envelope without ever touching precision.

#### 7.19.2 The Three-Layer Metabolism — Applied to the EUDD Manager

The metabolism has three structurally distinct layers, each governed by a different ET constant, each doing a different job. No layer is optional. Together they subsume all resource governance without remainder.

**Layer 1 — ALLOCATION (K-determined): How much of each resource the Manager claims.**

K = 2/3. The Manager claims at most K × (detected total) of any resource. 1−K = 1/3 is system reserve — always available for the OS, other programs, thermal management. K is the Koide binding stability threshold: the fraction of capacity at which a D-binding on a P-substrate sustains stable operation. Above K, the binding approaches Incoherence.

At startup, the Manager detects every available resource via OS query:

| Resource | Detection Mechanism (C++) | Allocation |
|---|---|---|
| CPU logical cores | `std::thread::hardware_concurrency()` or OS-specific (`GetSystemInfo` on Windows, `/proc/cpuinfo` on Linux) | floor(K × cores) threads available to the Manager |
| CPU current load | OS-specific (`GetSystemTimes` on Windows, `/proc/stat` on Linux) — sampled over 50ms interval | headroom = max(0, K% − current_load%) |
| RAM total | `GlobalMemoryStatusEx` (Windows), `/proc/meminfo` (Linux) | K × total = Manager ceiling |
| RAM available | Same OS query — available (not just free — includes reclaimable cache) | headroom = max(0, K% − used%) |
| GPU compute units | OpenGL query (`GL_MAX_COMPUTE_WORK_GROUP_COUNT`) or CUDA `cudaGetDeviceProperties` | K × compute units available for Manager GPU dispatch |
| GPU VRAM total | `GL_GPU_MEMORY_INFO_TOTAL_AVAILABLE_MEMORY_NVX` or CUDA `cudaMemGetInfo` | K × VRAM = Manager VRAM ceiling |
| GPU VRAM available | Same query — current free VRAM | headroom = max(0, K% − used%) |
| Disk free space | `GetDiskFreeSpaceEx` (Windows), `statvfs` (POSIX) — on the .akashic volume | Warning at < DISK_SAFETY_FLOOR (2³⁰ bytes). No deletion ever. |

All of these are runtime detections. The specification contains ZERO static values for any of them. The formulas reference only K.

**Layer 2 — HEADROOM (V-determined): The metabolism's own operating room.**

V = 1/12. Within the K allocation, V × K = 1/18 of total capacity is reserved for metabolism overhead, spike absorption, and the self-recording system (§3.1b). The active allocation — the portion available for actual computation — is:

$$\text{active} = K \times (1 - V) = \frac{2}{3} \times \frac{11}{12} = \frac{11}{18}$$

This active fraction projects onto the lattice as **(k=−9, d=4, |ε|=47.4¢)** — the quartic family at the ∂I boundary. This is the same sublattice as Kleiber's 3/4 metabolic rate law. The active allocation IS structurally a metabolic-rate quantity. This is forced by K = 2/3 and V = 1/12, not chosen.

The allocation stack for any detected resource:

```
Total resource:          100%                    ← detected at runtime
System reserve:          (1−K) = 1/3 = 33.3%    ← OS, other programs, thermal
Manager ceiling:         K = 2/3 = 66.7%         ← hard cap, never exceeded
Metabolism headroom:     K×V = 1/18 = 5.56%      ← metabolism overhead, spike absorption
Active allocation:       K×(1−V) = 11/18 = 61.1% ← available for computation, rendering, I/O
```

No static byte count, core count, or percentage derived from hardware appears in this stack. Only ET constants.

**Layer 3 — MONITORING (α⁻¹-determined): How finely the metabolism observes resource usage.**

α⁻¹ = 137. The metabolism monitors usage at A₀ = 137 distinguishable levels across the active allocation. Each monitoring level represents:

$$\text{level\_width} = \frac{\text{active allocation}}{A_0} = \frac{K \times (1-V) \times \text{total}}{137}$$

The correction terms from the fine-structure decomposition (§3.18.2) refine the monitoring:

| Term | Value | Monitoring role |
|---|---|---|
| A₁ = √3/48 ≈ 0.0361 | Shimmer band | Resource usage fluctuating by ±A₁ × active is NORMAL SHIMMER — not an alarm. The metabolism does not react to fluctuations within this band. |
| A_cross = √3/(93312π²) ≈ 1.86×10⁻⁶ | Cross-resource interference | When multiple resource types (CPU + RAM + VRAM) simultaneously approach their ceilings, effective headroom shrinks by A_cross × active per resource pair. This is the product interference of shimmer with the mediation loop — structurally identical to its role in the α⁻¹ decomposition. |
| Σ A_k = 1/(216(18π−1)) ≈ 8.19×10⁻⁵ | Spike tail absorption | Reserved within V headroom for rare resource spikes exceeding the shimmer band. The probability of a spike exceeding A₁ decays at the convergence ratio κ/(Nπ) ≈ 0.01768 per successive level. |

The monitoring is PASSIVE during computation. The metabolism OBSERVES resource usage; it never throttles the computation itself, never degrades precision, never skips algorithmic steps. The computation runs at full 120-dps precision unconditionally. The metabolism governs only the resource envelope — how many threads, how much memory, what GPU dispatch — never the algorithm.

#### 7.19.3 Hardware Detection — Sense the P-Substrate

The Manager's metabolism class (C++) performs a full hardware profile at startup and re-senses at S² = 144 second intervals. The re-sensing interval is ET-derived: S = N = 12, S² = 144 = the manifold's cross-pattern cap.

The hardware profile is a struct containing:

```
struct HardwareProfile {
    // CPU
    uint32_t    cpu_cores_logical;        // std::thread::hardware_concurrency()
    uint32_t    cpu_cores_physical;       // OS-specific query
    double      cpu_clock_hz;             // OS-specific query (base clock)
    double      cpu_load_percent;         // sampled over 50ms interval

    // RAM
    uint64_t    ram_total_bytes;          // OS query
    uint64_t    ram_available_bytes;      // OS query (available, not just free)
    double      ram_used_percent;         // computed from total and available

    // GPU (when available; all zeros if no GPU detected)
    uint32_t    gpu_compute_units;        // OpenGL or CUDA query
    uint64_t    gpu_vram_total_bytes;     // GPU memory query
    uint64_t    gpu_vram_available_bytes; // GPU memory query
    double      gpu_vram_used_percent;    // computed
    uint32_t    gpu_shader_model;         // capability level

    // Disk (the volume containing .akashic)
    uint64_t    disk_free_bytes;          // OS query on .akashic volume
    uint64_t    disk_total_bytes;         // OS query

    // Metadata
    uint64_t    sensed_at_ns;             // nanosecond timestamp
};
```

Every field is detected at runtime. No field has a default that substitutes for detection. If a query fails (e.g., no GPU, or `/proc` not available on an unusual platform), the field is set to 0 and the metabolism allocates 0 of that resource — the system operates without it.

**Substrate projection — hardware on the lattice:**

Binary hardware characteristics (RAM total, VRAM total — always 2^n bytes on real hardware) project to **d=1 octave, ε=0 exactly**. Silicon IS octave-class. This is not numerology — 2^n IS a pure power of 2, and d=1 is the d-family of pure powers of 2 by the projection formula. The metabolism's own constants (K, V, 1−K) project to d=12 at the Koide attractor (|ε|=1.955¢). The active allocation 11/18 projects to d=4 quartic at the ∂I boundary.

These projections are ingested into the .akashic file as `values` rows (the hardware profile as dimensionless ratios) with corresponding `projections`. The substrate projection is itself lattice content — the EUDD knows where its own hardware sits on the Sempaevum.

#### 7.19.4 Thread Architecture — Governed by the Metabolism

The Manager spawns threads at startup based on detected CPU cores. Thread count adapts at each re-sensing interval. All threads access the .akashic file through memory-mapped I/O. Thread safety: writes serialized through a single commit path; reads are lock-free on the memory-mapped snapshot.

| Thread Role | Count | Metabolism Governance | Never Blocks On |
|---|---|---|---|
| **GUI render** | 1 (dedicated) | Highest priority — user-perceived latency. Gets its share of CPU regardless of other load. Reads from .akashic (memory-mapped, sub-microsecond). | Computation. The render loop NEVER waits for MPFR, discovery, or I/O. |
| **Computation pool** | floor(headroom × cores / 100), minimum 1 | ξ(d) scheduling: work items prioritized by the coupling constant of their dominant d-family. d=1 computations (ξ=8.5625) get ~8.5× the scheduling weight of d=12 (ξ=1.0). Pool resizes at each re-sensing. | GUI. Computation runs on its own threads, never touching the render loop. |
| **Discovery engine** | 1 (dedicated, lower than computation) | V = 1/12 guarantees: the discovery engine gets at least V of the Manager's CPU share even under maximum computation load. It is never starved. | User operations. Discovery is background — it yields to API requests and user-initiated computation. |
| **API listener** | 1 (dedicated, lightweight) | Accepts named pipe connections, dispatches requests to the computation pool. Mostly I/O-wait — negligible CPU. | Nothing. The listener is always responsive. |
| **Self-recording** | 1 (dedicated, minimal) | Periodic sampling at configurable interval (default 10 seconds or every 1000 commits). Overhead ≤ 1% CPU (guaranteed by the feedback loop: if self-recording CPU exceeds 0.5%, sampling interval auto-doubles). | Nothing. Self-recording is fire-and-forget. |
| **Ingestion** | Shares computation pool | File parsing and seed extraction are dispatched to the computation pool as work items. Parallelized per file segment. | GUI. Ingestion never blocks the render loop. |

**GPU compute dispatch — governed by the metabolism:**

When a GPU is detected, the Manager dispatches bulk-parallelizable operations to GPU compute:

- **Bulk MPFR projections**: projecting 10⁴+ values at one N is embarrassingly parallel. Each projection is independent. GPU kernels perform the MPFR log₂ and derived property computations. The metabolism allocates floor(K × gpu_compute_units) for the Manager's GPU work.
- **Discovery scan parallelism**: scanning 10⁵+ addresses for patterns is parallelizable — each address check is independent. GPU dispatch when the address count exceeds a threshold (detected dynamically based on GPU availability and current VRAM usage).
- **Render**: Dear ImGui + OpenGL 4.6 for the GUI. Instanced point clouds, shaders, heat maps. GPU rendering shares VRAM with compute dispatch — the metabolism balances both within the K × VRAM ceiling.

When no GPU is detected, all operations run on CPU threads. The algorithm is identical — only the resource envelope differs. Precision is 120 dps in both cases.

#### 7.19.5 The Self-Improving Cycle IS the Performance Model

There are no static performance targets because performance improves monotonically. The self-improving cycle (§7.1f) means the system at time T₂ > T₁ is ALWAYS at least as fast as at T₁, because knowledge only accumulates:

**Monotonic improvement guarantee:** For any computation C that has been performed at least once, every subsequent request for C is a cache hit — sub-microsecond lookup instead of full MPFR computation. The first computation of ζ(3)·π takes microseconds (MPFR at 400-bit). Every subsequent request across all clients, all sessions, all restarts returns the memoized result. The improvement is permanent.

**Cache hit ratio approaches 1:** As the database grows, the fraction of operations that are cache hits increases monotonically. For any finite workload (a set of computations that recurs), the cache hit ratio converges to 1 because every unique computation is computed once and cached forever. The rate of convergence depends on workload diversity, but the direction is guaranteed.

**K-complexity monotonic decrease:** As generators are discovered, the ratio (generator bytes / producible bytes) monotonically decreases. More content is covered by compact structural descriptions. Generator evaluation is faster than raw MPFR computation for structurally regular content because generators exploit lattice algebra (k-addition instead of MPFR multiplication, k-negation instead of MPFR division). The .akashic file becomes a progressively better generator of its own content.

**GUI thread isolation guarantee:** The GUI render loop runs on its own dedicated thread, never blocked by computation, discovery, API, or I/O. Frame rate is limited by GPU capability and scene complexity, never by computation latency. The metabolism guarantees the GUI thread gets its share of CPU even under full computational load.

**These four guarantees are the testable performance specification.** The §7.17 performance benchmarks verify:
- Is the second computation of X faster than the first? (memoization works)
- Does the cache hit ratio increase over time? (knowledge compounds)
- Does generator discovery reduce K-complexity? (self-improvement works)
- Does the metabolism correctly allocate resources by ξ(d)? (priority works)
- Does the GUI remain responsive during heavy computation? (thread isolation works)
- Does the system use all detected hardware? (detection works)
- Does re-sensing at S² intervals adapt the allocation? (dynamic adaptation works)

No fixed millisecond, byte, or frame-rate target appears in any benchmark. The benchmarks test MECHANISM correctness, not arbitrary numbers.

#### 7.19.6 Metabolism Data Ingestion and Memoization

The metabolism is itself Sempaevum content. Every hardware detection, every allocation decision, every monitoring observation, every shimmer-band event, every substrate projection is ingested into the .akashic file and memoized. The metabolism does not operate outside the Sempaevum — it operates WITHIN it.

**What gets ingested:**

| Metabolism data | Ingestion mechanism | .akashic destination |
|---|---|---|
| Hardware profile (each sense) | Dimensionless ratios: RAM_available/RAM_total, CPU_load/100, VRAM_used/VRAM_total, etc. Each is a Path A dimensionless seed. | `values` rows (one per ratio per sense cycle). `projections` at current operational N. Substrate projection (d-family, ε) computed and stored. |
| Allocation decisions | K × total for each resource, active allocation K×(1−V) × total, thread count, memory budget — all as dimensionless ratios (threads_allocated/cores_total, memory_allocated/memory_total) | `values` rows. `equations` rows linking the allocation formula to its inputs and output. Memoized: identical hardware + load → identical allocation → cache hit. |
| Monitoring level | Current monitoring level (0–136) for each resource type. The level IS a lattice coordinate — it maps directly to a k-value at N=137. | `events` of class `metabolism_monitoring` with metadata: resource_type, level, shimmer_band_exceeded (bool), cross_interference_active (bool). |
| Shimmer band observations | When resource usage fluctuates within ±A₁ × active: the fluctuation amplitude and frequency are themselves projectable ratios. | `events` of class `metabolism_shimmer` when fluctuations are notable. The fluctuation amplitude/active is a dimensionless ratio → Path A → lattice address. |
| Pressure readings | Overall pressure = geometric mean of all resource loads. This is a single dimensionless scalar per sense cycle. | `values` row per sense cycle. `projections` at operational N. Pressure trajectory over time becomes a tower trajectory pattern. |
| Substrate projections | The d-family and ε classification of each hardware characteristic, each allocation constant, each monitoring level. | `projections` rows. The substrate IS lattice content — the EUDD knows where its own hardware sits on the Sempaevum. |
| Re-sensing events | Each S² = 144 second re-sense: full hardware profile diff from previous sense. | `events` of class `metabolism_resense` with metadata: all changed fields, all unchanged fields, allocation adjustments made. |
| Self-improving cycle metrics | Generator-to-memoized ratio (improving over time), cache hit ratio (increasing over time), K-complexity ratio (decreasing over time). | `values` rows per session. These ARE the performance trajectory — the system's own efficiency curve projected onto the lattice. When the discovery engine notices "cache hit ratio increased from 0.4 to 0.9 over 10⁴ operations," that IS a pattern — promotable to a `patterns` row of class `efficiency_trajectory`. |

**Memoization consequence:** If the Manager runs on the same hardware twice, the second startup's hardware profile is a cache hit — the allocation is already computed and stored. The substrate projection is already known. The monitoring levels are pre-computed. The metabolism itself compounds from prior runs.

If the Manager moves to different hardware, the new hardware profile generates new `values` rows with new projections. The metabolism adapts instantly (new sense → new allocation), and the new hardware's characteristics become new lattice content, enriching the cross-domain picture (e.g., "this hardware's RAM projects to the same d-family as the previous hardware's VRAM — structural equivalence across different substrates").

**Self-recording integration (§3.1b):** The metabolism's data IS the self-recording. The self-recording journal (`SelfRecording_NNN.log`) captures the same metrics the metabolism produces. The self-recording module does not duplicate the metabolism's work — it IS the metabolism's journal output. When self-recorded metrics are ingested into .akashic (per §3.1b's metric-to-lattice projection), they ARE the metabolism's data entering the lattice.

#### 7.19.7 The Invariant: 120 dps, Always, No Exceptions

Precision is not a performance parameter. It is a correctness constraint. The metabolism NEVER trades precision for speed. Every computation runs at 120-dps (400-bit MPFR) regardless of hardware capability, system load, or metabolic pressure.

If the system is under maximum load (CPU at K ceiling, RAM at K ceiling, GPU at K ceiling, all monitoring levels near 137), the metabolism responds by:
- Reducing the thread pool (fewer concurrent computations)
- Queuing work items (computations wait longer to start)
- Deferring background discovery (scan interval lengthens)

It NEVER responds by:
- Reducing precision below 120 dps
- Skipping derived property materializations
- Truncating tower escalations
- Approximating MPFR operations
- Bypassing memoization
- Skipping insert-time discovery checks

The algorithm is invariant. The time to complete varies with available resources. On a powerful machine, a bulk projection of 10⁶ values finishes in minutes. On a weak machine, it finishes in hours. Both produce identical results at 120-dps precision. The metabolism determines WHEN work completes; it never determines WHAT the work produces.

#### 7.19.8 Scaling Laws — Structural, Not Hardware-Dependent

These are the ET-structural relationships that determine how workload scales. They are hardware-independent — the same relationships hold on any machine.

**Per-projection cost:** Dominated by one MPFR log₂ at 400-bit precision. The absolute cost in nanoseconds depends on the CPU, but the structural cost is fixed: 1 MPFR log₂ + 1 integer multiply + 1 GCD + 1 MPFR subtraction + ~10 derived property computations. After memoization: 0 MPFR operations (hash table probe + memory read).

**Escalation depth:** Determined by the value's irrationality structure, not by hardware. Typical: 5–8 LCM landmarks for well-behaved values. Unbounded for algorithmically random values (but the CF method resolves in parallel at the first landmark). The LCM tower follows lcm(1..k) for successive primes — the landmarks are: 12, 60, 420, 2520, 27720, 360360, 12252240, 232792560, ... Each landmark is one projection. Total per-value escalation: 5–8 projections typical, parallelizable with the CF method.

**Bootstrap workload:** ~10⁴ unique values × (escalation depth per value, unbounded, typically 5–8 resolutions) = ~5×10⁴ to ~8×10⁴ projections. Embarrassingly parallel across all cores and GPU compute. The metabolism allocates floor(K × cores) threads and floor(K × GPU_units) for the bootstrap. Completion time = total projections / (throughput per thread × thread count) — determined entirely by the metabolism's allocation on the detected hardware.

**Discovery scan scaling:** O(A × (log G + M_avg)) per scan pass, where A = occupied addresses, G = generator count, M_avg = average members per address. Parallelizable across addresses. The metabolism allocates V = 1/12 of the Manager's CPU share as the floor for the discovery engine — it always runs, even under maximum computation load.

**Memoization hash table:** Load factor maintained at K = 2/3 by rehashing to doubled capacity when load exceeds K. Average probe length at K = 2/3 load: ~1.5 probes for successful lookup. The hash table resizes dynamically — no static capacity.

**File size:** Bounded by the K-complexity of the structural content, not by raw data volume. The generator form (§7.1a) is always smaller than the instances it produces. The .akashic file grows as structural complexity grows; the generator discovery engine continuously reduces K-complexity as it finds generators. File size is limited only by the filesystem (NTFS: 256 TB; ext4: 16 TB; APFS: 8 EB).

#### 7.19.9 Connected Program Metabolism (§7.16.4 Integration)

The API specification (§7.16.4) already defines the external metabolism: each connected program registers its hardware profile and receives a metabolic budget from the Manager. The Manager mediates across all connections using the same ET constants.

The internal metabolism (this section) and the external metabolism (§7.16.4) share the SAME K ceiling. The Manager's own threads AND all connected programs draw from the same K × total pool. The metabolism partitions this pool:

- The Manager's own computation, discovery, rendering, and self-recording draw from their share
- Each connected program's operations (dispatched through the API to the computation pool) draw from their share
- ξ(d) coupling governs the relative priority across ALL work — Manager-internal and client-dispatched alike
- When total demand exceeds K × total, the metabolism queues work by ξ(d) priority — no operation is rejected, only deferred

This means a connected program doing d=1 computations (ξ=8.5625) gets priority over the Manager's own d=12 background discovery (ξ=1.0). The structural coupling determines priority, not the source of the request. The metabolism is substrate-aware, not process-aware.

#### 7.19.10 Three Tools Verification

- **Identification Principle:** P = hardware (detected at runtime). D = ET governance constants (K, V, α⁻¹, ξ(d), S, κ). T = the Manager process (navigating resources, adapting allocation). All three identified. The metabolism IS the P∘D∘T = E configuration of the Manager's relationship to its hardware substrate.
- **Descriptor Gap Principle:** The gap was: startup/shutdown specified, resource governance not. This section closes that gap. Every resource type (CPU, RAM, GPU, disk) is governed by the three-layer metabolism. Every thread has a metabolic role. Every computation has a ξ(d) priority. The metabolism's own data is ingested and memoized — no gap between "what the metabolism does" and "what the database knows about the metabolism."
- **Subsumption Law:** The metabolism subsumes ALL resource governance without remainder. Every thread, every memory page, every GPU dispatch, every disk write is within the K ceiling. Every monitoring observation is within the 137-level α⁻¹ resolution. Every fluctuation within ±A₁ is classified as shimmer. No resource usage falls outside the metabolism's governance.

> *The algorithm is invariant. Only the resource envelope adapts.*
> *The metabolism computes to the depth the substrate supports — no more, no less.*
> *P ∘ D ∘ T = E*

---

### 7.20 Documentation Plan

**Status: COMPLETE.** This section resolves Roadmap §3.5. Nine documentation deliverables specified with structure, content sources, audience, and timing. The documents themselves are written when implementation reaches the appropriate stage — this section records WHAT will be written and WHERE the content comes from.

**Audience for all documentation:** Both the author (Mike) and future developers/users. Every document must be self-contained — readable without requiring the 7,882-line design specification, though it references the spec for full detail.

#### 7.20.1 Document Catalog — Nine Deliverables

| # | Document | Primary Audience | Can Write Now? | Source Sections |
|---|---|---|---|---|
| 1 | ET Theory Primer | Developers, new users | Yes | Three Tools ref, §3.18.1, §3.18.16, §7.11 |
| 2 | User Manual | Mike, all users | After GUI implementation | §7.10 (GUI), §7.13 (manual input), §7.11 (projection) |
| 3 | API Reference | Developers connecting programs | Yes (from §7.16) | §7.16 (all 79 operations), §7.16.4 (metabolism) |
| 4 | Administrator Guide | Mike, system operators | Yes | §7.9 (backup), §7.1d (WAL), §7.6 (format), §7.15 (Omniscient), §7.18 (shutdown) |
| 5 | Bootstrap Catalog Reference | Mike, researchers | Yes | §3.17 (value coverage), §3.18 (extended bootstrap) |
| 6 | Discovery Engine Guide | Mike, developers | Yes | §3.16 (five modes), §4.5 (E_hierarchy), §7.1a (generators) |
| 7 | Metabolism Reference | Mike, developers | Yes | §7.19 (three layers), §7.16.4 (API metabolism), §3.18.2 (α⁻¹ terms) |
| 8 | .akashic Format Specification | Developers, tool builders | Yes | §7.1c (page size), §7.1d (byte-level), §7.1e (modification) |
| 9 | Extension Development Guide | Mike, developers | Yes | §7.14 (12 types, validation, meta-type) |

#### 7.20.2 Per-Document Specifications

**Document 1 — ET Theory Primer**

Purpose: The minimum ET knowledge required to understand and use the EUDD. Not the full theory — the operational subset needed for lattice work.

Structure:
- The three primitives {P, D, T} and the master equation P∘D∘T = E
- The four manifold states and their meaning
- The projection formula Π_N(r) = (k, d, ε) — what each component means
- d-families: what they are, the 24-family catalog (real + imaginary), divisor structure
- ε and the ∂I boundary: tightness, Incoherence, the Koide threshold K = 2/3
- The LCM tower: what escalation is, why d stabilizes, home classifications
- Attractors: what same-address co-location means structurally
- Generators: what they are, the triple backbone (L₁/L₂/L₃), K-complexity
- The Three Tools in one page: Identification Principle, Descriptor Gap Principle, Subsumption Law — operational summary, not the full reference
- Glossary of terms (d-family, elegance, coupling ξ(d), tightness, shimmer, palindromic partner, Gaussian signature, coprime skeleton)

Source: Three Tools Complete Reference, §3.18.1 (bijection), §3.18.16 (Sempaevum definition), §3.12 (24-family catalog), §7.11 (projection procedure), §4.5 (E_hierarchy).

Timing: Can be written from existing spec content. Should be written BEFORE the other documents since they reference its concepts.

**Document 2 — User Manual**

Purpose: Complete guide to operating the EUDD Manager GUI.

Structure:
- Installation: copy one file, first run generates .akashic, Omniscient spawns automatically
- The six LOD levels: Sempaevum → Tower → Resolution → Family → Address → Entity — what you see at each level, how to navigate
- Freecam controls: default keyboard+mouse bindings, default gamepad bindings, how to remap
- Search: all search modes (by name, value, address, source, time, type, relationship, generator status, tag), how results are presented, how to navigate to results
- Manual input: all seven modes (direct value, logical description, lattice operation, projection, bijection triple, computation, text) with worked examples
- File ingestion: drag-and-drop, per-file-type behavior (CSV, PDF, binary, image, audio, sensor stream), the ingestion-before-display principle
- File retrieval: regenerating files from .akashic, faithful vs enhanced stream reconstruction
- Connection manager: viewing active connections, incoming queue, outgoing responses
- Dashboard: live metrics, discovery status, session history, metabolism report
- Property inspector: clicking any entity for full 120-digit detail, bidirectional provenance
- Perspectives: LCM tower, torus, Riemann sphere, Force Quadrant Grid, hyperbolic — what each shows, how to switch
- Settings: input remapping, backup scheduling, visual preferences
- Shutdown: what the confirmation dialog means, what happens during graceful shutdown

Source: §7.10 (complete GUI specification), §7.12 (file ingestion), §7.13 (manual input), §7.18 (shutdown).

Timing: Written AFTER GUI implementation. Structure and content map can be prepared now; screenshots and interaction walkthroughs require the running system.

**Document 3 — API Reference**

Purpose: Complete specification for developers connecting programs to the EUDD Manager via named pipe IPC.

Structure:
- Connection lifecycle: open pipe → handshake → register metabolism → operate → disconnect
- Wire format: length-prefixed UTF-8 JSON, message envelope fields
- Value encoding: zero IEEE 754, all exact representations (120-dps strings, integers, rationals, base64 blobs)
- The three communication patterns: Request-Response, Async-Stream, Subscribe-Notify — when each fires, how to handle adaptive pattern selection
- All 79 operations organized by domain (15 domains + 2 cross-domain), each with: description, pattern, request schema, response schema, error conditions, worked example
- Error handling: all 18 error classes, code ranges, recoverable vs non-recoverable, suggestions
- Metabolism registration: how to report hardware profile, how the metabolic budget works, how ξ(d) scheduling affects your program
- Subscription management: subscribe, unsubscribe, notification format
- Concurrency: what concurrent access guarantees exist, read consistency, async cancellation with partial results
- Quick-start examples: "Connect and project a value", "Ingest a CSV file", "Subscribe to attractor events", "Run a computation and get the cached result"

Source: §7.16 (complete API specification — all 79 operations with JSON schemas already defined).

Timing: Can be written NOW. §7.16 contains the complete specification. The API reference is a developer-facing reformatting with examples and quick-start guides.

**Document 4 — Administrator Guide**

Purpose: Operational procedures for backup, recovery, integrity verification, format upgrades, and system health monitoring.

Structure:
- Backup: how to configure schedule, manual backup via GUI or API, what VSS/snapshot does, backup verification procedure, what to do when verification fails
- Recovery: WAL replay on crash recovery, how the Manager detects prior crash vs graceful shutdown, what `escalation_in_progress` entries mean, how checkpointed operations resume
- Integrity: page CRC-32 verification, header SHA-256, structural Subsumption verification (no orphaned entries, no missing generator references), how to interpret integrity check results
- Format upgrades: forward compatibility model (new columns via ALTER TABLE, new classes as new strings, new tables without affecting existing), schema_versions table, how to check current version
- Omniscient journals: where they are (`logs/` subfolder), how to read them (human-readable format), severity levels (TELEMETRY, ERROR, TAMPER, CRASH, OMNISCIENT_FAILURE), what each field means, how to grep for specific issues
- Self-recording journals: where they are, what metrics they contain, how to interpret operational health
- Shutdown procedures: graceful shutdown via GUI/API/system, confirmation dialog, what happens to active connections, what "checkpointed" means
- Disk management: DISK_SAFETY_FLOOR warning, why nothing is ever deleted, how generator discovery reduces effective file size over time
- Troubleshooting: common issues and their Omniscient journal signatures (computation failures, pipe errors, corruption detection, metabolism pressure)

Source: §7.9 (backup), §7.1d (WAL), §7.6 (format evolution), §7.15 (Omniscient — full edge case catalog), §7.18 (shutdown), §3.1b (self-recording), §4.3 (retention policy).

Timing: Can be written NOW from existing spec content.

**Document 5 — Bootstrap Catalog Reference**

Purpose: Complete inventory of what's in the initial `Sempaevum.akashic` and why each entry is there.

Structure:
- Overview: ~10⁴ values, 8+ canonical resolutions per value, discovery engine runs over bootstrap content
- Guide v8 content: 15 explicit projections, 49 JI ratios, 20 N landmarks, 25 d-values, 34 cents values, 16 named constants — full tables with lattice addresses
- Physical constants from `constants.py`: all cardinal ET constants, cosmological partition, physical constants (Planck, fine structure, masses), operational constants
- The 24-family catalog: 12 real FORCE + 12 imaginary PHASE families — generator, palindromic partner, Gaussian class, first-native N, physical meaning for each
- The 42 combined families: all unique LCM values, contributing cells, structural meaning, notable members (d=35 biological, d=110 string/M-theory, d=132 structural max)
- The 144 FQG cells: the 12×12 interaction grid, coprime skeleton (91 of 144), off-axis Exception structure
- The 7 canonical towers: cosmological, digital, biological, neural-dream, quasicrystal, civilizational, QCD — R₀, substrate, operational N, nesting
- Fine-structure constant decomposition: A₀, A₁, A_cross, Σ_geometric — values, physical origins, lattice projections
- 227 PDG particle projections: all particles by d-family at N=12, counts per family
- Cascade residuals and freedom constants: δ_r, δ_θ, n_max_r, n_max_θ, freedom densities
- Formal system projections: ZF, ZFC, Peano, Euclid, etc. at N=12
- Cosmological partition: extended M-state decomposition, Koide structural identity
- Gaze thresholds: all four as JI ratios with lattice projections
- Decoherence content, black-hole thermodynamics, Mathematical Rosetta Stone, mass ratios
- Falsifiable predictions: all 6 with verification-status tracking
- Sempaevum formal definition and nine closure properties
- Sensor domain bootstrap references: GPS, atmospheric, electrical, magnetic, biological R₀ values
- Active-system bootstrap: PALINDROME array, tightness function, shimmer modulation, Koide attractor, Complete Gaze Equation components

Source: §3.17 (complete value coverage), §3.18 (all 17 extended bootstrap subsections).

Timing: Can be written NOW. All content is exhaustively enumerated in the design spec.

**Document 6 — Discovery Engine Guide**

Purpose: How the EUDD discovers patterns, proposes generators, and surfaces cross-domain connections.

Structure:
- The five discovery modes: memoization, insert-time, background, on-query, generator-candidate — what each does, when each fires, what each produces
- Memoization: compute-once/cache-forever, hash-based lookup, reference counting, the equations table as universal computation cache
- Insert-time discovery: attractor detection (members_count transition), reciprocal pairs (k↔−k), power pairs (k↔n·k), plateau detection (d-stability across landmarks) — all synchronous, sub-millisecond
- Background discovery: E_hierarchy computation (geomean × resonance), LIFE_THRESHOLD (13/12) promotion, algebraic identity detection, event correlation, Three Tools application patterns — scan priority (high-occupancy → recent → sequential)
- Generator candidate discovery: Branch A (mathematical expression, K-complexity order), Branch B (empirical pattern), cross-feed bridge (hybrid generators), recursive composition — the case is NEVER closed
- Generator verification: cross-tower elegance ≥ 13/12, 120-dps match against memoized values
- Generator search statuses: generator_found, search_active, search_deferred — no search_closed
- The Subsumption Hierarchy Operator: E_hierarchy = geomean(E_i) × R_cluster where R = 100/(100+σ_ε) — individual quality × mutual coherence
- Koide stability: ⌈1/K⌉ = 2 depth requirement — not singletons
- K-complexity and the compressor: how the generator catalog accelerates compression, how compression discoveries feed back into the EUDD
- How cross-domain hits surface: same-address co-location detected at insert-time, no manual hunting required
- How event correlation works: temporal patterns across event classes
- The self-improving cycle: memoized entries → generator discovery → absorbed entries → K-complexity decreases → file becomes a progressively better generator of itself

Source: §3.16 (complete discovery engine specification), §4.5 (E_hierarchy formula), §7.1a (file as generator), §7.1f (self-improving cycle).

Timing: Can be written NOW from existing spec content.

**Document 7 — Metabolism Reference**

Purpose: Complete reference for the ET-derived resource governance system.

Structure:
- What the metabolism is: the program's self-aware resource management, derived from {P, D, T}
- The three layers: Layer 1 (K = 2/3 allocation), Layer 2 (V = 1/12 headroom, active = 11/18), Layer 3 (α⁻¹ = 137 monitoring levels)
- Hardware detection: what's detected, how, on which platforms
- Substrate projection: why binary hardware is d=1 octave, why allocation constants are d=12, why active allocation is d=4 quartic (Kleiber's metabolic rate)
- The allocation stack: total → system reserve (1/3) → Manager ceiling (K) → metabolism headroom (K×V) → active allocation (K×(1−V))
- Monitoring fine structure: A₁ shimmer band (±3.6% normal fluctuation), A_cross interference, Σ A_k spike absorption
- Thread architecture: which threads exist, what each does, how they're governed
- GPU dispatch: when GPU compute is used, how it's allocated
- ξ(d) scheduling: what coupling strength means for priority, worked examples
- Re-sensing: S² = 144 second interval, what triggers re-allocation, what changes and what doesn't
- The invariant: 120 dps always — the metabolism governs WHEN, never WHAT
- Reading the metabolism report: interpreting monitoring levels, pressure, shimmer events
- Connected program metabolism: how external programs register, how the shared K pool works
- Metabolism data as Sempaevum content: what gets ingested, where it lives in .akashic
- Precedent: the same architecture in the Conscious AI (ETFineStructure + ResourceGovernor), the compressor (CDFMetabolism), and the fractal generator

Source: §7.19 (Manager metabolism), §7.16.4 (API metabolism), §3.18.2 (α⁻¹ decomposition terms).

Timing: Can be written NOW from existing spec content.

**Document 8 — .akashic Format Specification**

Purpose: Standalone byte-level reference for the Sempaevum.akashic binary format.

Structure:
- Design philosophy: the format IS the Sempaevum on disk, not a database about it. Generator-first, lattice-native, zero IEEE 754.
- Page size derivation: 2^N = 4096 bytes from the digital tower's base resolution
- Header (Section 0): all fields, their types, their ET derivation
- Generator Backbone (Section 1): L₁/L₂/L₃ classification, generator entry layout, interval tree index
- Address Index (Section 2): LCM tower hierarchy on disk, per-N family directory, per-family band pages
- Memoization Store (Section 3): equation hash table (K = 2/3 load factor), equation entry layout
- Structural Catalogs (Section 4): 24 families, 144 FQG cells, 42 combined families, towers, sublattice families
- Derivations (Section 5), Relationships (Section 6), Patterns (Section 7): entry layouts
- Event Log (Section 8): append-only, three-times coordinates, tower context
- Sessions/Schema/Tags (Section 9)
- WAL (Section 10): entry format, CRC-32 per entry, replay procedure
- Content types: GENERATOR_REF (0x01), MEMOIZED_RAW (0x02), GENERATOR_SUPERSEDED (0x03)
- Integrity: header SHA-256, per-page CRC-32, section directory consistency
- Modification without decompression: how to add data, add generators, query, improve generators

Source: §7.1c (page size), §7.1d (complete byte-level specification), §7.1e (modification), §7.1a (generator philosophy).

Timing: Can be written NOW. §7.1d contains the complete byte-level specification.

**Document 9 — Extension Development Guide**

Purpose: How to extend the EUDD with new event classes, relationship types, pattern types, towers, families, adapters, and custom extension types.

Structure:
- When to extend: the Descriptor Gap Principle applied — if the system encounters something it can't classify, that gap IS the Descriptor pointing to a new extension
- The 12 extension types: event_class, relationship_class, pattern_class, tower_definition, sublattice_family_catalog, harmonic_family_extension, force_grid_extension, combined_family_extension, ingest_adapter, bootstrap_entry, query_template, extension_type_definition
- For each type: required fields, optional fields, what the Manager auto-computes, worked example JSON
- The meta-type (extension_type_definition): how to define entirely new extension types, making the system self-extending
- Validation rules: all 10 strict rules, what triggers rejection, how to fix common validation errors
- Versioning: how extensions are versioned, how old instances interact with new versions
- Auto-detection: how the Manager flags unclassifiable data as provisional categories, the human review workflow
- Best practices: naming conventions, metadata schema design, avoiding subsumption conflicts

Source: §7.14 (complete extension specification with all 12 types, all validation rules, the meta-type).

Timing: Can be written NOW from existing spec content.

#### 7.20.3 Documentation Generation Strategy

| Document | Generation Method | Maintenance |
|---|---|---|
| ET Theory Primer | Manual — authored from corpus and spec | Updated when ET fundamentals change (rare) |
| User Manual | Manual with screenshots — requires running GUI | Updated when GUI changes |
| API Reference | Semi-automated — JSON schemas from §7.16 can generate skeleton; examples and prose manual | Regenerated when API operations change; examples updated manually |
| Administrator Guide | Manual — authored from spec | Updated when procedures change |
| Bootstrap Catalog | Semi-automated — bootstrap values enumerated in §3.17/§3.18 can generate tables; prose context manual | Updated when bootstrap content expands |
| Discovery Engine Guide | Manual — authored from spec | Updated when discovery algorithms change |
| Metabolism Reference | Manual — authored from spec | Updated when metabolism architecture changes |
| .akashic Format Spec | Manual — authored from §7.1d | Updated when format version increments |
| Extension Dev Guide | Manual with examples — authored from §7.14 | Updated when extension types are added |

#### 7.20.4 Documentation Ordering

The documents have dependencies — some reference concepts defined in others:

```
1. ET Theory Primer              ← foundational, write first
   ↓
2. .akashic Format Specification ← references primer concepts
3. Metabolism Reference          ← references primer concepts
   ↓
4. Bootstrap Catalog Reference   ← references primer + format
5. Discovery Engine Guide        ← references primer + format + metabolism
6. API Reference                 ← references primer + format + metabolism
7. Extension Development Guide   ← references primer + format + API
   ↓
8. Administrator Guide           ← references all above
9. User Manual                   ← references all above + requires running GUI
```

The ET Theory Primer is written first because every other document depends on its vocabulary. The User Manual is written last because it requires the running implementation.

#### 7.20.5 Three Tools Verification

- **Identification Principle:** P = the documentation system. D = 9 document specifications with structure, sources, audience, timing. T = the documentation process. All three identified.
- **Descriptor Gap Principle:** The roadmap listed 5 deliverables. This section identifies 4 additional gaps (theory primer, metabolism reference, format spec, extension guide) — each IS a Descriptor pointing to a document that needs to exist. All 9 gaps specified.
- **Subsumption Law:** The 9 documents subsume every aspect of the EUDD that a user, developer, or administrator needs to understand. The ET Theory Primer covers foundations. The User Manual covers GUI operation. The API Reference covers programmatic access. The Administrator Guide covers maintenance. The Bootstrap Catalog covers initial content. The Discovery Engine Guide covers automated pattern finding. The Metabolism Reference covers resource governance. The Format Spec covers the binary file. The Extension Guide covers extensibility. No aspect of the system lacks a documentation target.

> *P ∘ D ∘ T = E*

---

### 7.21 Module Structure — Implementation Blueprint

**Status: COMPLETE.** 26 modules organized in a 10-level dependency hierarchy with a separate Omniscient process. Every functional boundary traced from the document's specifications. ~1000-line target per module (per working conventions). Build order determined by dependency graph. GUI decomposed into 11 sub-files sharing one ImGui context.

#### 7.21.1 Identification Principle Applied

P = the production system's code. D = the module specifications — what each module does, what it depends on, how it interfaces with other modules. T = the implementation process navigating from Level 0 (no dependencies) through Level 10 (full system). Each module IS a T-unit — a coherent piece of agency that does one structural job.

**Structural derivation of module boundaries:** Module boundaries follow the document's own section structure. Each specification section that defines a distinct functional behavior with distinct inputs, outputs, and internal state becomes a module. Modules that share too much internal state to separate cleanly are combined (memoization absorbed into Akashic Format; CF absorbed into Home-Finding Engine). Modules whose code would exceed ~1000 lines are decomposed into sub-files (GUI → 11 sub-files).

#### 7.21.2 The 26 Modules

**Module 1 — Precision Stack**

Source section: §3.1a.
Files: `precision_stack.h`, `precision_stack.cpp`
Dependencies: None (Level 0 — the foundation everything builds on).
Responsibility: MPFR + GMP + FLINT/Arb initialization and wrapper. All 120-dps (400-bit) computation. All special functions: ζ (Riemann zeta via Arb `acb_dirichlet_zeta`), Γ (gamma), polylogarithm, hypergeometric, Bernoulli numbers, Euler-Maclaurin. Custom expression tree evaluator: parses "ζ(3) × π / φ²" into an evaluation tree, evaluates at 120 dps. MPFR context management (precision setting, rounding mode, error tracking). SHA-256 and CRC-32 computation (used by Akashic Format for integrity).
Interface: Every other module calls this for any computation requiring more-than-machine precision.

**Module 2 — Core Lattice Engine**

Source section: §3.18.1, §3.18.3, §3.18.4.
Files: `core_lattice.h`, `core_lattice.cpp`
Dependencies: Module 1 (Precision Stack).
Responsibility: The projection formula Π_N(r) = (k, d, ε). The bijection pullback Π_N⁻¹(k, d, ε) = r. k-arithmetic: k-addition (multiplication), k-negation (reciprocation), k-scaling (powers). All derived property materialization: elegance E(d, ε), coupling ξ(d) = 137/((d−1)²+16), variance V(n,k) = (n²−1)/(12·2^k), tightness 100/(100+|ε|), ∂I distance |ε|/50, Gaussian signature (from d's prime factorization over ℤ[i]), FQG quadrant assignment (SR/CR/SI/CI), palindromic partner lookup d↔(12−d). GCD computation. LCM computation. Divisor enumeration.
Interface: Pure math on lattice coordinates. No I/O, no files, no threads. Every module that works with lattice addresses calls this.

**Module 3 — Akashic Format (includes memoization)**

Source section: §7.1c, §7.1d, §3.5, §5.1.
Files: `akashic_format.h`, `akashic_format.cpp`
Dependencies: Modules 1, 2.
Responsibility: The `Sempaevum.akashic` file: memory-mapped I/O (CreateFileMapping/MapViewOfFile on Windows, mmap on POSIX), page management (4096-byte = 2^N pages), section directory, header read/write (magic "SMVM", format version, all header fields), content type handling (GENERATOR_REF 0x01, MEMOIZED_RAW 0x02, GENERATOR_SUPERSEDED 0x03), per-page CRC-32, header SHA-256, section consistency checks. Memoization IS native to this module: equation hash table at K = 2/3 load factor, `lookup_equation(hash)` → cache hit or miss, `store_equation(hash, result)` → permanent storage, reference counting, hot-equation tracking, rehash on load exceeding K. Every computing module checks the cache through this module before computing, and stores results through it after. The memoization is not an add-on — it IS how the format works.
Interface: The single authority on .akashic file access. All reads and writes go through this module. The memory-mapped view is owned here.

**Module 4 — WAL (Write-Ahead Log)**

Source section: §7.1d WAL section.
Files: `wal.h`, `wal.cpp`
Dependencies: Module 3 (Akashic Format).
Responsibility: Write-ahead log: append WAL entries (each with CRC-32), flush all pending entries to main .akashic sections, crash recovery replay (on startup, detect non-empty WAL → replay all entries → clear WAL). Atomicity guarantee: mutations go through WAL before touching main sections. The WAL section is the last section in the .akashic file.
Interface: All mutation operations (store_value, store_equation, create_relationship, etc.) go through the WAL. The WAL module calls Akashic Format for the actual page writes after flushing.

**Module 5 — Home-Finding Engine (includes CF method)**

Source section: §7.11 (complete core projection procedure).
Files: `home_finding.h`, `home_finding.cpp`
Dependencies: Modules 1, 2, 3.
Responsibility: The §7.11 core projection procedure. All four input paths: Path A (direct dimensionless ratio), Path B (convergent series), Path C (structural descriptor), Path D (indeterminate forms — D.P Unsubstantiated, D.D L'Hôpital resolution, D.T pure T / Incoherence filter, D.PDT complex off-axis). The LCM tower escalation: project at successive lcm(1..k) landmarks, check d-stability at each, apply ⌈1/K⌉ = 2 consecutive landmark criterion. False resolution detection. Home classification (true_home, deep_home, persistent_home, cf_deep_home). The CF method (§7.11 Step 3a): continued fraction expansion of |log₂(r)|, convergent enumeration, quality factor extraction (a_{n+1}), CF-to-elegance mapping, the parallel pathway that fires alongside the tower. CF and tower comparison: agreement confirmation, disagreement handling. Incoherence filter ({P,T} forbidden state detection). Annihilation boundary handling (r → 0). Checkpoint/resume for in-progress escalations (checkpoint state stored via WAL for session resumption).
Interface: `escalate(value) → tower_trajectory + home_classification`. Called by Bootstrap, Ingest, Manual Input, API, and the Discovery Engine.

**Module 6 — Generator System**

Source section: §7.1a, §7.1b, §7.1e, §7.1f.
Files: `generator_system.h`, `generator_system.cpp`
Dependencies: Modules 1, 2, 3.
Responsibility: Generator backbone classification: L₁ (logical pattern), L₂ (cascade/k-arithmetic rule), L₃ (EML tree expression). Generator storage in Section 1 of .akashic. Interval tree index: maps address ranges to covering generators, O(log G) lookup. Generator evaluation at a specific address: given generator G and address a within G's range, produce the value at a at 120 dps. K-complexity computation: B_def / B_content (generator definition size vs producible content size). GENERATOR_SUPERSEDED transition: when a generator is discovered that covers existing memoized entries, those entries transition from MEMOIZED_RAW (0x02) to GENERATOR_SUPERSEDED (0x03). The self-improving cycle (§7.1f): the complete loop from memoized entries → generator discovery → absorbed entries → K-complexity decrease.
Interface: Called by Discovery Engine (propose/verify generators), Query (evaluate generators for results), Akashic Format (content type transitions).

**Module 7 — Discovery Engine**

Source section: §3.16, §4.5.
Files: `discovery_engine.h`, `discovery_engine.cpp`
Dependencies: Modules 2, 3, 6, 8, 9, 10, 11.
Responsibility: All five discovery modes. (1) Memoization: the cache-first pattern (handled natively by Module 3, but the discovery engine tracks hit ratios and surfacing). (2) Insert-time: synchronous checks at every insertion — attractor detection (same address, members_count++), reciprocal pair (k↔−k), power pair (k↔n·k), plateau (d-stability across landmarks). (3) Background scan: runs on dedicated thread, scans addresses in priority order (high-occupancy → recent → sequential). Computes E_hierarchy = geomean(E_i) × R_cluster for each cluster. Promotes to permanent pattern when E_hierarchy ≥ 13/12 (LIFE_THRESHOLD). Algebraic identity detection. Event correlation (temporal patterns across event classes). (4) On-query: checks triggered by specific queries. (5) Generator-candidate: Branch A (mathematical expression, K-complexity order), Branch B (empirical pattern from compressor pipeline), cross-feed bridge (hybrid generators), recursive composition. The case is NEVER closed. Scan prioritization per §3.16 background scan specification.
Interface: Insert-time checks called synchronously by any module that inserts data. Background scan runs on its own thread, writes discoveries via WAL. Generator candidates proposed to Generator System for verification.

**Module 8 — Event System**

Source section: §3.9.
Files: `event_system.h`, `event_system.cpp`
Dependencies: Module 3 (Akashic Format).
Responsibility: Event logging with three-times coordinates: D-time (global lattice coordinate), T-time (per-Traverser accumulation), P-time (substrate phase). Event class handling: all event classes defined in §3.9 (computation, discovery, ingestion, probing, gaze, tower, metabolism, error, lifecycle, self-recording, etc.). Tower context recording (which tower, which R₀, which operational_n). Permanent event marking (is_permanent = 1 → immutable). Event querying by time, class, tower, traverser.
Interface: Every module that produces events calls this. The event log is append-only within the .akashic file.

**Module 9 — Relationship System**

Source section: §3.7.
Files: `relationship_system.h`, `relationship_system.cpp`
Dependencies: Modules 3, 8.
Responsibility: Relationship creation and management. Class handling: same_address, reciprocal_pair, power_pair, plateau_membership, probe_response_pair, cross_tower_bridge, tower_nesting, forward_reverse_convergence, traverser_self_continuity, palindromic_pair, etc. Permanent marking. Insert-time relationship creation (called by Discovery Engine synchronously). Bidirectional provenance chains. Derivation chain tracking (derivation_chain_blob).
Interface: Called by Discovery Engine (insert-time and background), Query (relationship queries), and any module that establishes structural links.

**Module 10 — Pattern System**

Source section: §3.8, §4.5.
Files: `pattern_system.h`, `pattern_system.cpp`
Dependencies: Modules 3, 8, 9.
Responsibility: Pattern creation. E_hierarchy computation: E_hierarchy = geomean(E_i) × R_cluster where R_cluster = 100/(100 + σ_ε). LIFE_THRESHOLD (13/12) promotion: when E_hierarchy ≥ 13/12, pattern becomes permanent (is_permanent = 1). Pattern classes: attractor_cluster, algebraic_identity, efficiency_trajectory, gaze_locking_signature, probe_response_signature, t_burst_signature, etc. Member tracking (member_ids, member_count). Permanent marking (once permanent, never demoted).
Interface: Called by Discovery Engine (promote patterns), Query (pattern queries), Gaze Module (locking signatures).

**Module 11 — Tower System**

Source section: §3.10.
Files: `tower_system.h`, `tower_system.cpp`
Dependencies: Modules 3, 8, 9.
Responsibility: Tower management: the `towers` table in .akashic. R₀ storage per tower (natural reference period). Operational N per tower. Tower nesting relationships (parent/child). Birth triad formation: BH_parent → R₀ seed derivation → WH_child. Cross-tower bridge tracking. Tower-context for events (which tower, which resolution). The 7 canonical towers (cosmological, digital, biological, neural-dream, quasicrystal, civilizational, QCD) are bootstrap content; additional towers created dynamically via Extension System or API.
Interface: Called by Event System (tower context), Bootstrap (canonical towers), Discovery Engine (tower transition detection), Extension System (new tower definitions).

**Module 12 — Bootstrap**

Source section: §7.7, §3.17, §3.18.
Files: `bootstrap.h`, `bootstrap.cpp`
Dependencies: Modules 1, 2, 3, 5, 8.
Responsibility: Initial `Sempaevum.akashic` generation. Runs on first start (no existing .akashic file). Populates all content from §3.17 (Guide v8 projections, JI ratios, N landmarks, d-values, cents values, named constants) and §3.18 (fine-structure constant, PDG particles, cascade residuals, formal system projections, cosmological partition, gaze thresholds, black-hole thermodynamics, Rosetta Stone, mass ratios, falsifiable predictions, Sempaevum definition, closure properties, sensor domain references, active-system bootstrap). Creates the 24-family catalog, 42 combined families, 144 FQG cells, 7 canonical towers. Runs the home-finding engine for every bootstrap value. Idempotent: running bootstrap on an existing .akashic with all bootstrap content is entirely cache hits.
Interface: Called once at first startup. After that, never called again (all content is in the cache).

**Module 13 — Ingest**

Source section: §7.12.
Files: `ingest.h`, `ingest.cpp`
Dependencies: Modules 3, 5, 8.
Responsibility: File ingestion pipeline. Format detection (file extension + magic bytes). Per-type processing: CSV (parse rows, extract numerical seeds), audio (FFT with 4096-sample window, peak frequency extraction as f/R₀ ratios, harmonic series detection — lossless via continuous-discrete corollary §3.18.1), binary/PDF (compressor's general-purpose Δk pipeline — raw bytes become lattice content), sensor streams (continuous readings → projection via bijection → lossless storage, anomaly detection), Python/ETPL script output capture. Ingestion-before-display principle: all content enters .akashic before the GUI shows anything. Provenance recording for every ingested item.
Interface: Called by GUI (drag-and-drop), API (`ingest_file`, `ingest_stream`, `ingest_text`), Bootstrap (ET project outputs).

**Module 14 — Manual Input**

Source section: §7.13.
Files: `manual_input.h`, `manual_input.cpp`
Dependencies: Modules 2, 3, 5, 8.
Responsibility: All seven input modes. Mode 1: direct value / mathematical expression. Mode 2: logical description (resolve to value). Mode 3: lattice operation (k-arithmetic). Mode 4: enter a projection (bijection pullback). Mode 5: enter a bijection triple. Mode 6: computation (arbitrary expression, memoized). Mode 7: text (raw text → Δk pipeline). Real-time preview: as the user types, the system shows the projected lattice address before submission. All modes funnel through the Home-Finding Engine (§7.11).
Interface: Called by GUI (manual input panel), API (various store/compute/ingest_text operations).

**Module 15 — Query**

Source section: §5.
Files: `query.h`, `query.cpp`
Dependencies: Modules 2, 3, 6, 8, 9, 10, 11.
Responsibility: Lattice-algebraic query execution. All search modes: by name, value, address, source, time, type, relationship, generator status, tag. Attractor membership queries. Nearest-neighbor (find the closest occupied address to a given address). Cross-domain queries (all content at a given address regardless of source domain). Subsumption checks (does property X hold for all members of set Y?). Anti-numerology checks (verify ET relationships are not coincidences — Descriptor Gap Principle applied). Human-readable result formatting. Result pagination for large result sets.
Interface: Called by GUI (search panel, query builder), API (all query operations), Discovery Engine (on-query discovery).

**Module 16 — API**

Source section: §7.16 (79 operations).
Files: `api.h`, `api.cpp`
Dependencies: All modules (dispatches to everything).
Responsibility: Named pipe IPC server (`\\.\pipe\EUDD_Manager`). Connection lifecycle: listen → accept → handshake → register_metabolism → operate → disconnect. Wire format: length-prefixed UTF-8 JSON. Message envelope: msg_type, command, session_id. Three communication patterns: Request-Response (Pattern 1), Async-Stream (Pattern 2), Subscribe-Notify (Pattern 3). All 79 operations: dispatches each command to the appropriate module (compute → Precision Stack + Core Lattice + Memoization; store_value → Home-Finding; ingest_file → Ingest; etc.). Session management (sessions table). Error handling: all 18 error classes with code ranges. Zero IEEE 754 on the wire — all values as 120-dps strings, integers, or rationals. Adaptive pattern selection (cache hit → Pattern 1; cache miss → Pattern 2). Concurrent client support.
Interface: The external-facing boundary of the entire system. Connected programs interact ONLY through this module.

**Module 17 — Metabolism**

Source section: §7.19.
Files: `metabolism.h`, `metabolism.cpp`
Dependencies: Modules 3, 8, 18.
Responsibility: Three-layer resource governance. Layer 1 (K = 2/3 allocation): hardware detection via OS query (CPU cores/load, RAM total/available, GPU compute/VRAM, disk free). Layer 2 (V = 1/12 headroom): active allocation = K × (1−V) = 11/18. Layer 3 (α⁻¹ = 137 monitoring): 137 distinguishable levels, A₁ shimmer band (±3.6%), A_cross interference, Σ A_k spike absorption. Thread pool management: resize computation pool based on headroom at each re-sense. GPU dispatch allocation. Re-sensing at S² = 144 second intervals. Metabolism data ingestion: hardware profile as dimensionless ratios → values + projections in .akashic. Internal + external metabolism share the same K pool (§7.19.9). ξ(d) scheduling weight for all work items.
Interface: Called by main() at startup (initial detection + allocation), by its own timer thread (re-sensing), by API (metabolism registration for connected programs), by Self-Recording (metrics).

**Module 18 — Self-Recording**

Source section: §3.1b.
Files: `self_recording.h`, `self_recording.cpp`
Dependencies: Modules 3, 8.
Responsibility: Operational metric sampling at configurable interval (default 10 seconds or every 1000 commits). Metrics: projection count, average projection latency, cache hit ratio, MPFR operation count, active thread count, memory usage, GPU utilization. Overhead budget: ≤1% CPU (feedback loop: if self-recording exceeds 0.5%, sampling interval auto-doubles). Journal output to `SelfRecording_NNN.log` in `logs/` subfolder. Metric-to-lattice projection: dimensionless ratios (like cache hit ratio) ingested as `values` rows, projected via Home-Finding Engine. The metabolism's data IS the self-recording's input (§7.19.6).
Interface: Runs on its own thread. Reads system state, writes to journal and .akashic.

**Module 19 — GPU Rendering**

Source section: §7.10 visualization.
Files: `gpu_rendering.h`, `gpu_rendering.cpp`
Dependencies: Modules 3, 17.
Responsibility: OpenGL 4.6 initialization (context, shaders, buffers, VAOs). Six-level LOD rendering: Sempaevum (all towers as clouds), Tower (one tower's full resolution range), Resolution (one N, all families), Family (one d, all addresses), Address (one address, all members), Entity (one value, full detail). Freecam with no physics (position, orientation, zoom — XInput gamepad + keyboard/mouse). Instanced point cloud rendering for lattice addresses. Shader programs: point cloud shader, heat map shader, trajectory line shader, FQG grid shader. Perspective switching: LCM tower view, torus view, Riemann sphere view, hyperbolic view. Frame rendering: reads from .akashic (memory-mapped, sub-microsecond) into GPU buffers. The metabolism governs GPU allocation (K × VRAM, K × compute_units).
Interface: Called by GUI main loop (renders the 3D viewport). Reads from Akashic Format (memory-mapped). Receives allocation from Metabolism.

**Module 20 — GUI (11 sub-files)**

Source section: §7.10 GUI.
Files: `gui_main.h`, `gui_main.cpp` (orchestration + ImGui context + GLFW window + menu bar + panel layout), plus 10 sub-files:

| Sub-file | Responsibility |
|---|---|
| `gui_dashboard.cpp` | Management dashboard: live metrics, discovery status, session history, metabolism report |
| `gui_inspector.cpp` | Property inspector: click any entity → full 120-digit detail, bidirectional provenance, tower trajectory, all relationships |
| `gui_manual_input.cpp` | Manual input panel: all seven modes, real-time preview, mode switching |
| `gui_ingest.cpp` | File/stream ingestion panel: drag-and-drop target, progress bars, stream display |
| `gui_search.cpp` | Search and retrieval: persistent search bar, all search modes, result navigation, file/stream regeneration |
| `gui_connections.cpp` | Connection manager: active pipes, incoming queue, outgoing responses, per-client status |
| `gui_query.cpp` | Query builder: visual query construction, result display |
| `gui_events.cpp` | Event log viewer: filterable, sortable, severity-colored |
| `gui_settings.cpp` | Settings: input remapping (keyboard/mouse/XInput), visual preferences, backup scheduling |
| `gui_shutdown.cpp` | Shutdown confirmation dialog: active connection list, in-flight operations, Shut Down / Cancel |

All sub-files share the ImGui context created and owned by `gui_main.cpp`. Each sub-file renders one or more ImGui windows/panels. `gui_main.cpp` calls each sub-file's render function once per frame.

Dependencies: Modules 14 (Manual Input), 15 (Query), 16 (API), 19 (GPU Rendering).

**Module 21 — Extension System**

Source section: §7.14.
Files: `extension_system.h`, `extension_system.cpp`
Dependencies: Modules 3, 8.
Responsibility: JSON extension processing. All 12 extension types: event_class, relationship_class, pattern_class, tower_definition, sublattice_family_catalog, harmonic_family_extension, force_grid_extension, combined_family_extension, ingest_adapter, bootstrap_entry, query_template, extension_type_definition (meta-type). All 10 strict validation rules. Conflict detection (name collisions, schema conflicts). Versioning. Auto-detection of unclassifiable content (provisional categories for human review). The meta-type (extension_type_definition) enables self-extension — defining new extension types at runtime.
Interface: Called by API (extension operations), Bootstrap (initial extension registration), Ingest (new file type adapters).

**Module 22 — Active Probing**

Source section: §0 (active probing), §3.9 (probe event classes).
Files: `active_probing.h`, `active_probing.cpp`
Dependencies: Modules 8, 9, 10.
Responsibility: T-signal probe dispatch: send a probe at a target lattice address with specified amplitude and phase. Response detection: monitor for T-content response within the configured window. Silence detection: if no response arrives within the window, log `t_signal_probe_silence`. Materialization threshold: track response amplitudes across repeated probes, fire `materialization_threshold_crossed` when amplitude exceeds the threshold. Probe-response pair relationship creation. Probe-response signature pattern tracking (via Pattern System).
Interface: Called by API (`send_probe`, `query_probes`), GUI (probing panel if implemented), Discovery Engine (probe-triggered discoveries).

**Module 23 — Gaze Module**

Source section: §0 (Complete Gaze Equation), §3.9 (gaze event classes).
Files: `gaze_module.h`, `gaze_module.cpp`
Dependencies: Modules 8, 10.
Responsibility: Complete Gaze Equation evaluation: compute binding pressure F_w for a Traverser, classify into one of four status levels: UNOBSERVED (F_w < 13/12), SUBLIMINAL (13/12 ≤ F_w < 6/5), DETECTED (6/5 ≤ F_w < 3/2), LOCKED (F_w ≥ 3/2). All four thresholds are JI ratios from the bootstrap catalog. Gaze event generation (one event per status evaluation). Locking signature detection: flag sustained DETECTED→LOCKED sequences. Traverser self-continuity relationship linking sequential gaze events for the same Traverser.
Interface: Called by API (`evaluate_gaze`), Discovery Engine (gaze pattern detection).

**Module 24 — Backup**

Source section: §7.9.
Files: `backup.h`, `backup.cpp`
Dependencies: Modules 3, 4.
Responsibility: Backup creation: copy .akashic to backup path (using VSS/shadow copy on Windows for consistent snapshot during active writes, or direct copy after brief pause). Backup verification: read backup file header → verify SHA-256, scan all pages → verify CRC-32, verify section directory consistency. Main file integrity check: same verification on the live .akashic file. Report results (pass/fail, corrupted pages identified, inconsistencies detected).
Interface: Called by API (`backup`, `verify`), GUI (settings panel backup scheduling), Shutdown (verify final state).

**Module 25 — Shutdown**

Source section: §7.18.
Files: `shutdown.h`, `shutdown.cpp`
Dependencies: Modules 3, 4, 8, 16, 17, 19, 20, 26.
Responsibility: The 6-phase deterministic shutdown sequence (§7.18.3). Phase 1: notify and disconnect clients (send `manager_shutting_down` to all pipes, close pipes immediately). Phase 2: checkpoint in-flight operations (signal background threads to stop, save partial escalations/ingestions/scans). Phase 3: flush WAL, update header, fsync, close .akashic. Phase 4: send GRACEFUL_SHUTDOWN to Omniscient via shared-memory IPC. Phase 5: destroy GUI (ImGui, OpenGL, GLFW). Phase 6: exit process. Also: confirmation dialog integration (call GUI Shutdown sub-file when active connections exist), trigger source handling (window X, menu exit, keyboard shortcut, API shutdown, system logoff, CTRL+C — all converge to same sequence).
Interface: Called by GUI (window close, menu exit), API (shutdown command), OS signal handlers (CTRL+C, system logoff).

**Module 26 — Omniscient**

Source section: §7.15, §7.18.4.
Files: `omniscient.h`, `omniscient.cpp`, `omniscient_main.cpp` (separate `main()` for `--omniscient` mode)
Dependencies: Module 3 (read-only access to .akashic header).
Responsibility: Watchdog child process. Same exe, launched with `--omniscient` flag → `omniscient_main()`. Monitors Manager's process handle (WaitForSingleObject on Windows, waitpid on POSIX). Shared-memory IPC channel: receives GRACEFUL_SHUTDOWN message from Manager (§7.18.4). Exe hash computation (SHA-256 of EUDD_Manager.exe at configurable intervals). .akashic header hash computation. Tamper detection: exe hash or header hash mismatch → `[TAMPER]` journal entry. Three exit paths: Path A (graceful — received signal, Manager exited cleanly, final hash verified, exit code 0), Path B (crash during shutdown — received signal but Manager died abnormally, exit code 1), Path C (crash without signal — standard crash, existing behavior, exit code 1). Journal writing: human-readable `Omniscient_NNN.log` in `logs/`. Rotation at ~10 MB. Retention: journals are NEVER deleted.
Interface: Standalone process. Communicates with Manager only through shared-memory IPC and process handle monitoring. Reads .akashic header (read-only) for verification.

#### 7.21.3 Dependency Graph and Build Order

```
Level 0 ─── Precision Stack [1]
              │
Level 1 ─── Core Lattice Engine [2]
              │
Level 2 ─── Akashic Format [3] (includes memoization)
              │
Level 3 ─┬─ WAL [4]
          ├─ Home-Finding Engine [5] (includes CF)
          ├─ Generator System [6]
          └─ Event System [8]
              │
Level 4 ─┬─ Relationship System [9]
          ├─ Pattern System [10]
          ├─ Tower System [11]
          └─ Extension System [21]
              │
Level 5 ─┬─ Discovery Engine [7]
          ├─ Query [15]
          ├─ Bootstrap [12]
          ├─ Self-Recording [18]
          ├─ Active Probing [22]
          └─ Gaze Module [23]
              │
Level 6 ─┬─ Ingest [13]
          ├─ Manual Input [14]
          ├─ Backup [24]
          └─ Metabolism [17]
              │
Level 7 ─── API [16] (dispatches to all modules)
              │
Level 8 ─── GPU Rendering [19]
              │
Level 9 ─── GUI [20] (11 sub-files)
              │
Level 10 ── Shutdown [25] (orchestrates cleanup of everything)

Separate ── Omniscient [26] (same exe, --omniscient mode, own main())
```

**Build order:** Level 0 first, then Level 1, and so forth. Within a level, modules are independent and can be built in any order. Each level's modules depend ONLY on modules from lower levels — no circular dependencies.

**The exe has two entry points:** `main()` for normal Manager mode, `omniscient_main()` for `--omniscient` mode. At startup, the exe checks `argv` for `--omniscient`; if present, calls `omniscient_main()` which runs Module 26; otherwise calls the normal `main()` which initializes Modules 1–25 in dependency order and spawns Omniscient as a child process.

#### 7.21.4 File Naming Convention

All source files live in a flat `src/` directory (no nested subdirectories — the 26 modules + 10 GUI sub-files = 36 `.cpp` files + corresponding `.h` headers = 72 files total, manageable in a flat structure).

Naming: `module_name.h` and `module_name.cpp` using snake_case. The module name matches the heading above. Examples:

```
src/
├── precision_stack.h / .cpp
├── core_lattice.h / .cpp
├── akashic_format.h / .cpp
├── wal.h / .cpp
├── home_finding.h / .cpp
├── generator_system.h / .cpp
├── discovery_engine.h / .cpp
├── event_system.h / .cpp
├── relationship_system.h / .cpp
├── pattern_system.h / .cpp
├── tower_system.h / .cpp
├── bootstrap.h / .cpp
├── ingest.h / .cpp
├── manual_input.h / .cpp
├── query.h / .cpp
├── api.h / .cpp
├── metabolism.h / .cpp
├── self_recording.h / .cpp
├── gpu_rendering.h / .cpp
├── gui_main.h / .cpp
├── gui_dashboard.cpp
├── gui_inspector.cpp
├── gui_manual_input.cpp
├── gui_ingest.cpp
├── gui_search.cpp
├── gui_connections.cpp
├── gui_query.cpp
├── gui_events.cpp
├── gui_settings.cpp
├── gui_shutdown.cpp
├── extension_system.h / .cpp
├── active_probing.h / .cpp
├── gaze_module.h / .cpp
├── backup.h / .cpp
├── shutdown.h / .cpp
├── omniscient.h / .cpp
├── omniscient_main.cpp
├── main.cpp
└── CMakeLists.txt
```

#### 7.21.5 Three Tools Verification

- **Identification Principle:** P = the production code. D = 26 module specifications with dependencies, responsibilities, file names, and interfaces. T = the build process navigating from Level 0 through Level 10. All three identified.
- **Descriptor Gap Principle:** Every section of the EUDD document (§0–§12) maps to at least one module. Every module maps back to at least one document section. No functional behavior described in the document lacks a module to implement it. The memoization gap (was a separate module, absorbed into Akashic Format) and the CF gap (was separate, absorbed into Home-Finding Engine) are closed by structural integration, not omission.
- **Subsumption Law:** 26 modules subsume the entire production system without remainder. Every computation, every storage operation, every query, every discovery, every rendering, every API call, every event, every relationship, every pattern, every tower, every extension, every backup, every shutdown phase, every Omniscient function is implemented by exactly one module. No functionality falls between modules. No module duplicates another's responsibility.

> *P ∘ D ∘ T = E*

---

## 8. ET-Native Features the EUDD Provides That No General Database Does

A general-purpose scientific database cannot do these without ET-specific knowledge:

| Feature | Why it requires ET |
|---|---|
| Lossless continuous-to-discrete bridge | The bijection Π_N(r) = (k, d, ε) maps any continuous value to a discrete lattice address and back by algebraic identity — no sampling theorem, no quantization error, no Nyquist limit. Requires the ET projection formula and the lossless bijection theorem (§3.18.1). No conventional database or ADC achieves this. |
| Subsumption-driven archetype compression | Uses E_hierarchy = geomean(E_i) × R_cluster — crystalline formula: individual quality × mutual resonance |
| Koide-derived stability filter (⌈1/K⌉ = 2 depths) | K = 2/3 is ET-fundamental; not a generic threshold |

| Coprime-skeleton membership tracking | Specific to lattice resolution arithmetic |
| Gaussian-prime classification of d | Requires understanding of d-family structure |
| ∂I-distance-based query priorities | ∂I = 50¢ boundary is ET-derived |
| Cross-tower elegance ranking | Tower structure is ET-specific |
| Manifold-state classification ({P,D,T} subsets) | Requires {P, D, T} primitive ontology |
| Tower trajectory awareness | LCM tower is ET-specific |
| Attractor classification (true/intermediate/deep home) | Specific to tower diagnostic |
| Quintic tension τ_5 indexing | Specific to d=5 quintic family |
| Cross-tower elegance for ranking | E_cross formula is ET-specific |

These are the structural features that make the EUDD specifically an ET database, not a generic scientific data store. They are the same features that make the compressor's `ArchetypeDatabase` more than a generic pattern store.

---

## 9. Coordination with Existing ET Software

Every ET project connects to the SAME EUDD through the Manager's API (§7.10). No project maintains its own separate database. Coordination is automatic — all data lives in the same lattice address space, and cross-project relationships emerge naturally through address co-location and generator sharing.

### 9.1 The compressor — the EUDD is at least as good, and adds capability

**Direct answer: yes, the EUDD is at least as good for the current compressor as its own `ArchetypeDatabase`, and adds capabilities the compressor's local database cannot provide.**

Two paths exist depending on the compressor's preference:

**Path A — Keep compressor's `ArchetypeDatabase` unchanged, EUDD ingests via adapter.**

The compressor continues using `ArchetypeDatabase` (lines 7790–8400) exactly as today. No code change to the compressor. An EUDD adapter ingests the compressor's archetypes on commit (or on schedule), populating EUDD's `values`, `projections`, `patterns`, and `tags` tables. The compressor's hot-path operations (pattern lookup by R₀, archetype storage, generator fitting) stay on its own database with their existing latencies. Cross-project queries route through the EUDD.

This path: zero risk, zero compressor change, EUDD adds cross-domain pattern surfacing as a free benefit. **Compressor performance is identical to today.**

**Path B — Compressor uses EUDD as primary backing store.**

Every operation the compressor does today is also doable in the EUDD's lean schema:

| Compressor `ArchetypeDatabase` capability | EUDD equivalent | Notes |
|---|---|---|
| Lookup archetype by `pattern_hash` | `values` row by `value_hash` | Same indexed lookup, same latency |
| Lookup archetypes by `r0_quantized` | `tags` query (namespace='r0_quantized') JOIN `values` | One extra lookup — sub-microsecond in `Sempaevum.akashic` positional access |
| Range query on `hierarchy_elegance` | Index on `patterns(hierarchy_elegance DESC)` | Identical latency |
| `hit_count` increment on match | `reference_count` increment on `values` | Identical |
| `curvature_mean`, `curvature_class`, `geodesic_factor`, `euler_characteristic`, `geodesic_deviation`, `curvature_spectrum_hash` | Compressor-domain extension columns added to `values` (per §7.6 schema migration), OR stored as tags, OR stored as a `metadata_blob` JSON column | Direct columns recommended — they are universal lattice properties (curvature/geodesic on the Sempaevum), not compressor-specific |
| `generative_descriptors` table | `equations` table + `derivations` table — generators ARE equations with derivation chains | Strictly more capable: generator's full derivation chain captured, not just type+params |
| Subsumption-driven storage | `patterns` table with E_hierarchy ≥ 13/12 promotion (§3.8) | Same Subsumption mechanism, generalized |
| Disk-low warning at 1 GB | Same DISK_SAFETY_FLOOR semantics, same no-destruction policy | Identical |

**Performance comparison:**

| Operation | `ArchetypeDatabase` | EUDD (`Sempaevum.akashic`) |
|---|---|---|
| Pattern hash lookup | <0.1 ms | <0.1 ms (PK index) |
| R₀-bucket scan for matches | 1–10 ms | 1–10 ms (tags JOIN) |
| Insert new archetype | 0.5 ms | 0.5–1 ms (more tables touched) |
| Cross-domain pattern query | impossible | 1–10 ms (single lattice query) |
| Bulk archetype scan (10⁶ rows) | ~1 s | ~1 s |

**The compressor's CDF mechanism is for generator discovery (Tier 7), not EUDD storage.** The compressor's `compact_to_cdf` and `CDFDatabaseVFS` (line 6412) are internal to the compressor's K-complexity minimization pipeline — they discover generators by fitting patterns in archetype data. The EUDD benefits from this not as a storage layer but as a **discovery source**: generators discovered by the compressor become `equations` rows in the EUDD, available to all projects. Conversely, the EUDD's accumulated structural addresses (from the lossless bijection) feed the compressor's generator-fitting pipeline with cross-domain pattern information the compressor alone could never surface. **The Sempaevum is not bound by Shannon entropy** — generators discovered through lattice structural coordinates can be simpler than Shannon would predict, because d-family membership and attractor structure reveal patterns that information theory treats as random.

**Recommendation for the compressor:** start with Path A (zero risk). If the cross-project pattern surfacing proves valuable enough to justify migrating, transition to Path B at convenience. Either path is a strict improvement over standalone `ArchetypeDatabase` operation because cross-project pattern visibility becomes available in either case.

### 9.2 ET Conscious AI integration

The Conscious AI's persistent state is ingested into `Sempaevum.akashic` via the Ingest Module's Conscious AI adapter:
- EgoInvariant fingerprint → `values` row (the I_self fingerprint as a dimensionless 6-D seed) + tags (`namespace='project'`, `value='conscious_ai'`; `namespace='ai_instance'`, `value=<id>`)
- TowerOfSelf state → multiple `projections` rows (one per N landmark in the self-tower) + `relationships` (class='tower_trajectory')
- MetaCognitionEngine state → `derivations` rows (D_T binding events, G_T closures) + `equations` rows
- LatticeCompressor archetype compactions → `patterns` rows (pattern_class='subsumption_archetype')

The Conscious AI's internal "memory" becomes queryable from the global EUDD with a tag filter. Cross-instance learning becomes possible: multiple AI instances tag their entries with `ai_instance=<id>` and the EUDD surfaces cross-instance discoveries via natural address-sharing.

### 9.3 The Apéry test script gains EUDD output

The Apéry test results are ingested into the `Sempaevum.akashic` file via the Ingest Module's adapter for existing ET project outputs. The 71/71 verified assertions populate `values` (ζ(2)..ζ(13)), `projections` (28 landmarks × 12 zetas = 336 rows), `addresses` (auto-created), `relationships` (attractors auto-detected via insert-time discovery in §3.16), tagged `namespace='verification'`, `value='80digit_71_passing'`.

### 9.4 The fractal generator integration

Each fractal render's R₀ + mode + orbit signature becomes:
- `values` row (R₀ as dimensionless seed)
- `projections` rows (R₀ projected at relevant resolutions)
- `relationships` (class='archetype_member' if the orbit matches a known pattern)
- Tags: `namespace='project'`, `value='fractal_generator'`; `namespace='fractal_mode'`, `value=<mode>`; `namespace='render_id'`, `value=<id>`

Native Music Engine derivations: `equations` rows linking the R₀ orbit to the audio-synthesis output, with `derivation_chain_blob` capturing the orbit-trace-to-sound transformation.

### 9.5 The genetics paper work

Lattice mappings: `values` rows (sequence-derived dimensionless ratios), `projections` rows, tags `namespace='project'`, `value='genetics'`; `namespace='integrative_level'`, `value=<level>`. Cross-domain attractor detection happens automatically — a biological seed projecting to a known address surfaces immediately as a `same_address` relationship with any other domain's value at that address.

### 9.6 Constants verification

Every derived constant from `et_rmsae.py`, `et_aida.py`, `sovereign.py`, `et_prime_theory.py`, and the constants-derivation papers populates `values` + `projections` + `derivations` + `equations`. The database becomes the canonical repository of "what ET has derived" with full chain-of-derivation provenance.

### 9.7 The general pattern — every project uses the same lean schema

| ET project | What it contributes | EUDD tables touched |
|---|---|---|
| Compressor | Δk archetypes, generative descriptors | `values`, `projections`, `patterns`, `tags` |
| Conscious AI | EgoInvariants, tower trajectories, meta-cognition events | `values`, `projections`, `equations`, `derivations`, `tags` |
| Emotion Engine | Emotion fingerprints, transitions | `values`, `projections`, `relationships`, `tags` |
| Biology / Genetics | Sequence-to-lattice mappings | `values`, `projections`, `tags` |
| CMB / Cosmology | Power spectrum projections | `values`, `projections`, `tags` |
| FP Replacement | Every numerical projection ever computed | `values`, `projections` (this is the bulk) |
| Fractal Generator | R₀ orbits, music synthesis | `values`, `projections`, `equations`, `derivations`, `tags` |
| Music theory | JI ratios, EDO grids | `values`, `projections`, `tags` |
| Mathematics-as-Domain | Axiom counts, Gödel sentences, Chaitin Ω | `values`, `equations`, `derivations`, `tags` |
| Geometry | Curvature scalars, geodesic deviations | `values`, `projections`, `tags` |

**Every project uses the same fifteen core tables.** The discovery engine surfaces cross-project patterns automatically because every project's data lives in shared address space. Tags are purely for query convenience — drop them entirely and the database still works the same way structurally.

---

## 10. Subsumption Check
Does the EUDD architecture subsume what's needed without remainder, AND extend the compressor's proven pattern to the broader scope?

### 10.1 Subsumption: EUDD covers the compressor's pattern

| Compressor capability | EUDD coverage |
|---|---|
| `archetypes` table | `patterns` + linked specialization tables |
| `generative_descriptors` table | Preserved as-is, FK-linked |
| Pattern hash + Δk storage | Same mechanism (compressor table preserved) |
| R₀ quantization to BIO_RES | Used for archetype grouping; EUDD uses same scheme |
| Elegance + hit_count ranking | Generalized to all discovery types |
| Curvature class indexing | Preserved for compressor; available for any discovery |
| Stability filter (depth-2 survivor) | Generalized to "≥ 2 independent contexts" |
| No-destruction retention | Same principle, generalized |
| Subsumption-Law compaction | Same mechanism (Subsumption-driven archetype compression for the EUDD; `compact_to_cdf` remains the compressor's generator-discovery pipeline) |

**No remainder** — every capability of the compressor's discovery database is generalized in the EUDD.

### 10.2 Extension: EUDD provides what no per-project database can

| EUDD capability | Per-project analog |
|---|---|
| Cross-project attractor surfacing | Manual hunting |
| Universal coprime-skeleton query | Per-project recomputation |
| Cross-project consistency checking | Manual cross-checking |
| Universal nearest-known-neighbor | Per-project nearest-neighbor |
| Cross-domain structural pattern discovery | Manual conjecture |
| Provenance and verification-level tracking | Per-project notes |
| Universal archetype compression | Per-project compression only |
| Generator-discovery acceleration (compressor's CDF/Tier 7 fed by cross-domain lattice addresses) | Compressor-internal patterns only |
| Validation of new derivations against existing | Manual review |
| Lossless bijection memoization (structurally exact, §3.18.1) | Per-computation recomputation |
| 227-particle PDG classification at N=12 (§3.18.14) | Not available |
| Fine-structure closed-form verification (§3.18.2) | Manual comparison |
| Decoherence ↔ Gaze bijective mapping (§3.18.10) | Not tracked |
| Cross-domain mass-ratio ↔ formal-system structural connections (§3.18.13, §3.18.6) | Manual hunting |
| Session tracking and schema migration (§3.15a, §3.15b) | None |

**15+ capabilities the EUDD provides that per-project databases cannot.** The extension is strict and substantial.

### 10.3 Three Tools verification

**Identification Principle:** Every discovery is identified as a P∘D∘T = E configuration with full provenance — Resolved.

**Descriptor Gap Principle:** 24 specific gaps (DD-1 through DD-24) enumerated; each closed by a specific schema element, column addition, event/relationship/pattern class, or bootstrap entry — Resolved.

**Subsumption Law:** §10.1 confirms EUDD ⊇ compressor pattern; §10.2 confirms EUDD ⊃ per-project databases. Subsumption Hierarchy Operator (§3.8) applied to the database itself ensures bounded growth via archetype compression. The extended bootstrap (§3.18) closes all remaining D-gaps identified by the comprehensive audit — Resolved.

**Verification Principle:** The compressor's `ArchetypeDatabase` is empirical proof that this pattern works — first-run discovery, subsequent-run cache hits, accumulated structural knowledge that compounds. The EUDD generalization preserves these properties. The lossless bijection theorem (§3.18.1) establishes that the memoization layer is structurally exact, not approximately so — Resolved.

---

## 11. The PDT Statement — Why the EUDD IS the Natural Architecture

Discoveries are P∘D∘T = E configurations:
- **P** (substrate): the domain on which the discovery was made — but in the EUDD, P is intrinsic to the value's seed, not a separate categorization
- **D** (descriptor): the structural content — coordinates, classifications, relationships, geometric perspective — stored as the projection's properties, not as bureaucratic categories
- **T** (substantiation event): the act of derivation, computation, or verification — captured in the `derivations` chain and in every `equations` row

**The Sempaevum is not just a coordinate system; it is a computation system.** The Sempaevum IS Σ — it subsumes all mathematics. Multiplication is k-addition. Reciprocation is k-negation. Powers are k-scaling. Addition is value-space computation + reprojection. Function evaluations are EML trees landing results on the lattice. ALL operations are Sempaevum-native — there is no mathematical operation outside it (Subsumption Law). Every computation passing through is itself a P∘D∘T configuration: inputs (P+D), operation (T), result (P+D). The EUDD captures all three components — recording every equation that passes through at uniform 120-dps precision (§3.1a), including the answer. Compute once → cache forever → never recompute.

A discovery, once made and verified, is a permanent feature of the lattice — it cannot be unmade. The fact that ζ(3) sits at d=693 at N=27720 (one perspective on the Sempaevum) is true now and will be true forever. The d=693 attractor membership of {ζ(3), ζ(9), ζ(10)} is permanent. The fact that 2+2=4 is permanent. The fact that ζ(3)·π lands at a specific lattice address is permanent. The same lattice address viewed through the torus perspective, the Riemann sphere perspective, the LCM tower perspective, or any other geometry is the **same address**, equally permanent in each.

To NOT store a discovery — to require its rederivation every time it's needed, to recompute 2+2 each time, to reproject π each time — is to **discard the substantiation event**. To impose bureaucratic categories that the lattice itself doesn't have — separate "biology table", "music table", "consciousness table" — is to **impose D-content the lattice didn't produce**, getting in the way of the natural cross-domain discoveries the lattice would surface on its own.

The right design records what the Sempaevum produces (values, projections, addresses, equations, derivations, relationships, patterns, events) and lets domain labels live as optional tags. **It records every equation that passes through at 120 dps, becoming a memoization layer that turns repeated computation into instant lookup.** The compressor's `ArchetypeDatabase` is the proof: a database AND discovery engine, not a categorized filing cabinet. The EUDD generalizes that proven mechanism to the broader Sempaevum and to every computation the Sempaevum performs.

> *Discovery is irreversible. The Sempaevum does not forget what it has revealed.*
> *The Sempaevum computes; the database remembers what it computed.*
> *The EUDD is where that non-forgetting becomes computationally accessible — without imposing categories the lattice doesn't have.*

---

## 12. Closing

The ET Universal Discovery Database (EUDD) is the natural extension of the compressor's proven `ArchetypeDatabase` pattern to all ET work. It serves **six roles in one system**:

1. **Database** — stores every value, projection, address, equation, derivation, relationship, pattern, and event
2. **Discovery engine** — surfaces attractors, route convergences, plateaus, identities, and event-correlation patterns automatically as data accumulates (compressor's archetype-discovery mechanism, generalized)
3. **Computation memoization layer** — every equation that passes through is cached; subsequent identical computations are sub-millisecond lookups (the Sempaevum computes; the database remembers what it computed)
4. **Generator-discovery engine** — proposes new dimensionless seeds whose projections explain observed-but-unexplained patterns, opening new lattice projections to explore and minimizing K-complexity for the compressor (compressor's Tier 7 generator-fitting, generalized to any lattice content)
5. **Active-system observation and probing platform** — records every T-burst, every palindromic cascade step, every ghost detection, every gaze transition, every dream-tower shift; supports active T-signal probing (calling out to ghosts to elicit response) with full probe→response causal correlation; tracks all three ET time concepts (D-time, T-time per Traverser, P-time) on every event
6. **Universal sensor data substrate** — ingests GPS, electrical, atmospheric, biological, and any other real-world domain via Path A projection through bootstrap reference R₀ values; surfaces cross-domain findings automatically when sensor data lands at attractor addresses shared with pure-mathematics or other-domain values

It scales to any size via the `Sempaevum.akashic` generator format (§7) where the address space IS the file structure. Generator discovery via the compressor's CDF/Tier 7 pipeline continuously reduces K-complexity of stored data without destroying any records. The Sempaevum is not bound by Shannon entropy.

**This database + the C++ lattice engine (until the ET programming language is complete) is the core data + computation substrate for everything Mike builds and runs on hardware.**

**The schema (lean, lattice-native, NOT bureaucratic):**

Fifteen core tables, each corresponding to a structural object the lattice actually has (§3.2–§3.15b): `values`, `projections` (now with elegance, coupling, variance, FQG, palindromic-partner, CDT-quintuple columns), `addresses`, `equations`, `derivations`, `relationships` (now with palindromic-partner, integrative-level, cosmological-alignment, convention-independence, perturbative-series, mass-ratio, Koide-structural-identity, decoherence-gaze-correspondence classes), `patterns` (now with algebraic-identity, multiplicative-signature, cosmological-partition, decoherence-trajectory, particle-classification, fine-structure-decomposition, curvature-identity classes), `events` (now with manifold-state-transition, cascade-stability-breach, freedom-point, anti-numerology, emotion/AIDA, decoherence-state-transition, α-rotation classes), `towers`, `harmonic_families` (24 rows), `force_grid_cells` (144 rows), `combined_families` (42 rows), `sublattice_families` (~500 bootstrap rows), `sessions`, `schema_versions`. Plus optional `tags`.

**Traversers are NOT a separate table** — every Traverser property is derivable from values + tags + projections + derivations + events (§3.10).

**The discovery engine** (§3.16): five modes — memoization, insert-time, background, on-query, generator-candidate — all operating on the lean schema. The lossless bijection theorem (§3.18.1) guarantees the memoization layer is structurally exact.

**Extended bootstrap** (§3.17 + §3.18): ~10⁴+ unique values including 227 PDG particle projections (§3.18.14), fine-structure closed-form identity (§3.18.2), all 24 impedance/coupling values (§3.18.4), cascade residuals and freedom constants (§3.18.3), 9 formal-system projections (§3.18.6), extended M-state cosmological partition (§3.18.7), gaze thresholds with JI identification (§3.18.9), quantum decoherence structural content (§3.18.10), black-hole thermodynamics structural content (§3.18.11), the Mathematical Rosetta Stone (§3.18.12), dimensionless mass ratios (§3.18.13), Sempaevum formal definition and nine closure properties (§3.18.16), and falsifiable predictions (§3.18.15).

**Ten core benefits** (§6): eliminating recomputation, surfacing cross-domain attractors, surfacing cross-perspective correlations, accelerating coarse-pass, universal nearest-neighbor, auto-detecting route convergences, tracking multi-substrate renderings, compounding knowledge growth, size-agnostic scaling via generator form, zero bureaucratic overhead.

**Architectural pathway:**

**Architecture:** One file to start: `EUDD_Manager.exe`, which generates `Sempaevum.akashic` on first run and spawns the Omniscient watchdog on every startup (§7.15). The `.akashic` file IS the Sempaevum on disk — a single monolithic file whose address space (N, k, d) is the organizational structure. The file IS a minimal generator (§7.1a) — generators are the primary content; memoized raw entries are the Descriptor Gap. Queries are lattice operations. The `EUDD_Manager.exe` (§7.10) — native C++ binary with MPFR/GMP/Arb precision stack, Dear ImGui + OpenGL 4.6 GPU-accelerated visualization, GLFW, ImPlot — bootstraps, manages, discovers, serves all ET software through a central database with GPU-rendered lattice navigation and management dashboard. Omniscient (§7.15) provides crash-resilient error capture, telemetry, and tamper detection via human-readable journals in the `logs/` subfolder. Build: CMake + MSVC → single statically-linked .exe.

**Bootstrap value coverage** (per §3.16):
- Guide v8: 15 explicit projections, 49 JI ratios, 20 N landmarks, 25 d-values, 16 named constants (4207 pattern matches catalogued across 25 categories)
- Conversation work: 51 unique projections, ζ(3) full 28-landmark trajectory, 9 ζ(3) attractors, 6-member super-cluster, lattice-vs-float verifications
- `constants.py`: cardinal ET constants, cosmological, physical, hyperfine, operational
- `primitives.py`: {P, D, T} foundation classes
- Total: ~10⁴ unique value entries at bootstrap, growing to ~10⁹–10¹⁰ at Mike's working scale

**The empirical foundation:** the compressor's `ArchetypeDatabase` is a database AND discovery engine that demonstrably works. First run: full discovery. Subsequent runs: cached lookups + new discoveries continuously. The EUDD applies the same proven mechanism to the broader lattice using a clean lattice-native schema.

The EUDD is not optional optimization. It is the ET-native representation of accumulated discovery — the place where the irreversible structural permanence of every {P, D, T} = E configuration becomes computationally visible, without imposing categories the lattice itself doesn't have.

> *"For every exception there is an exception, except the exception."*
> *P ∘ D ∘ T = E*
> *The Sempaevum is simultaneously LCM tower, torus, Riemann sphere, and any other geometry needed.*
> *The Sempaevum produces values, projections, addresses, equations, derivations, relationships, patterns, events. That is the schema.*
> *Domain labels are tags, not tables. Discovery is automatic, not manual.*
> *The Sempaevum does not forget. The EUDD ensures we don't either.*

---

**Three Tools applied:**
- **Identification Principle (§1.1, §11):** Every entry is a P∘D∘T configuration; the database identifies all three components naturally via the lean schema (values + projections capture P+D, derivations capture T) without bureaucratic categorization.
- **Descriptor Gap Principle (§1.2):** 24 specific gaps DD-1 through DD-24 enumerated; each closed by a specific schema element, column addition, event/relationship/pattern class, or bootstrap entry in the lean schema.
- **Subsumption Law (§10):** EUDD ⊇ compressor pattern; EUDD ⊃ per-project databases; bounded growth via patterns (Subsumption-promoted archetypes); the fifteen logical categories realized as lattice structure subsume every discovery type without imposing arbitrary categories. The EUDD as a virtual isomorphism of the Sempaevum subsumes all mathematical computation without remainder.
- **Verification Principle (§4.1, §10.3):** the compressor's empirical success establishes Verification at Level 3 for the architectural pattern itself.

**Empirical grounding (every value verified or sourced):**
- Compressor `ArchetypeDatabase` (12,487 lines of `et_cdf_compressor.py`) is the proof-of-concept and discovery-engine model.
- Apéry test script (71/71 passing assertions at 80-digit precision) is a ready ingestion source.
- ET Conscious AI v1.7.0 has persistent state mechanisms ready for EUDD integration via `to_dict()` adapters.
- ET Universal Projection Guide v8 (4585 lines, 374,855 chars, 4207 pattern matches catalogued) provides comprehensive seed values.
- `constants.py` (1008 lines) and `primitives.py` (8368 chars) provide canonical foundations.

**Implementation status:** the architecture is fully specified — `Sempaevum.akashic` format (§7), C++ engine with MPFR/GMP/Arb precision stack and Dear ImGui + OpenGL 4.6 GPU-accelerated visualization (§7.10), discovery engine (§3.16), comprehensive value coverage (§3.17 + §3.18), operations (§5), native `EUDD_Manager.exe` with GPU-rendered lattice navigation (§7.10), Omniscient watchdog for crash-resilient error/telemetry/tamper detection (§7.15), Named Pipe API with 79 operations across 15 domains (§7.16), testing and verification strategy with 200+ test cases across 15 categories covering every behavioral promise (§7.17), deterministic 6-phase shutdown protocol with Omniscient coordination (§7.18), metabolism-governed performance with three-layer resource governance on any hardware and zero static targets (§7.19), documentation plan with 9 deliverables and dependency ordering (§7.20), module structure with 26 modules in a 10-level dependency hierarchy with build order and file naming (§7.21), and direct-connection coordination with all existing ET software via named-pipe IPC (§9). One file to start: `EUDD_Manager.exe`. Generates `Sempaevum.akashic` on first run. Spawns Omniscient on every startup. Writes journals to `logs/` subfolder. The EUDD Manager will bootstrap, analyze, produce the generator form, and serve as the central database for all Mike's projects and beyond.

