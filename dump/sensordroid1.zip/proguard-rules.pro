# ET Lossless Sensor Capture — ProGuard Rules
# Keep all native methods (JNI signatures must be preserved)
-keepclasseswithmembernames class * {
    native <methods>;
}

# Keep the EtSensor facade (JNI class)
-keep class com.aevumdefluo.etsensor.EtSensor { *; }

# Keep all data classes used across JNI boundary
-keep class com.aevumdefluo.etsensor.Projection { *; }
-keep class com.aevumdefluo.etsensor.SensorType { *; }
-keep class com.aevumdefluo.etsensor.ManifoldState { *; }
-keep class com.aevumdefluo.etsensor.SensorInfo { *; }
-keep class com.aevumdefluo.etsensor.SensorSample { *; }

# Keep Compose runtime
-keep class androidx.compose.** { *; }
