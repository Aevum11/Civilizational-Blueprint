turner_1999_bulge_loop.htm are parameters for bulge loops.

turner_1999_coax.htm are parameters for coaxial stacking.

turner_1999_dangle_dg.txt are parameters for dangling ends on pairs.

turner_1999_gu_pair.htm are parameters for stacks with GU pairs.

turner_1999_hairpin_mismatch.htm are parameters for first mismtaches in hairpin loops.

turner_1999_hairpin_initiation.htm are parameters for hairpin initiation.

turner_1999_int11_dg.txt are parameters for 1×1 internal loops.

turner_1999_int21_dg.txt are parameters for 2×1 internal loops.

turner_1999_int22_dg.txt are parameters for 2×2 internal loops.

turner_1999_loop_dg.txt are parameters for loop initiations.

turner_1999_multi_branch.htm are parameters for multi branch loops.

turner_1999_tetraloop_dg.txt are parameters for hairpin loops of 4 unpaired nucleotides that have stabilities not well modeled by the parameters.
turner_1999_terminal_mismatch_dg.txt are parameters for terminal mismatches.

turner_1999_watson_crick_stack_dg.txt are parameters for helical stacking.


THESE PARAMETERS ARE NOT IN USE AND ARE NOT PART OF RNAstructure/data_tables.







