/* Print exact sizeof / offsetof for every libet_med struct so the JS
 * wrapper's hard-coded offsets can be verified against reality. */
#include "libet_med.h"
#include <stddef.h>
#include <stdio.h>

int main(void) {
    printf("=== et_projection_t ===\n");
    printf("  sizeof              = %zu\n", sizeof(et_projection_t));
    printf("  offsetof r          = %zu\n", offsetof(et_projection_t, r));
    printf("  offsetof log2_r     = %zu\n", offsetof(et_projection_t, log2_r));
    printf("  offsetof exact_pos  = %zu\n", offsetof(et_projection_t, exact_pos));
    printf("  offsetof k          = %zu\n", offsetof(et_projection_t, k));
    printf("  offsetof g          = %zu\n", offsetof(et_projection_t, g));
    printf("  offsetof d          = %zu\n", offsetof(et_projection_t, d));
    printf("  offsetof eps_cents  = %zu\n", offsetof(et_projection_t, eps_cents));
    printf("  offsetof N          = %zu\n", offsetof(et_projection_t, N));

    printf("\n=== et_patient_baseline_t ===\n");
    printf("  sizeof              = %zu\n", sizeof(et_patient_baseline_t));
    printf("  hr_rest_bpm         = %zu\n", offsetof(et_patient_baseline_t, hr_rest_bpm));
    printf("  rr_rest_per_min     = %zu\n", offsetof(et_patient_baseline_t, rr_rest_per_min));
    printf("  temperature_c       = %zu\n", offsetof(et_patient_baseline_t, temperature_c));
    printf("  sbp_rest_mmhg       = %zu\n", offsetof(et_patient_baseline_t, sbp_rest_mmhg));
    printf("  dbp_rest_mmhg       = %zu\n", offsetof(et_patient_baseline_t, dbp_rest_mmhg));
    printf("  spo2_pct            = %zu\n", offsetof(et_patient_baseline_t, spo2_pct));
    printf("  gait_cycle_s        = %zu\n", offsetof(et_patient_baseline_t, gait_cycle_s));
    printf("  menstrual_cycle_d   = %zu\n", offsetof(et_patient_baseline_t, menstrual_cycle_d));
    printf("  age_years           = %zu\n", offsetof(et_patient_baseline_t, age_years));
    printf("  sex                 = %zu\n", offsetof(et_patient_baseline_t, sex));

    printf("\n=== et_measurement_t ===\n");
    printf("  sizeof              = %zu\n", sizeof(et_measurement_t));
    printf("  name                = %zu\n", offsetof(et_measurement_t, name));
    printf("  current_value       = %zu\n", offsetof(et_measurement_t, current_value));
    printf("  baseline_value      = %zu\n", offsetof(et_measurement_t, baseline_value));
    printf("  units               = %zu\n", offsetof(et_measurement_t, units));
    printf("  tower               = %zu\n", offsetof(et_measurement_t, tower));
    printf("  resolution_override = %zu\n", offsetof(et_measurement_t, resolution_override));
    printf("  timestamp_s         = %zu\n", offsetof(et_measurement_t, timestamp_s));

    printf("\n=== et_finding_t ===\n");
    printf("  sizeof              = %zu\n", sizeof(et_finding_t));
    printf("  name                = %zu\n", offsetof(et_finding_t, name));
    printf("  description         = %zu\n", offsetof(et_finding_t, description));
    printf("  state               = %zu\n", offsetof(et_finding_t, state));
    printf("  incoherence_level   = %zu\n", offsetof(et_finding_t, incoherence_level));
    printf("  tower               = %zu\n", offsetof(et_finding_t, tower));
    printf("  lattice_resolution  = %zu\n", offsetof(et_finding_t, lattice_resolution));
    printf("  projection          = %zu\n", offsetof(et_finding_t, projection));
    printf("  severity_score_raw  = %zu\n", offsetof(et_finding_t, severity_score_raw));
    printf("  severity_score_pct  = %zu\n", offsetof(et_finding_t, severity_score_pct));
    printf("  urgency_rank        = %zu\n", offsetof(et_finding_t, urgency_rank));
    printf("  icd11_code          = %zu\n", offsetof(et_finding_t, icd11_code));
    printf("  icf_code            = %zu\n", offsetof(et_finding_t, icf_code));
    printf("  snomed_code         = %zu\n", offsetof(et_finding_t, snomed_code));
    printf("  laterality          = %zu\n", offsetof(et_finding_t, laterality));
    printf("  severity_text       = %zu\n", offsetof(et_finding_t, severity_text));
    printf("  specific_anatomy    = %zu\n", offsetof(et_finding_t, specific_anatomy));
    printf("  histopathology      = %zu\n", offsetof(et_finding_t, histopathology));
    printf("  temporal_pattern    = %zu\n", offsetof(et_finding_t, temporal_pattern));

    printf("\n=== et_elegance_t ===\n");
    printf("  sizeof              = %zu\n", sizeof(et_elegance_t));

    printf("\n=== et_multifold_signature_t ===\n");
    printf("  sizeof              = %zu\n", sizeof(et_multifold_signature_t));
    printf("  R0_seconds          = %zu\n", offsetof(et_multifold_signature_t, R0_seconds));
    printf("  R0_present          = %zu\n", offsetof(et_multifold_signature_t, R0_present));
    printf("  pairwise            = %zu\n", offsetof(et_multifold_signature_t, pairwise));
    printf("  multifold_scalar    = %zu\n", offsetof(et_multifold_signature_t, multifold_scalar));
    printf("  multifold_log_scalar= %zu\n", offsetof(et_multifold_signature_t, multifold_log_scalar));
    printf("  multifold_normalized= %zu\n", offsetof(et_multifold_signature_t, multifold_normalized));
    printf("  pair_count_valid    = %zu\n", offsetof(et_multifold_signature_t, pair_count_valid));

    return 0;
}
