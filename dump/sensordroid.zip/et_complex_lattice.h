/*
 * ET LOSSLESS SENSOR CAPTURE — COMPLEX LATTICE (Identity D)
 * ==========================================================
 * Two-axis projection on L_N^C ⊂ ℤ[i].
 *
 * Real axis: k_r ∈ ℤ (unbounded, flat — D's operational manifold)
 * Imaginary axis: k_θ ∈ {0,...,N-1} mod N (compact, curved — T's manifold)
 *
 * The mod N wrapping IS the lattice expression of U(1) compactness
 * (Proposition 2.30): T's positively curved operational manifold
 * wraps around at N, while D's flat manifold extends to ±∞.
 *
 * Key structural asymmetry:
 *   Λ_r = 1200/ln2 ≈ 1731    (non-uniform, 1/r-weighted)
 *   Λ_θ = 600/π   ≈ 191      (uniform angular measure)
 *   Ratio ≈ 9.08 — the D/T sensitivity ratio
 *
 * Combined family: d_c = lcm(d_r, d_θ) — the FQG cell classification.
 * 144 cells at N=12 (12 × 12 grid). 42 unique d_c values (D₄₂ closure).
 *
 * Application: multi-axis sensors (accelerometer 3-axis → magnitude + 2 angles),
 * camera (intensity + hue/saturation), any sensor with both amplitude and phase.
 *
 * From complex_lattice_arithmetic_identity.py, Theorems D.1–D.5.
 *
 * Author: Michael James Muller — Aevum Defluo (Exception Theory)
 * License: CC-BY-4.0
 */

#ifndef ET_COMPLEX_LATTICE_H
#define ET_COMPLEX_LATTICE_H

#include "et_bijection.h"

/* ═══════════════════════════════════════════════════════════════════
 * COMPLEX PROJECTION RESULT
 * Full (k_r, d_r, ε_r, k_θ, d_θ, ε_θ, d_c) 7-tuple
 * ═══════════════════════════════════════════════════════════════════ */
typedef struct {
    /* Real axis (magnitude) */
    long    k_r;        /* Real-axis lattice coordinate */
    int     d_r;        /* Real-axis sublattice family */
    mpfr_t  eps_r;      /* Real-axis ε in cents */

    /* Imaginary axis (phase/angle) */
    int     k_theta;    /* Phase-axis coordinate (mod N) */
    int     d_theta;    /* Phase-axis sublattice family */
    mpfr_t  eps_theta;  /* Phase-axis ε in cents */

    /* Combined */
    int     d_c;        /* Combined family: lcm(d_r, d_theta) */
    int     fqg_quadrant; /* FQG quadrant: 0=SR, 1=CR, 2=SI, 3=CI */
} et_complex_projection_t;

et_error_t et_complex_projection_init(et_complex_projection_t *cp, mpfr_prec_t prec);
void et_complex_projection_clear(et_complex_projection_t *cp);

/* ═══════════════════════════════════════════════════════════════════
 * PHASE PROJECTION: θ → (k_θ, d_θ, ε_θ)
 *
 * θ in radians ∈ [0, 2π). k_θ = round(N·θ/(2π)) mod N.
 * d_θ = N/gcd(k_θ, N). ε_θ = (N·θ/(2π) − k_θ) · 1200/N.
 *
 * The mod N wrapping: U(1) compactness on the phase axis.
 * ═══════════════════════════════════════════════════════════════════ */
et_error_t et_project_phase(int N, const char *theta_str,
                             int *k_theta_out, int *d_theta_out,
                             mpfr_t eps_theta_out, mpfr_prec_t prec);

/* ═══════════════════════════════════════════════════════════════════
 * FULL COMPLEX PROJECTION: (r, θ) → 7-tuple
 * ═══════════════════════════════════════════════════════════════════ */
et_error_t et_project_complex(const et_projector_t *proj,
                               const char *r_str, const char *theta_str,
                               et_complex_projection_t *result);

/* ═══════════════════════════════════════════════════════════════════
 * 3D VECTOR → COMPLEX LATTICE
 *
 * For accelerometer/gyroscope/magnetometer (x, y, z) vectors:
 *   r = √(x² + y² + z²)     — magnitude on real axis
 *   θ = atan2(y, x)          — azimuthal angle on imaginary axis
 *   φ = acos(z/r)            — polar angle (second phase axis)
 *
 * Projects magnitude + two angles = 3 independent (k, d, ε) triples.
 * ═══════════════════════════════════════════════════════════════════ */
et_error_t et_project_3d_vector(const et_projector_t *proj,
                                 const char *x_str, const char *y_str,
                                 const char *z_str, const char *R0_str,
                                 et_complex_projection_t *mag_azimuth,
                                 int *k_phi, int *d_phi, mpfr_t eps_phi,
                                 mpfr_prec_t prec);

/* ═══════════════════════════════════════════════════════════════════
 * COMPLEX ARITHMETIC (Theorems D.1–D.5)
 * ═══════════════════════════════════════════════════════════════════ */

/*
 * D.1: Complex Phase Addition — z₁ · z₂ phase component.
 *   k_θ,sum = (k_θ₁ + k_θ₂) mod N    (U(1) compactness)
 *   κ_θ rounding correction applies independently of real axis.
 */
et_error_t et_complex_phase_add(int N, int k_theta1, const mpfr_t eps_theta1,
                                 int k_theta2, const mpfr_t eps_theta2,
                                 int *k_theta_out, int *d_theta_out,
                                 mpfr_t eps_theta_out, int *kappa_theta,
                                 mpfr_prec_t prec);

/*
 * D.3: Complex Reciprocation — both axes negated.
 *   k_r,inv = −k_r, ε_r,inv = −ε_r
 *   k_θ,inv = (N − k_θ) mod N, ε_θ,inv = −ε_θ
 *   d preserved on both axes (Theorem D.3).
 */
et_error_t et_complex_reciprocal(int N,
                                  long k_r, const mpfr_t eps_r,
                                  int k_theta, const mpfr_t eps_theta,
                                  long *k_r_out, mpfr_t eps_r_out,
                                  int *k_theta_out, mpfr_t eps_theta_out,
                                  mpfr_prec_t prec);

/* ═══════════════════════════════════════════════════════════════════
 * FQG QUADRANT CLASSIFICATION
 *
 * SR (Simple-Real): d_r ∈ {1,2,3,4,6,12}, d_θ ∈ {1,2,3,4,6,12}
 * CR (Complex-Real): d_r extended, d_θ simple
 * SI (Simple-Imaginary): d_r simple, d_θ extended
 * CI (Complex-Imaginary): both extended
 *
 * At N=12: all cells are SR (no extended families).
 * At N=60: d=5,10 introduce CR and SI cells.
 * ═══════════════════════════════════════════════════════════════════ */
int et_fqg_quadrant(int d_r, int d_theta, int N);

/* Combined family: d_c = lcm(d_r, d_θ) */
int et_combined_family(int d_r, int d_theta);

#endif /* ET_COMPLEX_LATTICE_H */
