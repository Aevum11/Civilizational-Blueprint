#!/usr/bin/env bash
# ============================================================================
# build_wasm.sh — build libet_med.{js,wasm} via Emscripten
# ----------------------------------------------------------------------------
# Usage:
#     ./build_wasm.sh          (release build into ./build_wasm/)
#     ./build_wasm.sh --debug  (debug build with source maps)
#
# Prerequisites:
#     1. git clone https://github.com/emscripten-core/emsdk.git
#     2. cd emsdk && ./emsdk install latest && ./emsdk activate latest
#     3. source emsdk_env.sh    (this sets EMSDK, PATH, emcc, emcmake)
#
# Output:
#     build_wasm/et_med.js     — Emscripten glue (load with <script>)
#     build_wasm/et_med.wasm   — compiled library bytecode
# ============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LIBET_MED="$SCRIPT_DIR/../../libet_med"
BUILD_DIR="$SCRIPT_DIR/build_wasm"

BUILD_TYPE="Release"
if [[ "${1:-}" == "--debug" ]]; then
    BUILD_TYPE="Debug"
fi

if ! command -v emcmake >/dev/null 2>&1; then
    echo "error: emcmake not found on PATH. Source emsdk_env.sh first:" >&2
    echo "   cd /path/to/emsdk && source ./emsdk_env.sh" >&2
    exit 1
fi

echo "[build_wasm] configuring ($BUILD_TYPE)..."
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR"
cd "$BUILD_DIR"

emcmake cmake "$LIBET_MED" \
    -DCMAKE_BUILD_TYPE="$BUILD_TYPE" \
    -DLIBET_MED_BUILD_TESTS=OFF \
    -DLIBET_MED_BUILD_SHARED=OFF \
    -DLIBET_MED_BUILD_STATIC=OFF

echo "[build_wasm] building..."
emmake make -j"$(nproc 2>/dev/null || echo 4)"

echo "[build_wasm] done. Artifacts:"
ls -la et_med.js et_med.wasm 2>/dev/null || ls -la
