/*
 * ET LOSSLESS SENSOR CAPTURE — COMPLEX LATTICE IMPLEMENTATION
 * ============================================================
 * Identity D (Theorems D.1–D.5): two-axis lattice arithmetic
 * on the complex multiplicative manifold (ℝ⁺,×) × (U(1),×).
 *
 * Author: Michael James Muller — Aevum Defluo (Exception Theory)
 * License: CC-BY-4.0
 */

#include "et_complex_lattice.h"
#include <stdlib.h>
#include <string.h>

static long cl_gcd(long a, long b) {
    if (a < 0) a = -a;
    if (b < 0) b = -b;
    while (b != 0) { long t = b; b = a % b; a = t; }
    return a;
}

static int cl_lcm(int a, int b) {
    if (a == 0 || b == 0) return 0;
    long g = cl_gcd((long)a, (long)b);
    return (int)(((long)a / g) * (long)b);
}

/* Check if d is a "simple" family (divides 12) */
static int is_simple_family(int d) {
    return (12 % d == 0);
}

et_error_t et_complex_projection_init(et_complex_projection_t *cp, mpfr_prec_t prec) {
    if (!cp) return ET_ERR_NULL_INPUT;
    memset(cp, 0, sizeof(*cp));
    mpfr_init2(cp->eps_r, prec);
    mpfr_init2(cp->eps_theta, prec);
    return ET_OK;
}

void et_complex_projection_clear(et_complex_projection_t *cp) {
    if (!cp) return;
    mpfr_clear(cp->eps_r);
    mpfr_clear(cp->eps_theta);
}

/* ═══════════════════════════════════════════════════════════════════
 * PHASE PROJECTION: θ → (k_θ, d_θ, ε_θ)
 *
 * θ in radians. Normalize to [0, 2π).
 * x_θ = N · θ / (2π)
 * k_θ = round(x_θ) mod N    ← U(1) compactness
 * d_θ = N / gcd(k_θ, N)
 * ε_θ = (x_θ − round(x_θ)) · 1200/N
 * ═══════════════════════════════════════════════════════════════════ */
et_error_t et_project_phase(int N, const char *theta_str,
                             int *k_theta_out, int *d_theta_out,
                             mpfr_t eps_theta_out, mpfr_prec_t prec) {
    if (!theta_str || !k_theta_out || !d_theta_out) return ET_ERR_NULL_INPUT;

    mpfr_t theta, two_pi, x_theta, k_mpfr, cents, N_mpfr;
    mpfr_init2(theta, prec);
    mpfr_init2(two_pi, prec);
    mpfr_init2(x_theta, prec);
    mpfr_init2(k_mpfr, prec);
    mpfr_init2(cents, prec);
    mpfr_init2(N_mpfr, prec);

    mpfr_set_str(theta, theta_str, 10, MPFR_RNDN);
    mpfr_set_si(cents, ET_CENTS_PER_OCTAVE, MPFR_RNDN);
    mpfr_set_si(N_mpfr, N, MPFR_RNDN);

    /* 2π */
    mpfr_const_pi(two_pi, MPFR_RNDN);
    mpfr_mul_ui(two_pi, two_pi, 2, MPFR_RNDN);

    /* Normalize θ to [0, 2π) */
    mpfr_fmod(theta, theta, two_pi, MPFR_RNDN);
    if (mpfr_sgn(theta) < 0) mpfr_add(theta, theta, two_pi, MPFR_RNDN);

    /* x_θ = N · θ / (2π) */
    mpfr_mul(x_theta, N_mpfr, theta, MPFR_RNDN);
    mpfr_div(x_theta, x_theta, two_pi, MPFR_RNDN);

    /* k_θ = round(x_θ) mod N — U(1) compactness */
    mpfr_round(k_mpfr, x_theta);
    int k_raw = (int)mpfr_get_si(k_mpfr, MPFR_RNDN);
    int k_theta = ((k_raw % N) + N) % N; /* Ensure [0, N-1] */

    /* d_θ = N / gcd(k_θ, N) */
    long g = (k_theta == 0) ? (long)N : cl_gcd((long)k_theta, (long)N);
    int d_theta = (int)(N / g);

    /* ε_θ = (x_θ − round(x_θ)) · 1200/N
     * Note: use the UN-modded round for ε accuracy */
    mpfr_t delta_theta;
    mpfr_init2(delta_theta, prec);
    mpfr_sub(delta_theta, x_theta, k_mpfr, MPFR_RNDN);
    mpfr_mul(eps_theta_out, delta_theta, cents, MPFR_RNDN);
    mpfr_div(eps_theta_out, eps_theta_out, N_mpfr, MPFR_RNDN);

    *k_theta_out = k_theta;
    *d_theta_out = d_theta;

    mpfr_clears(theta, two_pi, x_theta, k_mpfr, cents, N_mpfr, delta_theta, (mpfr_ptr)0);
    return ET_OK;
}

/* ═══════════════════════════════════════════════════════════════════
 * FULL COMPLEX PROJECTION: (r, θ) → 7-tuple
 * ═══════════════════════════════════════════════════════════════════ */
et_error_t et_project_complex(const et_projector_t *proj,
                               const char *r_str, const char *theta_str,
                               et_complex_projection_t *result) {
    if (!proj || !r_str || !theta_str || !result) return ET_ERR_NULL_INPUT;

    /* Real axis: standard projection */
    et_projection_t real_proj;
    et_projection_init(&real_proj, proj->prec);
    et_error_t err = et_project(proj, r_str, &real_proj);
    if (err != ET_OK) { et_projection_clear(&real_proj); return err; }

    result->k_r = real_proj.k;
    result->d_r = real_proj.d;
    mpfr_set(result->eps_r, real_proj.eps, MPFR_RNDN);
    et_projection_clear(&real_proj);

    /* Imaginary axis: phase projection */
    err = et_project_phase(proj->N, theta_str,
                            &result->k_theta, &result->d_theta,
                            result->eps_theta, proj->prec);
    if (err != ET_OK) return err;

    /* Combined family: d_c = lcm(d_r, d_θ) */
    result->d_c = cl_lcm(result->d_r, result->d_theta);

    /* FQG quadrant */
    result->fqg_quadrant = et_fqg_quadrant(result->d_r, result->d_theta, proj->N);

    return ET_OK;
}

/* ═══════════════════════════════════════════════════════════════════
 * 3D VECTOR → COMPLEX LATTICE
 *
 * (x, y, z) → (r, θ_azimuth, φ_polar):
 *   r = √(x² + y² + z²) / R₀
 *   θ = atan2(y, x)  ∈ [−π, π) → normalize to [0, 2π)
 *   φ = acos(z/r)    ∈ [0, π]
 * ═══════════════════════════════════════════════════════════════════ */
et_error_t et_project_3d_vector(const et_projector_t *proj,
                                 const char *x_str, const char *y_str,
                                 const char *z_str, const char *R0_str,
                                 et_complex_projection_t *mag_azimuth,
                                 int *k_phi, int *d_phi, mpfr_t eps_phi,
                                 mpfr_prec_t prec) {
    if (!proj || !x_str || !y_str || !z_str || !R0_str) return ET_ERR_NULL_INPUT;

    mpfr_t x, y, z, R0, r, r_sq, theta, phi, r_ratio;
    mpfr_init2(x, prec); mpfr_init2(y, prec); mpfr_init2(z, prec);
    mpfr_init2(R0, prec); mpfr_init2(r, prec); mpfr_init2(r_sq, prec);
    mpfr_init2(theta, prec); mpfr_init2(phi, prec); mpfr_init2(r_ratio, prec);

    mpfr_set_str(x, x_str, 10, MPFR_RNDN);
    mpfr_set_str(y, y_str, 10, MPFR_RNDN);
    mpfr_set_str(z, z_str, 10, MPFR_RNDN);
    mpfr_set_str(R0, R0_str, 10, MPFR_RNDN);

    /* r = √(x² + y² + z²) */
    mpfr_t x2, y2, z2;
    mpfr_init2(x2, prec); mpfr_init2(y2, prec); mpfr_init2(z2, prec);
    mpfr_mul(x2, x, x, MPFR_RNDN);
    mpfr_mul(y2, y, y, MPFR_RNDN);
    mpfr_mul(z2, z, z, MPFR_RNDN);
    mpfr_add(r_sq, x2, y2, MPFR_RNDN);
    mpfr_add(r_sq, r_sq, z2, MPFR_RNDN);
    mpfr_sqrt(r, r_sq, MPFR_RNDN);

    /* r_ratio = r / R₀ — dimensionless */
    mpfr_div(r_ratio, r, R0, MPFR_RNDN);

    /* θ = atan2(y, x) — azimuthal angle */
    mpfr_atan2(theta, y, x, MPFR_RNDN);
    /* Normalize to [0, 2π) */
    mpfr_t two_pi;
    mpfr_init2(two_pi, prec);
    mpfr_const_pi(two_pi, MPFR_RNDN);
    mpfr_mul_ui(two_pi, two_pi, 2, MPFR_RNDN);
    if (mpfr_sgn(theta) < 0) mpfr_add(theta, theta, two_pi, MPFR_RNDN);

    /* φ = acos(z/r) — polar angle */
    if (mpfr_sgn(r) > 0) {
        mpfr_t z_over_r;
        mpfr_init2(z_over_r, prec);
        mpfr_div(z_over_r, z, r, MPFR_RNDN);
        /* Clamp to [-1, 1] for numerical safety */
        if (mpfr_cmp_si(z_over_r, 1) > 0) mpfr_set_si(z_over_r, 1, MPFR_RNDN);
        if (mpfr_cmp_si(z_over_r, -1) < 0) mpfr_set_si(z_over_r, -1, MPFR_RNDN);
        mpfr_acos(phi, z_over_r, MPFR_RNDN);
        mpfr_clear(z_over_r);
    } else {
        mpfr_set_zero(phi, 1);
    }

    /* Convert r_ratio to string for real-axis projection */
    char *r_str_buf = (char *)malloc(ET_WORK_DPS + 64);
    if (!r_str_buf) {
        mpfr_clears(x, y, z, R0, r, r_sq, theta, phi, r_ratio,
                     x2, y2, z2, two_pi, (mpfr_ptr)0);
        return ET_ERR_ALLOC;
    }
    mpfr_sprintf(r_str_buf, "%.*Re", ET_WORK_DPS, r_ratio);

    /* Convert theta to string for phase projection */
    char *theta_str_buf = (char *)malloc(ET_WORK_DPS + 64);
    if (!theta_str_buf) {
        free(r_str_buf);
        mpfr_clears(x, y, z, R0, r, r_sq, theta, phi, r_ratio,
                     x2, y2, z2, two_pi, (mpfr_ptr)0);
        return ET_ERR_ALLOC;
    }
    mpfr_sprintf(theta_str_buf, "%.*Re", ET_WORK_DPS, theta);

    /* Project magnitude + azimuth as complex */
    et_error_t err = et_project_complex(proj, r_str_buf, theta_str_buf, mag_azimuth);

    /* Project polar angle separately */
    if (err == ET_OK && k_phi && d_phi) {
        char *phi_str = (char *)malloc(ET_WORK_DPS + 64);
        if (phi_str) {
            mpfr_sprintf(phi_str, "%.*Re", ET_WORK_DPS, phi);
            err = et_project_phase(proj->N, phi_str, k_phi, d_phi, eps_phi, prec);
            free(phi_str);
        }
    }

    free(r_str_buf);
    free(theta_str_buf);
    mpfr_clears(x, y, z, R0, r, r_sq, theta, phi, r_ratio,
                 x2, y2, z2, two_pi, (mpfr_ptr)0);
    return err;
}

/* ═══════════════════════════════════════════════════════════════════
 * D.1: COMPLEX PHASE ADDITION
 *
 * Phase adds mod N (U(1) compactness):
 *   δ_sum = δ_θ₁ + δ_θ₂
 *   κ_θ = round(δ_sum)
 *   k_θ,sum = (k_θ₁ + k_θ₂ + κ_θ) mod N
 * ═══════════════════════════════════════════════════════════════════ */
et_error_t et_complex_phase_add(int N, int k_theta1, const mpfr_t eps_theta1,
                                 int k_theta2, const mpfr_t eps_theta2,
                                 int *k_theta_out, int *d_theta_out,
                                 mpfr_t eps_theta_out, int *kappa_theta,
                                 mpfr_prec_t prec) {
    mpfr_t delta1, delta2, delta_sum, kappa_mpfr, cents, N_mpfr;
    mpfr_init2(delta1, prec); mpfr_init2(delta2, prec);
    mpfr_init2(delta_sum, prec); mpfr_init2(kappa_mpfr, prec);
    mpfr_init2(cents, prec); mpfr_init2(N_mpfr, prec);

    mpfr_set_si(cents, ET_CENTS_PER_OCTAVE, MPFR_RNDN);
    mpfr_set_si(N_mpfr, N, MPFR_RNDN);

    mpfr_mul(delta1, eps_theta1, N_mpfr, MPFR_RNDN);
    mpfr_div(delta1, delta1, cents, MPFR_RNDN);
    mpfr_mul(delta2, eps_theta2, N_mpfr, MPFR_RNDN);
    mpfr_div(delta2, delta2, cents, MPFR_RNDN);

    mpfr_add(delta_sum, delta1, delta2, MPFR_RNDN);
    mpfr_round(kappa_mpfr, delta_sum);
    int kappa = (int)mpfr_get_si(kappa_mpfr, MPFR_RNDN);

    /* k_θ = (k_θ₁ + k_θ₂ + κ) mod N */
    int k_sum = ((k_theta1 + k_theta2 + kappa) % N + N) % N;

    long g = (k_sum == 0) ? (long)N : cl_gcd((long)k_sum, (long)N);
    *k_theta_out = k_sum;
    *d_theta_out = (int)(N / g);
    if (kappa_theta) *kappa_theta = kappa;

    /* ε_θ = (δ_sum − κ) · 1200/N */
    mpfr_sub(eps_theta_out, delta_sum, kappa_mpfr, MPFR_RNDN);
    mpfr_mul(eps_theta_out, eps_theta_out, cents, MPFR_RNDN);
    mpfr_div(eps_theta_out, eps_theta_out, N_mpfr, MPFR_RNDN);

    mpfr_clears(delta1, delta2, delta_sum, kappa_mpfr, cents, N_mpfr, (mpfr_ptr)0);
    return ET_OK;
}

/* ═══════════════════════════════════════════════════════════════════
 * D.3: COMPLEX RECIPROCATION
 * ═══════════════════════════════════════════════════════════════════ */
et_error_t et_complex_reciprocal(int N,
                                  long k_r, const mpfr_t eps_r,
                                  int k_theta, const mpfr_t eps_theta,
                                  long *k_r_out, mpfr_t eps_r_out,
                                  int *k_theta_out, mpfr_t eps_theta_out,
                                  mpfr_prec_t prec) {
    (void)prec;
    /* Real axis: negate k and ε (mirror symmetry, Theorem A.3) */
    *k_r_out = -k_r;
    mpfr_neg(eps_r_out, eps_r, MPFR_RNDN);

    /* Imaginary axis: (N − k_θ) mod N, negate ε_θ */
    *k_theta_out = ((N - k_theta) % N + N) % N;
    mpfr_neg(eps_theta_out, eps_theta, MPFR_RNDN);

    return ET_OK;
}

/* ═══════════════════════════════════════════════════════════════════
 * FQG QUADRANT
 * ═══════════════════════════════════════════════════════════════════ */
int et_fqg_quadrant(int d_r, int d_theta, int N) {
    (void)N;
    int r_simple = is_simple_family(d_r);
    int t_simple = is_simple_family(d_theta);
    if (r_simple && t_simple) return 0;    /* SR */
    if (!r_simple && t_simple) return 1;   /* CR */
    if (r_simple && !t_simple) return 2;   /* SI */
    return 3;                               /* CI */
}

int et_combined_family(int d_r, int d_theta) {
    return cl_lcm(d_r, d_theta);
}
