"""
Find the island of stability from the N/Z lattice data.
The island of stability: predicted superheavy shell closures around
Z=114,120,126 and N=172,184 where nuclei should be anomalously stable.

If the N/Z projection reveals stability, the island MUST be visible.
Look at EVERYTHING — k, d, ε, CF, tower — without conventional bias.
"""
import sys
sys.path.insert(0, '/home/claude')
import mpmath
mpmath.mp.dps = 130
from collections import defaultdict

from sempaevum_nz_viewer import (
    build_atomic_particles, compute_particle_projections,
    cf_home_find, sempaevum_project_mp, N, et_gcd
)

print("Loading...")
particles = build_atomic_particles(measured_only=True)
results = compute_particle_projections(particles)
print(f"Projected {len(results)} isotopes\n")

# ================================================================
print("=" * 100)
print("1. THE SUPERHEAVY REGION — Every isotope with Z ≥ 100")
print("   Full lattice data: k_NZ, d_NZ, ε_NZ, k_mass, d_mass, CF home")
print("=" * 100)

superheavy = sorted([r for r in results if r.get("Z", 0) >= 100], 
                     key=lambda r: (r.get("Z",0), r.get("A",0)))

print(f"\n  {len(superheavy)} superheavy isotopes (Z ≥ 100)")
print(f"\n  {'Symbol':>10s} Z   N   A   N/Z        k_NZ d_NZ  ε_NZ(¢)      k_mass d_mass CF_d     CF_q     CF_class")
for r in superheavy:
    Z = r.get("Z", 0)
    A = r.get("A", 0)
    N_val = A - Z
    nz = mpmath.nstr(r.get("nz_ratio", mpmath.mpf(0)), 6)
    k_nz = r.get("k_nz", "?")
    d_nz = r.get("d_nz", "?")
    eps_nz = mpmath.nstr(r.get("eps_nz", mpmath.mpf(0)), 6) if r.get("eps_nz") else "?"
    k_mass = r.get("k_r_12", "?")
    d_mass = r.get("d_r_12", "?")
    cf_d = r.get("cf_d_home", "?")
    cf_q = r.get("cf_quality", "?")
    cf_cl = r.get("cf_class", "?")
    
    # Flag predicted magic numbers
    magic_z = "◆Z" if Z in {114, 120, 126} else "  "
    magic_n = "◆N" if N_val in {172, 184} else "  "
    
    cf_d_str = str(cf_d) if isinstance(cf_d, int) and cf_d < 10000 else f"({len(str(cf_d))}d)" if isinstance(cf_d, int) else "?"
    
    print(f"  {r['symbol']:>10s} {Z:>3d} {N_val:>3d} {A:>3d} {nz:>10s} {k_nz:>4} {d_nz:>4}  {eps_nz:>12s} {k_mass:>6} {d_mass:>6} {cf_d_str:>8s} {cf_q:>8} {cf_cl:>15s} {magic_z}{magic_n}")

# ================================================================
print("\n" + "=" * 100)
print("2. THE k_NZ = 7 AND k_NZ = 8 BOUNDARY — Where the island lives")
print("   Predicted island: Z~114-126, N~172-184 → N/Z ≈ 1.46-1.53")
print("   log₂(1.46)×12 ≈ 6.6, log₂(1.53)×12 ≈ 7.4 → k_NZ = 7")
print("=" * 100)

# All isotopes at k_NZ = 7 and 8
for k_target in [7, 8]:
    band = [r for r in results if r.get("k_nz") == k_target]
    print(f"\n  k_NZ = {k_target}: {len(band)} isotopes")
    
    # Group by Z
    by_Z = defaultdict(list)
    for r in band:
        by_Z[r.get("Z", 0)].append(r)
    
    print(f"  Z range: {min(by_Z.keys())} to {max(by_Z.keys())}")
    
    # Show the HEAVIEST elements at this k_NZ
    for Z in sorted(by_Z.keys(), reverse=True)[:10]:
        group = sorted(by_Z[Z], key=lambda r: r.get("A", 0))
        nat_count = sum(1 for r in group if r.get("is_naturally_occurring"))
        eps_vals = [abs(r.get("eps_nz", mpmath.mpf(0))) for r in group if r.get("eps_nz")]
        min_eps = min(eps_vals) if eps_vals else mpmath.mpf(0)
        best = min(group, key=lambda r: abs(r.get("eps_nz", mpmath.mpf(99))))
        
        magic_z = " ◆MAGIC-Z" if Z in {114, 120, 126} else ""
        print(f"    Z={Z:>3d}{magic_z}: {len(group)} isotopes, {nat_count} natural, "
              f"min|ε|={mpmath.nstr(min_eps, 4)}¢ at {best['symbol']}")

# ================================================================
print("\n" + "=" * 100)
print("3. ε_NZ WITHIN THE BOUNDARY BANDS — Who sits closest to exact nodes?")
print("   The island of stability should show up as anomalously small |ε|")
print("   in the superheavy region if these nuclei are lattice-preferred")
print("=" * 100)

# For k_NZ = 7, find the most lattice-exact isotopes
for k_target in [6, 7, 8]:
    band = [r for r in results if r.get("k_nz") == k_target]
    band_sorted = sorted(band, key=lambda r: abs(r.get("eps_nz", mpmath.mpf(99))))
    
    print(f"\n  k_NZ = {k_target}: Top 15 most lattice-exact (smallest |ε_NZ|):")
    for r in band_sorted[:15]:
        Z = r.get("Z", 0)
        A = r.get("A", 0)
        N_val = A - Z
        nat = "NAT" if r.get("is_naturally_occurring") else "   "
        magic = ""
        if Z in {114, 120, 126}: magic += "◆Z"
        if N_val in {172, 184}: magic += "◆N"
        eps = mpmath.nstr(abs(r.get("eps_nz", mpmath.mpf(0))), 8)
        print(f"    {r['symbol']:>10s} Z={Z:>3d} N={N_val:>3d} |ε_NZ|={eps:>12s}¢ {nat} {magic}")

# ================================================================
print("\n" + "=" * 100)
print("4. N/Z RATIO ANALYSIS — Where does N/Z = 184/114 project?")
print("   Compute exact projections for predicted island ratios")
print("=" * 100)

island_ratios = [
    (184, 114, "Island center (Z=114, N=184)"),
    (184, 120, "Island center (Z=120, N=184)"),
    (184, 126, "Island center (Z=126, N=184)"),
    (172, 114, "Near-island (Z=114, N=172)"),
    (172, 120, "Near-island (Z=120, N=172)"),
    (178, 118, "Oganesson region (Z=118, N=178)"),
    (176, 116, "Livermorium region (Z=116, N=176)"),
    (175, 115, "Moscovium region (Z=115, N=175)"),
]

for N_val, Z_val, label in island_ratios:
    nz = mpmath.mpf(N_val) / mpmath.mpf(Z_val)
    nz_str = mpmath.nstr(nz, 30)
    proj = sempaevum_project_mp(nz_str, 12)
    cf = cf_home_find(nz)
    
    if proj:
        k, d, eps = proj
        print(f"\n  {label}:")
        print(f"    N/Z = {N_val}/{Z_val} = {mpmath.nstr(nz, 10)}")
        print(f"    k_NZ = {k}, d_NZ = {d}, ε_NZ = {mpmath.nstr(eps, 10)}¢")
        print(f"    CF: d_home = {str(cf['cf_d_home']) if cf['cf_d_home'] < 10000 else '(' + str(len(str(cf['cf_d_home']))) + 'd)'}, "
              f"quality = {cf['cf_quality']}, class = {cf['cf_class']}")

# ================================================================
print("\n" + "=" * 100)
print("5. ANOMALY DETECTION — Within each Z, which isotope has the most")
print("   anomalous ε_NZ? (Deviates most from the monotonic trend)")
print("   Anomalous ε = potential stability island signature")
print("=" * 100)

by_Z = defaultdict(list)
for r in results:
    by_Z[r.get("Z", 0)].append(r)

# For each heavy element (Z > 80), look at ε_NZ as a function of N
# A sudden DIP in |ε| could indicate anomalous stability
anomalies = []
for Z in sorted(by_Z.keys()):
    if Z < 80: continue
    chain = sorted(by_Z[Z], key=lambda r: r.get("A", 0))
    if len(chain) < 5: continue
    
    # Compute ε_NZ trend
    eps_vals = [(r.get("A",0), r.get("A",0)-Z, r.get("eps_nz", mpmath.mpf(0)), r) for r in chain if r.get("eps_nz") is not None]
    if len(eps_vals) < 5: continue
    
    # Look for local minima in |ε_NZ|
    for i in range(1, len(eps_vals) - 1):
        A_prev, N_prev, e_prev, r_prev = eps_vals[i-1]
        A_curr, N_curr, e_curr, r_curr = eps_vals[i]
        A_next, N_next, e_next, r_next = eps_vals[i+1]
        
        abs_prev = abs(e_prev)
        abs_curr = abs(e_curr)
        abs_next = abs(e_next)
        
        # Is this a significant local minimum?
        if abs_curr < abs_prev and abs_curr < abs_next:
            depth = min(abs_prev - abs_curr, abs_next - abs_curr)
            if depth > mpmath.mpf(1):  # > 1 cent dip
                anomalies.append((Z, N_curr, A_curr, abs_curr, depth, r_curr))

anomalies.sort(key=lambda x: -x[4])  # Sort by depth of dip
print(f"\n  {len(anomalies)} ε_NZ local minima with depth > 1¢ in heavy elements:")
print(f"\n  {'Symbol':>10s}  Z   N   A   |ε_NZ|(¢)  Dip depth(¢)  Magic?")
for Z, N_val, A_val, eps, depth, r in anomalies[:25]:
    magic = ""
    if Z in {114, 120, 126}: magic += "◆Z"
    if N_val in {82, 126, 172, 184}: magic += "◆N"
    if Z in {82}: magic += "◆Z82"
    if N_val in {126}: magic += "◆N126"
    nat = "NAT" if r.get("is_naturally_occurring") else "   "
    print(f"  {r['symbol']:>10s} {Z:>3d} {N_val:>3d} {A_val:>3d}  {mpmath.nstr(eps,6):>10s}  {mpmath.nstr(depth,6):>12s}  {nat} {magic}")

print("\n" + "=" * 100)
print("ISLAND OF STABILITY INVESTIGATION COMPLETE")
print("=" * 100)
