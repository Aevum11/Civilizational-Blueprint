/*
 * ET Lossless Sensor Capture — Recording Session
 * =================================================
 * Orchestrates multi-sensor recording: activates sensors,
 * routes samples through the ET bijection pipeline,
 * writes the .etsf lossless format.
 *
 * The pipeline per sensor sample:
 *   ADC integer → string → MPFR → Π_N(r/R₀) → (k, d, ε) → .etsf
 *
 * Zero float64 in the computation chain. Zero loss.
 *
 * Author: Michael James Muller — Aevum Defluo (Exception Theory)
 * License: CC-BY-4.0
 */

package com.aevumdefluo.etsensor

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.SystemClock
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * A single sensor sample in the recording queue.
 * Values cross as STRINGS to maintain zero-float64 chain.
 */
data class SensorSample(
    val sensorId: Int,
    val sensorType: SensorType,
    val timestampNs: Long,
    val axis: Int,
    val valueStr: String  /* Zero float64: value as string, NOT float */
)

/**
 * RecordingSession — manages a multi-sensor recording.
 *
 * Lifecycle:
 *   1. Create session with list of sensors to record
 *   2. start() — activates sensors, begins .etsf file
 *   3. Samples flow through SensorEventListener → projection queue
 *   4. Background thread processes queue: project → write .etsf
 *   5. stop() — deactivates sensors, finalizes .etsf file
 */
class RecordingSession(
    private val context: Context,
    private val sensors: List<SensorInfo>,
    private val outputDir: File,
    private val N: Int = 12,
) : SensorEventListener {

    /* Recording state */
    private val isRecording = AtomicBoolean(false)
    private val sampleCount = AtomicLong(0)

    /* Sensor manager */
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager

    /* Sample queue: SensorEventListener → processing thread */
    private val sampleQueue = ConcurrentLinkedQueue<SensorSample>()

    /* Native projector indices (one per sensor) */
    private val projectorIndices = mutableMapOf<Int, Int>()

    /* Processing thread */
    private var processingThread: Thread? = null

    /* Output file path */
    var outputPath: String = ""
        private set

    /* Session statistics */
    var totalSamples: Long = 0
        private set
    var startTimeNs: Long = 0
        private set
    var durationMs: Long = 0
        private set

    /**
     * Start recording from all configured sensors.
     * Initializes native projectors, opens .etsf file, activates sensors.
     */
    fun start(): Boolean {
        if (isRecording.get()) return false

        /* Generate output filename */
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val deviceModel = Build.MODEL.replace(" ", "_")
        outputPath = File(outputDir, "et_${timestamp}_${deviceModel}.etsf").absolutePath

        /* Initialize native projectors for each sensor */
        for (sensor in sensors) {
            val idx = EtSensor.initProjector(sensor.type, "default", N)
            if (idx < 0) {
                /* Failed to initialize — skip this sensor but continue */
                continue
            }
            projectorIndices[sensor.id] = idx
        }

        /* Register sensor listeners at maximum rate */
        for (sensor in sensors) {
            val androidSensor = findAndroidSensor(sensor) ?: continue
            sensorManager.registerListener(
                this, androidSensor,
                SensorManager.SENSOR_DELAY_FASTEST
            )
        }

        isRecording.set(true)
        startTimeNs = SystemClock.elapsedRealtimeNanos()

        /* Start background processing thread */
        processingThread = Thread({
            processLoop()
        }, "ET-Sensor-Processing").also { it.start() }

        return true
    }

    /**
     * Stop recording. Deactivates sensors, drains queue, closes .etsf.
     */
    fun stop() {
        if (!isRecording.get()) return

        isRecording.set(false)
        durationMs = (SystemClock.elapsedRealtimeNanos() - startTimeNs) / 1_000_000

        /* Unregister all sensor listeners */
        sensorManager.unregisterListener(this)

        /* Wait for processing thread to drain the queue */
        processingThread?.join(5000)

        totalSamples = sampleCount.get()

        /* Clean up native projectors */
        EtSensor.cleanup()
        projectorIndices.clear()
    }

    /* ═══════════════════════════════════════════════════════════════
     * SensorEventListener — receives raw sensor data
     *
     * CRITICAL: We convert float values to STRINGS immediately.
     * The float32 from Android → String → (later) MPFR → bijection.
     * This is the earliest point we can exit the float world.
     *
     * For sensors with resolution data, we recover the ADC integer:
     *   adc_int = round(value / resolution)
     * and pass as "adc_int/max_int" fraction string.
     * ═══════════════════════════════════════════════════════════════ */

    override fun onSensorChanged(event: SensorEvent) {
        if (!isRecording.get()) return

        val sensorInfo = sensors.find { findAndroidSensor(it)?.type == event.sensor.type } ?: return
        val ts = event.timestamp /* Nanoseconds from SystemClock.elapsedRealtimeNanos */

        for (axis in 0 until minOf(event.values.size, sensorInfo.axes)) {
            val value = event.values[axis]

            /* Convert to string maintaining maximum information.
             *
             * If we know the sensor resolution, recover the ADC integer:
             *   adc = round(value / resolution)
             * and pass as "adc/max" fraction.
             *
             * If resolution is unknown, pass the float as a string.
             * This is the FALLBACK path — float32 has only ~7 digits. */
            val valueStr: String
            if (sensorInfo.resolution > 0f) {
                val adc = Math.round(value / sensorInfo.resolution)
                val maxAdc = Math.round(sensorInfo.maxRange / sensorInfo.resolution)
                valueStr = if (adc == 0L) "0" else "$adc/$maxAdc"
            } else {
                /* Fallback: float as string (lossy at float32 precision) */
                valueStr = value.toBigDecimal().toPlainString()
            }

            sampleQueue.add(SensorSample(
                sensorId = sensorInfo.id,
                sensorType = sensorInfo.type,
                timestampNs = ts,
                axis = axis,
                valueStr = valueStr
            ))
            sampleCount.incrementAndGet()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {
        /* Accuracy changes are D-events — could be logged to .etsf as metadata */
    }

    /* ═══════════════════════════════════════════════════════════════
     * PROCESSING LOOP — runs on background thread
     *
     * Drains the sample queue, projects each sample through
     * the ET bijection, and writes to the .etsf file.
     *
     * The zero-float64 chain:
     *   SensorEventListener: float → string (onSensorChanged)
     *   Processing thread: string → JNI → MPFR → bijection → .etsf
     * ═══════════════════════════════════════════════════════════════ */

    private fun processLoop() {
        /* TODO: Open .etsf writer via JNI (et_etsf_writer_open)
         * For now, process samples and verify the bijection works.
         * Full .etsf writing requires JNI wrapper for et_format.c. */

        while (isRecording.get() || sampleQueue.isNotEmpty()) {
            val sample = sampleQueue.poll()
            if (sample == null) {
                Thread.sleep(1) /* Yield when queue is empty */
                continue
            }

            /* Get the native projector for this sensor */
            val projIdx = projectorIndices[sample.sensorId] ?: continue

            /* Project through the bijection — zero float64 chain */
            val projection = EtSensor.project(
                projIdx, sample.valueStr,
                sample.axis, sample.timestampNs
            )

            /* In production: write to .etsf via JNI call to et_etsf_writer_write_sample.
             * The projection contains k (long), d (int), ε (string), sign (int).
             * All cross the JNI boundary as exact types (no float64). */
        }
    }

    /* ═══════════════════════════════════════════════════════════════
     * HELPERS
     * ═══════════════════════════════════════════════════════════════ */

    private fun findAndroidSensor(info: SensorInfo): Sensor? {
        val androidType = when (info.type) {
            SensorType.ACCEL -> Sensor.TYPE_ACCELEROMETER
            SensorType.GYRO -> Sensor.TYPE_GYROSCOPE
            SensorType.MAG -> Sensor.TYPE_MAGNETIC_FIELD
            SensorType.BARO -> Sensor.TYPE_PRESSURE
            SensorType.LIGHT -> Sensor.TYPE_LIGHT
            SensorType.PROXIMITY -> Sensor.TYPE_PROXIMITY
            SensorType.TEMP -> Sensor.TYPE_AMBIENT_TEMPERATURE
            SensorType.HUMIDITY -> Sensor.TYPE_RELATIVE_HUMIDITY
            SensorType.HEART_RATE -> Sensor.TYPE_HEART_RATE
            SensorType.STEP -> Sensor.TYPE_STEP_COUNTER
            else -> return null
        }
        return sensorManager.getDefaultSensor(androidType)
    }
}
