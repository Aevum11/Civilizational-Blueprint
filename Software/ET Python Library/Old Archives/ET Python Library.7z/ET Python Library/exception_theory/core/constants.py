"""
Exception Theory Constants Module

All constants derived from Exception Theory primitives: P (Point), D (Descriptor), T (Traverser)

From: "For every exception there is an exception, except the exception."

Author: Derived from M.J.M.'s Exception Theory
"""

import os
import tempfile

# ============================================================================
# CACHE AND ENVIRONMENT CONFIGURATION
# ============================================================================

def _get_cache_file():
    """
    Get cache file path only if writable, else None (memory-only mode).
    
    Returns:
        str or None: Path to cache file if writable, None otherwise
    """
    try:
        tmp_dir = tempfile.gettempdir()
        test_file = os.path.join(tmp_dir, f".et_write_test_{os.getpid()}")
        try:
            with open(test_file, 'w') as f:
                f.write('test')
            os.remove(test_file)
            return os.path.join(tmp_dir, "et_compendium_geometry_v3_0.json")
        except (OSError, IOError):
            return None
    except:
        return None

CACHE_FILE = _get_cache_file()
MAX_SCAN_WIDTH = 2048
DEFAULT_TUPLE_DEPTH = 4
ET_CACHE_ENV_VAR = "ET_COMPENDIUM_GEOMETRY_CACHE_V3_0"
ET_SHARED_MEM_NAME = "et_compendium_geometry_shm_v3_0"
ET_SHARED_MEM_SIZE = 8192

# ============================================================================
# PHASE-LOCK DESCRIPTORS (RO Bypass)
# ============================================================================

DEFAULT_NOISE_PATTERN = 0xFF
DEFAULT_INJECTION_COUNT = 1
ALTERNATE_NOISE_PATTERNS = [0xFF, 0xAA, 0x55, 0x00]
PATTERN_NAMES = {
    0xFF: "BIT_INVERT",
    0xAA: "ALT_HIGH",
    0x55: "ALT_LOW",
    0x00: "DISABLED"
}

# ============================================================================
# MEMORY PROTECTION DESCRIPTORS
# ============================================================================

PROT = {
    'NONE': 0x0,
    'READ': 0x1,
    'WRITE': 0x2,
    'EXEC': 0x4
}

PAGE = {
    'NOACCESS': 0x01,
    'READONLY': 0x02,
    'READWRITE': 0x04,
    'EXEC_READ': 0x20,
    'EXEC_READWRITE': 0x40
}

# ============================================================================
# RO BYPASS TIER DESCRIPTORS
# ============================================================================

RO_BYPASS_TIERS = [
    "TUNNEL_PHASE_LOCK",
    "DIRECT_MEMMOVE",
    "MPROTECT_DIRECT",
    "CTYPES_POINTER_CAST",
    "PYOBJECT_STRUCTURE",
    "DISPLACEMENT_HOLOGRAPHIC"
]

# ============================================================================
# ET FUNDAMENTAL CONSTANTS (Derived from Exception Theory)
# ============================================================================

# Core Variance and Symmetry
BASE_VARIANCE = 1.0 / 12.0  # From ET manifold mathematics
MANIFOLD_SYMMETRY = 12      # Fundamental symmetry count
KOIDE_RATIO = 2.0 / 3.0     # Koide formula constant

# Cosmological Ratios (from ET predictions)
DARK_ENERGY_RATIO = 68.3 / 100.0
DARK_MATTER_RATIO = 26.8 / 100.0
ORDINARY_MATTER_RATIO = 4.9 / 100.0

# ============================================================================
# INDETERMINACY CONSTANTS (v2.1+)
# ============================================================================

T_SINGULARITY_THRESHOLD = 1e-9    # Nanosecond precision for T-gap detection
COHERENCE_VARIANCE_FLOOR = 0.0    # Absolute coherence floor

# ============================================================================
# MANIFOLD ARCHITECTURE CONSTANTS (v2.2+)
# ============================================================================

DEFAULT_BLOOM_SIZE = 1024
DEFAULT_BLOOM_HASHES = 3
ZK_DEFAULT_GENERATOR = 5
ZK_DEFAULT_PRIME = 1000000007

# ============================================================================
# DISTRIBUTED CONSCIOUSNESS CONSTANTS (v2.3+)
# ============================================================================

DEFAULT_SWARM_COHERENCE = 1.0
DEFAULT_SWARM_ALIGNMENT_BONUS = 0.1
DEFAULT_SWARM_STABILITY_BONUS = 0.05
PRECOG_HISTORY_SIZE = 5
PRECOG_PROBABILITY_THRESHOLD = 0.5
DEFAULT_VARIANCE_CAPACITY = 100.0
DEFAULT_VARIANCE_REFILL_RATE = 10.0
DEFAULT_POT_DIFFICULTY = 4
DEFAULT_HASH_RING_REPLICAS = 3
FRACTAL_DEFAULT_OCTAVES = 3
FRACTAL_DEFAULT_PERSISTENCE = 0.5

# ============================================================================
# QUANTUM MECHANICS CONSTANTS (v3.1+ - Hydrogen Atom)
# ============================================================================

# Planck constant (from BASE_VARIANCE = 1/12 manifold structure)
PLANCK_CONSTANT_HBAR = 1.054571817e-34  # J·s (ℏ = A_px action quantum)
PLANCK_CONSTANT_H = 6.62607015e-34      # J·s (h = 2πℏ)

# Backwards compatibility
PLANCK_CONSTANT = PLANCK_CONSTANT_HBAR  # Default to ℏ

# ============================================================================
# ELECTROMAGNETIC CONSTANTS (v3.1+)
# ============================================================================

# Charge quantum (manifold polarity descriptor)
ELEMENTARY_CHARGE = 1.602176634e-19  # C (e, exact by definition 2019)

# Vacuum properties (manifold geometric couplings)
VACUUM_PERMITTIVITY = 8.8541878128e-12   # F/m (ε₀, radial coupling)
VACUUM_PERMEABILITY = 1.25663706212e-6   # H/m (μ₀, rotational coupling)
SPEED_OF_LIGHT = 299792458.0             # m/s (c = 1/√(μ₀ε₀), exact)

# Fine structure constant (dimensionless EM coupling from Eq 183)
FINE_STRUCTURE_CONSTANT = 7.2973525693e-3  # α = e²/(4πε₀ℏc) ≈ 1/137.036
FINE_STRUCTURE_INVERSE = 137.035999084     # α⁻¹

# ============================================================================
# PARTICLE MASSES (v3.1+)
# ============================================================================

# Fundamental fermions (descriptor mass content)
PROTON_MASS = 1.67262192369e-27   # kg (938.272 MeV/c²)
ELECTRON_MASS = 9.1093837015e-31  # kg (0.511 MeV/c²)
NEUTRON_MASS = 1.67492749804e-27  # kg (939.565 MeV/c²)

# ============================================================================
# HYDROGEN ATOM CONSTANTS (v3.1+)
# ============================================================================

# Energy scale (ground state binding energy)
RYDBERG_ENERGY = 13.605693122994  # eV (E₁ = -Ry)

# Length scale (characteristic atomic size from manifold geometry)
BOHR_RADIUS = 5.29177210903e-11  # m (a₀ = 4πε₀ℏ²/(μe²))

# Spectroscopic constant (from manifold + EM coupling)
RYDBERG_CONSTANT = 1.0973731568160e7  # m⁻¹ (R∞ most precise constant)

# QED corrections
LAMB_SHIFT_2S = 1.057e9  # Hz (2s₁/₂ - 2p₁/₂ QED shift)

# Hyperfine structure (21cm line - famous in astronomy)
HYDROGEN_21CM_FREQUENCY = 1.420405751e9  # Hz (ground state splitting)
HYDROGEN_21CM_WAVELENGTH = 0.211061140542  # m (λ = c/f)

# Backwards compatibility aliases
HYDROGEN_IONIZATION = RYDBERG_ENERGY  # Old name for ground state binding energy
HYPERFINE_FREQUENCY = HYDROGEN_21CM_FREQUENCY  # Old name for 21cm line

# ============================================================================
# VERSION INFORMATION
# ============================================================================

VERSION = "3.1.0"
VERSION_INFO = (3, 1, 0)
BUILD = "production"

# Version History
VERSION_HISTORY = {
    "2.0": {"lines": 2586, "equations": "1-10", "focus": "Core transmutation"},
    "2.1": {"lines": 3119, "equations": "11-20", "focus": "Batch 1: Computational ET"},
    "2.2": {"lines": 4313, "equations": "21-30", "focus": "Batch 2: Manifold Architectures"},
    "2.3": {"lines": 5799, "equations": "31-40", "focus": "Batch 3: Distributed Consciousness"},
    "3.0": {"lines": 6402, "equations": "All", "focus": "Library Architecture"},
    "3.1": {"lines": "TBD", "equations": "41-90", "focus": "Hydrogen Atom (Batches 4-8)"}
}

__all__ = [
    # Cache and Environment
    'CACHE_FILE',
    'MAX_SCAN_WIDTH',
    'DEFAULT_TUPLE_DEPTH',
    'ET_CACHE_ENV_VAR',
    'ET_SHARED_MEM_NAME',
    'ET_SHARED_MEM_SIZE',
    
    # Phase-Lock
    'DEFAULT_NOISE_PATTERN',
    'DEFAULT_INJECTION_COUNT',
    'ALTERNATE_NOISE_PATTERNS',
    'PATTERN_NAMES',
    
    # Memory Protection
    'PROT',
    'PAGE',
    'RO_BYPASS_TIERS',
    
    # ET Fundamental Constants
    'BASE_VARIANCE',
    'MANIFOLD_SYMMETRY',
    'KOIDE_RATIO',
    'DARK_ENERGY_RATIO',
    'DARK_MATTER_RATIO',
    'ORDINARY_MATTER_RATIO',
    
    # Indeterminacy
    'T_SINGULARITY_THRESHOLD',
    'COHERENCE_VARIANCE_FLOOR',
    
    # Manifold Architecture
    'DEFAULT_BLOOM_SIZE',
    'DEFAULT_BLOOM_HASHES',
    'ZK_DEFAULT_GENERATOR',
    'ZK_DEFAULT_PRIME',
    
    # Distributed Consciousness
    'DEFAULT_SWARM_COHERENCE',
    'DEFAULT_SWARM_ALIGNMENT_BONUS',
    'DEFAULT_SWARM_STABILITY_BONUS',
    'PRECOG_HISTORY_SIZE',
    'PRECOG_PROBABILITY_THRESHOLD',
    'DEFAULT_VARIANCE_CAPACITY',
    'DEFAULT_VARIANCE_REFILL_RATE',
    'DEFAULT_POT_DIFFICULTY',
    'DEFAULT_HASH_RING_REPLICAS',
    'FRACTAL_DEFAULT_OCTAVES',
    'FRACTAL_DEFAULT_PERSISTENCE',
    
    # Quantum Mechanics (v3.1)
    'PLANCK_CONSTANT_HBAR',
    'PLANCK_CONSTANT_H',
    'PLANCK_CONSTANT',  # Backwards compat (= HBAR)
    
    # Electromagnetic (v3.1)
    'ELEMENTARY_CHARGE',
    'VACUUM_PERMITTIVITY',
    'VACUUM_PERMEABILITY',
    'SPEED_OF_LIGHT',
    'FINE_STRUCTURE_CONSTANT',
    'FINE_STRUCTURE_INVERSE',
    
    # Particle Masses (v3.1)
    'PROTON_MASS',
    'ELECTRON_MASS',
    'NEUTRON_MASS',
    
    # Hydrogen Atom (v3.1)
    'RYDBERG_ENERGY',
    'BOHR_RADIUS',
    'RYDBERG_CONSTANT',
    'LAMB_SHIFT_2S',
    'HYDROGEN_21CM_FREQUENCY',
    'HYDROGEN_21CM_WAVELENGTH',
    'HYDROGEN_IONIZATION',  # Backwards compat (= RYDBERG_ENERGY)
    'HYPERFINE_FREQUENCY',  # Backwards compat (= HYDROGEN_21CM_FREQUENCY)
    
    # Version
    'VERSION',
    'VERSION_INFO',
    'BUILD',
    'VERSION_HISTORY',
]
