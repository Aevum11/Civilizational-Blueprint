/* ============================================================================
 * et_med_jni.c — JNI bridge for libet_med
 * ----------------------------------------------------------------------------
 *  Identification: this file is the Android access layer. It marshals
 *  Java types (jobject, jdouble, jintArray) into C libet_med types, makes
 *  one-shot calls, and copies results back — no long-lived C handles are
 *  exposed to Java.
 *
 *  Subsumption: the Java API mirrors the C ABI 1:1 through
 *  com.aevumdefluo.etmed.EtMed helpers, so the same calling conventions
 *  used by the Windows wrapper and the WebAssembly wrapper apply here.
 * ========================================================================= */
#include <jni.h>
#include <string.h>
#include <stdlib.h>

#include "libet_med.h"

/* Helper: pull a double-valued field from a Java object by name. */
static jdouble get_double_field(JNIEnv* env, jobject obj, const char* name) {
    jclass cls = (*env)->GetObjectClass(env, obj);
    jfieldID fid = (*env)->GetFieldID(env, cls, name, "D");
    if (fid == NULL) return (jdouble)0.0;
    return (*env)->GetDoubleField(env, obj, fid);
}

static jint get_int_field(JNIEnv* env, jobject obj, const char* name) {
    jclass cls = (*env)->GetObjectClass(env, obj);
    jfieldID fid = (*env)->GetFieldID(env, cls, name, "I");
    if (fid == NULL) return 0;
    return (*env)->GetIntField(env, obj, fid);
}

/* ----------------------------------------------------------------------------
 * JNI: simple scalars
 * ------------------------------------------------------------------------- */
JNIEXPORT jdouble JNICALL
Java_com_aevumdefluo_etmed_EtMed_nativeVBase(JNIEnv* env, jclass cls) {
    (void)env; (void)cls; return (jdouble)ET_V_BASE;
}

JNIEXPORT jdouble JNICALL
Java_com_aevumdefluo_etmed_EtMed_nativeKKoide(JNIEnv* env, jclass cls) {
    (void)env; (void)cls; return (jdouble)ET_K_KOIDE;
}

JNIEXPORT jint JNICALL
Java_com_aevumdefluo_etmed_EtMed_nativeA0LocalEm(JNIEnv* env, jclass cls) {
    (void)env; (void)cls; return (jint)ET_A0_LOCAL_EM;
}

JNIEXPORT jint JNICALL
Java_com_aevumdefluo_etmed_EtMed_nativeBiologicalFloor(JNIEnv* env, jclass cls) {
    (void)env; (void)cls; return (jint)ET_BIOLOGICAL_FLOOR;
}

JNIEXPORT jint JNICALL
Java_com_aevumdefluo_etmed_EtMed_nativeCorticalFloor(JNIEnv* env, jclass cls) {
    (void)env; (void)cls; return (jint)ET_CORTICAL_FLOOR;
}

/* ----------------------------------------------------------------------------
 * JNI: projection — returns a double[] of size 8: [r, log2_r, exact_pos, k,
 *   g, d, eps_cents, N]
 * ------------------------------------------------------------------------- */
JNIEXPORT jdoubleArray JNICALL
Java_com_aevumdefluo_etmed_EtMed_nativeProjectReal(JNIEnv* env, jclass cls,
                                                    jdouble r, jint n) {
    (void)cls;
    et_projection_t p;
    et_error_t e = et_project_real((double)r, (int)n, &p);
    if (e != ET_OK) return NULL;

    jdoubleArray out = (*env)->NewDoubleArray(env, 8);
    if (out == NULL) return NULL;
    jdouble buf[8] = { p.r, p.log2_r, p.exact_pos,
                       (double)p.k, (double)p.g, (double)p.d,
                       p.eps_cents, (double)p.N };
    (*env)->SetDoubleArrayRegion(env, out, 0, 8, buf);
    return out;
}

/* ----------------------------------------------------------------------------
 * JNI: impedance / palindrome / shimmer
 * ------------------------------------------------------------------------- */
JNIEXPORT jdouble JNICALL
Java_com_aevumdefluo_etmed_EtMed_nativeMagicalImpedance(JNIEnv* env, jclass cls,
                                                        jint d, jint s, jint a0) {
    (void)env; (void)cls;
    return (jdouble)et_magical_impedance((int)d, (int)s, (int)a0);
}

JNIEXPORT jint JNICALL
Java_com_aevumdefluo_etmed_EtMed_nativePalindromeD(JNIEnv* env, jclass cls, jint n) {
    (void)env; (void)cls;
    return (jint)et_palindrome_d((int)n);
}

JNIEXPORT jdouble JNICALL
Java_com_aevumdefluo_etmed_EtMed_nativeShimmer(JNIEnv* env, jclass cls, jint n) {
    (void)env; (void)cls;
    return (jdouble)et_shimmer((int)n);
}

/* ----------------------------------------------------------------------------
 * JNI: tower default R0 / reference baseline value / resolution
 * ------------------------------------------------------------------------- */
JNIEXPORT jdouble JNICALL
Java_com_aevumdefluo_etmed_EtMed_nativeTowerDefaultR0(JNIEnv* env, jclass cls, jint t) {
    (void)env; (void)cls;
    return (jdouble)et_tower_default_R0((et_tower_t)(int)t);
}

JNIEXPORT jint JNICALL
Java_com_aevumdefluo_etmed_EtMed_nativeTowerResolution(JNIEnv* env, jclass cls, jint t) {
    (void)env; (void)cls;
    return (jint)et_tower_resolution((et_tower_t)(int)t);
}

JNIEXPORT jdouble JNICALL
Java_com_aevumdefluo_etmed_EtMed_nativeTowerReferenceBaseline(JNIEnv* env, jclass cls, jint t) {
    (void)env; (void)cls;
    return (jdouble)et_tower_reference_baseline_value((et_tower_t)(int)t);
}

JNIEXPORT jstring JNICALL
Java_com_aevumdefluo_etmed_EtMed_nativeTowerName(JNIEnv* env, jclass cls, jint t) {
    (void)cls;
    const char* s = et_tower_name((et_tower_t)(int)t);
    return (*env)->NewStringUTF(env, s ? s : "");
}

/* ----------------------------------------------------------------------------
 * JNI: error string + fallback counter
 * ------------------------------------------------------------------------- */
JNIEXPORT jstring JNICALL
Java_com_aevumdefluo_etmed_EtMed_nativeErrorString(JNIEnv* env, jclass cls, jint err) {
    (void)cls;
    const char* s = et_error_string((et_error_t)(int)err);
    return (*env)->NewStringUTF(env, s ? s : "");
}

JNIEXPORT jlong JNICALL
Java_com_aevumdefluo_etmed_EtMed_nativeFallbackCount(JNIEnv* env, jclass cls) {
    (void)env; (void)cls;
    return (jlong)et_fallback_count();
}

JNIEXPORT void JNICALL
Java_com_aevumdefluo_etmed_EtMed_nativeResetFallbackCount(JNIEnv* env, jclass cls) {
    (void)env; (void)cls;
    et_reset_fallback_count();
}

/* ----------------------------------------------------------------------------
 * JNI: build a C baseline struct from a Java PatientBaseline object.
 *  Fields expected in Java: hrRestBpm, rrRestPerMin, temperatureC,
 *  sbpRestMmHg, dbpRestMmHg, spo2Pct, gaitCycleS, menstrualCycleD, ageYears,
 *  sex (int: 0=F, 1=M, 2=U).
 * ------------------------------------------------------------------------- */
static void baseline_from_java(JNIEnv* env, jobject jbl, et_patient_baseline_t* b) {
    et_patient_baseline_init(b);
    b->hr_rest_bpm       = get_double_field(env, jbl, "hrRestBpm");
    b->rr_rest_per_min   = get_double_field(env, jbl, "rrRestPerMin");
    b->temperature_c     = get_double_field(env, jbl, "temperatureC");
    b->sbp_rest_mmhg     = get_double_field(env, jbl, "sbpRestMmHg");
    b->dbp_rest_mmhg     = get_double_field(env, jbl, "dbpRestMmHg");
    b->spo2_pct          = get_double_field(env, jbl, "spo2Pct");
    b->gait_cycle_s      = get_double_field(env, jbl, "gaitCycleS");
    b->menstrual_cycle_d = get_double_field(env, jbl, "menstrualCycleD");
    b->age_years         = get_double_field(env, jbl, "ageYears");
    int sex_int          = get_int_field(env, jbl, "sex");
    b->sex               = (et_sex_t)sex_int;
}

/* Compute multifold signature and return as a double[2 + TowerCount*2] array:
 *   [multifoldScalar, multifoldNormalized, R0_0..R0_9, present_0..present_9]
 */
JNIEXPORT jdoubleArray JNICALL
Java_com_aevumdefluo_etmed_EtMed_nativeComputeMultifold(JNIEnv* env, jclass cls,
                                                        jobject jbl,
                                                        jboolean fallbackAllowed) {
    (void)cls;
    et_patient_baseline_t b;
    baseline_from_java(env, jbl, &b);

    et_multifold_signature_t sig;
    et_error_t e = et_compute_multifold_signature(&b, fallbackAllowed ? 1 : 0, &sig);
    if (e != ET_OK) return NULL;

    int n = ET_TOWER_COUNT;
    jdoubleArray out = (*env)->NewDoubleArray(env, 2 + n * 2);
    if (out == NULL) return NULL;

    jdouble* buf = (jdouble*)malloc(sizeof(jdouble) * (size_t)(2 + n * 2));
    if (buf == NULL) return NULL;
    buf[0] = sig.multifold_scalar;
    buf[1] = sig.multifold_normalized;
    for (int i = 0; i < n; ++i) buf[2 + i]       = sig.R0_seconds[i];
    for (int i = 0; i < n; ++i) buf[2 + n + i]   = (double)sig.R0_present[i];

    (*env)->SetDoubleArrayRegion(env, out, 0, 2 + n * 2, buf);
    free(buf);
    return out;
}

/* ----------------------------------------------------------------------------
 * JNI: classify a single measurement.
 *
 *  Java passes the measurement's scalar fields directly; the JNI side packs
 *  them into an et_measurement_t and returns the resulting finding as a
 *  primitive-array bundle:
 *     [state(int as double), incoherence_level(int as double),
 *      tower(int as double), lattice_resolution, k, d, eps_cents,
 *      severity_pct, urgency_rank]
 * ------------------------------------------------------------------------- */
JNIEXPORT jdoubleArray JNICALL
Java_com_aevumdefluo_etmed_EtMed_nativeClassifyMeasurement(JNIEnv* env, jclass cls,
                                                           jstring jname,
                                                           jdouble currentValue,
                                                           jdouble baselineValue,
                                                           jint towerInt,
                                                           jobject jbaseline,
                                                           jboolean fallbackAllowed) {
    (void)cls;
    et_measurement_t m;
    et_measurement_init(&m);
    const char* name_utf = jname ? (*env)->GetStringUTFChars(env, jname, NULL) : "";
    if (name_utf) {
        strncpy(m.name, name_utf, sizeof(m.name) - 1);
        m.name[sizeof(m.name) - 1] = '\0';
    }
    m.current_value  = (double)currentValue;
    m.baseline_value = (double)baselineValue;
    m.tower          = (et_tower_t)(int)towerInt;
    if (jname) (*env)->ReleaseStringUTFChars(env, jname, name_utf);

    et_patient_baseline_t b;
    baseline_from_java(env, jbaseline, &b);

    et_finding_t f;
    et_finding_init(&f);
    et_error_t e = et_classify_measurement(&m, &b, fallbackAllowed ? 1 : 0, &f);
    if (e != ET_OK) return NULL;

    jdoubleArray out = (*env)->NewDoubleArray(env, 9);
    if (out == NULL) return NULL;
    jdouble buf[9] = {
        (double)f.state,
        (double)f.incoherence_level,
        (double)f.tower,
        (double)f.lattice_resolution,
        (double)f.projection.k,
        (double)f.projection.d,
        f.projection.eps_cents,
        f.severity_score_pct,
        (double)f.urgency_rank
    };
    (*env)->SetDoubleArrayRegion(env, out, 0, 9, buf);
    return out;
}
