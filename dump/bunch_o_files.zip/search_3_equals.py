"""Search the corpus for the exact structural meaning of 3=3=3=Σ."""
import os, re

corpus = "/mnt/project"

# Patterns for the equation itself
patterns = [
    r"3\s*=\s*3\s*=\s*3",
    r"three\s+equals\s+three",
    r"3\s*=\s*Σ",
    r"=\s*Σ\b",
    r"Σ\s*=",
    r"\bΣ\b",          # bare Σ
    r"sigma\s*[=]",    # spelled out
    r"totality",
    r"the\s+sum\b",
    r"sum\s+is",
]

print("=" * 80)
print("CORPUS SEARCH: 3 = 3 = 3 = Σ and Σ as totality-expression")
print("=" * 80)

for fname in sorted(os.listdir(corpus)):
    path = os.path.join(corpus, fname)
    if not os.path.isfile(path): continue
    try:
        with open(path, 'r', errors='ignore') as f:
            text = f.read()
    except:
        continue
    
    file_hits = []
    for pat in patterns:
        for m in re.finditer(pat, text, re.IGNORECASE):
            start = max(0, m.start() - 120)
            end   = min(len(text), m.end() + 200)
            ctx = text[start:end].replace("\n", " ").strip()
            file_hits.append((pat, ctx))
    
    if file_hits:
        # Dedupe by 80-char hash
        seen = set()
        unique = []
        for pat, ctx in file_hits:
            key = ctx[:100]
            if key in seen: continue
            seen.add(key)
            unique.append((pat, ctx))
        
        if unique:
            print(f"\n── {fname} ── ({len(unique)} unique hits)")
            for i, (pat, ctx) in enumerate(unique[:5]):  # first 5 per file
                print(f"  [{pat[:25]:<25}]")
                print(f"     ...{ctx[:350]}...")
                print()
