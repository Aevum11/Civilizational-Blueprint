#!/usr/bin/env python3
"""
IC-42 T-Act Structural Excess Verification
============================================
Exception Theory — Michael James Muller — Exception Theory LLC
P ∘ D ∘ T = E

Verifies: max(d_×/lcm(d₁,d₂)) = N for κ=±1
The T-act produces sublattice family transitions exceeding the D-arithmetic bound.
"""
from mpmath import mp, mpf
from math import gcd, lcm

mp.dps = 400
N = 12
divs = [1, 2, 3, 4, 6, 12]

passed = failed = total = 0

# Compute T-act excess for ALL (d₁, d₂, κ) combinations
max_excess = 0
max_case = None

for d1 in divs:
    res_d1 = [k for k in range(N) if (N // gcd(k, N) == d1 if k > 0 else d1 == 1)]
    for d2 in divs:
        res_d2 = [k for k in range(N) if (N // gcd(k, N) == d2 if k > 0 else d2 == 1)]
        lcm_d1d2 = lcm(d1, d2)
        for k1 in res_d1:
            for k2 in res_d2:
                for kappa in [-1, 0, 1]:
                    k_out = (k1 + k2 + kappa) % N
                    d_out = N // gcd(k_out, N) if k_out > 0 else 1
                    if kappa != 0:
                        excess = d_out / lcm_d1d2
                        if excess > max_excess:
                            max_excess = excess
                            max_case = (k1, k2, kappa, d1, d2, d_out, lcm_d1d2)

print(f"Maximum T-act excess ratio: d_×/lcm(d₁,d₂) = {max_excess}")
print(f"Achieved at: k₁={max_case[0]}, k₂={max_case[1]}, κ={max_case[2]}")
print(f"  d₁={max_case[3]}, d₂={max_case[4]}, d_×={max_case[5]}, lcm={max_case[6]}")

total += 1
if max_excess == N:
    passed += 1
    print(f"  Excess ratio = N = {N}: PASS")
else:
    failed += 1

# Verify κ=0 bound ALWAYS holds (IC-29)
kappa0_holds = True
for d1 in divs:
    res_d1 = [k for k in range(N) if (N // gcd(k, N) == d1 if k > 0 else d1 == 1)]
    for d2 in divs:
        res_d2 = [k for k in range(N) if (N // gcd(k, N) == d2 if k > 0 else d2 == 1)]
        lcm_d1d2 = lcm(d1, d2)
        for k1 in res_d1:
            for k2 in res_d2:
                k_out = (k1 + k2) % N
                d_out = N // gcd(k_out, N) if k_out > 0 else 1
                if d_out > lcm_d1d2:
                    kappa0_holds = False

total += 1
if kappa0_holds:
    passed += 1
    print(f"\nκ=0 bound d_× ≤ lcm(d₁,d₂) holds for ALL pairs: PASS")
else:
    failed += 1

# Count T-act excess cases
excess_cases = total_kappa_nonzero = 0
for d1 in divs:
    res_d1 = [k for k in range(N) if (N // gcd(k, N) == d1 if k > 0 else d1 == 1)]
    for d2 in divs:
        res_d2 = [k for k in range(N) if (N // gcd(k, N) == d2 if k > 0 else d2 == 1)]
        lcm_d1d2 = lcm(d1, d2)
        for k1 in res_d1:
            for k2 in res_d2:
                for kappa in [-1, 1]:
                    total_kappa_nonzero += 1
                    k_out = (k1 + k2 + kappa) % N
                    d_out = N // gcd(k_out, N) if k_out > 0 else 1
                    if d_out > lcm_d1d2:
                        excess_cases += 1

total += 1
if excess_cases > 0:
    passed += 1
print(f"\nT-act excess: {excess_cases}/{total_kappa_nonzero} κ≠0 pairs ({100*excess_cases/total_kappa_nonzero:.1f}%)")
print(f"\nTOTAL: {passed}/{total} PASSED")
