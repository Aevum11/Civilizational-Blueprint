/*
 * ET Lossless Sensor Capture — Kotlin Facade
 * =============================================
 * Type-safe Kotlin interface to the C bijection core.
 * All sensor values cross the JNI boundary as STRINGS
 * to maintain the zero-float64 chain.
 *
 * Author: Michael James Muller — Aevum Defluo (Exception Theory)
 * License: CC-BY-4.0
 */

package com.aevumdefluo.etsensor

/**
 * ET Sensor type enumeration — mirrors et_sensor_type_t in C.
 * Each type has a substrate-derived R₀ (not chosen, not tuned).
 */
enum class SensorType(val code: Int) {
    AUDIO(0),
    ACCEL(1),
    GYRO(2),
    MAG(3),
    BARO(4),
    LIGHT(5),
    TEMP(6),
    CAMERA(7),
    GPS_POS(8),
    GPS_TIME(9),
    HUMIDITY(10),
    PROXIMITY(11),
    HEART_RATE(12),
    STEP(13);

    companion object {
        fun fromCode(code: Int): SensorType? = entries.find { it.code == code }
    }
}

/**
 * Manifold state — the four states from P∘D∘T power set.
 */
enum class ManifoldState(val code: Int) {
    EXCEPTION(0),        // {P,D,T} — fully substantiated
    MEDIATION(1),        // {D,T}   — bridge without substrate
    INCOHERENCE(2),      // {P,T}   — self-defeating
    UNSUBSTANTIATED(3);  // {P,D}   — frozen potential (zero samples)
}

/**
 * Projection result — the output of Π_N(r).
 *
 * k = integer lattice coordinate
 * d = sublattice family (N/gcd(|k|,N))
 * epsilon = exact residual in cents (as STRING — zero float64)
 * sign = +1, -1, or 0
 */
data class Projection(
    val k: Long,
    val d: Int,
    val epsilon: String,   // Full-precision string — NOT Double
    val sign: Int,
    val isZero: Boolean,
    val atBoundary: Boolean,
    val N: Int
) {
    /** The d-family character name */
    val familyName: String get() = when {
        d == 1  -> "Octave (Gravitational)"
        d == 2  -> "Tritone (Quadratic)"
        d == 3  -> "Cubic (Strong Force)"
        d == 4  -> "Quartic (Hypercubic)"
        d == 6  -> "Hexadic (Composite)"
        d == 12 -> "Full Resolution (EM)"
        else    -> "d=$d (Extended)"
    }

    /** Quick summary string */
    override fun toString(): String {
        if (isZero) return "(zero — Unsubstantiated)"
        val signChar = when (sign) { 0 -> "+" ; 1 -> "-" ; else -> "?" }
        val boundary = if (atBoundary) " [∂I]" else ""
        return "(k=$k, d=$d, ε=${epsilon.take(12)}¢, sign=$signChar)$boundary"
    }
}

/**
 * EtSensor — the main interface to the ET bijection core.
 *
 * All methods are static (JNI calls to C library).
 * Sensor values ALWAYS cross as strings — zero float64.
 */
object EtSensor {

    init {
        System.loadLibrary("et_sensor")
    }

    /* ═══════════════════════════════════════════════════════════════
     * Native methods — implemented in et_sensor_jni.c
     * ═══════════════════════════════════════════════════════════════ */

    /**
     * Initialize a sensor projector for a specific sensor type.
     * @param sensorType the sensor type code
     * @param r0 the R₀ reference value as string ("default" for substrate-derived)
     * @param N lattice resolution (12 for base ET)
     * @return projector index (≥0) or -1 on error
     */
    @JvmStatic
    external fun initSensorProjector(sensorType: Int, r0: String, N: Int): Int

    /**
     * Project a sensor value through Π_N.
     * @param projectorIdx index from initSensorProjector
     * @param value measurement as string (zero float64 chain)
     * @param axis axis index (0=x/mono, 1=y, 2=z)
     * @param timestampNs monotonic nanosecond timestamp
     * @return [k, d, sign, isZero, atBoundary, N] or null on error
     */
    @JvmStatic
    external fun projectSensor(projectorIdx: Int, value: String,
                                axis: Int, timestampNs: Long): DoubleArray?

    /**
     * Get ε as a full-precision string (zero float64 output path).
     */
    @JvmStatic
    external fun getEpsilonString(projectorIdx: Int, value: String, axis: Int): String

    /**
     * Project an ADC integer directly (zero float64 shortcut).
     * @param adcValue raw ADC integer
     * @param maxValue ADC maximum (e.g., 2^31 for 32-bit)
     */
    @JvmStatic
    external fun projectAdc(projectorIdx: Int, adcValue: Long, maxValue: Long,
                             axis: Int, timestampNs: Long): DoubleArray?

    /**
     * Verify lossless round-trip: r → (k,d,ε) → r' = r.
     * @return true if round-trip is exact at WORK_DPS (400 decimal places)
     */
    @JvmStatic
    external fun verifyRoundtrip(rValue: String, N: Int): Boolean

    /** Get human-readable sensor type name */
    @JvmStatic
    external fun getSensorTypeName(sensorType: Int): String

    /** Get default R₀ for a sensor type */
    @JvmStatic
    external fun getDefaultR0(sensorType: Int): String

    /** Clean up all native projectors */
    @JvmStatic
    external fun cleanup()

    /** Get ET constants info string */
    @JvmStatic
    external fun getConstantsInfo(): String

    /* ═══════════════════════════════════════════════════════════════
     * Kotlin convenience wrappers
     * ═══════════════════════════════════════════════════════════════ */

    /**
     * Initialize a sensor projector with type-safe enum.
     */
    fun initProjector(type: SensorType, r0: String = "default", N: Int = 12): Int {
        return initSensorProjector(type.code, r0, N)
    }

    /**
     * Project and return a typed Projection result.
     */
    fun project(projectorIdx: Int, value: String,
                axis: Int = 0, timestampNs: Long = 0): Projection? {
        val raw = projectSensor(projectorIdx, value, axis, timestampNs) ?: return null
        val eps = getEpsilonString(projectorIdx, value, axis)

        return Projection(
            k = raw[0].toLong(),
            d = raw[1].toInt(),
            epsilon = eps,
            sign = raw[2].toInt(),
            isZero = raw[3].toInt() == 1,
            atBoundary = raw[4].toInt() == 1,
            N = raw[5].toInt()
        )
    }

    /**
     * Project ADC integer and return a typed Projection.
     */
    fun projectAdcValue(projectorIdx: Int, adcValue: Long, maxValue: Long,
                         axis: Int = 0, timestampNs: Long = 0): Projection? {
        val raw = projectAdc(projectorIdx, adcValue, maxValue, axis, timestampNs)
            ?: return null

        /* For ADC values, compute ε via the string path */
        val fracStr = if (adcValue == 0L) "0" else "$adcValue/$maxValue"
        val eps = getEpsilonString(projectorIdx, fracStr, axis)

        return Projection(
            k = raw[0].toLong(),
            d = raw[1].toInt(),
            epsilon = eps,
            sign = raw[2].toInt(),
            isZero = raw[3].toInt() == 1,
            atBoundary = raw[4].toInt() == 1,
            N = raw[5].toInt()
        )
    }
}
