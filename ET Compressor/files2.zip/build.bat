@echo off
REM ═══════════════════════════════════════════════════════════════════════
REM Exception Theory — CDF Compressor Build Script
REM Double-click to build: et_pattern_engine.dll + et_cdf_compressor.exe
REM
REM Requirements:
REM   - Python 3.8+ on PATH
REM   - Visual Studio 2022 Build Tools (or gcc/MinGW on PATH)
REM   - PyInstaller (auto-installed if missing)
REM
REM Output: dist\et_cdf_compressor11.exe (single portable .exe)
REM
REM P ∘ D ∘ T = E
REM ═══════════════════════════════════════════════════════════════════════

setlocal enabledelayedexpansion
cd /d "%~dp0"

echo ═══════════════════════════════════════════════════════════════
echo  ET CDF Compressor — Build Script
echo  P ∘ D ∘ T = E
echo ═══════════════════════════════════════════════════════════════
echo.

REM ── Step 1: Compile et_pattern_engine.dll ──────────────────────────

echo [1/3] Compiling C pattern engine...

set "DLL_NAME=et_pattern_engine.dll"
set "C_SRC=et_pattern_engine.c"
set "COMPILED=0"

REM Check if C source exists (optional — Python has embedded copy)
if not exist "%C_SRC%" (
    echo     Note: %C_SRC% not found — .exe will auto-compile from embedded source.
    echo     Skipping DLL pre-build.
    set "COMPILED=2"
    goto :skip_dll
)

REM Try VS2022 Build Tools
for %%V in (
    "C:\Program Files\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvarsall.bat"
    "C:\Program Files\Microsoft Visual Studio\2022\Community\VC\Auxiliary\Build\vcvarsall.bat"
    "C:\Program Files\Microsoft Visual Studio\2022\Professional\VC\Auxiliary\Build\vcvarsall.bat"
    "C:\Program Files\Microsoft Visual Studio\2022\Enterprise\VC\Auxiliary\Build\vcvarsall.bat"
    "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvarsall.bat"
) do (
    if exist %%V (
        echo     Found VS2022: %%V
        call %%V x64 >nul 2>&1
        cl /O2 /LD /Fe:"%DLL_NAME%" "%C_SRC%" >nul 2>&1
        if exist "%DLL_NAME%" (
            echo     Compiled %DLL_NAME% with MSVC
            set "COMPILED=1"
            goto :dll_done
        )
    )
)

REM Try gcc (MinGW)
where gcc >nul 2>&1
if %ERRORLEVEL% equ 0 (
    echo     Trying gcc...
    gcc -shared -O2 -o "%DLL_NAME%" "%C_SRC%" -lm >nul 2>&1
    if exist "%DLL_NAME%" (
        echo     Compiled %DLL_NAME% with gcc
        set "COMPILED=1"
        goto :dll_done
    )
)

echo     WARNING: No C compiler found. The .exe will auto-compile at runtime
echo     (requires a C compiler on the target machine) or use Python fallback.
set "COMPILED=2"

:dll_done
:skip_dll
echo.

REM ── Step 2: Ensure PyInstaller is installed ────────────────────────

echo [2/3] Checking PyInstaller...

python -m PyInstaller --version >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo     Installing PyInstaller...
    pip install pyinstaller --quiet
    if %ERRORLEVEL% neq 0 (
        echo     ERROR: Failed to install PyInstaller.
        echo     Run: pip install pyinstaller
        pause
        exit /b 1
    )
)
echo     PyInstaller ready.
echo.

REM ── Step 3: Build the single .exe ─────────────────────────────────

echo [3/3] Building single .exe...

set "PY_SCRIPT=et_cdf_compressor11.py"

if not exist "%PY_SCRIPT%" (
    echo     ERROR: %PY_SCRIPT% not found!
    pause
    exit /b 1
)

REM Build PyInstaller command
if "%COMPILED%"=="1" (
    REM DLL exists — bundle it into the .exe
    echo     Bundling %DLL_NAME% into .exe...
    python -m PyInstaller --onefile --add-binary "%DLL_NAME%;." --name "et_cdf_compressor11" "%PY_SCRIPT%" --noconfirm
) else (
    REM No DLL — the embedded C source will auto-compile at runtime
    echo     No pre-built DLL — embedded C source will auto-compile at runtime.
    python -m PyInstaller --onefile --name "et_cdf_compressor11" "%PY_SCRIPT%" --noconfirm
)

if %ERRORLEVEL% neq 0 (
    echo.
    echo     ERROR: PyInstaller failed!
    pause
    exit /b 1
)

echo.
echo ═══════════════════════════════════════════════════════════════
echo  BUILD COMPLETE
echo.
if exist "dist\et_cdf_compressor11.exe" (
    for %%F in ("dist\et_cdf_compressor11.exe") do echo  Output: %%~fF  ^(%%~zF bytes^)
) else (
    echo  WARNING: .exe not found in dist\ — check PyInstaller output above.
)
echo.
if "%COMPILED%"=="1" (
    echo  DLL: Pre-built and bundled in .exe
) else if "%COMPILED%"=="2" (
    echo  DLL: Not pre-built — will auto-compile from embedded source at runtime
) else (
    echo  DLL: Compilation failed — Python fallback will be used
)
echo ═══════════════════════════════════════════════════════════════
echo.

REM Clean up MSVC build artifacts
if exist "et_pattern_engine.obj" del "et_pattern_engine.obj" >nul 2>&1
if exist "et_pattern_engine.lib" del "et_pattern_engine.lib" >nul 2>&1
if exist "et_pattern_engine.exp" del "et_pattern_engine.exp" >nul 2>&1

pause
