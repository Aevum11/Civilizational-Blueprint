/* ============================================================================
 * test_et_med.c — Comprehensive verification suite for libet_med
 * ----------------------------------------------------------------------------
 *  Every public function is exercised; every verification baseline from the
 *  Projection Guide §51-54 is checked; every edge case (NULL, r<=0, non-finite)
 *  is tested for the correct error code.
 *
 *  Test categories:
 *    [A] Projection Primitives
 *    [B] Elegance and Impedance
 *    [C] Active-System Dynamics
 *    [D] Medical Towers and R0 derivation
 *    [E] Multifold Signature
 *    [F] State Classification and Incoherence Levels
 *    [G] Severity Score
 *    [H] Measurement -> Finding pipeline
 *    [I] Multi-measurement Findings Generation
 *    [J] Error handling and fallback counter
 *    [K] Edge cases
 *
 *  The harness prints [PASS]/[FAIL] per assertion and a summary at the end.
 *  Non-zero exit code if any assertion fails.
 * ========================================================================= */
#include "libet_med.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int g_pass_count = 0;
static int g_fail_count = 0;
static const char* g_current_section = "";

#define SECTION(name) do { \
    g_current_section = name; \
    printf("\n=== %s ===\n", name); \
} while(0)

#define CHECK(cond, fmt, ...) do { \
    if (cond) { \
        ++g_pass_count; \
        printf("  [PASS] " fmt "\n", ##__VA_ARGS__); \
    } else { \
        ++g_fail_count; \
        printf("  [FAIL] (%s:%d) " fmt "\n", __FILE__, __LINE__, ##__VA_ARGS__); \
    } \
} while(0)

#define CHECK_NEAR(actual, expected, tol, fmt, ...) do { \
    double _a = (actual), _e = (expected), _t = (tol); \
    double _d = fabs(_a - _e); \
    if (_d <= _t) { \
        ++g_pass_count; \
        printf("  [PASS] " fmt " (got %.6g, expected %.6g, diff %.3g)\n", ##__VA_ARGS__, _a, _e, _d); \
    } else { \
        ++g_fail_count; \
        printf("  [FAIL] (%s:%d) " fmt " (got %.6g, expected %.6g, diff %.3g)\n", __FILE__, __LINE__, ##__VA_ARGS__, _a, _e, _d); \
    } \
} while(0)

static void log_callback(et_error_t err, const char* file, int line,
                         const char* func, const char* message, void* ud) {
    (void)ud;
    /* Quiet by default in the harness — turn this on to see every fallback. */
    if (getenv("ET_TEST_VERBOSE") != NULL) {
        fprintf(stderr, "[log] %s (%s at %s:%d): %s\n",
                et_error_string(err), func, file, line, message);
    }
}

/* ========================================================================= */
/* [A] Projection Primitives                                                 */
/* ========================================================================= */
static void test_projection_primitives(void) {
    SECTION("[A] Projection Primitives — verification baselines");

    et_projection_t p;
    et_error_t e;

    /* unison r=1 -> (k=0, d=1, eps=0) at N=12 */
    e = et_project_real(1.0, 12, &p);
    CHECK(e == ET_OK, "et_project_real(1.0) returns OK");
    CHECK(p.k == 0,  "unison k == 0 (got %d)", p.k);
    CHECK(p.d == 1,  "unison d == 1 (got %d)", p.d);
    CHECK_NEAR(p.eps_cents, 0.0, 1e-9, "unison eps == 0");

    /* octave r=2 -> (k=12, d=1, eps=0) */
    e = et_project_real(2.0, 12, &p);
    CHECK(e == ET_OK, "et_project_real(2.0) returns OK");
    CHECK(p.k == 12, "octave k == 12 (got %d)", p.k);
    CHECK(p.d == 1,  "octave d == 1 (got %d)", p.d);
    CHECK_NEAR(p.eps_cents, 0.0, 1e-9, "octave eps == 0");

    /* perfect fifth r=3/2 -> (k=7, d=12, eps=+1.955¢) */
    e = et_project_real(1.5, 12, &p);
    CHECK(e == ET_OK, "et_project_real(1.5) returns OK");
    CHECK(p.k == 7,  "perfect fifth k == 7 (got %d)", p.k);
    CHECK(p.d == 12, "perfect fifth d == 12 (got %d)", p.d);
    CHECK_NEAR(p.eps_cents, 1.9550008653873928, 1e-6, "perfect fifth eps ≈ +1.955¢");

    /* Koide K=2/3 -> (k=-7, d=12, eps=-1.955¢) */
    e = et_project_real(2.0 / 3.0, 12, &p);
    CHECK(e == ET_OK, "et_project_real(2/3) returns OK");
    CHECK(p.k == -7, "Koide k == -7 (got %d)", p.k);
    CHECK(p.d == 12, "Koide d == 12 (got %d)", p.d);
    CHECK_NEAR(p.eps_cents, -1.9550008653873928, 1e-6, "Koide eps ≈ -1.955¢");

    /* tritone r=sqrt(2) -> (k=6, d=2, eps=0) */
    e = et_project_real(sqrt(2.0), 12, &p);
    CHECK(e == ET_OK, "et_project_real(sqrt 2) returns OK");
    CHECK(p.k == 6, "tritone k == 6 (got %d)", p.k);
    CHECK(p.d == 2, "tritone d == 2 (got %d)", p.d);
    CHECK_NEAR(p.eps_cents, 0.0, 1e-9, "tritone eps == 0");

    /* Error path: r <= 0 */
    et_reset_fallback_count();
    e = et_project_real(-1.0, 12, &p);
    CHECK(e == ET_ERR_INVALID_RATIO, "negative r returns INVALID_RATIO");
    e = et_project_real(0.0, 12, &p);
    CHECK(e == ET_ERR_INVALID_RATIO, "zero r returns INVALID_RATIO");

    /* Error path: NULL out */
    e = et_project_real(1.0, 12, NULL);
    CHECK(e == ET_ERR_INVALID_ARG, "NULL out returns INVALID_ARG");

    /* Imaginary projection: theta = 0 -> r = 1 -> unison */
    e = et_project_imag(0.0, 12, &p);
    CHECK(e == ET_OK, "et_project_imag(0) returns OK");
    CHECK(p.k == 0, "imag(0) k == 0 (got %d)", p.k);

    /* Imaginary projection: theta = 2*pi*7/12 (full-fifth phase)
     * 2^(7/12) = 1.49831... -> k=7 at N=12 */
    e = et_project_imag(6.283185307179586 * 7.0 / 12.0, 12, &p);
    CHECK(e == ET_OK, "et_project_imag(2*pi*7/12) returns OK");
    CHECK(p.k == 7, "imag(7/12 turn) k == 7 (got %d)", p.k);

    /* Complex projection */
    et_complex_projection_t cp;
    e = et_project_complex(1.5, 6.283185307179586 * 7.0 / 12.0, 12, &cp);
    CHECK(e == ET_OK, "et_project_complex returns OK");
    CHECK(cp.k_r == 7 && cp.k_theta == 7, "complex: both axes land at k=7");
    CHECK(cp.d_r == 12 && cp.d_theta == 12, "complex: both d = 12");
    CHECK(cp.d_combined == 12, "complex: combined d = lcm(12,12) = 12");
    CHECK(cp.D_fraction > 0.0 && cp.T_fraction > 0.0,
          "complex: D_frac=%.4f T_frac=%.4f (both > 0)", cp.D_fraction, cp.T_fraction);
    CHECK_NEAR(cp.D_fraction + cp.T_fraction, 1.0, 1e-9,
               "complex: D_frac + T_frac == 1");

    /* Multi-resolution */
    et_projection_t multi[8];
    int count = 0;
    e = et_project_multi(1.5, multi, 8, &count);
    CHECK(e == ET_OK, "et_project_multi(3/2) returns OK");
    CHECK(count == 6, "multi returned 6 landmarks (got %d)", count);
    /* At N=12, P5 sits at k=7. At N=420, k = round(420*log2(1.5)) = round(245.589) = 246
     * -> gcd(246, 420) = 6 -> d = 70. Just check first landmark is the 12ET result. */
    CHECK(multi[0].N == 12 && multi[0].k == 7, "multi[0] is 12ET k=7");

    /* Canonical LCM landmark enumeration */
    int lm[16];
    int lm_count = et_lcm_tower(lm, 16);
    CHECK(lm_count == 6, "et_lcm_tower returned 6 (got %d)", lm_count);
    CHECK(lm[0] == 12 && lm[5] == 27720,
          "et_lcm_tower bounds: 12 .. 27720 (got %d .. %d)", lm[0], lm[5]);
}

/* ========================================================================= */
/* [B] Elegance and Impedance                                                */
/* ========================================================================= */
static void test_elegance_and_impedance(void) {
    SECTION("[B] Elegance and Magical Impedance");

    /* xi(d) at canonical (S=4, A0=137) */
    CHECK_NEAR(et_magical_impedance(1,  4, 137), 137.0 / 16.0, 1e-9, "xi(1) = 8.5625");
    CHECK_NEAR(et_magical_impedance(2,  4, 137), 137.0 / 17.0, 1e-9, "xi(2) = 8.0588");
    CHECK_NEAR(et_magical_impedance(7,  4, 137), 137.0 / 52.0, 1e-9, "xi(7) = 2.6346");
    CHECK_NEAR(et_magical_impedance(12, 4, 137), 1.0,          1e-9, "xi(12) = 1.0 (unit reference)");

    /* Best rational approximation */
    int p, q;
    et_error_t e = et_best_rational(1.5, 12, &p, &q);
    CHECK(e == ET_OK && p == 3 && q == 2, "best_rational(1.5) = 3/2 (got %d/%d)", p, q);

    e = et_best_rational(1.0, 12, &p, &q);
    CHECK(e == ET_OK && p == 1 && q == 1, "best_rational(1.0) = 1/1 (got %d/%d)", p, q);

    e = et_best_rational(3.141592653589793, 113, &p, &q);
    CHECK(e == ET_OK && p == 355 && q == 113,
          "best_rational(pi, max 113) = 355/113 (got %d/%d)", p, q);

    /* Elegance score sanity */
    et_elegance_t el;
    e = et_elegance_score(1.0, 12, 12, &el);
    CHECK(e == ET_OK && el.d == 1 && el.p_plus_q == 2,
          "elegance(1.0): d=1 p+q=2 (got d=%d p+q=%d)", el.d, el.p_plus_q);
    CHECK(el.elegance > 0.0, "elegance(1.0) > 0 (got %.3f)", el.elegance);

    e = et_elegance_score(1.5, 12, 12, &el);
    CHECK(e == ET_OK && el.d == 12 && el.p == 3 && el.q == 2,
          "elegance(1.5): d=12 p/q=3/2 (got d=%d %d/%d)", el.d, el.p, el.q);

    /* A non-lattice-attractor ratio should have lower elegance than a simple one */
    et_elegance_t el_clean, el_messy;
    et_elegance_score(1.5, 12, 12, &el_clean);
    et_elegance_score(1.4142, 12, 12, &el_messy);
    /* 1.4142 approximates tritone (d=2) but is not exact — slightly lower elegance */
    CHECK(el_clean.elegance > 0.0 && el_messy.elegance > 0.0,
          "elegance sanity: both clean=%.2f messy=%.2f > 0", el_clean.elegance, el_messy.elegance);
}

/* ========================================================================= */
/* [C] Active-System Dynamics                                                */
/* ========================================================================= */
static void test_active_dynamics(void) {
    SECTION("[C] Active-System Dynamics");

    /* Palindromic cascade — exact sequence */
    int expected[12] = {12, 6, 4, 3, 12, 2, 12, 3, 4, 6, 12, 1};
    int ok = 1;
    for (int i = 0; i < 12; ++i) {
        int got = et_palindrome_d(i);
        if (got != expected[i]) { ok = 0; break; }
    }
    CHECK(ok, "palindromic cascade [12,6,4,3,12,2,12,3,4,6,12,1] exact");

    /* Wrap-around: n=12 should equal n=0, n=-1 should equal n=11 */
    CHECK(et_palindrome_d(12) == 12, "palindrome wraps: n=12 -> d=12");
    CHECK(et_palindrome_d(-1) == 1,  "palindrome wraps: n=-1 -> d=1");

    /* Shimmer: Psi_0 = 0, Psi_6 = sin(pi)*cos(pi/2) = 0 */
    CHECK_NEAR(et_shimmer(0), 0.0, 1e-12, "shimmer(0) = 0");
    CHECK_NEAR(et_shimmer(6), 0.0, 1e-12, "shimmer(6) = sin(pi)*cos(pi/2) = 0");
    CHECK(fabs(et_shimmer(3)) > 0.0, "shimmer(3) != 0 (got %.4f)", et_shimmer(3));

    /* Active state init */
    et_active_state_t st;
    et_error_t e = et_active_state_init(&st, 12);
    CHECK(e == ET_OK && st.N == 12 && st.n == 0 && st.history_len == 0,
          "active_state_init: N=12 n=0 history empty");
    CHECK_NEAR(st.z_real, 1.0, 1e-12, "active_state_init: z_real = 1");

    /* Single step at r=1 (unison) — no boundary crossing */
    e = et_active_step(&st, 1.0);
    CHECK(e == ET_OK, "active_step(r=1) OK");
    CHECK(st.n == 1 && st.history_len == 1, "after 1 step: n=1, hist=1");
    CHECK(st.cascade_depth == 0, "unison step: no cascade crossing");

    /* Step at r=2 (octave, still d=1, eps=0) — no crossing */
    e = et_active_step(&st, 2.0);
    CHECK(e == ET_OK, "active_step(r=2) OK");
    CHECK(st.cascade_depth == 0, "octave step: no cascade crossing");

    /* Tightness after two on-attractor steps should be 1.0 */
    CHECK_NEAR(et_tightness(&st), 1.0, 1e-9, "tightness on-attractor = 1");

    /* Step at r close to tritone — eps near 0 still (d=2). */
    e = et_active_step(&st, sqrt(2.0));
    CHECK(e == ET_OK, "active_step(r=sqrt2) OK");
    CHECK_NEAR(et_tightness(&st), 1.0, 1e-6, "tritone tightness ≈ 1 (eps=0)");

    /* Step at a ratio that lands eps clearly past the ET-derived boundary.
     * The boundary is at |eps| = 50*K_Koide = 100/3 ≈ 33.33¢ (derived, not
     * tuned — see et_active.c comment). We pick r = 2^(0.4/12) to land
     * eps = +40¢, unambiguously past the 33.33¢ crossing line. */
    e = et_active_step(&st, pow(2.0, 0.4 / 12.0));
    CHECK(e == ET_OK, "active_step(r=2^(0.4/12)) OK");
    CHECK(st.cascade_depth >= 1,
          "dI crossing detected after step past 33.33¢ (cascade=%d, expected >=1)",
          st.cascade_depth);

    /* Step back to r=1 -> back across the boundary (another crossing) */
    e = et_active_step(&st, 1.0);
    CHECK(e == ET_OK, "active_step(r=1 returning) OK");
    CHECK(st.cascade_depth >= 2,
          "second crossing detected (cascade=%d, expected >=2)", st.cascade_depth);
}

/* ========================================================================= */
/* [D] Medical Towers and R0 derivation                                      */
/* ========================================================================= */
static void test_towers(void) {
    SECTION("[D] Medical Towers and R0 derivation");

    /* Default R0s */
    CHECK_NEAR(et_tower_default_R0(ET_TOWER_CARDIAC),       1.0,      1e-9, "cardiac R0 = 1 s (at HR=60)");
    CHECK_NEAR(et_tower_default_R0(ET_TOWER_RESPIRATORY),   5.0,      1e-9, "respiratory R0 = 5 s (at RR=12)");
    CHECK_NEAR(et_tower_default_R0(ET_TOWER_NEURAL),        0.025,    1e-9, "neural R0 = 25 ms");
    CHECK_NEAR(et_tower_default_R0(ET_TOWER_ENDOCRINE),     86400.0,  1e-9, "endocrine R0 = 1 day");
    CHECK_NEAR(et_tower_default_R0(ET_TOWER_IMMUNE),        86400.0,  1e-9, "immune R0 = 1 day");
    CHECK_NEAR(et_tower_default_R0(ET_TOWER_MUSCULOSKELETAL),1.0,     1e-9, "musculoskeletal R0 = 1 s");
    CHECK(et_tower_default_R0(ET_TOWER_REPRODUCTIVE) > 2400000.0,
          "reproductive R0 ~ 28 days (got %.0f s)",
          et_tower_default_R0(ET_TOWER_REPRODUCTIVE));
    CHECK(et_tower_default_R0(ET_TOWER_DEVELOPMENTAL) > 700000000.0,
          "developmental R0 ~ 25 years (got %.3e s)",
          et_tower_default_R0(ET_TOWER_DEVELOPMENTAL));

    /* Tower resolutions */
    CHECK(et_tower_resolution(ET_TOWER_CARDIAC)  == 12,     "cardiac N = 12");
    CHECK(et_tower_resolution(ET_TOWER_NEURAL)   == 27720,  "neural N = 27720 (cortical floor)");
    CHECK(et_tower_resolution(ET_TOWER_IMMUNE)   == 420,    "immune N = 420 (biological floor)");
    CHECK(et_tower_resolution(ET_TOWER_REPRODUCTIVE) == 84, "reproductive N = 84 (septic)");

    /* Tower names */
    CHECK(strcmp(et_tower_name(ET_TOWER_CARDIAC), "Cardiac") == 0,
          "cardiac name = Cardiac (got %s)", et_tower_name(ET_TOWER_CARDIAC));

    /* Reference baseline values */
    CHECK_NEAR(et_tower_reference_baseline_value(ET_TOWER_CARDIAC),
               60.0, 1e-9, "cardiac reference baseline = 60 bpm");
    CHECK_NEAR(et_tower_reference_baseline_value(ET_TOWER_RESPIRATORY),
               12.0, 1e-9, "respiratory reference baseline = 12/min");
    CHECK_NEAR(et_tower_reference_baseline_value(ET_TOWER_ENDOCRINE),
               36.85, 1e-9, "endocrine reference baseline = 36.85 C");
    CHECK_NEAR(et_tower_reference_baseline_value(ET_TOWER_MUSCULOSKELETAL),
               1.0, 1e-9, "musculoskeletal reference baseline = 1.0 s");
    CHECK(isnan(et_tower_reference_baseline_value(ET_TOWER_NEURAL)),
          "neural reference baseline = NaN (no natural scalar)");

    /* Personal R0 derivation */
    et_patient_baseline_t bl;
    et_patient_baseline_init(&bl);
    bl.hr_rest_bpm       = 50.0;   /* athlete */
    bl.rr_rest_per_min   = 10.0;
    bl.temperature_c     = 36.8;
    bl.gait_cycle_s      = 1.1;
    bl.menstrual_cycle_d = 29.0;
    bl.age_years         = 30.0;
    bl.sex               = ET_SEX_FEMALE;

    double R0;
    et_error_t e;
    e = et_derive_personal_R0(&bl, ET_TOWER_CARDIAC, 0, &R0);
    CHECK(e == ET_OK, "personal cardiac R0 derives from HR=50");
    CHECK_NEAR(R0, 60.0 / 50.0, 1e-9, "cardiac R0 = 60/50 = 1.2 s");

    e = et_derive_personal_R0(&bl, ET_TOWER_REPRODUCTIVE, 0, &R0);
    CHECK(e == ET_OK, "personal reproductive R0 derives for female with menstrual data");
    CHECK_NEAR(R0, 29.0 * 86400.0, 1e-6, "reproductive R0 = 29 days = 2505600 s");

    /* Male reproductive */
    bl.sex = ET_SEX_MALE;
    e = et_derive_personal_R0(&bl, ET_TOWER_REPRODUCTIVE, 0, &R0);
    CHECK(e == ET_OK, "personal reproductive R0 derives for male");
    CHECK_NEAR(R0, 74.0 * 86400.0, 1e-6, "male reproductive R0 = 74 days");

    /* Missing field: no fallback -> INCOMPLETE_BASELINE */
    et_patient_baseline_init(&bl);
    e = et_derive_personal_R0(&bl, ET_TOWER_CARDIAC, 0, &R0);
    CHECK(e == ET_ERR_INCOMPLETE_BASELINE,
          "missing HR with fallback=0 returns INCOMPLETE_BASELINE");

    /* Missing field: with fallback -> uses default, logs fallback */
    et_reset_fallback_count();
    e = et_derive_personal_R0(&bl, ET_TOWER_CARDIAC, 1, &R0);
    CHECK(e == ET_OK, "missing HR with fallback=1 returns OK");
    CHECK_NEAR(R0, 1.0, 1e-9, "fallback cardiac R0 = 1.0");
    CHECK(et_fallback_count() >= 1,
          "fallback counter incremented (got %zu)", et_fallback_count());
}

/* ========================================================================= */
/* [E] Multifold Signature                                                   */
/* ========================================================================= */
static void test_multifold(void) {
    SECTION("[E] Multifold Signature");

    et_patient_baseline_t bl;
    et_patient_baseline_init(&bl);
    bl.hr_rest_bpm       = 60.0;
    bl.rr_rest_per_min   = 12.0;
    bl.temperature_c     = 36.8;
    bl.gait_cycle_s      = 1.0;
    bl.menstrual_cycle_d = 28.0;
    bl.sex               = ET_SEX_FEMALE;
    bl.age_years         = 30.0;

    et_multifold_signature_t mf;
    et_error_t e = et_compute_multifold_signature(&bl, 1, &mf);
    CHECK(e == ET_OK, "compute_multifold_signature OK");
    CHECK(mf.R0_seconds[ET_TOWER_CARDIAC] > 0.0,   "cardiac R0 > 0");
    CHECK(mf.R0_seconds[ET_TOWER_NEURAL]  > 0.0,   "neural R0 > 0");
    CHECK(mf.R0_present[ET_TOWER_CARDIAC] == 1,    "cardiac R0 came from baseline");
    CHECK(mf.R0_present[ET_TOWER_RESPIRATORY] == 1,"respiratory R0 came from baseline");
    CHECK(isfinite(mf.multifold_log_scalar),
          "multifold_log_scalar finite (got %.3g)", mf.multifold_log_scalar);

    /* Pair index verification */
    int idx_0_1 = et_pair_index(0, 1);
    int idx_1_0 = et_pair_index(1, 0);
    CHECK(idx_0_1 == 0, "pair_index(0,1) = 0 (got %d)", idx_0_1);
    CHECK(idx_0_1 == idx_1_0, "pair_index symmetric in args");
    int idx_last = et_pair_index(ET_TOWER_COUNT - 2, ET_TOWER_COUNT - 1);
    int last_expected = ET_TOWER_COUNT * (ET_TOWER_COUNT - 1) / 2 - 1;
    CHECK(idx_last == last_expected,
          "pair_index(last,last-1) = %d (got %d)", last_expected, idx_last);
}

/* ========================================================================= */
/* [F] State Classification and Incoherence Levels                           */
/* ========================================================================= */
static void test_state_classification(void) {
    SECTION("[F] State Classification and Incoherence Levels");

    /* On attractor, low d -> Exception */
    CHECK(et_classify_state(0.0, 1, 1.0) == ET_STATE_EXCEPTION,
          "(|eps|=0, d=1) -> Exception");
    CHECK(et_classify_state(2.0, 2, 0.98) == ET_STATE_EXCEPTION,
          "(|eps|=2, d=2) -> Exception");

    /* On attractor, high d -> Unsubstantiated */
    CHECK(et_classify_state(0.5, 7, 0.99) == ET_STATE_UNSUBSTANTIATED,
          "(|eps|=0.5, d=7) -> Unsubstantiated");

    /* In-transit (5..50) -> Mediation */
    CHECK(et_classify_state(20.0, 12, 0.83) == ET_STATE_MEDIATION,
          "(|eps|=20, d=12) -> Mediation");
    CHECK(et_classify_state(49.0, 1, 0.67) == ET_STATE_MEDIATION,
          "(|eps|=49, d=1) -> Mediation (just under boundary)");

    /* Beyond 50 -> Incoherence */
    CHECK(et_classify_state(51.0, 1, 0.66) == ET_STATE_INCOHERENCE,
          "(|eps|=51, d=1) -> Incoherence");
    CHECK(et_classify_state(100.0, 12, 0.5) == ET_STATE_INCOHERENCE,
          "(|eps|=100, d=12) -> Incoherence");

    /* Incoherence levels */
    et_incoherence_level_t L;
    L = et_classify_incoherence_level(ET_STATE_EXCEPTION, 0.0, 1, 0, 1.0);
    CHECK(L == ET_INCOH_NONE, "Exception state -> INCOH_NONE");

    L = et_classify_incoherence_level(ET_STATE_INCOHERENCE, 55.0, 1, 0, 1.0);
    CHECK(L == ET_INCOH_L4_STABILITY,
          "Incoherence, just over boundary, low d -> L4 Stability");

    L = et_classify_incoherence_level(ET_STATE_INCOHERENCE, 60.0, 5, 0, 1.0);
    CHECK(L == ET_INCOH_L2_BINDING, "Incoherence, d=5 prime -> L2 Binding");

    L = et_classify_incoherence_level(ET_STATE_INCOHERENCE, 60.0, 12, 30, 1.0);
    CHECK(L == ET_INCOH_L3_CASCADE, "Incoherence, cascade_depth>24 -> L3 Cascade");

    L = et_classify_incoherence_level(ET_STATE_INCOHERENCE, 60.0, 12, 0, 1e-6);
    CHECK(L == ET_INCOH_L5_COHERENCE, "Incoherence, M < V^2 -> L5 Coherence");
}

/* ========================================================================= */
/* [G] Severity Score                                                        */
/* ========================================================================= */
static void test_severity(void) {
    SECTION("[G] Severity Score");

    /* At |eps|=0 with d=1, the state classifier returns Exception, so the
     * state gate is 0 and the primary axis is 0. Complexity at d=1 is also 0
     * (since complexity_norm = (d-1)/(N-1)). With cascade=0, traj=0 too.
     * Total raw score should be exactly 0 — a patient on-attractor has no
     * severity, regardless of the sublattice family's "structural weight". */
    double raw_min = et_severity_score_raw(0.0, 1, 0.0, 12.0, 0, 12);
    CHECK_NEAR(raw_min, 0.0, 1e-12, "raw score at (eps=0, d=1) == 0 (Exception, not 'severe impedance')");

    /* True max: state=Incoherence (|eps|>=50), d=N (complexity_norm=1),
     * cascade full. At d=12, imp_norm = xi(12)/xi(1) = 1/8.5625. So the
     * primary term is g * 1 * (1/8.5625) = 0.1167, NOT 1.0. To hit the
     * TRUE maximum of 1 + 1/12 + 1/132, we need d=1 (imp=1, primary=1.0)
     * AND complexity at max, which requires d=N=1... impossible since d=1
     * forces complexity=0. The practical max is therefore at d=1 (primary
     * saturated) with trajectory saturated: 1 + 1/12 = 13/12 ≈ 1.0833. */
    double raw_at_d1  = et_severity_score_raw(50.0, 1, 1.0, 12.0, 24, 12);
    double expected_1 = 1.0 + 1.0/12.0;   /* primary saturated, complex=0 at d=1 */
    CHECK_NEAR(raw_at_d1, expected_1, 1e-9, "raw at (|eps|=50, d=1, cascade full) = 13/12");

    /* At d=12 (complexity saturated, impedance minimized), raw =
     *   primary   = 1 * 1 * (1/8.5625) = 0.1167
     *   traj      = 1/12 = 0.0833
     *   complex   = (1/132) * 1 * (1/8.5625) ≈ 0.000884
     *   total     ≈ 0.2009 */
    double raw_at_d12 = et_severity_score_raw(50.0, 12, 12.0, 12.0, 24, 12);
    double xi_max_inv = 16.0 / 137.0;  /* 1/xi_max */
    double expected_12 = 1.0 * 1.0 * xi_max_inv + 1.0/12.0 + (1.0/132.0) * 1.0 * xi_max_inv;
    CHECK_NEAR(raw_at_d12, expected_12, 1e-6, "raw at (|eps|=50, d=12, cascade full) matches state-gated formula");

    /* Normalized maximum — et_severity_score_max_raw returns the theoretical
     * envelope (primary=1, traj=1, complex=1), not necessarily hit by any
     * single (d, N) pair. This is deliberate: pct values in [0,100] are
     * meaningful regardless of whether a given lattice combo can reach 100. */
    double max_env = et_severity_score_max_raw();
    CHECK_NEAR(max_env, 1.0 + 1.0/12.0 + 1.0/132.0, 1e-12,
               "theoretical max envelope = 1 + 1/12 + 1/132");

    /* Percentage normalization */
    double pct_at_d1 = et_severity_score_pct(raw_at_d1);
    /* 13/12 divided by (13/12 + 1/132) = 143/(143+1) = 143/144 ≈ 99.31% */
    CHECK_NEAR(pct_at_d1, 100.0 * (13.0/12.0) / max_env, 1e-6,
               "d=1 pct ≈ 99.3%% (complexity axis inaccessible at d=1)");
    double pct_zero = et_severity_score_pct(0.0);
    CHECK_NEAR(pct_zero, 0.0, 1e-12, "pct at 0 = 0");

    /* Clinical sanity: HR=60 -> r=1 -> Exception -> severity=0 */
    double sev_healthy = et_severity_score_raw(0.0, 1, 0, 12, 0, 12);
    CHECK_NEAR(sev_healthy, 0.0, 1e-12, "healthy HR=60 -> severity=0 (Exception gate)");

    /* HR=120 -> r=2 -> octave (k=12, d=1, eps=0) -> still Exception -> severity=0 */
    double sev_octave = et_severity_score_raw(0.0, 1, 0, 12, 0, 12);
    CHECK_NEAR(sev_octave, 0.0, 1e-12, "octave HR=120 -> severity=0 (Exception gate)");

    /* Mediation at |eps|=30, d=12: gate=2/3, spatial=0.6, imp=1/8.5625 ≈ 0.117
     * primary = (2/3) * 0.6 * 0.117 = 0.0467
     * complexity = (1/132)*1*0.117 ≈ 0.000884
     * total ≈ 0.0476 -> pct ≈ 4.4% */
    double sev_med = et_severity_score_raw(30.0, 12, 12, 12, 0, 12);
    CHECK(sev_med > 0.0 && sev_med < 0.1, "Mediation mild: raw in (0, 0.1)  got %.4f", sev_med);

    /* Invalid inputs */
    et_reset_fallback_count();
    double bad = et_severity_score_raw(-1.0, 1, 0, 12, 0, 1);
    CHECK(isnan(bad), "negative eps -> NaN");
    bad = et_severity_score_raw(0.0, 0, 0, 12, 0, 1);
    CHECK(isnan(bad), "d<1 -> NaN");
}

/* ========================================================================= */
/* [H] Measurement -> Finding                                                */
/* ========================================================================= */
static void test_measurement_finding(void) {
    SECTION("[H] Measurement -> Finding pipeline");

    et_patient_baseline_t bl;
    et_patient_baseline_init(&bl);
    bl.hr_rest_bpm     = 60.0;
    bl.rr_rest_per_min = 12.0;
    bl.temperature_c   = 36.8;
    bl.age_years       = 30.0;
    bl.sex             = ET_SEX_MALE;

    /* A healthy measurement: HR=60 at baseline -> r=1 -> Exception */
    et_measurement_t m;
    et_measurement_init(&m);
    strcpy(m.name, "HR");
    m.current_value = 60.0;
    m.tower         = ET_TOWER_CARDIAC;
    strcpy(m.units, "bpm");

    et_finding_t f;
    et_error_t e = et_classify_measurement(&m, &bl, 0, &f);
    CHECK(e == ET_OK, "classify HR=60 at baseline=60 OK");
    CHECK(f.state == ET_STATE_EXCEPTION, "HR=60 -> Exception");
    CHECK(f.projection.k == 0 && f.projection.d == 1,
          "HR=60: k=0 d=1 (got k=%d d=%d)", f.projection.k, f.projection.d);

    /* Tachycardia: HR=120 -> r=2 -> still d=1 Exception (octave) */
    m.current_value = 120.0;
    e = et_classify_measurement(&m, &bl, 0, &f);
    CHECK(e == ET_OK, "classify HR=120 OK");
    CHECK(f.projection.k == 12 && f.projection.d == 1,
          "HR=120: octave k=12 d=1");
    /* Octave at d=1 is still Exception per our classifier (|eps|=0, d=1 <=4). */
    CHECK(f.state == ET_STATE_EXCEPTION,
          "HR=120 (octave of 60): Exception class (note: clinically abnormal, the lattice flags it as structurally stable doubling)");

    /* Bradycardia: HR=40 -> r=2/3 = Koide -> k=-7 d=12 |eps|≈1.955 */
    m.current_value = 40.0;
    e = et_classify_measurement(&m, &bl, 0, &f);
    CHECK(e == ET_OK, "classify HR=40 OK");
    CHECK(f.projection.k == -7 && f.projection.d == 12,
          "HR=40 (Koide): k=-7 d=12 (got k=%d d=%d)", f.projection.k, f.projection.d);
    /* |eps|=1.955 < 5 AND d=12 > 4 -> Unsubstantiated (latent) */
    CHECK(f.state == ET_STATE_UNSUBSTANTIATED,
          "HR=40 (Koide attractor, d=12): Unsubstantiated (latent, d>4)");

    /* Critical HR = 90 -> r=1.5 -> perfect fifth, |eps|=1.955 d=12 -> Unsubstantiated */
    m.current_value = 90.0;
    e = et_classify_measurement(&m, &bl, 0, &f);
    CHECK(e == ET_OK, "classify HR=90 OK");
    CHECK(f.projection.d == 12,
          "HR=90 (P5): d=12 (got d=%d)", f.projection.d);

    /* Severity is non-negative and in [0,100] */
    CHECK(f.severity_score_pct >= 0.0 && f.severity_score_pct <= 100.0,
          "severity_pct in [0,100] (got %.2f)", f.severity_score_pct);
}

/* ========================================================================= */
/* [I] Multi-measurement findings generation + sorting                       */
/* ========================================================================= */
static void test_findings_generation(void) {
    SECTION("[I] Multi-measurement findings generation");

    et_patient_baseline_t bl;
    et_patient_baseline_init(&bl);
    bl.hr_rest_bpm     = 60.0;
    bl.rr_rest_per_min = 12.0;
    bl.temperature_c   = 36.8;
    bl.age_years       = 45.0;
    bl.sex             = ET_SEX_MALE;

    et_measurement_t ms[3];
    et_measurement_init(&ms[0]);
    strcpy(ms[0].name, "HR");
    ms[0].current_value = 60.0;  ms[0].tower = ET_TOWER_CARDIAC;

    et_measurement_init(&ms[1]);
    strcpy(ms[1].name, "RR");
    ms[1].current_value = 40.0;  /* severe abnormality */
    ms[1].tower = ET_TOWER_RESPIRATORY;

    et_measurement_init(&ms[2]);
    strcpy(ms[2].name, "Temp");
    ms[2].current_value = 38.5;  /* fever */
    ms[2].tower = ET_TOWER_ENDOCRINE;

    et_finding_t* findings = NULL;
    int count = 0;
    et_error_t e = et_generate_findings(ms, 3, &bl, 1, &findings, &count);
    CHECK(e == ET_OK, "generate_findings OK");
    CHECK(count == 3, "3 findings produced (got %d)", count);

    /* Sort order: most severe first. Our abnormal measurements should be
     * ranked higher than HR=60 (Exception). */
    if (count == 3 && findings != NULL) {
        /* The Exception-state finding (HR=60) should be ranked LAST. */
        int exc_last = -1;
        for (int i = 0; i < count; ++i) {
            if (findings[i].state == ET_STATE_EXCEPTION) exc_last = i;
        }
        CHECK(exc_last == count - 1 || exc_last == -1,
              "Exception finding ranked last or absent (idx=%d)", exc_last);

        /* Urgency rank is 1..count */
        int ok_rank = 1;
        for (int i = 0; i < count; ++i) {
            if (findings[i].urgency_rank != i + 1) ok_rank = 0;
        }
        CHECK(ok_rank, "urgency ranks are 1..%d sequentially", count);

        /* Per-finding description is non-empty */
        CHECK(findings[0].description[0] != '\0', "first finding has description");
        CHECK(findings[0].name[0] != '\0', "first finding has name");
    }
    et_free_findings(findings, count);
}

/* ========================================================================= */
/* [J] Error handling and fallback counter                                   */
/* ========================================================================= */
static void test_error_handling(void) {
    SECTION("[J] Error handling and fallback counter");

    et_set_log_callback(log_callback, NULL);
    CHECK(et_get_log_callback() == log_callback, "log callback set/get");

    et_reset_fallback_count();
    CHECK(et_fallback_count() == 0, "fallback count reset to 0");

    /* Trigger a fallback: non-canonical lattice N (like 13) */
    et_projection_t p;
    et_error_t e = et_project_real(1.5, 13, &p);
    CHECK(e == ET_OK, "non-canonical N=13 still projects (research grade)");
    CHECK(et_fallback_count() >= 1, "fallback counter incremented for N=13");

    /* Trigger an error */
    et_reset_fallback_count();
    e = et_project_real(-1.0, 12, &p);
    CHECK(e == ET_ERR_INVALID_RATIO, "negative r -> INVALID_RATIO");
    CHECK(et_fallback_count() >= 1, "counter also records errors");

    /* Every error code has a string */
    for (int i = 0; i < ET_ERR_LAST; ++i) {
        const char* s = et_error_string((et_error_t)i);
        CHECK(s != NULL && s[0] != '\0',
              "error_string(%d) = '%s'", i, s ? s : "(null)");
    }
}

/* ========================================================================= */
/* [K] Edge cases                                                            */
/* ========================================================================= */
static void test_edge_cases(void) {
    SECTION("[K] Edge cases");

    /* NaN / Inf */
    et_projection_t p;
    et_error_t e = et_project_real(NAN, 12, &p);
    CHECK(e == ET_ERR_INVALID_RATIO, "NaN r -> INVALID_RATIO");
    e = et_project_real(INFINITY, 12, &p);
    CHECK(e == ET_ERR_INVALID_RATIO, "+Inf r -> INVALID_RATIO");
    e = et_project_real(-INFINITY, 12, &p);
    CHECK(e == ET_ERR_INVALID_RATIO, "-Inf r -> INVALID_RATIO");

    /* N=0 -> INVALID_N */
    e = et_project_real(1.5, 0, &p);
    CHECK(e == ET_ERR_INVALID_N, "N=0 -> INVALID_N");
    e = et_project_real(1.5, -12, &p);
    CHECK(e == ET_ERR_INVALID_N, "N<0 -> INVALID_N");

    /* Very large r (but finite) */
    e = et_project_real(1e100, 12, &p);
    CHECK(e == ET_OK, "very large finite r OK");
    CHECK(p.N == 12, "N preserved");

    /* Very small r */
    e = et_project_real(1e-100, 12, &p);
    CHECK(e == ET_OK, "very small finite r OK");

    /* Constants are accessible */
    CHECK(ET_N_PRIMITIVES == 3, "ET_N_PRIMITIVES = 3");
    CHECK(ET_S_STATES == 4, "ET_S_STATES = 4");
    CHECK(ET_N_MANIFOLD_12 == 12, "ET_N_MANIFOLD_12 = 12");
    CHECK_NEAR(ET_V_BASE, 1.0/12.0, 1e-15, "ET_V_BASE = 1/12");
    CHECK_NEAR(ET_K_KOIDE, 2.0/3.0, 1e-15, "ET_K_KOIDE = 2/3");
    CHECK(ET_A0_LOCAL_EM == 137, "ET_A0_LOCAL_EM = 137");
    CHECK(ET_BIOLOGICAL_FLOOR == 420, "ET_BIOLOGICAL_FLOOR = 420");
    CHECK(ET_CORTICAL_FLOOR == 27720, "ET_CORTICAL_FLOOR = 27720");
}

/* ========================================================================= */
/* Main                                                                      */
/* ========================================================================= */
int main(void) {
    printf("=========================================================\n");
    printf("  libet_med %s — verification test suite\n", LIBET_MED_VERSION_STRING);
    printf("=========================================================\n");

    et_set_log_callback(log_callback, NULL);

    test_projection_primitives();
    test_elegance_and_impedance();
    test_active_dynamics();
    test_towers();
    test_multifold();
    test_state_classification();
    test_severity();
    test_measurement_finding();
    test_findings_generation();
    test_error_handling();
    test_edge_cases();

    printf("\n=========================================================\n");
    printf("  SUMMARY:  %d passed,  %d failed   (of %d total)\n",
           g_pass_count, g_fail_count, g_pass_count + g_fail_count);
    printf("  Fallback counter at end: %zu\n", et_fallback_count());
    printf("=========================================================\n");

    return (g_fail_count == 0) ? 0 : 1;
}
