# ET Medical App

An ET-native medical projection framework that maps a patient's vital signs
and subsystem rhythms onto the ET lattice as a multifold of co-traversable
towers, classifies each measurement against the Four Manifold States
({P,D,T} Exception / {P,D} Unsubstantiated / {D,T} Mediation /
{P,T} Incoherence), and scores findings by a state-gated, impedance-amplified
severity metric derived from manifold constants (no tuning).

## Status

| Phase | Artifact | Status |
|------:|----------|:------:|
| 0 | Master Design Document (~1500-line MD) | ✅ complete |
| 1 | `libet_med` C core — projection primitives, elegance, impedance, active-system dynamics, 10 medical towers, multifold signature, state classification, severity scoring, findings generator | ✅ complete, 180/180 tests pass |
| 2a | Windows `.NET` P/Invoke wrapper | ✅ source complete (not MSVC-tested) |
| 2b | Android JNI + Kotlin Compose wrapper | ✅ source complete (not NDK-tested) |
| 2c | Browser WebAssembly wrapper | ✅ source complete (not Emscripten-built due to sandbox egress block) |
| 3+ | Medical ontology bridge, longitudinal/wearable integration, validation | ⏳ future phases |

## Layout

```
et_medical/
├── ET_Medical_App_Master_Design_v1.md   Master design document
├── ET_Medical_Journal.md                 Work log across sessions
├── libet_med/                            C core (production library)
│   ├── include/libet_med.h               Public C ABI (single header)
│   ├── src/                              8 C files per ET module
│   ├── test/
│   │   ├── test_et_med.c                 Verification suite (180 assertions)
│   │   ├── et_med_cli.c                  CLI demo
│   │   └── abi_probe.c                   Struct-layout verifier
│   └── CMakeLists.txt                    Cross-platform build
└── wrappers/
    ├── windows/                          P/Invoke binding (C#/.NET)
    ├── android/                          JNI + Kotlin + Compose
    └── browser/                          WebAssembly + JS facade
```

## Building the C core

```bash
cd libet_med
cmake -S . -B build
cmake --build build -j
ctest --test-dir build --output-on-failure
```

Artifacts: `build/libet_med.a`, `build/libet_med.so.1.0.0`,
`build/test_et_med`, `build/et_med_cli`, `build/abi_probe`.

## Running the CLI demo

```bash
./build/et_med_cli                    # built-in demo patient
./build/et_med_cli --help             # usage
./build/et_med_cli --hr-rest 55 --rr-rest 14 --sex female \
                   --measure HR 120 bpm CARDIAC \
                   --measure RR 30 /min RESPIRATORY
```

## Key design decisions (per ET corpus)

- **Universal Human Seed** R₀⁽ʰᵘᵐᵃⁿ⁾ = 60 / HR_rest seconds (resting cardiac
  period) — smallest closed T-traversal loop of the integrated organism
  (Level 8 in the nested traverser stack).
- **10 subsystem towers** — cardiac, respiratory, neural, endocrine, immune,
  digestive, renal, musculoskeletal, reproductive, developmental. Each has
  its own substrate-derived R₀.
- **Lattice-resolution hierarchy** — 12ET for base vitals, 60ET for
  qualia/pain, 84ET for septic/weekly cycles, 420ET for biological (5,7)
  co-binding, 27720ET for cortical 11-D cliques per Blue Brain 2017.
- **Severity formula** — state-gated, impedance-amplified:
  `S = g(state) · (|ε|/50) · (ξ(d)/ξ_max) + (1/12)·traj + (1/132)·complex·(ξ(d)/ξ_max)`
  where `g ∈ {0, 1/3, 2/3, 1}` for {Exception, Unsubstantiated, Mediation,
  Incoherence} — the primitive-count step on the Four Manifold States. An
  on-attractor patient has S=0 by construction; no tuning.
- **Multifold scalar** — geometric mean of pairwise elegance scores
  (scale-invariant), plus a `normalized_vs_reference` ratio where 1.0 =
  population baseline, «1 = multifold collapse (L5 Coherence incoherence).
- **Palindromic cascade** `[12,6,4,3,12,2,12,3,4,6,12,1]` — generator-7
  orbit on the 12-fold manifold, used as a matching filter for longitudinal
  data.
- **∂I boundary event detection** at `|ε| = 50·K_Koide = 100/3 ≈ 33.33¢`
  (the Koide-derived locus inside the half-octave where tightness
  `t = 100/(100+|ε|)` crosses K=2/3).
- **All fallbacks logged** via `_et_error(ET_ERR_FALLBACK_USED, ...)` —
  Rule 33 compliant, silent fallbacks are forbidden.

## Verification baselines (passing in `test_et_med`)

| Ratio | N | k | d | ε |
|------:|:-:|:-:|:-:|:--:|
| 1 (unison) | 12 | 0 | 1 | 0 |
| 2 (octave) | 12 | 12 | 1 | 0 |
| 3/2 (perfect fifth) | 12 | 7 | 12 | +1.955¢ |
| 2/3 (Koide) | 12 | -7 | 12 | -1.955¢ |
| √2 (tritone) | 12 | 6 | 2 | 0 |

## Untouched corpus items (Phase 3+)

- Medical ontology bridge — mapping every finding to ICD-11 / ICF / SNOMED
  codes (chapter d-fingerprinting table in the Master Design Part VII is
  the spec for this).
- Extended patient baseline — EEG dominant-frequency for neural tower R₀,
  GFR for renal tower, telomere / epigenetic-clock data for developmental.
- Active-system longitudinal mode — wearable integration for continuous HR,
  RR, temperature, step rate; full palindromic-cascade matching-filter on
  streaming data.
- FQG (Force Quadrant Grid) 144-cell pathology mapping — cross-complex
  cells (d_r, d_θ) as combined diagnostic fingerprints.
