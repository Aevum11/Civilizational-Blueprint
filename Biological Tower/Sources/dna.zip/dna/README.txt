What does each table type contain?

*.specification.dat indicates the alphabet and pairs.

*.coaxial.* are parameters for flush coaxial stacking where two helix ends stack without an intervening mismatch.

*.coaxstack.* are parameters for coaxial stacking of helices with an intervening mismatch. This is for the stack where the backbone is not continuous.

*.dangle.* are parameters for dangling ends on pairs.

*.hexaloop.* are parameters for hairpin loops of 6 unpaired nucleotides that have stabilities not well modeled by the parameters.

*.int11.* are parameters for 1×1 internal loops.

*.int21.* are parameters for 2×1 internal loops.

*.int22.* are parameters for 2×2 internal loops.

*.loop.* are parameters for loop initiations.

*.miscloop.* are parameters that do not fit into other tables.

*.stack.* are parameters for helical stacking.

*.tloop.* are parameters for hairpin loops of 4 unpaired nucleotides that have stabilities not well modeled by the parameters.

*.triloop.* are parameters for hairpin loops of 3 unpaired nucleotides that have stabilities not well modeled by the parameters.

*.tstack.* are parameters for terminal mismatches in exterior loops.

*.tstackcoax.* are parameters for coaxial stacking of helices with an intervening mismatch. This is for the stack where the backbone is continuous.

*.tstackh.* are parameters for first mismtaches in hairpin loops.

*.tstacki.* are parameters for the mismatches in internal loops.

*.tstacki23.* are parameters for the mismatches in 2×3 internal loops.

*.tstackm.* are parameters for the mismatches in multibranch loops.

Note that for many terminal stack tables, the AU/GU helix end penalty is included for computational speed.