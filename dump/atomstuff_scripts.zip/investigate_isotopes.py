"""
Deep investigation of the 2324-isotope AME2020 dataset on the Sempaevum.
Looking for patterns that emerge from REAL isotope masses vs blended averages.
"""
import sys
sys.path.insert(0, '/home/claude')
import mpmath
mpmath.mp.dps = 130

from sempaevum_atomic_viewer import (
    build_atomic_particles, compute_particle_projections,
    parse_ame2020, parse_nist_asd, parse_nist_abundances,
    sempaevum_project_mp, N, N_FULL, et_gcd, MU_OVER_ME_STR
)

print("Loading data...")
particles = build_atomic_particles(measured_only=True)
print(f"Built {len(particles)} isotopes")

print("Computing projections (this takes a while for 2324 isotopes)...")
results = compute_particle_projections(particles)
print(f"Projected {len(results)} isotopes\n")

# Build lookups
by_ZA = {}
for r in results:
    Z = r.get("Z", 0)
    A = r.get("A", 0)
    by_ZA[(Z, A)] = r

# ================================================================
print("=" * 80)
print("1. TOP 25 MOST LATTICE-EXACT ISOTOPES (smallest |ε| at N=12)")
print("=" * 80)
sorted_by_eps = sorted(results, key=lambda r: abs(r["eps_mp_12"]))
for i, r in enumerate(sorted_by_eps[:25]):
    nat = "NAT" if r.get("is_naturally_occurring") else "   "
    print(f"  {i+1:3d}. {r['symbol']:>8s} k={r['k_r_12']:>3d} d={r['d_r_12']:>2d} "
          f"|ε|={mpmath.nstr(abs(r['eps_mp_12']), 8):>12s}¢  "
          f"d_θ={r['d_theta']:>2d}  {nat}  BE/A={r.get('binding_energy_per_A_keV','?')}")

# ================================================================
print("\n" + "=" * 80)
print("2. NUCLEAR MAGIC NUMBERS — Do shell closures show lattice signatures?")
print("   Magic N or Z: 2, 8, 20, 28, 50, 82, 126")
print("=" * 80)

magic_numbers = {2, 8, 20, 28, 50, 82, 126}

# Doubly-magic nuclei
doubly_magic = [
    (2, 4, "⁴He"),     # Z=2, N=2
    (8, 16, "¹⁶O"),    # Z=8, N=8
    (20, 40, "⁴⁰Ca"),  # Z=20, N=20
    (20, 48, "⁴⁸Ca"),  # Z=20, N=28
    (28, 56, "⁵⁶Ni"),  # Z=28, N=28  (NOT Fe-56!)
    (50, 132, "¹³²Sn"), # Z=50, N=82
    (82, 208, "²⁰⁸Pb"), # Z=82, N=126
]

print("\n  Doubly-magic nuclei:")
for Z, A, name in doubly_magic:
    r = by_ZA.get((Z, A))
    if r:
        print(f"    {name:>8s} (Z={Z:>3d},N={A-Z:>3d}) k={r['k_r_12']:>3d} d_r={r['d_r_12']:>2d} "
              f"|ε|={mpmath.nstr(abs(r['eps_mp_12']), 8):>12s}¢ d_θ={r['d_theta']:>2d} "
              f"d_comb={r['d_combined']:>2d} Home={r['true_home_label']}")
    else:
        print(f"    {name:>8s}: NOT IN DATASET")

# Compare: average |ε| for magic-Z isotopes vs non-magic-Z
magic_Z_eps = [abs(r["eps_mp_12"]) for r in results if r.get("Z") in magic_numbers]
non_magic_Z_eps = [abs(r["eps_mp_12"]) for r in results if r.get("Z") not in magic_numbers]
magic_N_eps = [abs(r["eps_mp_12"]) for r in results if (r.get("A",0) - r.get("Z",0)) in magic_numbers]

if magic_Z_eps:
    avg_magic_Z = sum(magic_Z_eps) / len(magic_Z_eps)
    avg_non_magic = sum(non_magic_Z_eps) / len(non_magic_Z_eps)
    avg_magic_N = sum(magic_N_eps) / len(magic_N_eps) if magic_N_eps else mpmath.mpf(0)
    print(f"\n  Average |ε| for magic-Z isotopes:     {mpmath.nstr(avg_magic_Z, 6)}¢ ({len(magic_Z_eps)} isotopes)")
    print(f"  Average |ε| for non-magic-Z isotopes: {mpmath.nstr(avg_non_magic, 6)}¢ ({len(non_magic_Z_eps)} isotopes)")
    print(f"  Average |ε| for magic-N isotopes:     {mpmath.nstr(avg_magic_N, 6)}¢ ({len(magic_N_eps)} isotopes)")

# ================================================================
print("\n" + "=" * 80)
print("3. ISOTOPES OF THE SAME ELEMENT — Real-axis spread")
print("   How do isotopes of one element distribute across d_r families?")
print("=" * 80)

from collections import defaultdict
element_families = defaultdict(lambda: defaultdict(list))
element_k_range = {}

for r in results:
    Z = r.get("Z", 0)
    sym = r.get("symbol", "?").split("-")[0]
    d_r = r["d_r_12"]
    element_families[Z][d_r].append(r["symbol"])
    if Z not in element_k_range:
        element_k_range[Z] = {"min_k": r["k_r_12"], "max_k": r["k_r_12"], "sym": sym, "count": 0}
    element_k_range[Z]["min_k"] = min(element_k_range[Z]["min_k"], r["k_r_12"])
    element_k_range[Z]["max_k"] = max(element_k_range[Z]["max_k"], r["k_r_12"])
    element_k_range[Z]["count"] += 1

# Elements with isotopes in the MOST different d_r families
multi_family = [(Z, len(fams), fams) for Z, fams in element_families.items()]
multi_family.sort(key=lambda x: -x[1])

print("\n  Elements with isotopes in the most different d_r families:")
for Z, n_fams, fams in multi_family[:15]:
    info = element_k_range[Z]
    fam_str = ", ".join(f"d={d}({len(isos)})" for d, isos in sorted(fams.items()))
    print(f"    Z={Z:>3d} {info['sym']:>3s}: {n_fams} families, {info['count']} isotopes, "
          f"k=[{info['min_k']}..{info['max_k']}], Δk={info['max_k']-info['min_k']}")
    print(f"          {fam_str}")

# ================================================================
print("\n" + "=" * 80)
print("4. IRON PEAK — The binding energy maximum and its lattice position")
print("=" * 80)

# Fe-56 has the highest binding energy per nucleon for practical purposes
# (actually Ni-62 has the highest BE/A, but Fe-56 is most produced in stellar fusion)
iron_peak = [(26, 56), (26, 58), (28, 58), (28, 60), (28, 62)]
for Z, A in iron_peak:
    r = by_ZA.get((Z, A))
    if r:
        print(f"  {r['symbol']:>8s}: k={r['k_r_12']:>3d} d_r={r['d_r_12']:>2d} "
              f"|ε|={mpmath.nstr(abs(r['eps_mp_12']), 8):>12s}¢ "
              f"BE/A={r.get('binding_energy_per_A_keV','?')} keV")

# ================================================================
print("\n" + "=" * 80)
print("5. d_r FAMILY DISTRIBUTION: Naturally-occurring vs ALL measured")
print("=" * 80)

nat_dr = defaultdict(int)
all_dr = defaultdict(int)
for r in results:
    d = r["d_r_12"]
    all_dr[d] += 1
    if r.get("is_naturally_occurring"):
        nat_dr[d] += 1

nat_total = sum(nat_dr.values())
all_total = sum(all_dr.values())

print(f"\n  {'d_r':>4s} | {'Natural':>8s} {'%':>6s} | {'All':>8s} {'%':>6s} | {'Ratio':>6s}")
print(f"  {'-'*4}-+-{'-'*8}-{'-'*6}-+-{'-'*8}-{'-'*6}-+-{'-'*6}")
for d in sorted(all_dr.keys()):
    n = nat_dr.get(d, 0)
    a = all_dr[d]
    n_pct = 100 * n / nat_total if nat_total else 0
    a_pct = 100 * a / all_total
    ratio = n_pct / a_pct if a_pct > 0 else 0
    print(f"  {d:>4d} | {n:>8d} {n_pct:>5.1f}% | {a:>8d} {a_pct:>5.1f}% | {ratio:>5.2f}x")

# ================================================================
print("\n" + "=" * 80)
print("6. BINDING ENERGY vs LATTICE POSITION")
print("   Does higher BE/A correlate with smaller |ε|?")
print("=" * 80)

# Group by BE/A ranges
be_bins = [(0, 4), (4, 6), (6, 7), (7, 7.5), (7.5, 8), (8, 8.5), (8.5, 9)]
for lo, hi in be_bins:
    in_bin = [r for r in results 
              if r.get("binding_energy_per_A_keV") and 
              isinstance(r["binding_energy_per_A_keV"], str) and 
              r["binding_energy_per_A_keV"].replace('.','').replace('-','').isdigit() and
              lo <= mpmath.mpf(r["binding_energy_per_A_keV"]) / mpmath.mpf(1000) < hi]
    if not in_bin:
        in_bin = [r for r in results 
                  if r.get("binding_energy_per_A_keV") and 
                  not isinstance(r["binding_energy_per_A_keV"], str) and
                  lo <= r["binding_energy_per_A_keV"] / 1000 < hi]
    if in_bin:
        avg_eps = sum(abs(r["eps_mp_12"]) for r in in_bin) / len(in_bin)
        print(f"  BE/A [{lo:.1f}, {hi:.1f}) MeV: {len(in_bin):>5d} isotopes, avg|ε|={mpmath.nstr(avg_eps, 6)}¢")

# ================================================================
print("\n" + "=" * 80)
print("7. k_r DENSITY — Where are the isotopes concentrated on the log-mass axis?")
print("=" * 80)

k_counts = defaultdict(int)
k_nat_counts = defaultdict(int)
for r in results:
    k = r["k_r_12"]
    k_counts[k] += 1
    if r.get("is_naturally_occurring"):
        k_nat_counts[k] += 1

# Find the densest k values
dense_k = sorted(k_counts.items(), key=lambda x: -x[1])[:15]
print("\n  Most populated k values (number of isotopes at each lattice position):")
for k, count in dense_k:
    nat = k_nat_counts.get(k, 0)
    d = N // et_gcd(abs(k), N) if k != 0 else 1
    print(f"    k={k:>3d} (d_r={d:>2d}): {count:>3d} isotopes ({nat} natural)")

# ================================================================
print("\n" + "=" * 80)
print("8. TOWER DEPTH — Do naturally-occurring isotopes converge faster?")
print("=" * 80)

nat_homes = defaultdict(int)
all_homes = defaultdict(int)
for r in results:
    home = r.get("true_home_label", "?")
    all_homes[home] += 1
    if r.get("is_naturally_occurring"):
        nat_homes[home] += 1

print(f"\n  {'Tower Home':>20s} | {'Natural':>8s} | {'All':>8s}")
print(f"  {'-'*20}-+-{'-'*8}-+-{'-'*8}")
for home in sorted(all_homes.keys()):
    n = nat_homes.get(home, 0)
    a = all_homes[home]
    print(f"  {home:>20s} | {n:>8d} | {a:>8d}")

# ================================================================
print("\n" + "=" * 80)
print("9. ISOTOPE PAIRS — Same k_r (mass twins on the lattice)")
print("   Different nuclides that land at the same lattice node")
print("=" * 80)

from collections import defaultdict
k_groups = defaultdict(list)
for r in results:
    if r.get("is_naturally_occurring"):
        k_groups[r["k_r_12"]].append(r)

# Find k values with multiple natural isotopes from DIFFERENT elements
cross_element_twins = []
for k, group in k_groups.items():
    elements = set(r.get("Z") for r in group)
    if len(elements) >= 2 and len(group) >= 3:
        cross_element_twins.append((k, group))

cross_element_twins.sort(key=lambda x: len(x[1]), reverse=True)
print(f"\n  Lattice nodes hosting natural isotopes from 2+ elements:")
for k, group in cross_element_twins[:10]:
    d = N // et_gcd(abs(k), N) if k != 0 else 1
    names = [r["symbol"] for r in sorted(group, key=lambda x: x.get("Z", 0))]
    print(f"    k={k:>3d} (d_r={d:>2d}): {', '.join(names)}")

print("\n" + "=" * 80)
print("INVESTIGATION COMPLETE")
print("=" * 80)
