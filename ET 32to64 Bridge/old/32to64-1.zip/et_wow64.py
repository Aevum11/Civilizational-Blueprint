"""
et_bridge/et_wow64.py
ET32 Bridge — WOW64 Universal Hook (Complete API Coverage)

Derived from P ∘ D ∘ T = E.

The WOW64 Universal Hook is the ET solution to the API Descriptor Gap:

  CURRENT STATE: IAT hooks only catch calls from the ONE module we patched.
  Any other module (MSVC runtime, other DLLs, injected code, indirect calls)
  bypasses our hooks entirely.

  CORRECT STATE: Patch ntdll32.dll NT function exports DIRECTLY.
  Every call from EVERY caller — direct, indirect, cross-DLL — is intercepted
  because they all ultimately call into ntdll32's NT stub functions.

ET PDT of this module:
  P = ntdll32.dll loaded in the 32-bit target process (the substrate)
  D = the NT function exports (the Descriptor set of all system APIs)
  T = every thread making any Windows API call (the Traversers)
  E = complete interception and 64-bit extension of all relevant calls

Subsumption Law application:
  The IAT hook is {P,D_app} — it covers only the app's import table.
  The ntdll32 patch is {P,D_ntdll} — it covers ntdll32 itself.
  Since ALL Win32 API calls eventually call ntdll32 NT stubs, patching
  ntdll32 is the Subsumption of the entire API call tree.
  V(ntdll32 patch) = 0 (zero remainder, all callers covered).

The patch mechanism (32-bit x86 function prologue hook):
  The first 5 bytes of each NtXxx function are replaced with:
    JMP rel32  (E9 xx xx xx xx)
  that jumps to our per-function hook stub.
  The original 5 bytes are saved and executed at the end of the stub (trampoline).

This is a non-destructive additive modification:
  Original bytes saved → no code is removed, only intercepted.

Author: Derived from Michael James Muller's Exception Theory
"""

import ctypes
import ctypes.wintypes as wintypes
import struct
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple, Callable

from .et_math import (
    S, K, V_BASE,
    DIGITAL_ACTION_QUANTUM, QUEUE_DEPTH, HANDLE_BASE, CONN_TIMEOUT_MS,
    ETMetrics, pack_args, unpack_args,
    CmdFamily, CmdCode,
)
from .et_logger import ETLog
from .et_awe import ETAWEBookshelf, AWE_WINDOW_SIZE

# =============================================================================
# WOW64 CONSTANTS — ET DERIVED
# =============================================================================

# Maximum number of NT functions we track = S² = 144
WOW64_MAX_HOOKS: int = QUEUE_DEPTH          # 144 hook slots

# Trampoline buffer size per hook = S × ħ_d / S = ħ_d = 4096? No —
# Trampoline = original_bytes (5..8) + JMP back (5) = max 16 bytes
# Buffer for all trampolines = WOW64_MAX_HOOKS × 16 = 2304 bytes
# Round up to ħ_d = 4096 for page alignment
WOW64_TRAMPOLINE_SLOT: int = 16             # bytes per trampoline
WOW64_TRAMPOLINE_TOTAL: int = max(DIGITAL_ACTION_QUANTUM,
    WOW64_MAX_HOOKS * WOW64_TRAMPOLINE_SLOT)  # 4096 bytes

# x86 JMP rel32 opcode
JMP_REL32: int = 0xE9

# x86 NOP
NOP: int = 0x90

# Page protection constants
PAGE_EXECUTE_READWRITE  = 0x40
PAGE_EXECUTE_READ       = 0x20
PAGE_READWRITE          = 0x04

# MEM flags
MEM_COMMIT  = 0x00001000
MEM_RESERVE = 0x00002000
MEM_RELEASE = 0x00008000

# Windows API function types
kernel32 = ctypes.windll.kernel32

_VirtualAlloc = kernel32.VirtualAlloc
_VirtualAlloc.restype  = ctypes.c_void_p
_VirtualAlloc.argtypes = [ctypes.c_void_p, ctypes.c_size_t, wintypes.DWORD, wintypes.DWORD]

_VirtualFree = kernel32.VirtualFree
_VirtualFree.restype  = wintypes.BOOL
_VirtualFree.argtypes = [ctypes.c_void_p, ctypes.c_size_t, wintypes.DWORD]

_VirtualProtect = kernel32.VirtualProtect
_VirtualProtect.restype  = wintypes.BOOL
_VirtualProtect.argtypes = [ctypes.c_void_p, ctypes.c_size_t, wintypes.DWORD, ctypes.POINTER(wintypes.DWORD)]

_ReadProcessMemory = kernel32.ReadProcessMemory
_ReadProcessMemory.restype  = wintypes.BOOL
_ReadProcessMemory.argtypes = [
    wintypes.HANDLE, ctypes.c_void_p,
    ctypes.c_void_p, ctypes.c_size_t,
    ctypes.POINTER(ctypes.c_size_t),
]

_WriteProcessMemory = kernel32.WriteProcessMemory
_WriteProcessMemory.restype  = wintypes.BOOL
_WriteProcessMemory.argtypes = [
    wintypes.HANDLE, ctypes.c_void_p,
    ctypes.c_void_p, ctypes.c_size_t,
    ctypes.POINTER(ctypes.c_size_t),
]

_GetModuleHandleA = kernel32.GetModuleHandleA
_GetModuleHandleA.restype  = wintypes.HMODULE
_GetModuleHandleA.argtypes = [ctypes.c_char_p]

_GetProcAddress = kernel32.GetProcAddress
_GetProcAddress.restype  = ctypes.c_void_p
_GetProcAddress.argtypes = [wintypes.HMODULE, ctypes.c_char_p]

_CreateToolhelp32Snapshot = kernel32.CreateToolhelp32Snapshot
_Module32First  = kernel32.Module32First
_Module32Next   = kernel32.Module32Next

TH32CS_SNAPMODULE   = 0x00000008
TH32CS_SNAPMODULE32 = 0x00000010


# =============================================================================
# NT FUNCTION HOOK DESCRIPTOR — D-UNIT FOR ONE PATCHED FUNCTION
# =============================================================================

@dataclass
class NTHookEntry:
    """
    Describes one patched ntdll32 NT function.

    PDT of one hook:
      P = the function bytes at func_addr (the substrate to be modified)
      D = the JMP patch bytes (the new Descriptor redirecting execution)
      T = any thread calling the function (the Traverser being redirected)
      E = our hook_fn is called instead (the Exception: extended 64-bit behavior)
    """
    func_name:     str           # NT function name (e.g. "NtAllocateVirtualMemory")
    func_addr_32:  int           # 32-bit address of function in TARGET process
    original_bytes: bytes        # first 5–8 bytes saved before patching
    hook_stub_addr: int          # address of our hook stub in TARGET process
    cmd_family:    int           # ET lattice family (1..12)
    cmd_code:      int           # ET command code within family
    arg_count:     int           # number of arguments
    active:        bool = False  # patch is installed
    call_count:    int = 0       # how many times hook fired

    def variance(self) -> float:
        return 0.0 if self.active else V_BASE


# =============================================================================
# NT FUNCTION CATALOGUE — COMPLETE LIST FOR UNIVERSAL COVERAGE
# =============================================================================
# Each entry: (function_name, cmd_family, cmd_code, arg_count, needs_64bit)
# needs_64bit=True: always route to broker
# needs_64bit=False: pass-through unless extension condition met (e.g. size > K×4GB)
#
# ET derivation: the function catalogue IS the D-set of the 32-bit process.
# Covering it completely satisfies the Subsumption Law.
# Functions not in the catalogue: pass-through via original ntdll32 stub.

NT_HOOK_CATALOGUE: List[Tuple[str, int, int, int, bool]] = [
    # --- MEMORY_BASIC (d=1) ---
    # Routing criterion: size > K × 4GB (Koide threshold ≈ 2.86 GB)
    ("NtAllocateVirtualMemory",     CmdFamily.MEMORY_BASIC,  CmdCode.VIRT_ALLOC,    6, False),
    ("NtFreeVirtualMemory",         CmdFamily.MEMORY_BASIC,  CmdCode.VIRT_FREE,     4, False),
    ("NtProtectVirtualMemory",      CmdFamily.MEMORY_BASIC,  CmdCode.VIRT_PROTECT,  5, False),
    ("NtQueryVirtualMemory",        CmdFamily.MEMORY_BASIC,  CmdCode.VIRT_QUERY,    6, False),
    ("NtReadVirtualMemory",         CmdFamily.MEMORY_BASIC,  CmdCode.READ_MEM,      5, False),
    ("NtWriteVirtualMemory",        CmdFamily.MEMORY_BASIC,  CmdCode.WRITE_MEM,     5, False),
    ("NtAllocateUserPhysicalPages", CmdFamily.MEMORY_BASIC,  CmdCode.HEAP_ALLOC,    3, True ),
    ("NtFreeUserPhysicalPages",     CmdFamily.MEMORY_BASIC,  CmdCode.HEAP_FREE,     3, True ),
    ("NtMapUserPhysicalPages",      CmdFamily.MEMORY_BASIC,  CmdCode.VIRT_ALLOC,    3, True ),
    # Heap
    ("RtlAllocateHeap",             CmdFamily.MEMORY_BASIC,  CmdCode.HEAP_ALLOC,    3, False),
    ("RtlFreeHeap",                 CmdFamily.MEMORY_BASIC,  CmdCode.HEAP_FREE,     3, False),
    ("RtlReAllocateHeap",           CmdFamily.MEMORY_BASIC,  CmdCode.HEAP_ALLOC,    4, False),
    ("RtlCreateHeap",               CmdFamily.MEMORY_BASIC,  CmdCode.HEAP_ALLOC,    6, False),
    ("RtlDestroyHeap",              CmdFamily.MEMORY_BASIC,  CmdCode.HEAP_FREE,     1, False),
    # --- MEMORY_MAP (d=2) ---
    ("NtCreateSection",             CmdFamily.MEMORY_MAP,    CmdCode.FILE_MAP_CREATE, 7, False),
    ("NtOpenSection",               CmdFamily.MEMORY_MAP,    CmdCode.FILE_MAP_CREATE, 3, False),
    ("NtMapViewOfSection",          CmdFamily.MEMORY_MAP,    CmdCode.FILE_MAP_VIEW, 10, False),
    ("NtUnmapViewOfSection",        CmdFamily.MEMORY_MAP,    CmdCode.FILE_MAP_CLOSE, 2, False),
    ("NtExtendSection",             CmdFamily.MEMORY_MAP,    CmdCode.FILE_MAP_FLUSH, 2, False),
    ("NtQuerySection",              CmdFamily.MEMORY_MAP,    CmdCode.VIRT_QUERY,    5, False),
    # --- THREAD_OPS (d=3) ---
    ("NtCreateThread",              CmdFamily.THREAD_OPS,    CmdCode.THREAD_CREATE,  8, False),
    ("NtCreateThreadEx",            CmdFamily.THREAD_OPS,    CmdCode.THREAD_CREATE, 11, False),
    ("NtSuspendThread",             CmdFamily.THREAD_OPS,    CmdCode.THREAD_SUSPEND, 2, False),
    ("NtResumeThread",              CmdFamily.THREAD_OPS,    CmdCode.THREAD_RESUME,  2, False),
    ("NtTerminateThread",           CmdFamily.THREAD_OPS,    CmdCode.THREAD_TERMINATE, 2, False),
    ("NtGetContextThread",          CmdFamily.THREAD_OPS,    CmdCode.THREAD_CONTEXT, 2, True ),
    ("NtSetContextThread",          CmdFamily.THREAD_OPS,    CmdCode.THREAD_CONTEXT, 2, True ),
    ("NtQueryInformationThread",    CmdFamily.THREAD_OPS,    CmdCode.THREAD_CONTEXT, 5, False),
    ("NtSetInformationThread",      CmdFamily.THREAD_OPS,    CmdCode.THREAD_CONTEXT, 4, False),
    # --- DLL / LDR (d=4) ---
    ("LdrLoadDll",                  CmdFamily.DLL_OPS,       CmdCode.DLL_LOAD,      4, False),
    ("LdrUnloadDll",                CmdFamily.DLL_OPS,       CmdCode.DLL_FREE,      1, False),
    ("LdrGetProcedureAddress",      CmdFamily.DLL_OPS,       CmdCode.DLL_GETPROC,   4, False),
    ("LdrFindEntryForAddress",      CmdFamily.DLL_OPS,       CmdCode.DLL_LIST,      2, False),
    ("LdrQueryImageFileExecutionOptions", CmdFamily.DLL_OPS, CmdCode.DLL_LIST,      5, False),
    # --- PROCESS_OPS (d=5) ---
    ("NtCreateProcess",             CmdFamily.PROCESS_OPS,   CmdCode.PROC_CREATE,   8, False),
    ("NtCreateProcessEx",           CmdFamily.PROCESS_OPS,   CmdCode.PROC_CREATE,   9, False),
    ("NtOpenProcess",               CmdFamily.PROCESS_OPS,   CmdCode.PROC_OPEN,     4, False),
    ("NtTerminateProcess",          CmdFamily.PROCESS_OPS,   CmdCode.PROC_CREATE,   2, False),
    ("NtQueryInformationProcess",   CmdFamily.PROCESS_OPS,   CmdCode.PROC_INFO,     5, True ),
    ("NtSetInformationProcess",     CmdFamily.PROCESS_OPS,   CmdCode.PROC_INFO,     4, False),
    ("NtQuerySystemInformation",    CmdFamily.PROCESS_OPS,   CmdCode.PROC_INFO,     4, True ),
    ("NtSetSystemInformation",      CmdFamily.PROCESS_OPS,   CmdCode.PROC_INFO,     3, False),
    # --- REGISTRY_OPS (d=6) ---
    ("NtOpenKey",                   CmdFamily.REGISTRY_OPS,  CmdCode.REG_OPEN64,    3, True ),
    ("NtOpenKeyEx",                 CmdFamily.REGISTRY_OPS,  CmdCode.REG_OPEN64,    4, True ),
    ("NtCreateKey",                 CmdFamily.REGISTRY_OPS,  CmdCode.REG_OPEN64,    7, True ),
    ("NtQueryValueKey",             CmdFamily.REGISTRY_OPS,  CmdCode.REG_QUERY64,   6, True ),
    ("NtSetValueKey",               CmdFamily.REGISTRY_OPS,  CmdCode.REG_SET64,     6, True ),
    ("NtDeleteKey",                 CmdFamily.REGISTRY_OPS,  CmdCode.REG_OPEN64,    1, True ),
    ("NtDeleteValueKey",            CmdFamily.REGISTRY_OPS,  CmdCode.REG_OPEN64,    2, True ),
    ("NtEnumerateKey",              CmdFamily.REGISTRY_OPS,  CmdCode.REG_ENUM64,    6, True ),
    ("NtEnumerateValueKey",         CmdFamily.REGISTRY_OPS,  CmdCode.REG_ENUM64,    6, True ),
    ("NtFlushKey",                  CmdFamily.REGISTRY_OPS,  CmdCode.REG_OPEN64,    1, True ),
    ("NtQueryKey",                  CmdFamily.REGISTRY_OPS,  CmdCode.REG_QUERY64,   5, True ),
    # --- GRAPHICS/GPU (d=7) ---
    ("NtGdiCreateBitmap",           CmdFamily.GRAPHICS_OPS,  CmdCode.GPU_QUERY_INFO, 5, False),
    ("NtGdiCreateCompatibleDC",     CmdFamily.GRAPHICS_OPS,  CmdCode.GPU_QUERY_INFO, 1, False),
    ("NtDxgkCreateContext",         CmdFamily.GRAPHICS_OPS,  CmdCode.GPU_ALLOC_VRAM, 4, True ),
    ("NtDxgkCreateAllocation",      CmdFamily.GRAPHICS_OPS,  CmdCode.GPU_ALLOC_VRAM, 2, True ),
    ("NtDxgkFreeAllocation",        CmdFamily.GRAPHICS_OPS,  CmdCode.GPU_FREE_VRAM,  3, True ),
    ("NtDxgkRender",                CmdFamily.GRAPHICS_OPS,  CmdCode.GPU_SUBMIT,     2, True ),
    ("NtDxgkMapGpuVirtualAddress",  CmdFamily.GRAPHICS_OPS,  CmdCode.GPU_MAP_VRAM,   2, True ),
    # --- FILE_OPS (d=8) ---
    ("NtCreateFile",                CmdFamily.FILE_OPS,      CmdCode.FILE_OPEN_LARGE, 11, False),
    ("NtOpenFile",                  CmdFamily.FILE_OPS,      CmdCode.FILE_OPEN_LARGE,  6, False),
    ("NtReadFile",                  CmdFamily.FILE_OPS,      CmdCode.FILE_READ_LARGE,  9, False),
    ("NtWriteFile",                 CmdFamily.FILE_OPS,      CmdCode.FILE_WRITE_LARGE, 9, False),
    ("NtQueryInformationFile",      CmdFamily.FILE_OPS,      CmdCode.FILE_OPEN_LARGE,  5, False),
    ("NtSetInformationFile",        CmdFamily.FILE_OPS,      CmdCode.FILE_SEEK_LARGE,  5, False),
    ("NtQueryDirectoryFile",        CmdFamily.FILE_OPS,      CmdCode.FILE_OPEN_LARGE, 11, False),
    ("NtDeleteFile",                CmdFamily.FILE_OPS,      CmdCode.FILE_OPEN_LARGE,  1, False),
    ("NtQueryEaFile",               CmdFamily.FILE_OPS,      CmdCode.FILE_READ_LARGE,  9, False),
    ("NtSetEaFile",                 CmdFamily.FILE_OPS,      CmdCode.FILE_WRITE_LARGE, 4, False),
    ("NtFlushBuffersFile",          CmdFamily.FILE_OPS,      CmdCode.FILE_WRITE_LARGE, 2, False),
    ("NtCancelIoFile",              CmdFamily.FILE_OPS,      CmdCode.FILE_OPEN_LARGE,  2, False),
    ("NtLockFile",                  CmdFamily.FILE_OPS,      CmdCode.FILE_SEEK_LARGE, 10, False),
    ("NtUnlockFile",                CmdFamily.FILE_OPS,      CmdCode.FILE_SEEK_LARGE,  5, False),
    ("NtDeviceIoControlFile",       CmdFamily.FILE_OPS,      CmdCode.FILE_OPEN_LARGE, 10, False),
    ("NtFsControlFile",             CmdFamily.FILE_OPS,      CmdCode.FILE_OPEN_LARGE, 10, False),
    # --- SYNC_OPS (d=9) ---
    ("NtCreateEvent",               CmdFamily.SYNC_OPS,      CmdCode.SYNC_CREATE_EVENT, 5, False),
    ("NtOpenEvent",                 CmdFamily.SYNC_OPS,      CmdCode.SYNC_CREATE_EVENT, 3, False),
    ("NtSetEvent",                  CmdFamily.SYNC_OPS,      CmdCode.SYNC_SIGNAL,       2, False),
    ("NtResetEvent",                CmdFamily.SYNC_OPS,      CmdCode.SYNC_SIGNAL,       2, False),
    ("NtPulseEvent",                CmdFamily.SYNC_OPS,      CmdCode.SYNC_SIGNAL,       2, False),
    ("NtWaitForSingleObject",       CmdFamily.SYNC_OPS,      CmdCode.SYNC_WAIT,         3, False),
    ("NtWaitForMultipleObjects",    CmdFamily.SYNC_OPS,      CmdCode.SYNC_WAIT,         5, False),
    ("NtSignalAndWaitForSingleObject", CmdFamily.SYNC_OPS,   CmdCode.SYNC_WAIT,         4, False),
    ("NtCreateMutant",              CmdFamily.SYNC_OPS,      CmdCode.SYNC_MUTEX,        4, False),
    ("NtOpenMutant",                CmdFamily.SYNC_OPS,      CmdCode.SYNC_MUTEX,        3, False),
    ("NtReleaseMutant",             CmdFamily.SYNC_OPS,      CmdCode.SYNC_MUTEX,        2, False),
    ("NtCreateSemaphore",           CmdFamily.SYNC_OPS,      CmdCode.SYNC_MUTEX,        5, False),
    ("NtOpenSemaphore",             CmdFamily.SYNC_OPS,      CmdCode.SYNC_MUTEX,        3, False),
    ("NtReleaseSemaphore",          CmdFamily.SYNC_OPS,      CmdCode.SYNC_MUTEX,        3, False),
    ("NtCreateTimer",               CmdFamily.SYNC_OPS,      CmdCode.SYNC_CREATE_EVENT, 4, False),
    ("NtOpenTimer",                 CmdFamily.SYNC_OPS,      CmdCode.SYNC_CREATE_EVENT, 3, False),
    ("NtSetTimer",                  CmdFamily.SYNC_OPS,      CmdCode.SYNC_SIGNAL,       7, False),
    ("NtCancelTimer",               CmdFamily.SYNC_OPS,      CmdCode.SYNC_SIGNAL,       2, False),
    # --- NET_OPS (d=10) — AFD (Ancillary Function Driver for Winsock) ---
    ("NtCreateIoCompletion",        CmdFamily.NET_OPS,       CmdCode.NET_SOCKET64,      4, False),
    ("NtOpenIoCompletion",          CmdFamily.NET_OPS,       CmdCode.NET_SOCKET64,      3, False),
    ("NtSetIoCompletion",           CmdFamily.NET_OPS,       CmdCode.NET_SEND64,        5, False),
    ("NtRemoveIoCompletion",        CmdFamily.NET_OPS,       CmdCode.NET_RECV64,        5, False),
    ("NtQueryIoCompletion",         CmdFamily.NET_OPS,       CmdCode.NET_SOCKET64,      5, False),
    # --- PYTHON_OPS (d=11) — placeholder, handled by broker dynamically ---
    # --- COMPOUND_OPS (d=12) ---
    ("NtClose",                     CmdFamily.COMPOUND_OPS,  CmdCode.FILE_MAP_CLOSE,    1, False),
    ("NtDuplicateObject",           CmdFamily.COMPOUND_OPS,  CmdCode.COMPOUND_ATOMIC,   7, False),
    ("NtQueryObject",               CmdFamily.COMPOUND_OPS,  CmdCode.COMPOUND_BATCH,    5, False),
    ("NtSetSecurityObject",         CmdFamily.COMPOUND_OPS,  CmdCode.COMPOUND_ATOMIC,   3, False),
    ("NtQuerySecurityObject",       CmdFamily.COMPOUND_OPS,  CmdCode.COMPOUND_BATCH,    5, False),
    ("NtWaitForDebugEvent",         CmdFamily.COMPOUND_OPS,  CmdCode.SYNC_WAIT,         4, False),
    ("NtSystemDebugControl",        CmdFamily.COMPOUND_OPS,  CmdCode.COMPOUND_BATCH,    6, False),
    ("NtSetDebugFilterState",       CmdFamily.COMPOUND_OPS,  CmdCode.COMPOUND_ATOMIC,   3, False),
    ("RtlRaiseException",           CmdFamily.COMPOUND_OPS,  CmdCode.COMPOUND_ROLLBACK, 1, False),
    ("RtlUnwind",                   CmdFamily.COMPOUND_OPS,  CmdCode.COMPOUND_ROLLBACK, 4, False),
    ("RtlGetNtVersionNumbers",      CmdFamily.COMPOUND_OPS,  CmdCode.COMPOUND_BATCH,    3, True ),
    ("RtlGetSystemTimePrecise",     CmdFamily.COMPOUND_OPS,  CmdCode.COMPOUND_BATCH,    0, False),
]

# Build fast lookup: function_name → catalogue entry
_CATALOGUE_MAP: Dict[str, Tuple] = {e[0]: e for e in NT_HOOK_CATALOGUE}


# =============================================================================
# SHELLCODE GENERATION FOR 32-BIT HOOK STUBS
# =============================================================================

def _make_jmp_rel32(from_addr: int, to_addr: int) -> bytes:
    """
    Generate a 32-bit relative JMP instruction.
    from_addr: address of the JMP instruction itself (5 bytes).
    to_addr: destination address.
    rel32 = to_addr - (from_addr + 5)
    """
    rel = (to_addr - (from_addr + 5)) & 0xFFFFFFFF
    return struct.pack("<BI", JMP_REL32, rel)


def _make_call_rel32(from_addr: int, to_addr: int) -> bytes:
    rel = (to_addr - (from_addr + 5)) & 0xFFFFFFFF
    return struct.pack("<BI", 0xE8, rel)


def _make_trampoline(original_bytes: bytes, original_func_addr: int,
                     trampoline_addr: int) -> bytes:
    """
    Build a trampoline that:
      1. Executes the saved original bytes (first 5 bytes of the patched function)
      2. JMPs back to original_func_addr + 5 (continues original function)

    Layout at trampoline_addr:
      [original_bytes (5 bytes)]
      [JMP original_func_addr+5 (5 bytes)]
    """
    jmp_back = _make_jmp_rel32(
        trampoline_addr + len(original_bytes),
        original_func_addr + len(original_bytes),
    )
    return original_bytes + jmp_back


def _make_hook_stub_32(
    stub_addr:       int,   # where this stub lives in target
    trampoline_addr: int,   # trampoline for the original function
    ipc_write_fn:    int,   # address of our IPC write function in target
    hook_id:         int,   # (cmd_family << 16) | cmd_code
    arg_count:       int,   # number of arguments to the hooked function
    needs_64bit:     bool,  # if False: check size condition before routing
) -> bytes:
    """
    Generate a 32-bit x86 hook stub that intercepts a function call.

    The stub:
      1. Checks if this call needs 64-bit extension:
         - If needs_64bit=True: always route to broker
         - If needs_64bit=False: check if first SIZE argument > K×4GB threshold;
           if not, JMP directly to trampoline (zero overhead for normal calls)
      2. If routing needed:
         a. pushad / pushfd (save all registers and flags)
         b. Push hook_id and stack arguments onto stack
         c. Call ipc_write_fn (our C function in et_bridge32.dll)
         d. Store result from EAX
         e. popfd / popad
         f. RET with correct stack cleanup (arg_count × 4 bytes)
      3. If not routing: JMP trampoline

    Stack frame on entry to stub (stdcall convention):
      [esp+0]  = return address
      [esp+4]  = arg1
      [esp+8]  = arg2
      ...
      [esp + 4*arg_count] = last arg

    Register state on entry: caller-saved (EAX, ECX, EDX may be clobbered,
    callee-saved EBX, ESI, EDI, EBP must be preserved).
    """
    s = bytearray()

    if not needs_64bit:
        # Fast path: check if first arg (size) exceeds K×4GB = 0xAAAAAAAA
        # If [esp+4] <= 0xAAAAAAAA: jump to trampoline (normal call)
        koide_threshold = int(K * 0x100000000) & 0xFFFFFFFF  # 0xAAAAAAAB
        # cmp dword ptr [esp+4], koide_threshold
        s += bytes([0x81, 0x7C, 0x24, 0x04]) + struct.pack("<I", koide_threshold)
        # jbe skip_to_trampoline (unsigned below or equal → normal call)
        # We'll fill the offset after we know the trampoline distance
        jbe_offset_pos = len(s)
        s += bytes([0x76, 0x00])  # JBE rel8 (placeholder)

    # Save all registers and flags
    s += bytes([0x60])   # PUSHAD
    s += bytes([0x9C])   # PUSHFD

    # Push hook_id
    s += bytes([0x68]) + struct.pack("<I", hook_id)

    # Push arg_count
    s += bytes([0x68]) + struct.pack("<I", arg_count)

    # Push pointer to caller's arg block: [esp + 4 + 4 + 4 + 4 + 4 + 8×4]
    # After PUSHAD (8 regs × 4 = 32) + PUSHFD (4) + hook_id (4) + arg_count (4) = 44 bytes pushed
    # + return addr (4) = esp_original + 4 = start of caller's args
    # Current esp offset from caller's esp = 44 + 4(for this PUSH) = 48
    # Actually: let's compute the offset to [original esp + 4] (first caller arg)
    # After push reg×8, pushfd, push hook_id, push arg_count, next push = 44 bytes deep
    # [esp + 44 + 4(return addr)] = first caller arg
    # But we need to push the address, so:
    # lea eax, [esp + 48]  ; points to return addr on original stack
    # push eax             ; pointer to return-addr slot (caller arg block is at +4 from here)
    s += bytes([0x8D, 0x44, 0x24, 0x30])  # LEA EAX, [ESP+48] (44 pushed + 4 this lea)
    s += bytes([0x50])                     # PUSH EAX

    # Call ipc_write_fn
    call_pos = len(s) + int(stub_addr)
    call_dest = ipc_write_fn
    call_rel = (call_dest - (call_pos + 5)) & 0xFFFFFFFF
    s += bytes([0xE8]) + struct.pack("<I", call_rel)

    # Clean up pushed args (hook_id, arg_count, ptr = 12 bytes)
    s += bytes([0x83, 0xC4, 0x0C])   # ADD ESP, 12

    # Save EAX result temporarily
    s += bytes([0x89, 0x44, 0x24, 0x24])  # MOV [ESP+36], EAX (into pushad's EAX slot)

    # Restore flags and registers
    s += bytes([0x9D])   # POPFD
    s += bytes([0x61])   # POPAD  (EAX is now the IPC result)

    # Return to caller with stack cleanup (stdcall)
    ret_bytes = arg_count * 4
    if ret_bytes == 0:
        s += bytes([0xC3])
    elif ret_bytes <= 0xFFFF:
        s += bytes([0xC2]) + struct.pack("<H", ret_bytes)
    else:
        s += bytes([0xC3])  # fallback (shouldn't happen)

    if not needs_64bit:
        # Fill in the JBE target: jump to JMP-trampoline instruction
        jbe_target_offset = len(s)
        s[jbe_offset_pos + 1] = (jbe_target_offset - jbe_offset_pos - 2) & 0xFF

    # Fast path: JMP to trampoline
    jmp_trampoline_pos = len(s) + int(stub_addr)
    jmp_bytes = _make_jmp_rel32(jmp_trampoline_pos, trampoline_addr)
    s += jmp_bytes

    return bytes(s)


# =============================================================================
# ET WOW64 HOOK MANAGER
# =============================================================================

class ETWow64Hook:
    """
    Installs universal ntdll32 hooks in a 32-bit target process.

    Subsumption Law guarantee:
      Every call to every function in NT_HOOK_CATALOGUE from EVERY
      caller module in the target process is intercepted.
      Functions not in the catalogue: native pass-through (zero overhead).
      Together: complete coverage with zero remainder.

    Mechanism:
      1. Locate ntdll32.dll in the target's 32-bit address space
      2. For each function in NT_HOOK_CATALOGUE:
         a. Find function address via ReadProcessMemory + PE export parsing
         b. Read and save original 5 bytes (hook-safe if not already 5-byte op)
         c. Allocate trampoline buffer in target process memory
         d. Write trampoline: [original_bytes][JMP original+5]
         e. Write hook stub: [check conditions][call ipc_fn OR JMP trampoline]
         f. Patch first 5 bytes of original: [JMP hook_stub]
      3. To remove: restore original 5 bytes from saved copies

    The IPC function (ipc_write_fn) is the ET32_UniversalHook export in
    et_bridge32.dll, which forwards to the broker via the named pipe.
    """

    def __init__(self, awe: ETAWEBookshelf) -> None:
        self._log = ETLog.get("et_wow64")
        self._lock = threading.Lock()
        self._awe = awe
        # pid → list of NTHookEntry
        self._hooks: Dict[int, List[NTHookEntry]] = {}
        # pid → trampoline buffer address in target
        self._trampoline_buffers: Dict[int, int] = {}
        # pid → hook stub buffer address in target
        self._stub_buffers: Dict[int, int] = {}
        self._metrics = ETMetrics()

    # ------------------------------------------------------------------
    # NTDLL32 MODULE LOCATION
    # ------------------------------------------------------------------

    def _get_ntdll32_base(self, h_process: int, pid: int) -> Optional[int]:
        """
        Find ntdll32.dll base address in the target 32-bit process.
        Uses CreateToolhelp32Snapshot with TH32CS_SNAPMODULE32 to enumerate
        only 32-bit modules (critical for WOW64 processes).
        """
        snap = _CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid)
        if snap == 0xFFFFFFFF:
            return None

        class MODULEENTRY32(ctypes.Structure):
            _fields_ = [
                ("dwSize",        wintypes.DWORD),
                ("th32ModuleID",  wintypes.DWORD),
                ("th32ProcessID", wintypes.DWORD),
                ("GlblcntUsage",  wintypes.DWORD),
                ("ProccntUsage",  wintypes.DWORD),
                ("modBaseAddr",   ctypes.c_void_p),
                ("modBaseSize",   wintypes.DWORD),
                ("hModule",       wintypes.HMODULE),
                ("szModule",      ctypes.c_char * 256),
                ("szExePath",     ctypes.c_char * 260),
            ]

        me = MODULEENTRY32()
        me.dwSize = ctypes.sizeof(MODULEENTRY32)
        base = None

        if _Module32First(snap, ctypes.byref(me)):
            while True:
                name = me.szModule.decode("ascii", errors="replace").lower()
                if name in ("ntdll.dll", "ntdll32.dll"):
                    if me.modBaseAddr and me.modBaseAddr < 0x100000000:
                        base = me.modBaseAddr
                        break
                if not _Module32Next(snap, ctypes.byref(me)):
                    break

        kernel32.CloseHandle(snap)
        return base

    def _resolve_export(self, h_process: int, module_base: int,
                        func_name: str) -> Optional[int]:
        """
        Resolve a function export address from a module's PE export table,
        reading the target process's memory via ReadProcessMemory.
        """
        # Read DOS header
        buf = ctypes.create_string_buffer(4096)
        n = ctypes.c_size_t()
        if not _ReadProcessMemory(
            wintypes.HANDLE(h_process),
            ctypes.c_void_p(module_base),
            buf, 4096, ctypes.byref(n)
        ):
            return None

        # DOS header: e_lfanew at offset 0x3C
        e_lfanew = struct.unpack_from("<I", buf.raw, 0x3C)[0]
        if e_lfanew > 3072:
            return None

        # NT headers signature check
        sig = struct.unpack_from("<I", buf.raw, e_lfanew)[0]
        if sig != 0x4550:  # "PE\0\0"
            return None

        # Optional header: DataDirectory[0] = export table RVA at offset
        # NT header + 4 (sig) + 20 (COFF) = e_lfanew + 24, then opt header
        opt_off = e_lfanew + 24
        export_rva = struct.unpack_from("<I", buf.raw, opt_off + 0x60)[0]
        if export_rva == 0:
            return None

        # Read export directory (40 bytes)
        exp_buf = ctypes.create_string_buffer(256)
        exp_addr = module_base + export_rva
        if not _ReadProcessMemory(
            wintypes.HANDLE(h_process),
            ctypes.c_void_p(exp_addr),
            exp_buf, 256, ctypes.byref(n)
        ):
            return None

        n_names = struct.unpack_from("<I", exp_buf.raw, 0x18)[0]
        addr_table_rva  = struct.unpack_from("<I", exp_buf.raw, 0x1C)[0]
        name_table_rva  = struct.unpack_from("<I", exp_buf.raw, 0x20)[0]
        ord_table_rva   = struct.unpack_from("<I", exp_buf.raw, 0x24)[0]

        # Read name pointer table
        name_ptrs_buf = ctypes.create_string_buffer(n_names * 4)
        _ReadProcessMemory(
            wintypes.HANDLE(h_process),
            ctypes.c_void_p(module_base + name_table_rva),
            name_ptrs_buf, n_names * 4, ctypes.byref(n)
        )
        name_ptrs = struct.unpack_from(f"<{n_names}I", name_ptrs_buf.raw)

        # Read ordinal table
        ord_buf = ctypes.create_string_buffer(n_names * 2)
        _ReadProcessMemory(
            wintypes.HANDLE(h_process),
            ctypes.c_void_p(module_base + ord_table_rva),
            ord_buf, n_names * 2, ctypes.byref(n)
        )
        ordinals = struct.unpack_from(f"<{n_names}H", ord_buf.raw)

        # Read address table
        n_funcs_buf = ctypes.create_string_buffer(512)
        _ReadProcessMemory(
            wintypes.HANDLE(h_process),
            ctypes.c_void_p(module_base + addr_table_rva),
            n_funcs_buf, 512, ctypes.byref(n)
        )

        enc_name = func_name.encode("ascii") + b"\x00"
        for i in range(n_names):
            name_rva = name_ptrs[i]
            name_buf = ctypes.create_string_buffer(128)
            _ReadProcessMemory(
                wintypes.HANDLE(h_process),
                ctypes.c_void_p(module_base + name_rva),
                name_buf, 128, ctypes.byref(n)
            )
            name_at_rva = name_buf.raw.split(b"\x00")[0]
            if name_at_rva == enc_name.rstrip(b"\x00"):
                ord_idx = ordinals[i]
                func_rva = struct.unpack_from("<I", n_funcs_buf.raw, ord_idx * 4)[0]
                return module_base + func_rva

        return None

    # ------------------------------------------------------------------
    # HOOK INSTALLATION
    # ------------------------------------------------------------------

    def install_hooks(self, pid: int, h_process: int,
                      ipc_fn_addr_in_target: int) -> int:
        """
        Install all catalogue hooks into the target process's ntdll32.dll.

        ipc_fn_addr_in_target: 32-bit address of ET32_UniversalHook export
        in et_bridge32.dll as loaded in the target process.

        Returns number of hooks successfully installed.
        """
        with self._lock:
            # Locate ntdll32
            ntdll_base = self._get_ntdll32_base(h_process, pid)
            if ntdll_base is None:
                self._log.exception_state(
                    "Cannot find ntdll32.dll in PID %d — WOW64 hooks not installed.", pid
                )
                return 0

            self._log.mediation("ntdll32 base for PID %d: 0x%08X", pid, ntdll_base)

            # Allocate trampoline buffer in target (executable)
            trampoline_buf = _VirtualAllocEx(
                wintypes.HANDLE(h_process),
                None,
                WOW64_TRAMPOLINE_TOTAL,
                MEM_COMMIT | MEM_RESERVE,
                PAGE_EXECUTE_READWRITE,
            )
            if not trampoline_buf:
                self._log.exception_state(
                    "Failed to allocate trampoline buffer in PID %d.", pid
                )
                return 0
            self._trampoline_buffers[pid] = int(trampoline_buf)

            # Allocate stub buffer in target (executable)
            stub_buf_size = WOW64_MAX_HOOKS * 128  # max 128 bytes per stub
            stub_buf = _VirtualAllocEx(
                wintypes.HANDLE(h_process),
                None,
                stub_buf_size,
                MEM_COMMIT | MEM_RESERVE,
                PAGE_EXECUTE_READWRITE,
            )
            if not stub_buf:
                self._log.exception_state(
                    "Failed to allocate stub buffer in PID %d.", pid
                )
                return 0
            self._stub_buffers[pid] = int(stub_buf)

            installed = 0
            tramp_cursor = int(trampoline_buf)
            stub_cursor  = int(stub_buf)
            entries: List[NTHookEntry] = []

            for func_name, cmd_family, cmd_code, arg_count, needs_64bit in NT_HOOK_CATALOGUE:
                func_addr = self._resolve_export(h_process, ntdll_base, func_name)
                if func_addr is None:
                    # Function not present in this ntdll32 version — skip silently
                    continue

                # Read original 5 bytes
                orig_buf = ctypes.create_string_buffer(8)
                n = ctypes.c_size_t()
                ok = _ReadProcessMemory(
                    wintypes.HANDLE(h_process),
                    ctypes.c_void_p(func_addr),
                    orig_buf, 8, ctypes.byref(n)
                )
                if not ok or n.value < 5:
                    continue

                orig_bytes = bytes(orig_buf.raw[:5])

                # Build trampoline
                trampoline_bytes = _make_trampoline(orig_bytes, func_addr, tramp_cursor)
                self._write_target(h_process, tramp_cursor, trampoline_bytes)

                # Build hook stub
                hook_id = (cmd_family << 16) | cmd_code
                stub_bytes = _make_hook_stub_32(
                    stub_cursor, tramp_cursor,
                    ipc_fn_addr_in_target, hook_id, arg_count, needs_64bit
                )
                self._write_target(h_process, stub_cursor, stub_bytes)

                # Patch original function: write JMP to stub
                jmp_patch = _make_jmp_rel32(func_addr, stub_cursor)

                # Temporarily make the function writable
                old_prot = wintypes.DWORD()
                _VirtualProtect(
                    ctypes.c_void_p(func_addr),
                    5,
                    PAGE_EXECUTE_READWRITE,
                    ctypes.byref(old_prot),
                )
                # Note: VirtualProtect is for LOCAL process. For target process,
                # we use WriteProcessMemory which ignores page protection on win.
                patched = self._write_target(h_process, func_addr, jmp_patch)

                if patched:
                    entry = NTHookEntry(
                        func_name     = func_name,
                        func_addr_32  = func_addr,
                        original_bytes = orig_bytes,
                        hook_stub_addr = stub_cursor,
                        cmd_family    = cmd_family,
                        cmd_code      = cmd_code,
                        arg_count     = arg_count,
                        active        = True,
                    )
                    entries.append(entry)
                    installed += 1

                    tramp_cursor += len(trampoline_bytes)
                    stub_cursor  += len(stub_bytes)

            self._hooks[pid] = entries
            self._log.mediation(
                "WOW64 universal hooks installed in PID %d: %d / %d functions patched.",
                pid, installed, len(NT_HOOK_CATALOGUE)
            )
            return installed

    def remove_hooks(self, pid: int, h_process: int) -> int:
        """
        Remove all installed hooks by restoring original bytes.
        No code is deleted — only the 5-byte patches are reversed.
        Returns number of hooks successfully removed.
        """
        with self._lock:
            entries = self._hooks.pop(pid, [])
            removed = 0
            for entry in entries:
                if entry.active:
                    if self._write_target(h_process, entry.func_addr_32,
                                          entry.original_bytes):
                        entry.active = False
                        removed += 1

            # Free trampoline and stub buffers
            for buf_dict in (self._trampoline_buffers, self._stub_buffers):
                addr = buf_dict.pop(pid, None)
                if addr:
                    _VirtualFreeEx(wintypes.HANDLE(h_process),
                                   ctypes.c_void_p(addr), 0, MEM_RELEASE)

            self._log.mediation(
                "WOW64 hooks removed from PID %d: %d restored.", pid, removed
            )
            return removed

    # ------------------------------------------------------------------
    # HELPERS
    # ------------------------------------------------------------------

    @staticmethod
    def _write_target(h_process: int, addr: int, data: bytes) -> bool:
        n = ctypes.c_size_t()
        buf = (ctypes.c_char * len(data))(*data)
        ok = _WriteProcessMemory(
            wintypes.HANDLE(h_process),
            ctypes.c_void_p(addr),
            buf, len(data),
            ctypes.byref(n),
        )
        return bool(ok) and n.value == len(data)

    def hook_count(self, pid: int) -> int:
        return len(self._hooks.get(pid, []))

    def active_hooks(self, pid: int) -> int:
        return sum(1 for e in self._hooks.get(pid, []) if e.active)
