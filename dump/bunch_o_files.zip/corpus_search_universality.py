"""
Per Rule 36 (corpus is large, use python to search), grep the corpus
for the explicit statements about universality, Subsumption totality,
and the Descriptor Gap Principle's "anything can be solved" claim.
"""
import os, re

corpus = "/mnt/project"
patterns = [
    # Statements claiming TOTAL coverage (not subset coverage)
    r"subsume[s]? (everything|Σ|the totality|all|every)",
    r"totality",
    r"(every|any|all) phenomenon",
    r"(every|any|all) (domain|integrative level)",
    r"(anything|everything|all) can be (solved|projected|classified|described)",
    r"no (phenomenon|domain) (outside|excluded|beyond)",
    r"complete[ly]? (description|classification|framework)",
    r"universal[ly]? applicable",
    r"no remainder",
    r"without remainder",
    # Gödel explicit
    r"G[öo]del",
    r"undecidab",
    r"incomputab",
    r"non-computab",
    # Meta-level
    r"self.applicat",
    r"recursive.*self",
    r"applies to itself",
]

hits = {}
for fname in sorted(os.listdir(corpus)):
    path = os.path.join(corpus, fname)
    if not os.path.isfile(path): continue
    try:
        with open(path, 'r', errors='ignore') as f:
            text = f.read()
    except:
        continue
    for pat in patterns:
        for m in re.finditer(pat, text, re.IGNORECASE):
            # grab context
            start = max(0, m.start() - 80)
            end   = min(len(text), m.end() + 120)
            ctx = text[start:end].replace("\n", " ")
            hits.setdefault(fname, []).append((pat, ctx))

# Print the most relevant hits
print("=" * 80)
print("CORPUS SEARCH for universal-subsumption statements")
print("=" * 80)
high_priority_files = [
    "ET_Three_Tools_Complete_Reference.md",
    "ET_Universal_Projection_Guide6.md",  # not in corpus, uploaded instead
    "ET_Domain_Validity_Theorem.md",
    "ET_Lattice_Compendium.md",
    "ExceptionTheory.md",
]
for fname in high_priority_files:
    if fname in hits:
        print(f"\n── {fname} ─────────────────────────")
        seen = set()
        for pat, ctx in hits[fname][:20]:
            key = ctx.strip()[:100]
            if key in seen: continue
            seen.add(key)
            print(f"  [{pat[:30]:<30}] ...{ctx.strip()}...")
