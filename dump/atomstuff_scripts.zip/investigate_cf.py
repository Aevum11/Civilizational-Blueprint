"""
Deep investigation of the CF method results for N/Z stability projection.
This is unexplored territory — no one has projected N/Z rationals through
the Sempaevum CF method before. Look at EVERYTHING.
"""
import sys
sys.path.insert(0, '/home/claude')
import mpmath
mpmath.mp.dps = 130
from collections import defaultdict, Counter

from sempaevum_nz_viewer import (
    build_atomic_particles, compute_particle_projections, cf_home_find,
    sempaevum_project_mp, N, et_gcd
)

print("Loading and projecting...")
particles = build_atomic_particles(measured_only=True)
results = compute_particle_projections(particles)
print(f"Projected {len(results)} isotopes\n")

# ================================================================
print("=" * 80)
print("1. CF QUALITY FACTOR vs STABILITY")
print("   Do natural isotopes have different CF quality than unstable ones?")
print("=" * 80)

nat_qualities = []
unst_qualities = []
for r in results:
    q = r.get("cf_quality", 0)
    if r.get("is_naturally_occurring"):
        nat_qualities.append(q)
    else:
        unst_qualities.append(q)

nat_qualities.sort()
unst_qualities.sort()

print(f"\n  Natural ({len(nat_qualities)}):")
print(f"    Min quality: {min(nat_qualities) if nat_qualities else 'N/A'}")
print(f"    Max quality: {max(nat_qualities) if nat_qualities else 'N/A'}")
print(f"    Median:      {nat_qualities[len(nat_qualities)//2] if nat_qualities else 'N/A'}")
print(f"  Unstable ({len(unst_qualities)}):")
print(f"    Min quality: {min(unst_qualities) if unst_qualities else 'N/A'}")
print(f"    Max quality: {max(unst_qualities) if unst_qualities else 'N/A'}")
print(f"    Median:      {unst_qualities[len(unst_qualities)//2] if unst_qualities else 'N/A'}")

# ================================================================
print("\n" + "=" * 80)
print("2. SHARED N/Z RATIOS — Isotopes with identical N/Z share CF homes")
print("   How many distinct N/Z values are there? How do they cluster?")
print("=" * 80)

# Group by N/Z ratio (as exact fraction N_val/Z_val in lowest terms)
from math import gcd as math_gcd
nz_groups = defaultdict(list)
for r in results:
    Z = r.get("Z", 0)
    A = r.get("A", 0)
    N_val = A - Z
    if Z == 0: continue
    g = math_gcd(N_val, Z)
    key = (N_val // g, Z // g)  # lowest terms
    nz_groups[key].append(r)

print(f"\n  Total isotopes: {len(results)}")
print(f"  Distinct N/Z values (lowest terms): {len(nz_groups)}")

# Largest groups (same N/Z, different isotopes)
big_groups = sorted(nz_groups.items(), key=lambda x: -len(x[1]))
print(f"\n  Largest same-N/Z groups (different nuclides with identical N/Z):")
for (n, z), group in big_groups[:15]:
    nat = sum(1 for r in group if r.get("is_naturally_occurring"))
    symbols = [r["symbol"] for r in group[:5]]
    more = f" +{len(group)-5} more" if len(group) > 5 else ""
    print(f"    N/Z = {n}/{z} ({len(group)} isotopes, {nat} natural): "
          f"{', '.join(symbols)}{more}")

# ================================================================
print("\n" + "=" * 80)
print("3. CF d_home FACTORIZATION — What primes appear?")
print("   Factor the small d_home values to look for structure")
print("=" * 80)

def factor_small(n):
    """Factor integers up to ~10^15 efficiently."""
    if n <= 1: return {1: 1}
    factors = {}
    d = 2
    while d * d <= n and d < 10**7:
        while n % d == 0:
            factors[d] = factors.get(d, 0) + 1
            n //= d
        d += 1 if d == 2 else 2
    if n > 1:
        factors[n] = 1
    return factors

# Sort by cf_d_home size
by_d_size = sorted(results, key=lambda r: r.get("cf_d_home", 0))

print(f"\n  20 SMALLEST cf_d_home values:")
seen_d = set()
for r in by_d_size:
    d = r.get("cf_d_home", 0)
    if d in seen_d or d <= 0: continue
    seen_d.add(d)
    if len(seen_d) > 20: break
    
    nat = "NAT" if r.get("is_naturally_occurring") else "   "
    q = r.get("cf_quality", 0)
    cls = r.get("cf_class", "?")
    
    if d < 10**15:
        facs = factor_small(d)
        fac_str = " × ".join(f"{p}^{e}" if e > 1 else str(p) for p, e in sorted(facs.items()))
    else:
        fac_str = f"({len(str(d))} digits)"
    
    # How many isotopes share this d_home?
    count = sum(1 for r2 in results if r2.get("cf_d_home") == d)
    
    print(f"    d={d:>12d} = {fac_str:>30s} quality={q:>8d} {nat} {cls:>15s} "
          f"({count} isotopes) e.g. {r['symbol']}")

# ================================================================
print("\n" + "=" * 80)
print("4. CF d_home DIGIT COUNT DISTRIBUTION")
print("   How many digits do the d_home values typically have?")
print("=" * 80)

digit_counts = defaultdict(int)
for r in results:
    d = r.get("cf_d_home", 0)
    if d > 0:
        digits = len(str(d))
        digit_counts[digits] += 1

print(f"\n  {'Digits':>6s} | {'Count':>6s} | Bar")
for digits in sorted(digit_counts.keys()):
    c = digit_counts[digits]
    bar = "█" * min(c, 60)
    print(f"  {digits:>6d} | {c:>6d} | {bar}")

# ================================================================
print("\n" + "=" * 80)
print("5. THE 49 CF_MARGINAL — What's special about them?")
print("=" * 80)

marginals = [r for r in results if r.get("cf_class") == "cf_marginal"]
print(f"\n  {len(marginals)} cf_marginal isotopes:")
for r in sorted(marginals, key=lambda x: x.get("cf_quality", 0)):
    Z = r.get("Z", 0)
    A = r.get("A", 0)
    N_val = A - Z
    g = math_gcd(N_val, Z)
    print(f"    {r['symbol']:>8s} N/Z={N_val}/{Z}={N_val//g}/{Z//g} "
          f"k_NZ={r.get('k_nz','?')} quality={r.get('cf_quality',0)} "
          f"{'NAT' if r.get('is_naturally_occurring') else '   '}")

# ================================================================
print("\n" + "=" * 80)
print("6. CF QUALITY vs k_NZ STABILITY BAND")
print("   Does the CF quality correlate with position in the stability band?")
print("=" * 80)

knz_quality = defaultdict(list)
for r in results:
    k = r.get("k_nz")
    q = r.get("cf_quality", 0)
    if k is not None:
        knz_quality[k].append(q)

print(f"\n  {'k_NZ':>5s} | {'Count':>6s} | {'Min Q':>8s} | {'Max Q':>12s} | {'Median Q':>12s}")
for k in sorted(knz_quality.keys()):
    qs = sorted(knz_quality[k])
    if not qs: continue
    print(f"  {k:>5d} | {len(qs):>6d} | {min(qs):>8d} | {max(qs):>12d} | {qs[len(qs)//2]:>12d}")

# ================================================================
print("\n" + "=" * 80)
print("7. N/Z = 1 SPECIAL CASE — The N=Z line (k_NZ=0)")
print("   log₂(1) = 0 exactly. What does CF do with this?")
print("=" * 80)

nz_one = [r for r in results if r.get("k_nz") == 0]
print(f"\n  {len(nz_one)} isotopes with k_NZ = 0 (N/Z projecting near 1):")
for r in nz_one[:15]:
    Z = r.get("Z", 0)
    A = r.get("A", 0)
    N_val = A - Z
    nz = mpmath.nstr(r.get("nz_ratio", mpmath.mpf(0)), 8)
    print(f"    {r['symbol']:>8s} N={N_val:>3d} Z={Z:>3d} N/Z={nz} "
          f"cf_d={r.get('cf_d_home','?')} quality={r.get('cf_quality','?')} "
          f"{'NAT' if r.get('is_naturally_occurring') else '   '}")

# ================================================================
print("\n" + "=" * 80)
print("8. PRIME CONTENT OF N/Z DENOMINATORS vs CF d_home")
print("   For N/Z = p/q in lowest terms, does q relate to cf_d_home?")
print("=" * 80)

# For each distinct N/Z = p/q, compare q with cf_d_home
print(f"\n  {'N/Z':>10s} | {'q (denom)':>10s} | {'cf_d_home':>12s} | {'quality':>8s} | {'q divides d?':>12s} | Example")
seen = set()
for (n, z), group in sorted(nz_groups.items(), key=lambda x: x[0][0]/x[0][1]):
    if (n, z) in seen: continue
    seen.add((n, z))
    if len(seen) > 30: break
    
    r = group[0]
    d = r.get("cf_d_home", 0)
    q_val = r.get("cf_quality", 0)
    divides = "YES" if d > 0 and z > 0 and d % z == 0 else "no"
    
    d_str = str(d) if d < 10**10 else f"({len(str(d))}d)"
    print(f"  {n:>4d}/{z:<4d} | {z:>10d} | {d_str:>12s} | {q_val:>8d} | {divides:>12s} | {r['symbol']}")

print("\n" + "=" * 80)
print("INVESTIGATION COMPLETE")
print("=" * 80)
