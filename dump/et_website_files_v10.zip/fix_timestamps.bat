@echo off
cd /d "%~dp0"
echo Re-stamping every file under: %CD%
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -Recurse -File | ForEach-Object { $_.LastWriteTime = Get-Date; $_.CreationTime = Get-Date }"
echo.
echo Done.
pause
