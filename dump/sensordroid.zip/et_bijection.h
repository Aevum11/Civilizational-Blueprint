/*
 * ET LOSSLESS SENSOR CAPTURE — CORE BIJECTION
 * =============================================
 * The universal projection Π_N : ℝ⁺ → ℤ × {N/d : d|N} × ℝ
 * and its exact inverse (pullback).
 *
 * Π_N(r) = (k, d, ε) where:
 *   k = round(N · log₂(r))           — integer lattice coordinate
 *   d = N / gcd(|k|, N)              — sublattice family
 *   ε = (N·log₂(r) − k) · 1200/N    — exact residual in cents
 *
 * Pullback: r = 2^((k + ε·N/1200) / N)  — ALGEBRAIC IDENTITY
 *
 * Implementation uses MPFR for arbitrary-precision arithmetic.
 * Zero IEEE 754 float64 anywhere in the computation chain.
 * String → MPFR → computation → (int, int, MPFR string)
 *
 * Derived forward from P∘D∘T = E via Theorem 19.4 (Sempaevum Paper v20).
 *
 * Author: Michael James Muller — Aevum Defluo (Exception Theory)
 * License: CC-BY-4.0
 */

#ifndef ET_BIJECTION_H
#define ET_BIJECTION_H

#include <mpfr.h>
#include <gmp.h>
#include "et_constants.h"

/* ═══════════════════════════════════════════════════════════════════
 * PROJECTION RESULT STRUCTURE
 * The complete output of Π_N(r)
 * ═══════════════════════════════════════════════════════════════════ */
typedef struct {
    long            k;          /* Integer lattice coordinate */
    int             d;          /* Sublattice family: N/gcd(|k|,N) */
    mpfr_t          eps;        /* Exact residual ε in cents (MPFR, full precision) */
    int             sign;       /* +1, -1, or 0 (for bipolar values) */
    int             is_zero;    /* 1 if input was zero ({P,D} Unsubstantiated) */
    int             at_boundary;/* 1 if |ε| is within 1 cent of ∂I boundary */
    int             N;          /* Resolution used for this projection */
} et_projection_t;

/* ═══════════════════════════════════════════════════════════════════
 * PROJECTOR CONTEXT
 * Holds precomputed values for a given resolution N.
 * One projector instance per resolution level.
 * ═══════════════════════════════════════════════════════════════════ */
typedef struct {
    int             N;              /* Resolution */
    mpfr_t          N_mpfr;         /* N as MPFR */
    mpfr_t          cents;          /* 1200 as MPFR */
    mpfr_t          ln2;            /* ln(2) precomputed at full precision */
    mpfr_t          cell_width;     /* 1200/N cents */
    mpfr_t          half_cell;      /* 600/N cents (∂I boundary) */
    mpfr_t          lambda_manifold;/* Λ = 1200/ln2 */
    mpfr_prec_t     prec;           /* MPFR precision in bits */
} et_projector_t;

/* ═══════════════════════════════════════════════════════════════════
 * LIFECYCLE
 * ═══════════════════════════════════════════════════════════════════ */

/*
 * Initialize a projector at resolution N with the given MPFR precision.
 * Precomputes ln(2), cell width, half-cell, Λ.
 * Returns ET_OK on success.
 */
et_error_t et_projector_init(et_projector_t *proj, int N, mpfr_prec_t prec);

/*
 * Free all MPFR resources in a projector.
 */
void et_projector_clear(et_projector_t *proj);

/*
 * Initialize a projection result structure.
 * Must be called before first use.
 */
et_error_t et_projection_init(et_projection_t *result, mpfr_prec_t prec);

/*
 * Free all MPFR resources in a projection result.
 */
void et_projection_clear(et_projection_t *result);

/* ═══════════════════════════════════════════════════════════════════
 * CORE BIJECTION OPERATIONS
 * ═══════════════════════════════════════════════════════════════════ */

/*
 * PROJECT: r_str → (k, d, ε)
 *
 * The universal projection Π_N. Input is a string representation
 * of a POSITIVE real number (the zero-float64 chain requirement).
 *
 * The string → MPFR → computation → result chain ensures zero
 * IEEE 754 float64 contamination.
 *
 * Parameters:
 *   proj     — initialized projector context
 *   r_str    — string representation of r ∈ ℝ⁺ (NOT float)
 *   result   — output projection (must be initialized)
 *
 * Returns ET_OK on success, error code otherwise.
 *
 * The T-act (rounding) is the ONLY nondeterministic step:
 *   k = round(N · log₂(r))  ← TRAVERSER RESOLVES INDETERMINACY
 */
et_error_t et_project(const et_projector_t *proj, const char *r_str,
                       et_projection_t *result);

/*
 * PULLBACK: (k, ε) → r
 *
 * The exact inverse of the projection. ALGEBRAIC IDENTITY.
 * r = 2^((k + ε·N/1200) / N)
 *
 * Proof: ε = (N·log₂(r) − k)·1200/N
 *   ⟹ ε·N/1200 = N·log₂(r) − k
 *   ⟹ k + ε·N/1200 = N·log₂(r)
 *   ⟹ (k + ε·N/1200)/N = log₂(r)
 *   ⟹ 2^((k + ε·N/1200)/N) = r   Q.E.D.
 *
 * Parameters:
 *   proj   — initialized projector context
 *   k      — integer lattice coordinate
 *   eps    — exact residual in cents (MPFR)
 *   r_out  — output: recovered r (must be initialized MPFR)
 *
 * Returns ET_OK on success.
 */
et_error_t et_pullback(const et_projector_t *proj, long k,
                        const mpfr_t eps, mpfr_t r_out);

/*
 * PROJECT BIPOLAR: s_str → (k, d, ε, sign)
 *
 * For bipolar sensor values (audio, accelerometer, gyroscope, magnetometer).
 * Decomposes s = sign(s) · |s|, projects |s|/R₀ through Π_N.
 *
 * In the Complex Lattice (Identity D):
 *   s > 0: k_θ = 0,   d_θ = 1  (identity phase)
 *   s < 0: k_θ = N/2, d_θ = 2  (half-rotation: negation)
 *   s = 0: Unsubstantiated state ({P,D} without T)
 *
 * Parameters:
 *   proj     — initialized projector context
 *   s_str    — string representation of s ∈ ℝ (may be negative)
 *   R0_str   — string representation of R₀ (substrate-derived reference)
 *   result   — output projection (must be initialized)
 *
 * Returns ET_OK on success.
 */
et_error_t et_project_bipolar(const et_projector_t *proj, const char *s_str,
                               const char *R0_str, et_projection_t *result);

/*
 * PULLBACK BIPOLAR: (k, ε, sign, R₀) → s
 *
 * Reconstruct the original bipolar value from lattice coordinates.
 * s = sign · 2^((k + ε·N/1200) / N) · R₀
 *
 * Parameters:
 *   proj   — initialized projector context
 *   result — projection containing k, eps, sign
 *   R0_str — string representation of R₀
 *   s_out  — output: recovered s (must be initialized MPFR)
 *
 * Returns ET_OK on success.
 */
et_error_t et_pullback_bipolar(const et_projector_t *proj,
                                const et_projection_t *result,
                                const char *R0_str, mpfr_t s_out);

/*
 * VERIFY ROUND-TRIP: r_str → project → pullback → r'
 *
 * Verifies losslessness by projecting r, pulling back, and comparing
 * at WORK_DPS precision. Guard digits (COMPUTE_DPS − WORK_DPS = 100)
 * absorb ALL transcendental function residual.
 *
 * Parameters:
 *   proj      — initialized projector context
 *   r_str     — string representation of r
 *   is_exact  — output: 1 if round-trip is exact at WORK_DPS, 0 otherwise
 *
 * Returns ET_OK on success.
 */
et_error_t et_verify_roundtrip(const et_projector_t *proj, const char *r_str,
                                int *is_exact);

/* ═══════════════════════════════════════════════════════════════════
 * ∂I BOUNDARY DETECTION (Identity F)
 * ═══════════════════════════════════════════════════════════════════ */

/*
 * TIGHTNESS: t(ε) = W / (W + |ε|)
 *
 * At N=12 (W=100):
 *   t = 1.0 at ε = 0      (lattice-exact, Exception state)
 *   t = K = 2/3 at |ε| = 50¢  (∂I boundary, Koide threshold)
 *   t = 0.752 at |ε| = 33¢    (Twilight Zone entry)
 *
 * Parameters:
 *   proj    — projector (for cell width W)
 *   eps     — ε in cents
 *   t_out   — output tightness (must be initialized MPFR)
 */
void et_tightness(const et_projector_t *proj, const mpfr_t eps, mpfr_t t_out);

/*
 * ε TO STRING: convert ε (MPFR) to string at specified decimal places.
 *
 * The zero-float64 output path: MPFR → string, never touching float64.
 *
 * Parameters:
 *   eps     — ε value (MPFR)
 *   dps     — number of decimal places to output
 *   buf     — output buffer (must be large enough: dps + 20 for sign/exponent)
 *   buf_len — buffer length
 *
 * Returns number of characters written, or -1 on error.
 */
int et_eps_to_string(const mpfr_t eps, int dps, char *buf, size_t buf_len);

/* ═══════════════════════════════════════════════════════════════════
 * UTILITY: GCD for d-family computation
 * ═══════════════════════════════════════════════════════════════════ */

/*
 * Integer GCD using GMP.
 * d = N / gcd(|k|, N)
 * If k == 0, returns 1 (d = N/N = 1? No: gcd(0, N) = N, so d = N/N = 1)
 *
 * Actually: gcd(0, N) = N by convention, so d = N/gcd(0,N) = N/N = 1.
 * This is correct: k=0 means r = 2^(0/N) = 1, which is the identity
 * element of (ℝ⁺, ×). d=1 is the trivial/octave family. ✓
 */
int et_compute_d(long k, int N);

#endif /* ET_BIJECTION_H */
