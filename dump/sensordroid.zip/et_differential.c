/*
 * ET LOSSLESS SENSOR CAPTURE — DIFFERENTIAL TRACKER IMPLEMENTATION
 * =================================================================
 * Sub-quantization recovery via the differential control law.
 * Ports the Python ETDifferentialTracker from et_lossless_microphone.py
 * to C with MPFR for arbitrary-precision arithmetic.
 *
 * Six algebraic identities converge in process_sample():
 *   B — dε = Λ·dr/r (forward law)
 *   F — tightness t = W/(W+|ε|), ∂I escalation
 *   H — transfer tensor for d-family prediction
 *   C — composition table for d-family validation
 *   K — d-family window for shape coherence
 *   E3 — D₄₂ closure for harmonic shadow consistency
 *
 * Author: Michael James Muller — Aevum Defluo (Exception Theory)
 * License: CC-BY-4.0
 */

#include "et_differential.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>

/* ═══════════════════════════════════════════════════════════════════
 * HELPER: integer GCD (same as in et_bijection.c)
 * ═══════════════════════════════════════════════════════════════════ */
static long i_gcd_d(long a, long b) {
    if (a < 0) a = -a;
    if (b < 0) b = -b;
    while (b != 0) { long t = b; b = a % b; a = t; }
    return a;
}

static int i_lcm(int a, int b) {
    if (a == 0 || b == 0) return 0;
    long g = i_gcd_d((long)a, (long)b);
    return (int)(((long)a / g) * (long)b);
}

/* Euler's totient function φ(n) */
static int euler_phi(int n) {
    int result = n;
    int temp = n;
    for (int p = 2; p * p <= temp; p++) {
        if (temp % p == 0) {
            while (temp % p == 0) temp /= p;
            result -= result / p;
        }
    }
    if (temp > 1) result -= result / temp;
    return result;
}

/* ═══════════════════════════════════════════════════════════════════
 * DIVISOR INDEX LOOKUP
 * ═══════════════════════════════════════════════════════════════════ */
int et_tracker_divisor_index(const et_differential_tracker_t *tracker, int d) {
    for (int i = 0; i < tracker->n_divisors; i++) {
        if (tracker->divisors[i] == d) return i;
    }
    return -1;
}

/* ═══════════════════════════════════════════════════════════════════
 * INITIALIZATION
 *
 * Precomputes all algebraic identity tables:
 *   - Divisors of N and residue sets
 *   - d-family composition table (Identity C)
 *   - Transfer tensor (Identity H) with κ-weighting
 *   - ∂I bifurcation pairs (Identity F)
 *   - D₄₂ closure set (Identity E3)
 *   - Escalation projectors for higher tower levels
 * ═══════════════════════════════════════════════════════════════════ */
et_error_t et_tracker_init(et_differential_tracker_t *tracker,
                            int N, const char *R0_str,
                            int sample_rate, int bit_depth,
                            mpfr_prec_t prec) {
    if (!tracker || !R0_str) return ET_ERR_NULL_INPUT;
    if (N < 1) return ET_ERR_INVALID_N;

    memset(tracker, 0, sizeof(*tracker));
    tracker->N = N;
    tracker->sample_rate = sample_rate;
    tracker->bit_depth = bit_depth;
    tracker->prec = prec;

    /* Copy R₀ string */
    strncpy(tracker->R0_str, R0_str, sizeof(tracker->R0_str) - 1);

    /* ── Initialize MPFR fields ── */
    mpfr_init2(tracker->R0, prec);
    mpfr_init2(tracker->cell_width, prec);
    mpfr_init2(tracker->lsb_normalized, prec);
    mpfr_init2(tracker->eps_max, prec);
    mpfr_init2(tracker->koide_K, prec);
    mpfr_init2(tracker->twilight_entry, prec);
    mpfr_init2(tracker->lambda_manifold, prec);
    mpfr_init2(tracker->sigma_audio, prec);
    mpfr_init2(tracker->prev_refined_eps, prec);
    mpfr_init2(tracker->prev_r, prec);
    mpfr_init2(tracker->prev_tightness, prec);

    /* Parse R₀ */
    if (mpfr_set_str(tracker->R0, R0_str, 10, MPFR_RNDN) != 0)
        return ET_ERR_FORMAT;

    /* Initialize base projector */
    et_error_t err = et_projector_init(&tracker->projector, N, prec);
    if (err != ET_OK) return err;

    /* ── Derived constants ── */
    /* cell_width = 1200/N */
    mpfr_set_si(tracker->cell_width, ET_CENTS_PER_OCTAVE, MPFR_RNDN);
    mpfr_div_si(tracker->cell_width, tracker->cell_width, N, MPFR_RNDN);

    /* lsb_normalized = 1 / 2^(bit_depth - 1) */
    mpfr_set_ui(tracker->lsb_normalized, 1, MPFR_RNDN);
    mpfr_div_2ui(tracker->lsb_normalized, tracker->lsb_normalized,
                  (unsigned long)(bit_depth - 1), MPFR_RNDN);

    /* eps_max = 600/N (half-cell width) */
    mpfr_set_si(tracker->eps_max, 600, MPFR_RNDN);
    mpfr_div_si(tracker->eps_max, tracker->eps_max, N, MPFR_RNDN);

    /* Koide K = 2/3 */
    mpfr_set_si(tracker->koide_K, 2, MPFR_RNDN);
    mpfr_div_si(tracker->koide_K, tracker->koide_K, 3, MPFR_RNDN);

    /* Twilight Zone entry: 33¢ at N=12, generalized */
    mpfr_set_si(tracker->twilight_entry, 33, MPFR_RNDN);

    /* Λ = 1200/ln(2) */
    mpfr_set_si(tracker->lambda_manifold, ET_CENTS_PER_OCTAVE, MPFR_RNDN);
    mpfr_t ln2;
    mpfr_init2(ln2, prec);
    mpfr_const_log2(ln2, MPFR_RNDN);
    mpfr_div(tracker->lambda_manifold, tracker->lambda_manifold, ln2, MPFR_RNDN);
    mpfr_clear(ln2);

    /* σ = 1/√12 */
    mpfr_set_si(tracker->sigma_audio, 12, MPFR_RNDN);
    mpfr_sqrt(tracker->sigma_audio, tracker->sigma_audio, MPFR_RNDN);
    mpfr_ui_div(tracker->sigma_audio, 1, tracker->sigma_audio, MPFR_RNDN);

    /* ── Compute divisors of N ── */
    tracker->n_divisors = 0;
    for (int d = 1; d <= N; d++) {
        if (N % d == 0 && tracker->n_divisors < ET_MAX_DIVISORS) {
            tracker->divisors[tracker->n_divisors++] = d;
        }
    }

    /* ── Compute residue sets: Res_N(d) ── */
    for (int di = 0; di < tracker->n_divisors; di++) {
        int d = tracker->divisors[di];
        tracker->residue_sets[di].count = 0;
        for (int k = 0; k < N; k++) {
            long g = i_gcd_d((long)k, (long)N);
            if (g == 0) g = (long)N;
            int dk = (int)(N / g);
            if (dk == d && tracker->residue_sets[di].count < ET_MAX_DIVISORS) {
                tracker->residue_sets[di].residues[tracker->residue_sets[di].count++] = k;
            }
        }
    }

    /* ── d-family composition table (Identity C, Theorem C.2) ──
     * comp_table[i][j] = set of possible d-families from d_i ⊗ d_j
     * with κ ∈ {-1, 0, +1} */
    for (int i = 0; i < tracker->n_divisors; i++) {
        for (int j = 0; j < tracker->n_divisors; j++) {
            et_d_composition_set_t *cs = &tracker->comp_table[i][j];
            cs->count = 0;
            /* Track which d-values we've already added */
            int seen[ET_MAX_DIVISORS];
            int n_seen = 0;

            for (int ki = 0; ki < tracker->residue_sets[i].count; ki++) {
                int r1 = tracker->residue_sets[i].residues[ki];
                for (int kj = 0; kj < tracker->residue_sets[j].count; kj++) {
                    int r2 = tracker->residue_sets[j].residues[kj];
                    for (int kappa = -1; kappa <= 1; kappa++) {
                        int s = ((r1 + r2 + kappa) % N + N) % N;
                        long g = i_gcd_d((long)s, (long)N);
                        if (g == 0) g = (long)N;
                        int ds = (int)(N / g);
                        /* Add if not already present */
                        int found = 0;
                        for (int si = 0; si < n_seen; si++) {
                            if (seen[si] == ds) { found = 1; break; }
                        }
                        if (!found && cs->count < ET_MAX_DIVISORS) {
                            cs->values[cs->count++] = ds;
                            seen[n_seen++] = ds;
                        }
                    }
                }
            }
        }
    }

    /* ── Transfer tensor (Identity H) with κ-weighting ──
     * tensor[i][j] = P(d_j | d_i self-composition)
     * P(κ=0) = 3/4, P(κ=+1) = P(κ=-1) = 1/8 */
    tracker->tensor_initialized = 1;
    for (int i = 0; i < tracker->n_divisors; i++) {
        for (int j = 0; j < tracker->n_divisors; j++) {
            mpfr_init2(tracker->tensor[i][j], prec);
            mpfr_set_zero(tracker->tensor[i][j], 1);

            int d1 = tracker->divisors[i];
            int d3 = tracker->divisors[j];
            et_residue_set_t *rs1 = &tracker->residue_sets[i];

            if (rs1->count == 0) continue;
            int total = rs1->count * rs1->count;

            /* For each κ value, count compositions producing d3 */
            int kappa_weights[3] = {0, 0, 0}; /* κ=-1, κ=0, κ=+1 */
            mpfr_t p_kappa[3], count_mpfr, total_mpfr, term;
            for (int pi = 0; pi < 3; pi++) mpfr_init2(p_kappa[pi], prec);
            mpfr_init2(count_mpfr, prec);
            mpfr_init2(total_mpfr, prec);
            mpfr_init2(term, prec);

            /* P(κ=-1) = 1/8, P(κ=0) = 3/4, P(κ=+1) = 1/8 */
            mpfr_set_si(p_kappa[0], 1, MPFR_RNDN);
            mpfr_div_si(p_kappa[0], p_kappa[0], 8, MPFR_RNDN);
            mpfr_set_si(p_kappa[1], 3, MPFR_RNDN);
            mpfr_div_si(p_kappa[1], p_kappa[1], 4, MPFR_RNDN);
            mpfr_set_si(p_kappa[2], 1, MPFR_RNDN);
            mpfr_div_si(p_kappa[2], p_kappa[2], 8, MPFR_RNDN);

            mpfr_set_si(total_mpfr, total, MPFR_RNDN);

            for (int ki = -1; ki <= 1; ki++) {
                int count = 0;
                for (int a = 0; a < rs1->count; a++) {
                    for (int b = 0; b < rs1->count; b++) {
                        int s = ((rs1->residues[a] + rs1->residues[b] + ki) % N + N) % N;
                        long g = i_gcd_d((long)s, (long)N);
                        if (g == 0) g = (long)N;
                        if ((int)(N / g) == d3) count++;
                    }
                }
                mpfr_set_si(count_mpfr, count, MPFR_RNDN);
                mpfr_div(term, count_mpfr, total_mpfr, MPFR_RNDN);
                mpfr_mul(term, term, p_kappa[ki + 1], MPFR_RNDN);
                mpfr_add(tracker->tensor[i][j], tracker->tensor[i][j], term, MPFR_RNDN);
            }

            for (int pi = 0; pi < 3; pi++) mpfr_clear(p_kappa[pi]);
            mpfr_clears(count_mpfr, total_mpfr, term, (mpfr_ptr)0);
        }
    }

    /* ── ∂I bifurcation pairs (Identity F, Theorem F.3) ── */
    for (int k = 0; k < N; k++) {
        int k_next = (k + 1) % N;
        long g_left = i_gcd_d((long)k, (long)N);
        if (g_left == 0) g_left = (long)N;
        long g_right = i_gcd_d((long)k_next, (long)N);
        if (g_right == 0) g_right = (long)N;
        tracker->bifurc_d_left[k] = (int)(N / g_left);
        tracker->bifurc_d_right[k] = (int)(N / g_right);
    }

    /* ── D₄₂ closure set (Identity E3) ──
     * {lcm(a,b) : a,b ∈ {1,...,12}} */
    tracker->dc42_count = 0;
    for (int a = 1; a <= 12; a++) {
        for (int b = 1; b <= 12; b++) {
            int lc = i_lcm(a, b);
            /* Check if already present */
            int found = 0;
            for (int ci = 0; ci < tracker->dc42_count; ci++) {
                if (tracker->dc42_set[ci] == lc) { found = 1; break; }
            }
            if (!found && tracker->dc42_count < 64) {
                tracker->dc42_set[tracker->dc42_count++] = lc;
            }
        }
    }

    /* ── Escalation projectors (higher tower levels) ── */
    tracker->n_esc_projectors = 0;
    for (int ti = 0; ti < ET_LCM_TOWER_SIZE; ti++) {
        int N_esc = ET_LCM_TOWER[ti];
        if (N_esc > N && tracker->n_esc_projectors < ET_MAX_ESCALATION) {
            int idx = tracker->n_esc_projectors;
            tracker->esc_N[idx] = N_esc;
            et_projector_init(&tracker->esc_projectors[idx], N_esc, prec);
            tracker->n_esc_projectors++;
        }
    }

    /* ── Initialize tracking state ── */
    et_tracker_reset(tracker);

    return ET_OK;
}

void et_tracker_clear(et_differential_tracker_t *tracker) {
    if (!tracker) return;

    mpfr_clears(tracker->R0, tracker->cell_width, tracker->lsb_normalized,
                tracker->eps_max, tracker->koide_K, tracker->twilight_entry,
                tracker->lambda_manifold, tracker->sigma_audio,
                tracker->prev_refined_eps, tracker->prev_r, tracker->prev_tightness,
                (mpfr_ptr)0);

    et_projector_clear(&tracker->projector);

    /* Clear tensor MPFR values */
    if (tracker->tensor_initialized) {
        for (int i = 0; i < tracker->n_divisors; i++) {
            for (int j = 0; j < tracker->n_divisors; j++) {
                mpfr_clear(tracker->tensor[i][j]);
            }
        }
    }

    /* Clear escalation projectors */
    for (int i = 0; i < tracker->n_esc_projectors; i++) {
        et_projector_clear(&tracker->esc_projectors[i]);
    }
}

void et_tracker_reset(et_differential_tracker_t *tracker) {
    if (!tracker) return;
    tracker->has_prev = 0;
    tracker->prev_k = 0;
    tracker->prev_d = 0;
    tracker->prev_sign = 0;
    mpfr_set_zero(tracker->prev_refined_eps, 1);
    mpfr_set_zero(tracker->prev_r, 1);
    mpfr_set_zero(tracker->prev_tightness, 1);
    tracker->sample_count = 0;
    tracker->prediction_count = 0;
    tracker->override_count = 0;
    tracker->escalation_count = 0;
    tracker->twilight_count = 0;
    tracker->d_window_pos = 0;
    tracker->d_window_filled = 0;
    memset(tracker->d_window, 0, sizeof(tracker->d_window));
}

/* ═══════════════════════════════════════════════════════════════════
 * TIGHTNESS (Identity F, Theorem F.1)
 * ═══════════════════════════════════════════════════════════════════ */
void et_tracker_tightness(const et_differential_tracker_t *tracker,
                           const mpfr_t eps, mpfr_t t_out) {
    et_tightness(&tracker->projector, eps, t_out);
}

/* ═══════════════════════════════════════════════════════════════════
 * CORE: PROCESS ONE SAMPLE
 *
 * The 7-step algorithm where all six identities converge:
 *
 * 1. MEASURE: Π_N(|s|/R₀) → (k, d, ε_meas)
 * 2. LATTICE-EXACT CHECK: |ε| ≈ 0 → d invariant (E2.2)
 * 3. ∂I CHECK: t ≤ K+0.05 → ESCALATE to higher N (F)
 * 4. PREDICT: ε_pred = ε_prev + Λ·dr/r (B.1)
 * 5. d-FAMILY PREDICT: P(d_meas|d_prev) via tensor (H) + validation (C)
 * 6. FUSE: compare prediction vs measurement
 * 7. UPDATE: store refined ε and tracking state
 * ═══════════════════════════════════════════════════════════════════ */
et_error_t et_tracker_process(et_differential_tracker_t *tracker,
                               const char *sample_str,
                               et_sensor_sample_t *result) {
    if (!tracker || !sample_str || !result) return ET_ERR_NULL_INPUT;

    mpfr_prec_t prec = tracker->prec;
    tracker->sample_count++;

    /* Initialize result projection */
    et_error_t err = et_projection_init(&result->projection, prec);
    if (err != ET_OK) return err;

    /* Parse sample value */
    mpfr_t s, r;
    mpfr_init2(s, prec);
    mpfr_init2(r, prec);

    /* Handle fraction format "a/b" */
    const char *slash = strchr(sample_str, '/');
    if (slash) {
        mpfr_t num, den;
        mpfr_init2(num, prec);
        mpfr_init2(den, prec);
        size_t num_len = (size_t)(slash - sample_str);
        char *num_s = (char *)malloc(num_len + 1);
        if (!num_s) { mpfr_clears(s, r, (mpfr_ptr)0); return ET_ERR_ALLOC; }
        memcpy(num_s, sample_str, num_len);
        num_s[num_len] = '\0';
        mpfr_set_str(num, num_s, 10, MPFR_RNDN);
        mpfr_set_str(den, slash + 1, 10, MPFR_RNDN);
        mpfr_div(s, num, den, MPFR_RNDN);
        free(num_s);
        mpfr_clears(num, den, (mpfr_ptr)0);
    } else {
        mpfr_set_str(s, sample_str, 10, MPFR_RNDN);
    }

    int sgn = mpfr_sgn(s);

    /* ── Handle zero: {P,D} Unsubstantiated ── */
    if (sgn == 0) {
        result->projection.k = 0;
        result->projection.d = 0;
        mpfr_set_zero(result->projection.eps, 1);
        result->projection.sign = ET_SIGN_ZERO;
        result->projection.is_zero = 1;
        result->projection.N = tracker->N;
        result->tracking_source = 0; /* initial */
        tracker->has_prev = 0;
        mpfr_clears(s, r, (mpfr_ptr)0);
        return ET_OK;
    }

    /* Decompose: sign + magnitude, divide by R₀ */
    int sign = (sgn > 0) ? 1 : -1;
    mpfr_abs(r, s, MPFR_RNDN);
    mpfr_div(r, r, tracker->R0, MPFR_RNDN);

    /* Convert r to string for projection (zero float64 chain) */
    char *r_str = (char *)malloc(ET_WORK_DPS + 64);
    if (!r_str) { mpfr_clears(s, r, (mpfr_ptr)0); return ET_ERR_ALLOC; }
    mpfr_sprintf(r_str, "%.*Re", ET_WORK_DPS, r);

    /* ═══ STEP 1: MEASURE — raw projection at base N ═══ */
    et_projection_t meas;
    et_projection_init(&meas, prec);
    err = et_project(&tracker->projector, r_str, &meas);
    if (err != ET_OK) {
        free(r_str);
        et_projection_clear(&meas);
        mpfr_clears(s, r, (mpfr_ptr)0);
        return err;
    }

    long k_meas = meas.k;
    int d_meas = meas.d;

    /* Compute tightness of measurement (Identity F) */
    mpfr_t t_meas;
    mpfr_init2(t_meas, prec);
    et_tracker_tightness(tracker, meas.eps, t_meas);

    /* ═══ STEP 2: LATTICE-EXACT CHECK (Identity E2, Theorem E2.2) ═══
     * If |ε| < 1 cent, d is invariant across ALL resolutions.
     * No escalation needed. */
    mpfr_t abs_eps, one_cent;
    mpfr_init2(abs_eps, prec);
    mpfr_init2(one_cent, prec);
    mpfr_abs(abs_eps, meas.eps, MPFR_RNDN);
    mpfr_set_ui(one_cent, 1, MPFR_RNDN);
    int lattice_exact = (mpfr_cmp(abs_eps, one_cent) < 0) ? 1 : 0;

    /* ═══ STEP 3: ∂I BOUNDARY CHECK (Identity F, Theorem F.6) ═══
     * If not lattice-exact and tightness ≤ K + 0.05, escalate */
    int escalated = 0;
    int escalated_N = tracker->N;

    if (!lattice_exact) {
        mpfr_t threshold_t, margin;
        mpfr_init2(threshold_t, prec);
        mpfr_init2(margin, prec);
        mpfr_set_str(margin, "0.05", 10, MPFR_RNDN);
        mpfr_add(threshold_t, tracker->koide_K, margin, MPFR_RNDN);

        if (mpfr_cmp(t_meas, threshold_t) <= 0) {
            /* ESCALATE: project at higher tower levels */
            for (int ei = 0; ei < tracker->n_esc_projectors; ei++) {
                et_projection_t esc_proj;
                et_projection_init(&esc_proj, prec);
                et_error_t esc_err = et_project(&tracker->esc_projectors[ei], r_str, &esc_proj);
                if (esc_err == ET_OK) {
                    mpfr_t t_esc;
                    mpfr_init2(t_esc, prec);
                    et_tightness(&tracker->esc_projectors[ei], esc_proj.eps, t_esc);

                    /* Check if clear of ∂I at this resolution */
                    mpfr_t esc_boundary_t, esc_eps_max;
                    mpfr_init2(esc_boundary_t, prec);
                    mpfr_init2(esc_eps_max, prec);
                    mpfr_set_si(esc_eps_max, 600, MPFR_RNDN);
                    mpfr_div_si(esc_eps_max, esc_eps_max, tracker->esc_N[ei], MPFR_RNDN);
                    /* t_boundary = 100/(100 + eps_max) generalized */
                    mpfr_t w_esc;
                    mpfr_init2(w_esc, prec);
                    mpfr_set_si(w_esc, ET_CENTS_PER_OCTAVE, MPFR_RNDN);
                    mpfr_div_si(w_esc, w_esc, tracker->esc_N[ei], MPFR_RNDN);
                    mpfr_t denom_esc;
                    mpfr_init2(denom_esc, prec);
                    mpfr_add(denom_esc, w_esc, esc_eps_max, MPFR_RNDN);
                    mpfr_div(esc_boundary_t, w_esc, denom_esc, MPFR_RNDN);
                    mpfr_add(esc_boundary_t, esc_boundary_t, margin, MPFR_RNDN);

                    if (mpfr_cmp(t_esc, esc_boundary_t) > 0) {
                        /* Clear of ∂I — use escalated projection */
                        k_meas = esc_proj.k;
                        d_meas = esc_proj.d;
                        mpfr_set(meas.eps, esc_proj.eps, MPFR_RNDN);
                        mpfr_set(t_meas, t_esc, MPFR_RNDN);
                        escalated = 1;
                        escalated_N = tracker->esc_N[ei];
                        tracker->escalation_count++;
                        mpfr_clears(t_esc, esc_boundary_t, esc_eps_max, w_esc, denom_esc, (mpfr_ptr)0);
                        et_projection_clear(&esc_proj);
                        break;
                    }
                    mpfr_clears(t_esc, esc_boundary_t, esc_eps_max, w_esc, denom_esc, (mpfr_ptr)0);
                }
                et_projection_clear(&esc_proj);
            }
        }
        mpfr_clears(threshold_t, margin, (mpfr_ptr)0);
    }

    /* Twilight Zone tracking */
    if (mpfr_cmp(abs_eps, tracker->twilight_entry) > 0) {
        tracker->twilight_count++;
    }

    /* ═══ STEP 4: PREDICT — control law if we have prior state ═══ */
    mpfr_t refined_eps;
    mpfr_init2(refined_eps, prec);
    int tracking_source;

    int can_predict = (tracker->has_prev &&
                       mpfr_sgn(tracker->prev_r) > 0 &&
                       mpfr_sgn(r) > 0 &&
                       sign == tracker->prev_sign);

    if (!can_predict) {
        mpfr_set(refined_eps, meas.eps, MPFR_RNDN);
        tracking_source = 0; /* initial */
    } else {
        /* Predict ε change via Identity B (Theorem B.1): dε = Λ·dr/r */
        mpfr_t dr, predicted_deps, predicted_eps;
        mpfr_init2(dr, prec);
        mpfr_init2(predicted_deps, prec);
        mpfr_init2(predicted_eps, prec);

        mpfr_sub(dr, r, tracker->prev_r, MPFR_RNDN);
        mpfr_mul(predicted_deps, tracker->lambda_manifold, dr, MPFR_RNDN);
        mpfr_div(predicted_deps, predicted_deps, tracker->prev_r, MPFR_RNDN);

        mpfr_add(predicted_eps, tracker->prev_refined_eps, predicted_deps, MPFR_RNDN);

        /* Account for cell transitions */
        if (k_meas != tracker->prev_k) {
            mpfr_t k_shift_cents;
            mpfr_init2(k_shift_cents, prec);
            mpfr_set_si(k_shift_cents, (long)(k_meas - tracker->prev_k), MPFR_RNDN);
            mpfr_mul(k_shift_cents, k_shift_cents, tracker->cell_width, MPFR_RNDN);
            mpfr_sub(predicted_eps, predicted_eps, k_shift_cents, MPFR_RNDN);
            mpfr_clear(k_shift_cents);
        }

        /* ═══ STEP 5: TIGHTNESS-WEIGHTED THRESHOLD (Identity F) ═══ */
        mpfr_t quantization_cents, effective_threshold, confidence;
        mpfr_init2(quantization_cents, prec);
        mpfr_init2(effective_threshold, prec);
        mpfr_init2(confidence, prec);

        /* quantization_cents = Λ · LSB / r */
        mpfr_mul(quantization_cents, tracker->lambda_manifold,
                 tracker->lsb_normalized, MPFR_RNDN);
        mpfr_div(quantization_cents, quantization_cents, r, MPFR_RNDN);

        /* confidence = prev_tightness × current_tightness */
        if (mpfr_sgn(tracker->prev_tightness) > 0) {
            mpfr_mul(confidence, tracker->prev_tightness, t_meas, MPFR_RNDN);
        } else {
            mpfr_set(confidence, t_meas, MPFR_RNDN);
        }

        /* ═══ STEP 5b: d-FAMILY PREDICTION (Identities H + C) ═══ */
        mpfr_t d_boost;
        mpfr_init2(d_boost, prec);
        mpfr_set_ui(d_boost, 1, MPFR_RNDN);

        if (tracker->has_prev && tracker->prev_d > 0) {
            int prev_idx = et_tracker_divisor_index(tracker, tracker->prev_d);
            int meas_idx = et_tracker_divisor_index(tracker, d_meas);

            if (prev_idx >= 0) {
                /* Identity C validation: is d_meas reachable? */
                et_d_composition_set_t *reachable = &tracker->comp_table[prev_idx][prev_idx];
                int is_reachable = 0;
                for (int ri = 0; ri < reachable->count; ri++) {
                    if (reachable->values[ri] == d_meas) { is_reachable = 1; break; }
                }
                if (!is_reachable) {
                    mpfr_set_str(d_boost, "0.5", 10, MPFR_RNDN);
                }

                /* Identity H: transition probability */
                if (meas_idx >= 0) {
                    mpfr_t t_prob;
                    mpfr_init2(t_prob, prec);
                    mpfr_set(t_prob, tracker->tensor[prev_idx][meas_idx], MPFR_RNDN);

                    mpfr_t thresh_high, thresh_mid;
                    mpfr_init2(thresh_high, prec);
                    mpfr_init2(thresh_mid, prec);
                    mpfr_set_str(thresh_high, "0.3", 10, MPFR_RNDN);
                    mpfr_set_str(thresh_mid, "0.1", 10, MPFR_RNDN);

                    if (mpfr_cmp(t_prob, thresh_high) > 0) {
                        mpfr_set_str(d_boost, "1.2", 10, MPFR_RNDN);
                    } else if (mpfr_cmp(t_prob, thresh_mid) > 0) {
                        mpfr_set_ui(d_boost, 1, MPFR_RNDN);
                    } else if (mpfr_sgn(t_prob) > 0) {
                        mpfr_set_str(d_boost, "0.8", 10, MPFR_RNDN);
                    }

                    mpfr_clears(t_prob, thresh_high, thresh_mid, (mpfr_ptr)0);
                }
            }
        }

        /* Combined threshold */
        mpfr_mul(effective_threshold, quantization_cents, confidence, MPFR_RNDN);
        mpfr_mul(effective_threshold, effective_threshold, d_boost, MPFR_RNDN);

        /* ═══ STEP 6: FUSE ═══ */
        mpfr_t disagreement;
        mpfr_init2(disagreement, prec);
        mpfr_sub(disagreement, predicted_eps, meas.eps, MPFR_RNDN);
        mpfr_abs(disagreement, disagreement, MPFR_RNDN);

        if (mpfr_cmp(disagreement, effective_threshold) <= 0) {
            /* Prediction within threshold — accept (higher precision) */
            mpfr_set(refined_eps, predicted_eps, MPFR_RNDN);
            tracking_source = 1; /* predicted */
            tracker->prediction_count++;
        } else {
            /* Override — measurement wins (transient/discontinuity) */
            mpfr_set(refined_eps, meas.eps, MPFR_RNDN);
            tracking_source = 2; /* override */
            tracker->override_count++;
        }

        mpfr_clears(dr, predicted_deps, predicted_eps, quantization_cents,
                     effective_threshold, confidence, d_boost, disagreement, (mpfr_ptr)0);
    }

    /* ═══ STEP 7: UPDATE STATE ═══ */
    tracker->prev_k = k_meas;
    tracker->prev_d = d_meas;
    mpfr_set(tracker->prev_refined_eps, refined_eps, MPFR_RNDN);
    mpfr_set(tracker->prev_r, r, MPFR_RNDN);
    tracker->prev_sign = sign;
    et_tracker_tightness(tracker, refined_eps, tracker->prev_tightness);
    tracker->has_prev = 1;

    /* Identity K: update d-family window */
    if (et_tracker_divisor_index(tracker, d_meas) >= 0) {
        tracker->d_window[tracker->d_window_pos] = d_meas;
        tracker->d_window_pos = (tracker->d_window_pos + 1) % ET_D_WINDOW_SIZE;
        if (tracker->d_window_filled < ET_D_WINDOW_SIZE)
            tracker->d_window_filled++;
    }

    /* ── Pack result ── */
    result->projection.k = k_meas;
    result->projection.d = d_meas;
    mpfr_set(result->projection.eps, refined_eps, MPFR_RNDN);
    result->projection.sign = (sign > 0) ? ET_SIGN_POSITIVE : ET_SIGN_NEGATIVE;
    result->projection.is_zero = 0;
    result->projection.at_boundary = meas.at_boundary;
    result->projection.N = escalated ? escalated_N : tracker->N;
    result->tracking_source = tracking_source;
    result->escalated = escalated;
    result->escalated_N = escalated_N;

    /* Cleanup */
    mpfr_clears(s, r, t_meas, abs_eps, one_cent, refined_eps, (mpfr_ptr)0);
    et_projection_clear(&meas);
    free(r_str);

    return ET_OK;
}

/* ═══════════════════════════════════════════════════════════════════
 * ADC INTEGER SHORTCUT
 * ═══════════════════════════════════════════════════════════════════ */
et_error_t et_tracker_process_adc(et_differential_tracker_t *tracker,
                                   long adc_value, long max_value,
                                   et_sensor_sample_t *result) {
    if (!tracker || !result) return ET_ERR_NULL_INPUT;
    if (max_value == 0) return ET_ERR_DIVISION_BY_ZERO;

    char frac_str[64];
    if (adc_value == 0) {
        snprintf(frac_str, sizeof(frac_str), "0");
    } else {
        long abs_adc = (adc_value < 0) ? -adc_value : adc_value;
        if (adc_value > 0) {
            snprintf(frac_str, sizeof(frac_str), "%ld/%ld", abs_adc, max_value);
        } else {
            snprintf(frac_str, sizeof(frac_str), "-%ld/%ld", abs_adc, max_value);
        }
    }

    return et_tracker_process(tracker, frac_str, result);
}

/* ═══════════════════════════════════════════════════════════════════
 * STATISTICS
 * ═══════════════════════════════════════════════════════════════════ */
et_error_t et_tracker_stats_init(et_tracker_stats_t *stats, mpfr_prec_t prec) {
    if (!stats) return ET_ERR_NULL_INPUT;
    memset(stats, 0, sizeof(*stats));
    mpfr_init2(stats->prediction_rate, prec);
    mpfr_init2(stats->resolved_depth, prec);
    mpfr_init2(stats->total_resolved, prec);
    mpfr_init2(stats->sigma_ET, prec);
    return ET_OK;
}

void et_tracker_stats_clear(et_tracker_stats_t *stats) {
    if (!stats) return;
    mpfr_clears(stats->prediction_rate, stats->resolved_depth,
                stats->total_resolved, stats->sigma_ET, (mpfr_ptr)0);
}

et_error_t et_tracker_get_stats(const et_differential_tracker_t *tracker,
                                 et_tracker_stats_t *stats) {
    if (!tracker || !stats) return ET_ERR_NULL_INPUT;

    stats->total_samples = tracker->sample_count;
    stats->predictions_accepted = tracker->prediction_count;
    stats->measurement_overrides = tracker->override_count;
    stats->escalations = tracker->escalation_count;
    stats->twilight_zone_samples = tracker->twilight_count;

    /* Prediction rate */
    long long total_tracked = tracker->prediction_count + tracker->override_count;
    if (total_tracked > 0) {
        mpfr_set_si(stats->prediction_rate, (long)tracker->prediction_count, MPFR_RNDN);
        mpfr_t total_mpfr;
        mpfr_init2(total_mpfr, tracker->prec);
        mpfr_set_si(total_mpfr, (long)total_tracked, MPFR_RNDN);
        mpfr_div(stats->prediction_rate, stats->prediction_rate, total_mpfr, MPFR_RNDN);
        mpfr_clear(total_mpfr);
    } else {
        mpfr_set_zero(stats->prediction_rate, 1);
    }

    /* Resolved depth: log₂(1/(1-rate)) / 2 */
    if (mpfr_sgn(stats->prediction_rate) > 0 &&
        mpfr_cmp_ui(stats->prediction_rate, 1) < 0) {
        mpfr_t one_minus, inv, log_val, two;
        mpfr_init2(one_minus, tracker->prec);
        mpfr_init2(inv, tracker->prec);
        mpfr_init2(log_val, tracker->prec);
        mpfr_init2(two, tracker->prec);

        mpfr_ui_sub(one_minus, 1, stats->prediction_rate, MPFR_RNDN);
        mpfr_ui_div(inv, 1, one_minus, MPFR_RNDN);
        mpfr_log2(log_val, inv, MPFR_RNDN);
        mpfr_set_ui(two, 2, MPFR_RNDN);
        mpfr_div(stats->resolved_depth, log_val, two, MPFR_RNDN);

        mpfr_clears(one_minus, inv, log_val, two, (mpfr_ptr)0);
    } else if (mpfr_cmp_ui(stats->prediction_rate, 1) >= 0) {
        mpfr_set_si(stats->resolved_depth, tracker->bit_depth, MPFR_RNDN);
    } else {
        mpfr_set_zero(stats->resolved_depth, 1);
    }

    /* Total resolved = bit_depth + resolved_depth */
    mpfr_set_si(stats->total_resolved, tracker->bit_depth, MPFR_RNDN);
    mpfr_add(stats->total_resolved, stats->total_resolved,
             stats->resolved_depth, MPFR_RNDN);

    /* σ_ET = 1/√12 */
    mpfr_set(stats->sigma_ET, tracker->sigma_audio, MPFR_RNDN);

    /* d-family window distribution */
    memset(stats->d_window_dist, 0, sizeof(stats->d_window_dist));
    stats->d_window_dist_count = 0;
    stats->dominant_d_family = -1;
    int max_count = 0;

    for (int i = 0; i < tracker->d_window_filled; i++) {
        int d = tracker->d_window[i];
        int idx = et_tracker_divisor_index(tracker, d);
        if (idx >= 0) {
            stats->d_window_dist[idx]++;
            if (stats->d_window_dist[idx] > max_count) {
                max_count = stats->d_window_dist[idx];
                stats->dominant_d_family = d;
            }
        }
    }
    for (int i = 0; i < tracker->n_divisors; i++) {
        if (stats->d_window_dist[i] > 0) stats->d_window_dist_count++;
    }

    return ET_OK;
}
