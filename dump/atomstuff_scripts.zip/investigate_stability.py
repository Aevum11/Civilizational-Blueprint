"""
Find the projection that reveals nuclear stability.
The mass projection (r = m/m_e) doesn't show it — stability uses a different Descriptor.

Candidate DSRs:
  1. N/Z — neutron-to-proton ratio (defines the valley of stability)
  2. Binding fraction — Δm / M_constituents (how much mass→binding)
  3. β-decay Q / m_e — directly measures stability (Q<0 = stable against β-decay)
  4. S_2n / m_e — two-neutron separation energy (reveals shell closures)
  5. Asymmetry — (N-Z)/A (how far from N=Z symmetry)
"""
import sys
sys.path.insert(0, '/home/claude')
import mpmath
mpmath.mp.dps = 130
from collections import defaultdict

from sempaevum_atomic_viewer import (
    build_atomic_particles, compute_particle_projections,
    sempaevum_project_mp, N, et_gcd
)

print("Loading data...")
particles = build_atomic_particles(measured_only=True)
results = compute_particle_projections(particles)
print(f"Projected {len(results)} isotopes")

# Constants as strings for mpmath
m_p_str = "1.007276466621"   # proton mass in u
m_n_str = "1.008664915600"   # neutron mass in u
m_e_MeV_str = "0.51099895000" # electron mass in MeV

by_ZA = {}
for r in results:
    by_ZA[(r.get("Z",0), r.get("A",0))] = r

# ================================================================
print("\n" + "=" * 80)
print("PROJECTION 1: N/Z (neutron-to-proton ratio)")
print("  The valley of stability IS N/Z ≈ 1 for light, ~1.5 for heavy")
print("=" * 80)

nz_data = []
for r in results:
    Z = r.get("Z", 0)
    A = r.get("A", 0)
    N_val = A - Z
    if Z == 0 or A <= Z: continue
    
    nz_mp = mpmath.mpf(N_val) / mpmath.mpf(Z)
    nz_str = mpmath.nstr(nz_mp, 30)
    proj = sempaevum_project_mp(nz_str, 12)
    
    nz_data.append({
        "symbol": r["symbol"], "Z": Z, "A": A, "N": N_val,
        "nz": nz_mp, "k_nz": proj[0], "d_nz": proj[1], "eps_nz": proj[2],
        "is_nat": r.get("is_naturally_occurring", False),
    })

# Distribution of k_nz for natural vs all
nat_k = defaultdict(int)
all_k = defaultdict(int)
for d in nz_data:
    all_k[d["k_nz"]] += 1
    if d["is_nat"]:
        nat_k[d["k_nz"]] += 1

print(f"\n  k_NZ distribution (N/Z projected at N=12):")
print(f"  {'k_NZ':>5s} | {'N/Z range':>14s} | {'Natural':>8s} | {'All':>8s} | {'Nat%':>6s} | {'2^(k/12)':>10s}")
for k in sorted(all_k.keys()):
    n = nat_k.get(k, 0)
    a = all_k[k]
    pct = 100 * n / a if a else 0
    nz_val = mpmath.power(2, mpmath.mpf(k) / mpmath.mpf(12))
    print(f"  {k:>5d} | N/Z≈{mpmath.nstr(nz_val, 5):>9s} | {n:>8d} | {a:>8d} | {pct:>5.1f}% | {mpmath.nstr(nz_val, 8)}")

# ================================================================
print("\n" + "=" * 80)
print("PROJECTION 2: Binding fraction Δm/(Z·m_p + N·m_n)")
print("  How much constituent mass is converted to binding energy")
print("=" * 80)

bf_nat_k = defaultdict(int)
bf_all_k = defaultdict(int)
bf_data = []

for r in results:
    Z = r.get("Z", 0)
    A = r.get("A", 0)
    N_val = A - Z
    mass_str = r.get("Ar_str", r.get("mass_str", ""))
    if not mass_str or Z == 0: continue
    
    M = mpmath.mpf(mass_str)
    constituent = Z * mpmath.mpf(m_p_str) + N_val * mpmath.mpf(m_n_str)
    
    if constituent <= M: continue  # Unbound
    
    bf = (constituent - M) / constituent  # binding fraction
    
    if bf > 0:
        bf_str = mpmath.nstr(bf, 30)
        proj = sempaevum_project_mp(bf_str, 12)
        bf_data.append({
            "symbol": r["symbol"], "Z": Z, "A": A,
            "bf": bf, "k_bf": proj[0], "d_bf": proj[1], "eps_bf": proj[2],
            "is_nat": r.get("is_naturally_occurring", False),
        })
        bf_all_k[proj[0]] += 1
        if r.get("is_naturally_occurring"):
            bf_nat_k[proj[0]] += 1

print(f"\n  k_BF distribution (binding fraction projected at N=12):")
print(f"  {'k_BF':>5s} | {'BF range':>14s} | {'Natural':>8s} | {'All':>8s} | {'Nat%':>6s}")
for k in sorted(bf_all_k.keys()):
    n = bf_nat_k.get(k, 0)
    a = bf_all_k[k]
    pct = 100 * n / a if a else 0
    bf_val = mpmath.power(2, mpmath.mpf(k) / mpmath.mpf(12))
    print(f"  {k:>5d} | BF≈{mpmath.nstr(bf_val, 5):>10s} | {n:>8d} | {a:>8d} | {pct:>5.1f}%")

# ================================================================
print("\n" + "=" * 80)
print("PROJECTION 3: β-decay energy ratio Q_β / m_e")
print("  Positive = unstable (can β-decay), Negative = stable against β-decay")
print("  Uses mass differences between adjacent isobars")
print("=" * 80)

beta_nat_k = defaultdict(int)
beta_all_k = defaultdict(int)
beta_stable_k = defaultdict(int)
beta_data = []

for r in results:
    Z = r.get("Z", 0)
    A = r.get("A", 0)
    if Z == 0 or A <= Z: continue
    
    # Q_β⁻ = M(Z,A) - M(Z+1,A) in atomic mass units
    # If Q > 0, β⁻ decay is possible (unstable)
    daughter = by_ZA.get((Z+1, A))
    if not daughter: continue
    
    M_parent_str = r.get("Ar_str", r.get("mass_str", ""))
    M_daughter_str = daughter.get("Ar_str", daughter.get("mass_str", ""))
    if not M_parent_str or not M_daughter_str: continue
    
    M_parent = mpmath.mpf(M_parent_str)
    M_daughter = mpmath.mpf(M_daughter_str)
    
    Q_u = M_parent - M_daughter  # in atomic mass units
    Q_MeV = Q_u * mpmath.mpf("931.494102")  # convert to MeV
    Q_over_me = Q_MeV / mpmath.mpf(m_e_MeV_str)  # dimensionless
    
    # Check stability: also need Q_β⁺ < 0 (check Z-1 daughter)
    parent_of_EC = by_ZA.get((Z-1, A))
    is_beta_stable = False
    if parent_of_EC:
        M_ec = mpmath.mpf(parent_of_EC.get("Ar_str", parent_of_EC.get("mass_str", "")))
        Q_ec = M_ec - M_parent  # Q for EC from the Z-1 parent
        # This nucleus is stable if Q_β⁻ < 0 AND it can't be produced by β⁺ of Z-1
        # Actually: stable against β⁻ if Q_β⁻ = M(Z,A)-M(Z+1,A) < 0
        # And stable against EC/β⁺ if Q_EC = M(Z,A)-M(Z-1,A) > 0 ... wait
        # Q_β⁺ for THIS nucleus = M(Z,A) - M(Z-1,A) - 2*m_e (in atomic mass units roughly)
        pass
    
    # For now just track Q_β⁻
    if abs(Q_over_me) > 0:
        # Use |Q/m_e| as the ratio, track sign separately
        abs_Q = abs(Q_over_me)
        q_str = mpmath.nstr(abs_Q, 30)
        proj = sempaevum_project_mp(q_str, 12)
        
        sign = "β⁻ unstable" if Q_over_me > 0 else "β⁻ stable"
        
        beta_data.append({
            "symbol": r["symbol"], "Z": Z, "A": A,
            "Q_MeV": Q_MeV, "Q_over_me": Q_over_me,
            "k_Q": proj[0], "d_Q": proj[1], "sign": "+" if Q_over_me > 0 else "-",
            "is_nat": r.get("is_naturally_occurring", False),
        })

# Analyze: do stable nuclei cluster at specific k_Q?
stable_Qs = [d for d in beta_data if d["sign"] == "-"]
unstable_Qs = [d for d in beta_data if d["sign"] == "+"]

print(f"\n  β⁻ decay Q-values projected:")
print(f"  Total pairs analyzed: {len(beta_data)}")
print(f"  β⁻ stable (Q<0): {len(stable_Qs)}")
print(f"  β⁻ unstable (Q>0): {len(unstable_Qs)}")

# k distribution for |Q|/m_e
q_stable_k = defaultdict(int)
q_unstable_k = defaultdict(int)
for d in beta_data:
    if d["sign"] == "-":
        q_stable_k[d["k_Q"]] += 1
    else:
        q_unstable_k[d["k_Q"]] += 1

print(f"\n  {'k_|Q|':>6s} | {'|Q|/m_e≈':>10s} | {'β⁻ stable':>10s} | {'β⁻ unstable':>12s} | {'Stable%':>8s}")
all_q_k = sorted(set(list(q_stable_k.keys()) + list(q_unstable_k.keys())))
for k in all_q_k:
    s = q_stable_k.get(k, 0)
    u = q_unstable_k.get(k, 0)
    total = s + u
    pct = 100 * s / total if total else 0
    q_val = mpmath.power(2, mpmath.mpf(k) / mpmath.mpf(12))
    q_MeV = q_val * mpmath.mpf(m_e_MeV_str)
    print(f"  {k:>6d} | {mpmath.nstr(q_val, 6):>10s} | {s:>10d} | {u:>12d} | {pct:>7.1f}%")

# ================================================================
print("\n" + "=" * 80)
print("PROJECTION 4: Two-neutron separation energy S_2n / m_e")
print("  S_2n = M(Z,A-2) + M(n) + M(n) - M(Z,A)")
print("  Reveals shell closures and drip lines")
print("=" * 80)

s2n_data = []
m_n_u = mpmath.mpf(m_n_str)

for r in results:
    Z = r.get("Z", 0)
    A = r.get("A", 0)
    if Z == 0 or A < 3: continue
    
    parent = by_ZA.get((Z, A-2))
    if not parent: continue
    
    M_str = r.get("Ar_str", r.get("mass_str", ""))
    M_parent_str = parent.get("Ar_str", parent.get("mass_str", ""))
    if not M_str or not M_parent_str: continue
    
    M = mpmath.mpf(M_str)
    M_parent = mpmath.mpf(M_parent_str)
    
    S_2n_u = M_parent + 2 * m_n_u - M  # in atomic mass units
    S_2n_MeV = S_2n_u * mpmath.mpf("931.494102")
    S_2n_over_me = S_2n_MeV / mpmath.mpf(m_e_MeV_str)
    
    if S_2n_over_me > 0:
        s2n_str = mpmath.nstr(S_2n_over_me, 30)
        proj = sempaevum_project_mp(s2n_str, 12)
        N_val = A - Z
        is_magic_N = N_val in {2,8,20,28,50,82,126}
        
        s2n_data.append({
            "symbol": r["symbol"], "Z": Z, "A": A, "N": N_val,
            "S_2n_MeV": S_2n_MeV, "k_s2n": proj[0], "d_s2n": proj[1],
            "eps_s2n": proj[2], "is_nat": r.get("is_naturally_occurring", False),
            "is_magic_N": is_magic_N,
        })

# Do magic-N isotopes cluster at specific k_s2n?
magic_k = defaultdict(int)
non_magic_k = defaultdict(int)
for d in s2n_data:
    if d["is_magic_N"]:
        magic_k[d["k_s2n"]] += 1
    else:
        non_magic_k[d["k_s2n"]] += 1

print(f"\n  S_2n projected for {len(s2n_data)} isotopes")
print(f"  Magic-N isotopes: {sum(magic_k.values())}")

print(f"\n  {'k_S2n':>6s} | {'S_2n≈MeV':>10s} | {'Magic N':>8s} | {'Non-magic':>10s} | {'Magic%':>8s}")
all_s2n_k = sorted(set(list(magic_k.keys()) + list(non_magic_k.keys())))
for k in all_s2n_k:
    m = magic_k.get(k, 0)
    nm = non_magic_k.get(k, 0)
    total = m + nm
    pct = 100 * m / total if total else 0
    s2n_MeV = mpmath.power(2, mpmath.mpf(k) / mpmath.mpf(12)) * mpmath.mpf(m_e_MeV_str)
    print(f"  {k:>6d} | {mpmath.nstr(s2n_MeV, 5):>10s} | {m:>8d} | {nm:>10d} | {pct:>7.1f}%")

# ================================================================
print("\n" + "=" * 80)
print("PROJECTION 5: COMPOSITE — N/Z combined with mass projection")
print("  Using N/Z as the imaginary-axis coordinate instead of J")
print("=" * 80)

# For each isotope, compute k_θ from N/Z instead of from J
# This gives a 2D lattice: (k_mass, k_NZ) 
nz_mass_data = []
for i, r in enumerate(results):
    Z = r.get("Z", 0)
    A = r.get("A", 0)
    N_val = A - Z
    if Z == 0 or A <= Z: continue
    
    k_mass = r["k_r_12"]
    nz_mp = mpmath.mpf(N_val) / mpmath.mpf(Z)
    nz_str = mpmath.nstr(nz_mp, 30)
    proj_nz = sempaevum_project_mp(nz_str, 12)
    k_nz = proj_nz[0]
    
    nz_mass_data.append({
        "symbol": r["symbol"], "k_mass": k_mass, "k_nz": k_nz,
        "is_nat": r.get("is_naturally_occurring", False),
    })

# Count natural isotopes in each (k_mass, k_nz) cell
cell_nat = defaultdict(int)
cell_all = defaultdict(int)
for d in nz_mass_data:
    cell = (d["k_mass"], d["k_nz"])
    cell_all[cell] += 1
    if d["is_nat"]:
        cell_nat[cell] += 1

# For each k_nz band, what fraction is natural?
nz_band_nat = defaultdict(int)
nz_band_all = defaultdict(int)
for d in nz_mass_data:
    nz_band_all[d["k_nz"]] += 1
    if d["is_nat"]:
        nz_band_nat[d["k_nz"]] += 1

print(f"\n  Natural fraction by k_NZ band (N/Z projected):")
print(f"  {'k_NZ':>5s} | {'N/Z≈':>8s} | {'Natural':>8s} | {'All':>8s} | {'Nat%':>8s} | Visualization")
for k_nz in sorted(nz_band_all.keys()):
    n = nz_band_nat.get(k_nz, 0)
    a = nz_band_all[k_nz]
    pct = 100 * n / a if a else 0
    nz_approx = mpmath.power(2, mpmath.mpf(k_nz) / mpmath.mpf(12))
    bar_len = int(pct / 2)
    bar = "█" * bar_len + "░" * (50 - bar_len)
    print(f"  {k_nz:>5d} | {mpmath.nstr(nz_approx, 4):>8s} | {n:>8d} | {a:>8d} | {pct:>7.1f}% | {bar}")

print("\n" + "=" * 80)
print("STABILITY PROJECTION INVESTIGATION COMPLETE")
print("=" * 80)
