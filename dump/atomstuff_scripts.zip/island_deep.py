"""
Deep island of stability investigation.
1. Map the ENTIRE predicted island region on the N/Z lattice
2. Find where the island first appears
3. Analyze every superheavy artificial element
"""
import sys
sys.path.insert(0, '/home/claude')
import mpmath
mpmath.mp.dps = 130
from collections import defaultdict

from sempaevum_nz_viewer import (
    build_atomic_particles, compute_particle_projections,
    cf_home_find, sempaevum_project_mp, N, et_gcd
)

print("Loading...")
particles = build_atomic_particles(measured_only=True)
results = compute_particle_projections(particles)
print(f"Projected {len(results)} isotopes\n")

by_ZA = {}
by_Z = defaultdict(list)
for r in results:
    Z, A = r.get("Z", 0), r.get("A", 0)
    by_ZA[(Z, A)] = r
    by_Z[Z].append(r)

# ================================================================
print("=" * 100)
print("1. MAP THE ENTIRE ISLAND REGION — Z=104 to Z=130, N=150 to N=200")
print("   Project every possible (Z, N) combination onto the N/Z lattice")
print("   Even isotopes NOT in AME2020 — project the RATIO itself")
print("=" * 100)

# The Koide threshold
KOIDE_EPS = mpmath.mpf("1.955")

print(f"\n  Projecting all N/Z ratios for Z=104..130, N=150..200...")
print(f"  Highlighting: k_NZ=7 (stability band edge), |ε|≤1.955¢ (Koide), |ε|≤5¢ (near-node)")

island_map = []
for Z_val in range(104, 131):
    for N_val in range(150, 201):
        A_val = Z_val + N_val
        nz = mpmath.mpf(N_val) / mpmath.mpf(Z_val)
        nz_str = mpmath.nstr(nz, 40)
        proj = sempaevum_project_mp(nz_str, 12)
        if proj is None: continue
        k, d, eps = proj
        
        # Check if this isotope is in AME2020
        in_ame = (Z_val, A_val) in by_ZA
        ame_data = by_ZA.get((Z_val, A_val))
        
        island_map.append({
            "Z": Z_val, "N": N_val, "A": A_val,
            "nz": nz, "k": k, "d": d, "eps": eps,
            "abs_eps": abs(eps), "in_ame": in_ame,
            "ame": ame_data,
        })

# Find the most lattice-exact positions in the island region
island_map.sort(key=lambda x: x["abs_eps"])

print(f"\n  Total (Z,N) combinations mapped: {len(island_map)}")
print(f"  In AME2020: {sum(1 for x in island_map if x['in_ame'])}")

print(f"\n  TOP 30 MOST LATTICE-EXACT in the island region:")
print(f"  {'Z':>4s} {'N':>4s} {'A':>4s} {'N/Z':>10s} {'k_NZ':>5s} {'d_NZ':>5s} {'|ε_NZ|':>12s} {'AME?':>5s} {'Magic':>8s}")
for entry in island_map[:30]:
    magic = ""
    if entry["Z"] in {114, 120, 126}: magic += f"Z{entry['Z']}"
    if entry["N"] in {172, 184}: magic += f"N{entry['N']}"
    ame_flag = "YES" if entry["in_ame"] else "---"
    print(f"  {entry['Z']:>4d} {entry['N']:>4d} {entry['A']:>4d} {mpmath.nstr(entry['nz'], 8):>10s} "
          f"{entry['k']:>5d} {entry['d']:>5d} {mpmath.nstr(entry['abs_eps'], 8):>12s} {ame_flag:>5s} {magic:>8s}")

# ================================================================
print(f"\n{'=' * 100}")
print("2. THE k_NZ = 7 SLICE OF THE ISLAND — Only the stability-band isotopes")
print("   Sorted by |ε| to find the lattice-preferred island nuclei")
print("=" * 100)

k7_island = [x for x in island_map if x["k"] == 7]
k7_island.sort(key=lambda x: x["abs_eps"])

print(f"\n  {len(k7_island)} island-region isotopes at k_NZ = 7 (inside stability band)")
print(f"\n  TOP 30 (smallest |ε|):")
print(f"  {'Z':>4s} {'N':>4s} {'A':>4s} {'N/Z':>10s} {'d_NZ':>5s} {'ε_NZ(¢)':>12s} {'AME?':>5s} {'Magic':>10s}")
for entry in k7_island[:30]:
    magic = ""
    if entry["Z"] in {114, 120, 126}: magic += f"Z{entry['Z']}"
    if entry["N"] in {172, 184}: magic += f"N{entry['N']}"
    ame_flag = "YES" if entry["in_ame"] else "---"
    print(f"  {entry['Z']:>4d} {entry['N']:>4d} {entry['A']:>4d} {mpmath.nstr(entry['nz'], 8):>10s} "
          f"{entry['d']:>5d} {mpmath.nstr(entry['eps'], 8):>12s} {ame_flag:>5s} {magic:>10s}")

# ================================================================
print(f"\n{'=' * 100}")
print("3. N/Z = 3/2 LINE THROUGH THE ISLAND — The Koide track")
print("   Every (Z, N) where N/Z = 3/2 exactly → |ε| = 1.955¢ (Koide)")
print("=" * 100)

koide_track = []
for Z_val in range(2, 130):
    N_val = Z_val * 3 // 2
    if N_val * 2 == Z_val * 3:  # Exact 3/2
        A_val = Z_val + N_val
        in_ame = (Z_val, A_val) in by_ZA
        koide_track.append((Z_val, N_val, A_val, in_ame))

print(f"\n  N/Z = 3/2 exactly (every even Z):")
print(f"  {'Z':>4s} {'N':>4s} {'A':>4s} {'In AME2020':>10s} {'Element':>10s}")
for Z_val, N_val, A_val, in_ame in koide_track:
    if Z_val >= 80:  # Focus on heavy
        elem_names = {80:"Hg",82:"Pb",84:"Po",86:"Rn",88:"Ra",90:"Th",92:"U",94:"Pu",
                      96:"Cm",98:"Cf",100:"Fm",102:"No",104:"Rf",106:"Sg",108:"Hs",
                      110:"Ds",112:"Cn",114:"Fl",116:"Lv",118:"Og",120:"Ubn",122:"Ubt",
                      124:"Ubq",126:"Ubh",128:"Ubo"}
        name = elem_names.get(Z_val, f"Z={Z_val}")
        ame_flag = "MEASURED" if in_ame else "predicted"
        print(f"  {Z_val:>4d} {N_val:>4d} {A_val:>4d} {ame_flag:>10s} {name:>10s}")

# ================================================================
print(f"\n{'=' * 100}")
print("4. EVERY SUPERHEAVY ELEMENT — Full lattice comparison")
print("   Compare d_NZ, d_mass, ε distributions, CF homes")
print("=" * 100)

for Z_val in range(100, 119):
    chain = sorted(by_Z.get(Z_val, []), key=lambda r: r.get("A", 0))
    if not chain: continue
    
    elem_names = {100:"Fm",101:"Md",102:"No",103:"Lr",104:"Rf",105:"Db",
                  106:"Sg",107:"Bh",108:"Hs",109:"Mt",110:"Ds",111:"Rg",
                  112:"Cn",113:"Nh",114:"Fl",115:"Mc",116:"Lv",117:"Ts",118:"Og"}
    name = elem_names.get(Z_val, f"Z{Z_val}")
    
    # Compute statistics
    k_nz_vals = [r.get("k_nz") for r in chain if r.get("k_nz") is not None]
    d_nz_vals = [r.get("d_nz") for r in chain if r.get("d_nz") is not None]
    eps_nz_vals = [abs(r.get("eps_nz", mpmath.mpf(0))) for r in chain if r.get("eps_nz") is not None]
    d_mass_vals = [r.get("d_r_12") for r in chain]
    
    k_nz_unique = sorted(set(k_nz_vals)) if k_nz_vals else []
    d_nz_unique = sorted(set(d_nz_vals)) if d_nz_vals else []
    d_mass_unique = sorted(set(d_mass_vals))
    min_eps = min(eps_nz_vals) if eps_nz_vals else mpmath.mpf(99)
    best_iso = min(chain, key=lambda r: abs(r.get("eps_nz", mpmath.mpf(99))))
    
    # Check for N/Z = 3/2 isotope
    has_koide = any(r.get("A",0) - Z_val == Z_val * 3 // 2 and (Z_val * 3) % 2 == 0 for r in chain)
    
    print(f"\n  {name} (Z={Z_val}): {len(chain)} isotopes")
    print(f"    k_NZ values: {k_nz_unique}")
    print(f"    d_NZ families: {d_nz_unique}")
    print(f"    d_mass families: {d_mass_unique}")
    print(f"    min |ε_NZ|: {mpmath.nstr(min_eps, 6)}¢ at {best_iso['symbol']}")
    print(f"    Koide isotope (N/Z=3/2): {'YES' if has_koide else 'no'}")
    
    # Show each isotope
    for r in chain:
        A = r.get("A", 0)
        N_val = A - Z_val
        eps = r.get("eps_nz", mpmath.mpf(0))
        nz_str = mpmath.nstr(r.get("nz_ratio", mpmath.mpf(0)), 6)
        koide_flag = " ★KOIDE" if abs(abs(eps) - KOIDE_EPS) < mpmath.mpf("0.001") else ""
        k7_flag = " ◄BAND" if r.get("k_nz") == 7 else ""
        k8_flag = " ◄EDGE" if r.get("k_nz") == 8 else ""
        print(f"      A={A:>3d} N={N_val:>3d} N/Z={nz_str:>8s} k_NZ={r.get('k_nz','?'):>2} d_NZ={r.get('d_nz','?'):>2} "
              f"ε_NZ={mpmath.nstr(eps, 6):>10s}¢ d_mass={r.get('d_r_12','?'):>2}{koide_flag}{k7_flag}{k8_flag}")

# ================================================================
print(f"\n{'=' * 100}")
print("5. THE LATTICE PREDICTION — Where does the island FIRST appear?")
print("   For each Z from 104 upward, find the N that gives the smallest |ε_NZ|")
print("   at k_NZ = 7 (inside the stability band)")
print("=" * 100)

print(f"\n  For each Z, the N that minimizes |ε_NZ| within k_NZ = 7:")
print(f"  {'Z':>4s} {'Best N':>6s} {'A':>4s} {'N/Z':>10s} {'|ε_NZ|':>12s} {'d_NZ':>5s} {'In AME?':>7s} {'Magic':>10s}")

for Z_val in range(104, 131):
    # Find all N values that give k_NZ = 7
    best_entry = None
    for N_val in range(Z_val, Z_val * 2 + 1):  # N from Z to 2Z
        nz = mpmath.mpf(N_val) / mpmath.mpf(Z_val)
        nz_str = mpmath.nstr(nz, 40)
        proj = sempaevum_project_mp(nz_str, 12)
        if proj is None: continue
        k, d, eps = proj
        if k != 7: continue
        if best_entry is None or abs(eps) < best_entry["abs_eps"]:
            best_entry = {
                "Z": Z_val, "N": N_val, "A": Z_val + N_val,
                "nz": nz, "k": k, "d": d, "eps": eps, "abs_eps": abs(eps),
                "in_ame": (Z_val, Z_val + N_val) in by_ZA,
            }
    
    if best_entry:
        magic = ""
        if best_entry["Z"] in {114, 120, 126}: magic += f"Z{best_entry['Z']}"
        if best_entry["N"] in {172, 184}: magic += f"N{best_entry['N']}"
        ame_flag = "YES" if best_entry["in_ame"] else "---"
        print(f"  {best_entry['Z']:>4d} {best_entry['N']:>6d} {best_entry['A']:>4d} "
              f"{mpmath.nstr(best_entry['nz'], 8):>10s} {mpmath.nstr(best_entry['abs_eps'], 8):>12s} "
              f"{best_entry['d']:>5d} {ame_flag:>7s} {magic:>10s}")

# ================================================================
print(f"\n{'=' * 100}")
print("6. d_NZ FAMILY TRANSITION — Where does d_NZ change in superheavy region?")
print("   d_NZ family assignment may distinguish island from non-island")
print("=" * 100)

for Z_val in range(104, 131):
    entries = []
    for N_val in range(max(Z_val, 140), min(Z_val * 2 + 1, 210)):
        nz = mpmath.mpf(N_val) / mpmath.mpf(Z_val)
        proj = sempaevum_project_mp(mpmath.nstr(nz, 40), 12)
        if proj is None: continue
        k, d, eps = proj
        entries.append((N_val, k, d, eps))
    
    if not entries: continue
    
    # Find d transitions
    transitions = []
    for i in range(1, len(entries)):
        if entries[i][2] != entries[i-1][2] or entries[i][1] != entries[i-1][1]:
            transitions.append((entries[i-1], entries[i]))
    
    if transitions:
        elem_names = {104:"Rf",105:"Db",106:"Sg",107:"Bh",108:"Hs",109:"Mt",110:"Ds",
                      111:"Rg",112:"Cn",113:"Nh",114:"Fl",115:"Mc",116:"Lv",117:"Ts",
                      118:"Og",119:"Uue",120:"Ubn",121:"Ubu",122:"Ubt",123:"Ubt",
                      124:"Ubq",125:"Ubp",126:"Ubh",127:"Ubs",128:"Ubo",129:"Ube",130:"Utn"}
        name = elem_names.get(Z_val, f"Z{Z_val}")
        print(f"\n  {name} (Z={Z_val}): d/k transitions in N={entries[0][0]}..{entries[-1][0]}:")
        for (n1, k1, d1, e1), (n2, k2, d2, e2) in transitions:
            arrow_k = f"k={k1}→{k2}" if k1 != k2 else f"k={k1}"
            arrow_d = f"d={d1}→{d2}" if d1 != d2 else f"d={d1}"
            magic_n1 = " ◆" if n1 in {172, 184} else ""
            magic_n2 = " ◆" if n2 in {172, 184} else ""
            print(f"      N={n1}{magic_n1} → N={n2}{magic_n2}: {arrow_k}, {arrow_d}")

print(f"\n{'=' * 100}")
print("DEEP ISLAND INVESTIGATION COMPLETE")
print("=" * 100)
