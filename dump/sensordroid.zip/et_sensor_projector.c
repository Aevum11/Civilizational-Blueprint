/*
 * ET LOSSLESS SENSOR CAPTURE — SENSOR PROJECTOR IMPLEMENTATION
 * =============================================================
 * Parameterizes the universal bijection per sensor type.
 * Each sensor's R₀ is derived from its P-substrate via the
 * Identification Principle — not chosen, not tuned.
 *
 * Author: Michael James Muller — Aevum Defluo (Exception Theory)
 * License: CC-BY-4.0
 */

#include "et_sensor_projector.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

/* ═══════════════════════════════════════════════════════════════════
 * SENSOR PROPERTIES TABLE
 * Defines per-sensor characteristics based on sensor type.
 * ═══════════════════════════════════════════════════════════════════ */
typedef struct {
    int axes;
    int is_bipolar;
} et_sensor_props_t;

static const et_sensor_props_t SENSOR_PROPS[] = {
    /* AUDIO */       {1, 1},
    /* ACCEL */       {3, 1},
    /* GYRO */        {3, 1},
    /* MAG */         {3, 1},
    /* BARO */        {1, 0},
    /* LIGHT */       {1, 0},
    /* TEMP */        {1, 0},
    /* CAMERA */      {1, 0},  /* Per-pixel, per-channel scalar */
    /* GPS_POS */     {3, 1},  /* lat, lon, alt (lat/lon can be "negative" via convention) */
    /* GPS_TIME */    {1, 0},
    /* HUMIDITY */    {1, 0},
    /* PROXIMITY */   {1, 0},
    /* HEART_RATE */  {1, 0},
    /* STEP */        {1, 0}
};

/* ═══════════════════════════════════════════════════════════════════
 * LIFECYCLE
 * ═══════════════════════════════════════════════════════════════════ */

et_error_t et_sensor_projector_init(et_sensor_projector_t *sp,
                                     et_sensor_type_t sensor_type,
                                     int N, mpfr_prec_t prec) {
    if ((int)sensor_type < 0 || (int)sensor_type >= ET_SENSOR_TYPE_COUNT)
        return ET_ERR_SENSOR;

    return et_sensor_projector_init_custom(sp, sensor_type,
                                           ET_SENSOR_R0_DEFAULTS[sensor_type],
                                           N, prec);
}

et_error_t et_sensor_projector_init_custom(et_sensor_projector_t *sp,
                                            et_sensor_type_t sensor_type,
                                            const char *R0_str,
                                            int N, mpfr_prec_t prec) {
    if (!sp || !R0_str) return ET_ERR_NULL_INPUT;
    if ((int)sensor_type < 0 || (int)sensor_type >= ET_SENSOR_TYPE_COUNT)
        return ET_ERR_SENSOR;

    memset(sp, 0, sizeof(*sp));
    sp->sensor_type = sensor_type;

    /* Copy R₀ string */
    strncpy(sp->R0_str, R0_str, sizeof(sp->R0_str) - 1);
    sp->R0_str[sizeof(sp->R0_str) - 1] = '\0';

    /* Initialize R₀ as MPFR — from string, zero float64 */
    mpfr_init2(sp->R0, prec);
    if (mpfr_set_str(sp->R0, R0_str, 10, MPFR_RNDN) != 0) {
        mpfr_clear(sp->R0);
        return ET_ERR_FORMAT;
    }
    if (mpfr_sgn(sp->R0) <= 0) {
        mpfr_clear(sp->R0);
        return ET_ERR_ZERO_R0;
    }

    /* Initialize the universal projector at resolution N */
    et_error_t err = et_projector_init(&sp->projector, N, prec);
    if (err != ET_OK) {
        mpfr_clear(sp->R0);
        return err;
    }

    /* Set sensor properties from the table */
    sp->axes = SENSOR_PROPS[sensor_type].axes;
    sp->is_bipolar = SENSOR_PROPS[sensor_type].is_bipolar;

    /* Default sensor metadata */
    strncpy(sp->sensor_name, ET_SENSOR_TYPE_NAMES[sensor_type],
            sizeof(sp->sensor_name) - 1);
    strncpy(sp->access_mode, "unknown", sizeof(sp->access_mode) - 1);
    sp->sample_rate = 0;
    sp->bit_depth = 0;

    return ET_OK;
}

void et_sensor_projector_clear(et_sensor_projector_t *sp) {
    if (!sp) return;
    mpfr_clear(sp->R0);
    et_projector_clear(&sp->projector);
}

/* ═══════════════════════════════════════════════════════════════════
 * SENSOR PROJECTION
 *
 * The pipeline per sensor sample:
 *   1. Parse value from string (zero float64)
 *   2. If bipolar: decompose sign + magnitude
 *   3. Divide by R₀ to get dimensionless ratio r
 *   4. Project r through Π_N → (k, d, ε)
 *   5. Pack into et_sensor_sample_t with metadata
 * ═══════════════════════════════════════════════════════════════════ */

et_error_t et_sensor_project(const et_sensor_projector_t *sp,
                              const char *value_str, int axis,
                              long long timestamp_ns,
                              et_sensor_sample_t *sample) {
    if (!sp || !value_str || !sample) return ET_ERR_NULL_INPUT;

    memset(sample, 0, sizeof(*sample));
    sample->axis = axis;
    sample->timestamp_ns = timestamp_ns;
    sample->sensor_type = sp->sensor_type;

    et_error_t err;

    if (sp->is_bipolar) {
        /* Bipolar projection: handles sign decomposition internally */
        err = et_projection_init(&sample->projection, sp->projector.prec);
        if (err != ET_OK) return err;

        err = et_project_bipolar(&sp->projector, value_str, sp->R0_str,
                                  &sample->projection);
    } else {
        /* Unipolar projection: value is always positive */
        err = et_projection_init(&sample->projection, sp->projector.prec);
        if (err != ET_OK) return err;

        /* Divide by R₀ first to get dimensionless ratio */
        mpfr_prec_t prec = sp->projector.prec;
        mpfr_t val, ratio;
        mpfr_init2(val, prec);
        mpfr_init2(ratio, prec);

        /* Parse value — handle fraction format */
        const char *slash = strchr(value_str, '/');
        if (slash) {
            mpfr_t num, den;
            mpfr_init2(num, prec);
            mpfr_init2(den, prec);
            size_t num_len = (size_t)(slash - value_str);
            char *num_s = (char *)malloc(num_len + 1);
            if (!num_s) {
                mpfr_clears(val, ratio, (mpfr_ptr)0);
                return ET_ERR_ALLOC;
            }
            memcpy(num_s, value_str, num_len);
            num_s[num_len] = '\0';
            mpfr_set_str(num, num_s, 10, MPFR_RNDN);
            mpfr_set_str(den, slash + 1, 10, MPFR_RNDN);
            mpfr_div(val, num, den, MPFR_RNDN);
            free(num_s);
            mpfr_clear(num);
            mpfr_clear(den);
        } else {
            if (mpfr_set_str(val, value_str, 10, MPFR_RNDN) != 0) {
                mpfr_clears(val, ratio, (mpfr_ptr)0);
                return ET_ERR_FORMAT;
            }
        }

        /* Check for zero */
        if (mpfr_sgn(val) == 0) {
            sample->projection.k = 0;
            sample->projection.d = 0;
            mpfr_set_zero(sample->projection.eps, 1);
            sample->projection.sign = ET_SIGN_ZERO;
            sample->projection.is_zero = 1;
            sample->projection.N = sp->projector.N;
            mpfr_clears(val, ratio, (mpfr_ptr)0);
            return ET_OK;
        }

        if (mpfr_sgn(val) < 0) {
            mpfr_clears(val, ratio, (mpfr_ptr)0);
            return ET_ERR_NEGATIVE_R;
        }

        /* r = value / R₀ — dimensionless ratio */
        mpfr_div(ratio, val, sp->R0, MPFR_RNDN);

        /* Convert to string for projection (zero float64 chain maintained) */
        char *r_str = (char *)malloc(ET_WORK_DPS + 64);
        if (!r_str) {
            mpfr_clears(val, ratio, (mpfr_ptr)0);
            return ET_ERR_ALLOC;
        }
        mpfr_sprintf(r_str, "%.*Re", ET_WORK_DPS, ratio);

        /* Project through Π_N */
        err = et_project(&sp->projector, r_str, &sample->projection);

        free(r_str);
        mpfr_clears(val, ratio, (mpfr_ptr)0);
    }

    return err;
}

/* ═══════════════════════════════════════════════════════════════════
 * RECONSTRUCTION
 * ═══════════════════════════════════════════════════════════════════ */

et_error_t et_sensor_reconstruct(const et_sensor_projector_t *sp,
                                  const et_sensor_sample_t *sample,
                                  mpfr_t value_out) {
    if (!sp || !sample) return ET_ERR_NULL_INPUT;

    if (sample->projection.is_zero) {
        mpfr_set_zero(value_out, 1);
        return ET_OK;
    }

    if (sp->is_bipolar) {
        /* Bipolar reconstruction */
        return et_pullback_bipolar(&sp->projector, &sample->projection,
                                    sp->R0_str, value_out);
    } else {
        /* Unipolar: pullback r, then multiply by R₀ */
        mpfr_prec_t prec = sp->projector.prec;
        mpfr_t r;
        mpfr_init2(r, prec);

        et_error_t err = et_pullback(&sp->projector, sample->projection.k,
                                      sample->projection.eps, r);
        if (err != ET_OK) {
            mpfr_clear(r);
            return err;
        }

        /* value = r · R₀ */
        mpfr_mul(value_out, r, sp->R0, MPFR_RNDN);

        mpfr_clear(r);
        return ET_OK;
    }
}

/* ═══════════════════════════════════════════════════════════════════
 * ADC INTEGER PROJECTION — zero float64 shortcut
 *
 * For sensors reporting integer ADC values:
 *   adc_value / max_value → fraction string → bijection
 *
 * The fraction "adc/max" is parsed by et_project() as a rational
 * number, maintaining the zero-float64 chain from ADC register
 * to lattice coordinates.
 * ═══════════════════════════════════════════════════════════════════ */

et_error_t et_sensor_project_adc(const et_sensor_projector_t *sp,
                                  long adc_value, long max_value,
                                  int axis, long long timestamp_ns,
                                  et_sensor_sample_t *sample) {
    if (!sp || !sample) return ET_ERR_NULL_INPUT;
    if (max_value == 0) return ET_ERR_DIVISION_BY_ZERO;

    /*
     * Build the fraction string: "adc_value/max_value"
     * This maintains the zero-float64 chain:
     *   ADC integer → string fraction → MPFR rational → bijection
     *
     * For bipolar ADC values (audio, accelerometer):
     *   Sign is encoded by the sign of adc_value.
     *   Magnitude = |adc_value| / max_value.
     *   The fraction is always positive; sign is handled separately.
     */
    char frac_str[64];
    if (sp->is_bipolar) {
        long abs_adc = (adc_value < 0) ? -adc_value : adc_value;
        if (adc_value == 0) {
            snprintf(frac_str, sizeof(frac_str), "0");
        } else if (adc_value > 0) {
            snprintf(frac_str, sizeof(frac_str), "%ld/%ld", abs_adc, max_value);
        } else {
            /* Negative: format as negative fraction for bipolar handling */
            snprintf(frac_str, sizeof(frac_str), "-%ld/%ld", abs_adc, max_value);
        }
    } else {
        /* Unipolar: value is always non-negative */
        if (adc_value <= 0) {
            snprintf(frac_str, sizeof(frac_str), "0");
        } else {
            snprintf(frac_str, sizeof(frac_str), "%ld/%ld", adc_value, max_value);
        }
    }

    return et_sensor_project(sp, frac_str, axis, timestamp_ns, sample);
}
