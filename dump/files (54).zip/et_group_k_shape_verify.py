#!/usr/bin/env python3
"""
Group K Shape Projection Verification Suite
=============================================
Exception Theory — Michael James Muller — Exception Theory LLC
P ∘ D ∘ T = E

Verifies lattice addresses for orbital shape seeds, level-set ratios,
SDF ratios, hydrogen 1s, nD quadrupole, and related shape projections.
"""
from mpmath import mp, mpf, log, nint, sin, cos, pi, sqrt
from math import gcd
import sympy

mp.dps = 400
N = 12

def proj(r):
    x = mpf(str(N)) * log(r, 2)
    k = int(nint(x))
    d = N // gcd(abs(k), N) if k != 0 else 1
    eps = (x - mpf(str(k))) * mpf('1200') / mpf(str(N))
    return k, d, eps

passed = failed = total = 0

print("=" * 60)
print("ORBITAL SHAPE SEEDS (Legendre polynomials)")
print("=" * 60)

# s-orbital l=0: ρ₀ = |P₀(0)|²/|P₀(1)|² = 1
total += 1; k, d, eps = proj(mpf('1'))
if (k, d) == (0, 1) and eps == mpf('0'):
    passed += 1; print(f"  l=0 (s): ρ₀=1 → ({k},{d},{float(eps)}¢) PASS")
else: failed += 1

# d-orbital l=2: ρ₂ = |P₂(0)|²/|P₂(1)|² = 1/4
total += 1; k, d, eps = proj(mpf('1')/mpf('4'))
if (k, d) == (-24, 1) and eps == mpf('0'):
    passed += 1; print(f"  l=2 (d): ρ₂=1/4 → ({k},{d},{float(eps)}¢) PASS — lattice-exact")
else: failed += 1

# g-orbital l=4: ρ₄ = 9/64
total += 1; k, d, eps = proj(mpf('9')/mpf('64'))
if k == -34 and d == 6:
    passed += 1; print(f"  l=4 (g): ρ₄=9/64 → ({k},{d},{float(eps):.2f}¢) PASS")
else: failed += 1

# i-orbital l=6: ρ₆ = 25/256
total += 1; k, d, eps = proj(mpf('25')/mpf('256'))
if k == -40 and d == 3:
    passed += 1; print(f"  l=6 (i): ρ₆=25/256 → ({k},{d},{float(eps):.2f}¢) PASS")
else: failed += 1

print("\n" + "=" * 60)
print("TOPOLOGY LEVELS (L3-L5)")
print("=" * 60)

# Level 3: unit ball 3(sin1−cos1)
ratio_L3 = 3 * (sin(mpf('1')) - cos(mpf('1')))
total += 1; k, d, eps = proj(ratio_L3)
if k == -2 and d == 6:
    passed += 1; print(f"  L3 unit ball: 3(sin1−cos1)={float(ratio_L3):.4f} → ({k},{d},{float(eps):.2f}¢) PASS")
else: failed += 1

# Level 4: SDF 2/π
ratio_L4 = mpf('2') / pi
total += 1; k, d, eps = proj(ratio_L4)
if k == -8 and d == 3:
    passed += 1; print(f"  L4 SDF: 2/π={float(ratio_L4):.4f} → ({k},{d},{float(eps):.2f}¢) PASS")
else: failed += 1

# Level 5: hydrogen 1s 1/2
total += 1; k, d, eps = proj(mpf('1')/mpf('2'))
if (k, d) == (-12, 1) and eps == mpf('0'):
    passed += 1; print(f"  L5 H-1s: 1/2 → ({k},{d},{float(eps)}¢) PASS — lattice-exact")
else: failed += 1

print("\n" + "=" * 60)
print("nD QUADRUPOLE (oblate a=2, c=1)")
print("=" * 60)

a, c = mpf('2'), mpf('1')
for n_dim in [3, 4, 5, 10]:
    q_n = (mpf('1')/mpf(str(n_dim))) * (c**2 - a**2) / (c**2 + (n_dim-1)*a**2)
    dsr = abs(q_n)
    total += 1; k, d, eps = proj(dsr)
    if d in [1, 2, 3, 4, 6, 12]:
        passed += 1; print(f"  n={n_dim}: q_n={float(q_n):.6f} → ({k},{d},{float(eps):.2f}¢) PASS")
    else: failed += 1

print("\n" + "=" * 60)
print("LORENTZIAN DIELECTRIC (4/3 = 2K)")
print("=" * 60)

total += 1; k, d, eps = proj(mpf('4')/mpf('3'))
if k == 5 and d == 12:
    passed += 1; print(f"  4/3=2K → ({k},{d},{float(eps):.3f}¢) PASS — d=12 (EM)")
else: failed += 1

# Verify 4/3 = 2K = 2N/(N+6)
K = mpf('2') / mpf('3')
total += 1
if mpf('4')/mpf('3') == 2*K:
    passed += 1; print(f"  4/3 = 2K = 2·{float(K):.4f} PASS")
else: failed += 1

print("\n" + "=" * 60)
print("HEMISPHERE DIPOLE (3/2)")
print("=" * 60)

total += 1; k, d, eps = proj(mpf('3')/mpf('2'))
if k == 7 and d == 12:
    passed += 1; print(f"  3/2 → ({k},{d},{float(eps):.3f}¢) PASS — d=12 (EM)")
else: failed += 1

print("\n" + "=" * 60)
print(f"TOTAL: {passed}/{total} PASSED")
if failed == 0:
    print("ALL TESTS PASSED — residual is zero")
else:
    print(f"FAILURES: {failed}")
    import sys; sys.exit(1)
