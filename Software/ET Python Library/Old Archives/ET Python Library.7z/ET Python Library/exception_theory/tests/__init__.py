"""
Exception Theory - Test Suite

From: "For every exception there is an exception, except the exception."

Author: ET Development Team
"""
