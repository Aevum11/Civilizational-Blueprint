"""
et_bridge/et_config.py
ET32 Bridge — Configuration Management

Derived from P ∘ D ∘ T = E.

Configuration IS the Descriptor set of the bridge's runtime behaviour.
The config file is a {P,D} Unsubstantiated configuration waiting for T
(the running bridge process) to traverse it into actuality.

Config structure derived from ET:
  - target_exes    : D-set of 32-bit processes to bridge
  - bridge_options : fine-grained D-constraints per target
  - ipc_config     : Mediation channel descriptors
  - log_config     : Logging Descriptors

The config file is watched for changes using polling (S-second interval =
12 seconds). When changed, the new D-set replaces the old one — the bridge
T-traverses the updated configuration.
"""

import json
import os
import time
import threading
import hashlib
import copy
from typing import Dict, List, Optional, Any, Callable
from pathlib import Path

from .et_math import S, K, V_BASE, CONN_TIMEOUT_MS, DIGITAL_ACTION_QUANTUM, IPC_BUFFER_SIZE


# Default config path — sits next to the executable
DEFAULT_CONFIG_PATH = os.path.join(
    os.path.dirname(os.path.abspath(__file__)),
    "..", "et32_bridge_config.json"
)


class TargetConfig:
    """
    Configuration for a single 32-bit target process.
    
    Each target is a potential Descriptor: it describes what capabilities to
    extend and under what conditions. The bridge T-traverses this Descriptor
    when the process matching 'exe_name' is detected.
    
    Fields derived from ET:
      exe_name      : D₁ — which process (process identity Descriptor)
      features      : D₂..D₁₂ — which features to enable (lattice positions)
      mem_threshold : D₁ threshold for memory bridging (default K × 4GB)
      dll_paths     : D₄ — extra 64-bit DLL search paths
      gpu_enabled   : D₇ — whether to bridge GPU operations
      python_64     : D₁₁ — whether to bridge 64-bit Python
      inject_mode   : T-mode for injection (debug, iat, shellcode)
    """

    # Available features keyed by ET lattice position
    FEATURE_NAMES = {
        1:  "memory_basic",     # d=1: extended memory allocation
        2:  "memory_map",       # d=2: large memory-mapped files
        3:  "threads",          # d=3: 64-bit thread operations
        4:  "dll_64bit",        # d=4: 64-bit DLL loading
        5:  "process",          # d=5: 64-bit process creation
        6:  "registry_bypass",  # d=6: bypass WOW64 registry redirect
        7:  "gpu_vram",         # d=7: GPU/VRAM extension
        8:  "large_files",      # d=8: files/maps > 4GB
        9:  "sync",             # d=9: 64-bit sync objects
        10: "network",          # d=10: 64-bit network buffers
        11: "python_64",        # d=11: 64-bit Python embedding
        12: "compound",         # d=12: compound/batched operations
    }

    def __init__(self, data: Dict):
        self.exe_name: str = data.get("exe_name", "")
        self.enabled: bool = data.get("enabled", True)
        self.inject_mode: str = data.get("inject_mode", "iat")  # "iat", "debug", "shellcode"

        # Feature flags: which lattice positions to enable
        features = data.get("features", "all")
        if features == "all":
            self.features = set(range(1, S + 1))
        elif features == "none":
            self.features = set()
        else:
            self.features = set(int(f) for f in features if isinstance(f, (int, str)))

        # Memory threshold: size above which allocations are bridged to 64-bit
        # Default = K × 2^31 (Koide threshold of 32-bit user space ceiling)
        default_threshold = int(K * (1 << 31))
        self.mem_threshold_bytes: int = data.get("mem_threshold_mb", default_threshold >> 20) * (1 << 20)

        # Extra 64-bit DLL search directories
        self.dll_search_paths: List[str] = data.get("dll_64_paths", [])

        # GPU configuration
        self.gpu_enabled: bool = 7 in self.features and data.get("gpu_enabled", True)
        self.gpu_vram_limit_gb: float = data.get("gpu_vram_limit_gb", 0.0)  # 0 = no limit

        # 64-bit Python configuration
        self.python_64: bool = 11 in self.features and data.get("python_64", False)
        self.python_home: str = data.get("python_home", "")  # path to 64-bit Python

        # Registry bypass configuration
        self.reg_bypass: bool = 6 in self.features and data.get("registry_bypass", False)

        # Large file support
        self.large_files: bool = 8 in self.features and data.get("large_files", True)

        # IPC overrides per target
        self.pipe_timeout_ms: int = data.get("pipe_timeout_ms", CONN_TIMEOUT_MS)

        # Process launch settings (if we're the launcher)
        self.launch_before: bool = data.get("launch_before", False)
        self.launch_args: List[str] = data.get("launch_args", [])

    def has_feature(self, lattice_d: int) -> bool:
        return lattice_d in self.features

    def to_dict(self) -> Dict:
        return {
            "exe_name": self.exe_name,
            "enabled": self.enabled,
            "inject_mode": self.inject_mode,
            "features": sorted(self.features),
            "mem_threshold_mb": self.mem_threshold_bytes >> 20,
            "dll_64_paths": self.dll_search_paths,
            "gpu_enabled": self.gpu_enabled,
            "gpu_vram_limit_gb": self.gpu_vram_limit_gb,
            "python_64": self.python_64,
            "python_home": self.python_home,
            "registry_bypass": self.reg_bypass,
            "large_files": self.large_files,
            "pipe_timeout_ms": self.pipe_timeout_ms,
            "launch_before": self.launch_before,
            "launch_args": self.launch_args,
        }


class ETBridgeConfig:
    """
    Complete bridge configuration. This is the root Descriptor set for the bridge.

    ET-derived structure:
      P = the config file (featureless substrate containing the Descriptor data)
      D = the parsed configuration values (constraints on bridge behaviour)
      T = the config watcher (traverses the file and actualises the Descriptors)

    The config watcher polls every S seconds (12 seconds = MANIFOLD_SYMMETRY).
    On change, the bridge hot-reloads — the new D-set replaces the old.
    """

    # Poll interval = S seconds (manifold symmetry)
    POLL_INTERVAL_S: float = float(S)

    def __init__(self, path: str = None):
        self.path = path or DEFAULT_CONFIG_PATH
        self._data: Dict = {}
        self._hash: str = ""
        self._targets: Dict[str, TargetConfig] = {}
        self._lock = threading.RLock()
        self._watch_thread: Optional[threading.Thread] = None
        self._watching = False
        self._on_change_callbacks: List[Callable] = []

        # Bridge-level IPC config
        self.ipc_buffer_size: int = IPC_BUFFER_SIZE  # 49152 bytes
        self.ipc_queue_depth: int = S * S             # 144

        # Logging config
        self.log_level: str = "INFO"
        self.log_file: Optional[str] = None
        self.log_et_metrics: bool = True  # log ET variance metrics

        # Bridge behaviour
        self.auto_inject: bool = True
        self.inject_on_startup: bool = True
        self.helper_path: Optional[str] = None  # path to et_bridge_helper32.exe

        # Load initial config
        self._load()

    # ------------------------------------------------------------------
    # Loading and parsing
    # ------------------------------------------------------------------

    def _load(self) -> bool:
        """Load and parse the config file. Returns True if successfully loaded."""
        path = Path(self.path)
        if not path.exists():
            self._create_default()
            return False

        try:
            text = path.read_text(encoding="utf-8")
            data = json.loads(text)
            new_hash = hashlib.sha256(text.encode()).hexdigest()

            if new_hash == self._hash:
                return False  # no change

            with self._lock:
                self._data = data
                self._hash = new_hash
                self._parse(data)

            return True

        except (json.JSONDecodeError, OSError) as e:
            # Descriptor Gap: config file is malformed → log but continue with defaults
            return False

    def _parse(self, data: Dict):
        """Parse the raw JSON dict into typed configuration objects."""
        # Bridge-level settings
        ipc = data.get("ipc", {})
        self.ipc_buffer_size = ipc.get("buffer_size", IPC_BUFFER_SIZE)
        self.ipc_queue_depth = ipc.get("queue_depth", S * S)

        log = data.get("logging", {})
        self.log_level    = log.get("level", "INFO")
        self.log_file     = log.get("file", None)
        self.log_et_metrics = log.get("et_metrics", True)

        bridge = data.get("bridge", {})
        self.auto_inject       = bridge.get("auto_inject", True)
        self.inject_on_startup = bridge.get("inject_on_startup", True)
        self.helper_path       = bridge.get("helper_path", None)

        # Target configurations
        self._targets = {}
        for entry in data.get("targets", []):
            cfg = TargetConfig(entry)
            if cfg.exe_name:
                key = cfg.exe_name.lower()
                self._targets[key] = cfg

    def _create_default(self):
        """Write a default config file if none exists."""
        default = {
            "_comment": "ET32 Bridge Configuration — P∘D∘T = E",
            "_version": "1.0.0",
            "bridge": {
                "auto_inject": True,
                "inject_on_startup": True,
                "helper_path": None
            },
            "ipc": {
                "buffer_size": IPC_BUFFER_SIZE,
                "queue_depth": S * S
            },
            "logging": {
                "level": "INFO",
                "file": "et32_bridge.log",
                "et_metrics": True
            },
            "targets": [
                {
                    "_comment": "Example: bridge a 32-bit game",
                    "exe_name": "example_game.exe",
                    "enabled": False,
                    "inject_mode": "iat",
                    "features": "all",
                    "mem_threshold_mb": int((K * (1 << 31)) >> 20),
                    "dll_64_paths": [],
                    "gpu_enabled": True,
                    "gpu_vram_limit_gb": 0.0,
                    "python_64": False,
                    "python_home": "",
                    "registry_bypass": True,
                    "large_files": True,
                    "pipe_timeout_ms": CONN_TIMEOUT_MS,
                    "launch_before": False,
                    "launch_args": []
                }
            ]
        }

        try:
            Path(self.path).parent.mkdir(parents=True, exist_ok=True)
            Path(self.path).write_text(
                json.dumps(default, indent=2),
                encoding="utf-8"
            )
        except OSError:
            pass

    # ------------------------------------------------------------------
    # Target lookup
    # ------------------------------------------------------------------

    def get_target(self, exe_name: str) -> Optional[TargetConfig]:
        """Return config for a target process (case-insensitive match)."""
        with self._lock:
            return self._targets.get(exe_name.lower())

    def all_targets(self) -> List[TargetConfig]:
        """Return all enabled target configurations."""
        with self._lock:
            return [t for t in self._targets.values() if t.enabled]

    def target_exe_names(self) -> List[str]:
        """Return lowercase exe names of all enabled targets."""
        with self._lock:
            return [k for k, v in self._targets.items() if v.enabled]

    # ------------------------------------------------------------------
    # File watcher
    # ------------------------------------------------------------------

    def start_watching(self, on_change: Callable = None):
        """
        Start the config file watcher thread.
        Polls every S seconds (= 12 seconds = manifold symmetry interval).
        Calls on_change(new_config) when config changes.
        """
        if on_change:
            self._on_change_callbacks.append(on_change)

        if self._watching:
            return

        self._watching = True
        self._watch_thread = threading.Thread(
            target=self._watch_loop,
            name="ET_ConfigWatcher",
            daemon=True
        )
        self._watch_thread.start()

    def stop_watching(self):
        self._watching = False
        if self._watch_thread:
            self._watch_thread.join(timeout=self.POLL_INTERVAL_S + 1)

    def _watch_loop(self):
        while self._watching:
            # Poll interval = S seconds
            time.sleep(self.POLL_INTERVAL_S)
            if self._load():
                for cb in self._on_change_callbacks:
                    try:
                        cb(self)
                    except Exception:
                        pass

    # ------------------------------------------------------------------
    # Hot reload
    # ------------------------------------------------------------------

    def reload(self) -> bool:
        """Force immediate reload. Returns True if config changed."""
        # Invalidate hash to force re-parse
        old_hash = self._hash
        self._hash = ""
        changed = self._load()
        if not changed:
            self._hash = old_hash
        return changed

    # ------------------------------------------------------------------
    # Runtime config modification (for UI/CLI integration)
    # ------------------------------------------------------------------

    def add_target(self, exe_name: str, features: str = "all") -> TargetConfig:
        """Dynamically add a target at runtime. Writes back to config file."""
        entry = {
            "exe_name": exe_name,
            "enabled": True,
            "features": features,
            "inject_mode": "iat",
        }
        cfg = TargetConfig(entry)
        with self._lock:
            self._targets[exe_name.lower()] = cfg

        # Persist to file
        try:
            path = Path(self.path)
            if path.exists():
                data = json.loads(path.read_text(encoding="utf-8"))
                data.setdefault("targets", [])
                # Remove existing entry for same exe
                data["targets"] = [
                    t for t in data["targets"]
                    if t.get("exe_name", "").lower() != exe_name.lower()
                ]
                data["targets"].append(cfg.to_dict())
                path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except (OSError, json.JSONDecodeError):
            pass

        return cfg

    def remove_target(self, exe_name: str) -> bool:
        """Remove a target at runtime."""
        key = exe_name.lower()
        with self._lock:
            if key not in self._targets:
                return False
            del self._targets[key]

        try:
            path = Path(self.path)
            if path.exists():
                data = json.loads(path.read_text(encoding="utf-8"))
                data["targets"] = [
                    t for t in data.get("targets", [])
                    if t.get("exe_name", "").lower() != key
                ]
                path.write_text(json.dumps(data, indent=2), encoding="utf-8")
        except (OSError, json.JSONDecodeError):
            pass

        return True

    # ------------------------------------------------------------------
    # Diagnostics
    # ------------------------------------------------------------------

    def variance(self) -> float:
        """
        V(config) = fraction of targets that have no features enabled.
        V(config) = 0 → all targets fully configured (Exception state).
        V(config) = V_BASE × count_empty → some Descriptor gaps remain.
        """
        with self._lock:
            targets = list(self._targets.values())
        if not targets:
            return V_BASE  # empty config = one V_BASE gap
        empty = sum(1 for t in targets if not t.features)
        return (empty / len(targets)) * V_BASE if empty else 0.0

    def summary(self) -> Dict:
        with self._lock:
            targets = list(self._targets.values())
        return {
            "config_path": self.path,
            "targets_total": len(targets),
            "targets_enabled": sum(1 for t in targets if t.enabled),
            "targets": [t.exe_name for t in targets if t.enabled],
            "ipc_buffer_size": self.ipc_buffer_size,
            "log_level": self.log_level,
            "variance": self.variance(),
        }
