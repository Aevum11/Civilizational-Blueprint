/*
 * ET LOSSLESS SENSOR CAPTURE — JNI BRIDGE
 * =========================================
 * Marshals data between the Kotlin UI layer and the C bijection core.
 *
 * CRITICAL DESIGN: The zero-float64 chain is maintained THROUGH the
 * JNI boundary. All sensor values cross as STRINGS (JNI jstring),
 * never as jfloat or jdouble. The C core parses strings to MPFR,
 * computes in arbitrary precision, and returns strings.
 *
 * The only integers crossing are: k (long), d (int), sign (int),
 * sensor_type (int), N (int), axis (int), timestamp (long).
 * These are exact in both Java and C.
 *
 * Author: Michael James Muller — Aevum Defluo (Exception Theory)
 * License: CC-BY-4.0
 */

#include <jni.h>
#include <android/log.h>
#include <string.h>
#include <stdlib.h>

#include "et_bijection.hpp"
#include "et_sensor_projector.hpp"
#include "et_differential.hpp"
#include "et_audio_capture.hpp"
#include "et_direct_channel.hpp"
#include "et_format.hpp"
#include "et_lattice_arithmetic.hpp"
#include "et_complex_lattice.hpp"
#include "et_cross_resolution.hpp"
#include "et_constants.h"

#define LOG_TAG "EtSensor"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

/* All JNI functions require C linkage */
extern "C" {

/* ═══════════════════════════════════════════════════════════════════
 * GLOBAL STATE
 * Per-sensor projectors, initialized on demand.
 * ═══════════════════════════════════════════════════════════════════ */

/* Maximum concurrent sensor projectors */
#define MAX_PROJECTORS 32

static et_sensor_projector_t g_projectors[MAX_PROJECTORS];
static int g_projector_initialized[MAX_PROJECTORS] = {0};
static int g_projector_count = 0;

/* A single base projector for standalone bijection operations */
static et_projector_t g_base_projector;
static int g_base_initialized = 0;

/* ═══════════════════════════════════════════════════════════════════
 * HELPER: ensure base projector is initialized
 * ═══════════════════════════════════════════════════════════════════ */
static et_error_t ensure_base_projector(void) {
    if (g_base_initialized) return ET_OK;
    et_error_t err = et_projector_init(&g_base_projector, ET_N_BASE, ET_MPFR_BITS);
    if (err == ET_OK) g_base_initialized = 1;
    return err;
}

/* ═══════════════════════════════════════════════════════════════════
 * JNI FUNCTION: Initialize a sensor projector
 *
 * Returns the projector index (0-based), or -1 on error.
 *
 * Java signature:
 *   native int initSensorProjector(int sensorType, String r0, int N);
 * ═══════════════════════════════════════════════════════════════════ */
JNIEXPORT jint JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_initSensorProjector(
        JNIEnv *env, jclass clazz,
        jint sensor_type, jstring jR0, jint N) {
    (void)clazz;

    if (g_projector_count >= MAX_PROJECTORS) {
        LOGE("Maximum projector count (%d) reached", MAX_PROJECTORS);
        return -1;
    }

    const char *r0_str = env->GetStringUTFChars(jR0, NULL);
    if (!r0_str) return -1;

    int idx = g_projector_count;
    et_error_t err;

    if (r0_str[0] == '\0' || strcmp(r0_str, "default") == 0) {
        /* Use default R₀ for this sensor type */
        err = et_sensor_projector_init(&g_projectors[idx],
                                        (et_sensor_type_t)sensor_type,
                                        N, ET_MPFR_BITS);
    } else {
        /* Custom R₀ */
        err = et_sensor_projector_init_custom(&g_projectors[idx],
                                               (et_sensor_type_t)sensor_type,
                                               r0_str, N, ET_MPFR_BITS);
    }

    env->ReleaseStringUTFChars(jR0, r0_str);

    if (err != ET_OK) {
        LOGE("Failed to init sensor projector: type=%d, error=%d",
             sensor_type, (int)err);
        return -1;
    }

    g_projector_initialized[idx] = 1;
    g_projector_count++;

    LOGI("Sensor projector %d initialized: type=%s, N=%d, R0=%s",
         idx, ET_SENSOR_TYPE_NAMES[sensor_type], N,
         g_projectors[idx].R0_str);

    return idx;
}

/* ═══════════════════════════════════════════════════════════════════
 * JNI FUNCTION: Project a sensor value
 *
 * Returns a double array: [k, d, sign, is_zero, at_boundary, N]
 * Plus ε as a separate string return (via output parameter).
 *
 * Java signature:
 *   native double[] projectSensor(int projectorIdx, String value,
 *                                  int axis, long timestampNs);
 *
 * Note: k is returned as double because JNI doesn't have jlong arrays
 * with mixed types. The caller casts back to long. k fits in double's
 * 52-bit mantissa for any realistic lattice coordinate.
 * ═══════════════════════════════════════════════════════════════════ */
JNIEXPORT jdoubleArray JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_projectSensor(
        JNIEnv *env, jclass clazz,
        jint projector_idx, jstring jValue, jint axis, jlong timestamp_ns) {
    (void)clazz;

    if (projector_idx < 0 || projector_idx >= g_projector_count ||
        !g_projector_initialized[projector_idx]) {
        LOGE("Invalid projector index: %d", projector_idx);
        return NULL;
    }

    const char *value_str = env->GetStringUTFChars(jValue, NULL);
    if (!value_str) return NULL;

    et_sensor_sample_t sample;
    memset(&sample, 0, sizeof(sample));
    et_projection_init(&sample.projection, ET_MPFR_BITS);

    et_error_t err = et_sensor_project(&g_projectors[projector_idx],
                                        value_str, axis,
                                        (long long)timestamp_ns, &sample);

    env->ReleaseStringUTFChars(jValue, value_str);

    if (err != ET_OK) {
        LOGE("Projection failed: error=%d", (int)err);
        et_projection_clear(&sample.projection);
        return NULL;
    }

    /* Return array: [k, d, sign, is_zero, at_boundary, N] */
    jdoubleArray result = env->NewDoubleArray(6);
    if (!result) {
        et_projection_clear(&sample.projection);
        return NULL;
    }

    jdouble buf[6] = {
        (jdouble)sample.projection.k,
        (jdouble)sample.projection.d,
        (jdouble)sample.projection.sign,
        (jdouble)sample.projection.is_zero,
        (jdouble)sample.projection.at_boundary,
        (jdouble)sample.projection.N
    };
    env->SetDoubleArrayRegion(result, 0, 6, buf);

    et_projection_clear(&sample.projection);
    return result;
}

/* ═══════════════════════════════════════════════════════════════════
 * JNI FUNCTION: Get ε as string (zero float64 output path)
 *
 * Returns ε at full WORK_DPS precision as a Java String.
 * This maintains the zero-float64 chain through JNI.
 *
 * Java signature:
 *   native String getEpsilonString(int projectorIdx, String value, int axis);
 * ═══════════════════════════════════════════════════════════════════ */
JNIEXPORT jstring JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_getEpsilonString(
        JNIEnv *env, jclass clazz,
        jint projector_idx, jstring jValue, jint axis) {
    (void)clazz;

    if (projector_idx < 0 || projector_idx >= g_projector_count ||
        !g_projector_initialized[projector_idx]) {
        return env->NewStringUTF("ERROR");
    }

    const char *value_str = env->GetStringUTFChars(jValue, NULL);
    if (!value_str) return env->NewStringUTF("ERROR");

    et_sensor_sample_t sample;
    memset(&sample, 0, sizeof(sample));
    et_projection_init(&sample.projection, ET_MPFR_BITS);

    et_error_t err = et_sensor_project(&g_projectors[projector_idx],
                                        value_str, axis, 0, &sample);

    env->ReleaseStringUTFChars(jValue, value_str);

    if (err != ET_OK) {
        et_projection_clear(&sample.projection);
        return env->NewStringUTF("ERROR");
    }

    /* Convert ε to string at WORK_DPS — the zero-float64 output path */
    char eps_buf[ET_WORK_DPS + 64];
    et_eps_to_string(sample.projection.eps, ET_WORK_DPS, eps_buf, sizeof(eps_buf));

    jstring jeps = env->NewStringUTF(eps_buf);

    et_projection_clear(&sample.projection);
    return jeps;
}

/* ═══════════════════════════════════════════════════════════════════
 * JNI FUNCTION: Project ADC integer directly
 *
 * For sensors reporting raw ADC integers (accelerometer, camera).
 * Maintains zero-float64 chain: ADC int → fraction string → MPFR.
 *
 * Java signature:
 *   native double[] projectAdc(int projectorIdx, long adcValue,
 *                               long maxValue, int axis, long timestampNs);
 * ═══════════════════════════════════════════════════════════════════ */
JNIEXPORT jdoubleArray JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_projectAdc(
        JNIEnv *env, jclass clazz,
        jint projector_idx, jlong adc_value, jlong max_value,
        jint axis, jlong timestamp_ns) {
    (void)clazz;

    if (projector_idx < 0 || projector_idx >= g_projector_count ||
        !g_projector_initialized[projector_idx]) {
        return NULL;
    }

    et_sensor_sample_t sample;
    memset(&sample, 0, sizeof(sample));
    et_projection_init(&sample.projection, ET_MPFR_BITS);

    et_error_t err = et_sensor_project_adc(&g_projectors[projector_idx],
                                            (long)adc_value, (long)max_value,
                                            axis, (long long)timestamp_ns,
                                            &sample);

    if (err != ET_OK) {
        et_projection_clear(&sample.projection);
        return NULL;
    }

    jdoubleArray result = env->NewDoubleArray(6);
    if (!result) {
        et_projection_clear(&sample.projection);
        return NULL;
    }

    jdouble buf[6] = {
        (jdouble)sample.projection.k,
        (jdouble)sample.projection.d,
        (jdouble)sample.projection.sign,
        (jdouble)sample.projection.is_zero,
        (jdouble)sample.projection.at_boundary,
        (jdouble)sample.projection.N
    };
    env->SetDoubleArrayRegion(result, 0, 6, buf);

    et_projection_clear(&sample.projection);
    return result;
}

/* ═══════════════════════════════════════════════════════════════════
 * JNI FUNCTION: Verify lossless round-trip
 *
 * Projects r → (k,d,ε) → r' and verifies r = r' at WORK_DPS.
 *
 * Java signature:
 *   native boolean verifyRoundtrip(String rValue, int N);
 * ═══════════════════════════════════════════════════════════════════ */
JNIEXPORT jboolean JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_verifyRoundtrip(
        JNIEnv *env, jclass clazz,
        jstring jR, jint N) {
    (void)clazz;

    const char *r_str = env->GetStringUTFChars(jR, NULL);
    if (!r_str) return JNI_FALSE;

    et_projector_t proj;
    et_error_t err = et_projector_init(&proj, N, ET_MPFR_BITS);
    if (err != ET_OK) {
        env->ReleaseStringUTFChars(jR, r_str);
        return JNI_FALSE;
    }

    int is_exact = 0;
    err = et_verify_roundtrip(&proj, r_str, &is_exact);

    env->ReleaseStringUTFChars(jR, r_str);
    et_projector_clear(&proj);

    if (err != ET_OK) return JNI_FALSE;
    return is_exact ? JNI_TRUE : JNI_FALSE;
}

/* ═══════════════════════════════════════════════════════════════════
 * JNI FUNCTION: Get sensor type name
 * ═══════════════════════════════════════════════════════════════════ */
JNIEXPORT jstring JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_getSensorTypeName(
        JNIEnv *env, jclass clazz, jint sensor_type) {
    (void)clazz;
    if (sensor_type < 0 || sensor_type >= ET_SENSOR_TYPE_COUNT) {
        return env->NewStringUTF("UNKNOWN");
    }
    return env->NewStringUTF(ET_SENSOR_TYPE_NAMES[sensor_type]);
}

/* ═══════════════════════════════════════════════════════════════════
 * JNI FUNCTION: Get default R₀ for a sensor type
 * ═══════════════════════════════════════════════════════════════════ */
JNIEXPORT jstring JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_getDefaultR0(
        JNIEnv *env, jclass clazz, jint sensor_type) {
    (void)clazz;
    if (sensor_type < 0 || sensor_type >= ET_SENSOR_TYPE_COUNT) {
        return env->NewStringUTF("1");
    }
    return env->NewStringUTF(ET_SENSOR_R0_DEFAULTS[sensor_type]);
}

/* ═══════════════════════════════════════════════════════════════════
 * JNI FUNCTION: Cleanup all projectors
 * ═══════════════════════════════════════════════════════════════════ */
JNIEXPORT void JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_cleanup(
        JNIEnv *env, jclass clazz) {
    (void)env;
    (void)clazz;

    for (int i = 0; i < g_projector_count; i++) {
        if (g_projector_initialized[i]) {
            et_sensor_projector_clear(&g_projectors[i]);
            g_projector_initialized[i] = 0;
        }
    }
    g_projector_count = 0;

    if (g_base_initialized) {
        et_projector_clear(&g_base_projector);
        g_base_initialized = 0;
    }

    LOGI("All projectors cleaned up");
}

/* ═══════════════════════════════════════════════════════════════════
 * JNI FUNCTION: Get ET constants for display
 * ═══════════════════════════════════════════════════════════════════ */
JNIEXPORT jstring JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_getConstantsInfo(
        JNIEnv *env, jclass clazz) {
    (void)clazz;

    char buf[2048];
    snprintf(buf, sizeof(buf),
        "N=%d | V=1/%d | K=2/3 | Λ=1200/ln2\n"
        "WORK_DPS=%d | COMPUTE_DPS=%d | MPFR_BITS=%d\n"
        "LCM Tower: 12→60→420→2520→27720\n"
        "Sensor types: %d\n"
        "P∘D∘T = E",
        ET_N_BASE, ET_N_BASE,
        ET_WORK_DPS, ET_COMPUTE_DPS, ET_MPFR_BITS,
        ET_SENSOR_TYPE_COUNT);

    return env->NewStringUTF(buf);
}

/* ═══════════════════════════════════════════════════════════════════
 * DIFFERENTIAL TRACKER JNI
 * ═══════════════════════════════════════════════════════════════════ */
#define MAX_TRACKERS 32
static et_differential_tracker_t g_trackers[MAX_TRACKERS];
static int g_tracker_initialized[MAX_TRACKERS] = {0};
static int g_tracker_count = 0;

JNIEXPORT jint JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_initTracker(
        JNIEnv *env, jclass clazz,
        jint N, jstring jR0, jint sampleRate, jint bitDepth) {
    (void)clazz;
    if (g_tracker_count >= MAX_TRACKERS) return -1;

    const char *r0 = env->GetStringUTFChars(jR0, NULL);
    if (!r0) return -1;

    int idx = g_tracker_count;
    et_error_t err = et_tracker_init(&g_trackers[idx], N, r0,
                                      sampleRate, bitDepth, ET_MPFR_BITS);
    env->ReleaseStringUTFChars(jR0, r0);

    if (err != ET_OK) return -1;
    g_tracker_initialized[idx] = 1;
    g_tracker_count++;
    return idx;
}

JNIEXPORT jdoubleArray JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_processTracker(
        JNIEnv *env, jclass clazz,
        jint trackerIdx, jstring jValue) {
    (void)clazz;
    if (trackerIdx < 0 || trackerIdx >= g_tracker_count ||
        !g_tracker_initialized[trackerIdx]) return NULL;

    const char *val = env->GetStringUTFChars(jValue, NULL);
    if (!val) return NULL;

    et_sensor_sample_t sample;
    memset(&sample, 0, sizeof(sample));
    et_projection_init(&sample.projection, ET_MPFR_BITS);

    et_error_t err = et_tracker_process(&g_trackers[trackerIdx], val, &sample);
    env->ReleaseStringUTFChars(jValue, val);

    if (err != ET_OK) { et_projection_clear(&sample.projection); return NULL; }

    jdoubleArray result = env->NewDoubleArray(8);
    jdouble buf[8] = {
        (jdouble)sample.projection.k, (jdouble)sample.projection.d,
        (jdouble)sample.projection.sign, (jdouble)sample.projection.is_zero,
        (jdouble)sample.projection.at_boundary, (jdouble)sample.projection.N,
        (jdouble)sample.tracking_source, (jdouble)sample.escalated
    };
    env->SetDoubleArrayRegion(result, 0, 8, buf);
    et_projection_clear(&sample.projection);
    return result;
}

JNIEXPORT jstring JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_getTrackerEpsilon(
        JNIEnv *env, jclass clazz, jint trackerIdx, jstring jValue) {
    (void)clazz;
    if (trackerIdx < 0 || trackerIdx >= g_tracker_count) return env->NewStringUTF("ERROR");

    const char *val = env->GetStringUTFChars(jValue, NULL);
    if (!val) return env->NewStringUTF("ERROR");

    et_sensor_sample_t sample;
    memset(&sample, 0, sizeof(sample));
    et_projection_init(&sample.projection, ET_MPFR_BITS);

    et_error_t err = et_tracker_process(&g_trackers[trackerIdx], val, &sample);
    env->ReleaseStringUTFChars(jValue, val);

    if (err != ET_OK) { et_projection_clear(&sample.projection); return env->NewStringUTF("ERROR"); }

    char eps_buf[ET_WORK_DPS + 64];
    et_eps_to_string(sample.projection.eps, ET_WORK_DPS, eps_buf, sizeof(eps_buf));
    jstring jeps = env->NewStringUTF(eps_buf);
    et_projection_clear(&sample.projection);
    return jeps;
}

JNIEXPORT jstring JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_getTrackerStats(
        JNIEnv *env, jclass clazz, jint trackerIdx) {
    (void)clazz;
    if (trackerIdx < 0 || trackerIdx >= g_tracker_count) return env->NewStringUTF("ERROR");

    et_tracker_stats_t stats;
    et_tracker_stats_init(&stats, ET_MPFR_BITS);
    et_tracker_get_stats(&g_trackers[trackerIdx], &stats);

    char buf[2048];
    char rate_str[64], depth_str[64], total_str[64];
    et_eps_to_string(stats.prediction_rate, 6, rate_str, sizeof(rate_str));
    et_eps_to_string(stats.resolved_depth, 4, depth_str, sizeof(depth_str));
    et_eps_to_string(stats.total_resolved, 4, total_str, sizeof(total_str));

    snprintf(buf, sizeof(buf),
        "samples=%lld|predictions=%lld|overrides=%lld|escalations=%lld|"
        "twilight=%lld|rate=%s|resolved=%s|total=%s|dominant_d=%d",
        (long long)stats.total_samples, (long long)stats.predictions_accepted,
        (long long)stats.measurement_overrides, (long long)stats.escalations,
        (long long)stats.twilight_zone_samples, rate_str, depth_str, total_str,
        stats.dominant_d_family);

    et_tracker_stats_clear(&stats);
    return env->NewStringUTF(buf);
}

JNIEXPORT void JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_resetTracker(
        JNIEnv *env, jclass clazz, jint trackerIdx) {
    (void)env; (void)clazz;
    if (trackerIdx >= 0 && trackerIdx < g_tracker_count && g_tracker_initialized[trackerIdx])
        et_tracker_reset(&g_trackers[trackerIdx]);
}

/* ═══════════════════════════════════════════════════════════════════
 * LATTICE ARITHMETIC JNI (Identity A)
 * Returns: [k, d, kappa] + epsilon string via separate call
 * ═══════════════════════════════════════════════════════════════════ */
JNIEXPORT jdoubleArray JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_latticeMultiply(
        JNIEnv *env, jclass clazz,
        jint N, jlong k1, jstring jEps1, jlong k2, jstring jEps2) {
    (void)clazz;
    const char *e1 = env->GetStringUTFChars(jEps1, NULL);
    const char *e2 = env->GetStringUTFChars(jEps2, NULL);

    et_arith_result_t result;
    et_arith_result_init(&result, ET_MPFR_BITS);

    mpfr_t eps1, eps2;
    mpfr_init2(eps1, ET_MPFR_BITS); mpfr_init2(eps2, ET_MPFR_BITS);
    mpfr_set_str(eps1, e1, 10, MPFR_RNDN);
    mpfr_set_str(eps2, e2, 10, MPFR_RNDN);

    env->ReleaseStringUTFChars(jEps1, e1);
    env->ReleaseStringUTFChars(jEps2, e2);

    et_lattice_multiply(N, (long)k1, eps1, (long)k2, eps2, &result, ET_MPFR_BITS);

    char eps_buf[ET_WORK_DPS + 64];
    et_eps_to_string(result.eps, ET_WORK_DPS, eps_buf, sizeof(eps_buf));

    jdoubleArray jarr = env->NewDoubleArray(3);
    jdouble buf[3] = { (jdouble)result.k, (jdouble)result.d, (jdouble)result.kappa };
    env->SetDoubleArrayRegion(jarr, 0, 3, buf);

    mpfr_clears(eps1, eps2, (mpfr_ptr)0);
    et_arith_result_clear(&result);
    return jarr;
}

JNIEXPORT jdoubleArray JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_latticeDivide(
        JNIEnv *env, jclass clazz,
        jint N, jlong k1, jstring jEps1, jlong k2, jstring jEps2) {
    (void)clazz;
    const char *e1 = env->GetStringUTFChars(jEps1, NULL);
    const char *e2 = env->GetStringUTFChars(jEps2, NULL);

    et_arith_result_t result;
    et_arith_result_init(&result, ET_MPFR_BITS);

    mpfr_t eps1, eps2;
    mpfr_init2(eps1, ET_MPFR_BITS); mpfr_init2(eps2, ET_MPFR_BITS);
    mpfr_set_str(eps1, e1, 10, MPFR_RNDN);
    mpfr_set_str(eps2, e2, 10, MPFR_RNDN);

    env->ReleaseStringUTFChars(jEps1, e1);
    env->ReleaseStringUTFChars(jEps2, e2);

    et_lattice_divide(N, (long)k1, eps1, (long)k2, eps2, &result, ET_MPFR_BITS);

    jdoubleArray jarr = env->NewDoubleArray(3);
    jdouble buf[3] = { (jdouble)result.k, (jdouble)result.d, (jdouble)result.kappa };
    env->SetDoubleArrayRegion(jarr, 0, 3, buf);

    mpfr_clears(eps1, eps2, (mpfr_ptr)0);
    et_arith_result_clear(&result);
    return jarr;
}

JNIEXPORT jdoubleArray JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_latticePower(
        JNIEnv *env, jclass clazz,
        jint N, jlong k1, jstring jEps1, jint n) {
    (void)clazz;
    const char *e1 = env->GetStringUTFChars(jEps1, NULL);

    et_arith_result_t result;
    et_arith_result_init(&result, ET_MPFR_BITS);

    mpfr_t eps1;
    mpfr_init2(eps1, ET_MPFR_BITS);
    mpfr_set_str(eps1, e1, 10, MPFR_RNDN);
    env->ReleaseStringUTFChars(jEps1, e1);

    et_lattice_power(N, (long)k1, eps1, n, &result, ET_MPFR_BITS);

    jdoubleArray jarr = env->NewDoubleArray(3);
    jdouble buf[3] = { (jdouble)result.k, (jdouble)result.d, (jdouble)result.kappa };
    env->SetDoubleArrayRegion(jarr, 0, 3, buf);

    mpfr_clear(eps1);
    et_arith_result_clear(&result);
    return jarr;
}

/* ═══════════════════════════════════════════════════════════════════
 * CROSS-RESOLUTION JNI (Finding 11)
 * ═══════════════════════════════════════════════════════════════════ */
JNIEXPORT jdoubleArray JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_crossResolution(
        JNIEnv *env, jclass clazz,
        jlong k1, jint d1, jstring jEps1, jint N1, jint N2) {
    (void)clazz;
    const char *e1 = env->GetStringUTFChars(jEps1, NULL);

    mpfr_t eps1, eps2;
    mpfr_init2(eps1, ET_MPFR_BITS); mpfr_init2(eps2, ET_MPFR_BITS);
    mpfr_set_str(eps1, e1, 10, MPFR_RNDN);
    env->ReleaseStringUTFChars(jEps1, e1);

    long k2; int d2;
    et_cross_resolution((long)k1, d1, eps1, N1, N2, &k2, &d2, eps2, ET_MPFR_BITS);

    char eps_buf[ET_WORK_DPS + 64];
    et_eps_to_string(eps2, ET_WORK_DPS, eps_buf, sizeof(eps_buf));

    jdoubleArray jarr = env->NewDoubleArray(2);
    jdouble buf[2] = { (jdouble)k2, (jdouble)d2 };
    env->SetDoubleArrayRegion(jarr, 0, 2, buf);

    mpfr_clears(eps1, eps2, (mpfr_ptr)0);
    return jarr;
}

/* ═══════════════════════════════════════════════════════════════════
 * .etsf WRITER JNI
 * ═══════════════════════════════════════════════════════════════════ */
static et_etsf_writer_t g_etsf_writer;
static int g_etsf_writer_open = 0;

JNIEXPORT jboolean JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_etsfWriterOpen(
        JNIEnv *env, jclass clazz,
        jstring jPath, jint globalN, jint precisionDps, jstring jDeviceModel) {
    (void)clazz;
    if (g_etsf_writer_open) return JNI_FALSE;

    const char *path = env->GetStringUTFChars(jPath, NULL);
    const char *model = env->GetStringUTFChars(jDeviceModel, NULL);

    et_error_t err = et_etsf_writer_open(&g_etsf_writer, path, globalN, precisionDps, model);

    env->ReleaseStringUTFChars(jPath, path);
    env->ReleaseStringUTFChars(jDeviceModel, model);

    if (err == ET_OK) { g_etsf_writer_open = 1; return JNI_TRUE; }
    return JNI_FALSE;
}

JNIEXPORT jint JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_etsfWriterAddSensor(
        JNIEnv *env, jclass clazz,
        jint sensorType, jstring jName, jint axes, jstring jR0,
        jint sampleRate, jint bitDepth, jstring jAccessMode, jint N) {
    (void)clazz;
    if (!g_etsf_writer_open) return -1;

    const char *name = env->GetStringUTFChars(jName, NULL);
    const char *r0 = env->GetStringUTFChars(jR0, NULL);
    const char *mode = env->GetStringUTFChars(jAccessMode, NULL);

    int sid = -1;
    et_etsf_writer_add_sensor(&g_etsf_writer, (et_sensor_type_t)sensorType,
                               name, axes, r0, sampleRate, bitDepth, mode, N, &sid);

    env->ReleaseStringUTFChars(jName, name);
    env->ReleaseStringUTFChars(jR0, r0);
    env->ReleaseStringUTFChars(jAccessMode, mode);
    return sid;
}

JNIEXPORT jboolean JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_etsfWriterWriteSample(
        JNIEnv *env, jclass clazz,
        jint sensorId, jlong timestampNs, jint axis, jint sign,
        jlong k, jstring jEps, jint epsDps) {
    (void)clazz;
    if (!g_etsf_writer_open) return JNI_FALSE;

    const char *eps_str = env->GetStringUTFChars(jEps, NULL);
    mpfr_t eps;
    mpfr_init2(eps, ET_MPFR_BITS);
    mpfr_set_str(eps, eps_str, 10, MPFR_RNDN);
    env->ReleaseStringUTFChars(jEps, eps_str);

    et_error_t err = et_etsf_writer_write_sample(&g_etsf_writer, sensorId,
                                                   (long long)timestampNs,
                                                   axis, sign, (long)k, eps, epsDps);
    mpfr_clear(eps);
    return (err == ET_OK) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_etsfWriterClose(
        JNIEnv *env, jclass clazz) {
    (void)env; (void)clazz;
    if (!g_etsf_writer_open) return JNI_FALSE;
    et_error_t err = et_etsf_writer_close(&g_etsf_writer);
    g_etsf_writer_open = 0;
    return (err == ET_OK) ? JNI_TRUE : JNI_FALSE;
}

/* ═══════════════════════════════════════════════════════════════════
 * AUDIO CAPTURE JNI
 * ═══════════════════════════════════════════════════════════════════ */
static et_audio_capture_t g_audio_capture;
static int g_audio_initialized = 0;

/* Native audio callback — runs on Oboe's audio thread.
 * Projects each PCM sample through the tracker and writes to .etsf.
 * ENTIRELY NATIVE — no JNI calls from the audio thread. */
static et_differential_tracker_t *g_audio_tracker = NULL;
static int g_audio_sensor_id_etsf = -1;

static void native_audio_callback(void *user_data,
                                    long sample_int, long max_value,
                                    int channel, int frame_index,
                                    long long timestamp_ns) {
    (void)user_data; (void)frame_index;

    if (!g_audio_tracker || !g_etsf_writer_open) return;

    /* Convert ADC int to fraction string (zero float64 chain) */
    char frac_str[64];
    long abs_val = (sample_int < 0) ? -sample_int : sample_int;
    if (sample_int == 0) {
        snprintf(frac_str, sizeof(frac_str), "0");
    } else if (sample_int > 0) {
        snprintf(frac_str, sizeof(frac_str), "%ld/%ld", abs_val, max_value);
    } else {
        snprintf(frac_str, sizeof(frac_str), "-%ld/%ld", abs_val, max_value);
    }

    /* Process through differential tracker (full 7-step algorithm) */
    et_sensor_sample_t sample;
    memset(&sample, 0, sizeof(sample));
    et_projection_init(&sample.projection, ET_MPFR_BITS);

    et_error_t err = et_tracker_process(g_audio_tracker, frac_str, &sample);

    if (err == ET_OK && g_audio_sensor_id_etsf >= 0) {
        /* Write to .etsf (native, no JNI) */
        et_etsf_writer_write_sample(&g_etsf_writer, g_audio_sensor_id_etsf,
                                     timestamp_ns, channel,
                                     sample.projection.sign,
                                     sample.projection.k,
                                     sample.projection.eps, ET_WORK_DPS);
    }

    et_projection_clear(&sample.projection);
}

JNIEXPORT jboolean JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_audioInit(
        JNIEnv *env, jclass clazz,
        jint sampleRate, jint channelCount, jint bitDepth, jint exclusive) {
    (void)env; (void)clazz;

    et_audio_config_t config = et_audio_default_config();
    config.sample_rate = sampleRate;
    config.channel_count = channelCount;
    config.bit_depth = bitDepth;
    config.exclusive_mode = exclusive;

    et_error_t err = et_audio_init(&g_audio_capture, &config,
                                    native_audio_callback, NULL);
    if (err == ET_OK) g_audio_initialized = 1;
    return (err == ET_OK) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_audioOpen(
        JNIEnv *env, jclass clazz) {
    (void)env; (void)clazz;
    if (!g_audio_initialized) return JNI_FALSE;
    return (et_audio_open(&g_audio_capture) == ET_OK) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT jboolean JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_audioStart(
        JNIEnv *env, jclass clazz, jint trackerIdx, jint etsfSensorId) {
    (void)env; (void)clazz;
    if (!g_audio_initialized) return JNI_FALSE;

    /* Set the tracker for the native callback to use */
    if (trackerIdx >= 0 && trackerIdx < g_tracker_count && g_tracker_initialized[trackerIdx]) {
        g_audio_tracker = &g_trackers[trackerIdx];
    }
    g_audio_sensor_id_etsf = etsfSensorId;

    return (et_audio_start(&g_audio_capture) == ET_OK) ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_audioStop(
        JNIEnv *env, jclass clazz) {
    (void)env; (void)clazz;
    et_audio_stop(&g_audio_capture);
    g_audio_tracker = NULL;
    g_audio_sensor_id_etsf = -1;
}

JNIEXPORT void JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_audioClose(
        JNIEnv *env, jclass clazz) {
    (void)env; (void)clazz;
    et_audio_close(&g_audio_capture);
    g_audio_initialized = 0;
}

JNIEXPORT jstring JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_audioGetInfo(
        JNIEnv *env, jclass clazz) {
    (void)clazz;
    if (!g_audio_initialized) return env->NewStringUTF("not initialized");

    const et_audio_hw_info_t *hw = &g_audio_capture.hw_info;
    char buf[1024];
    snprintf(buf, sizeof(buf),
        "rate=%d|channels=%d|bits=%d|exclusive=%d|mmap=%d|"
        "sharing=%s|perf=%s|frames=%lld|xruns=%lld",
        hw->actual_sample_rate, hw->actual_channel_count,
        hw->actual_bit_depth, hw->is_exclusive, hw->is_mmap,
        hw->sharing_mode, hw->performance_mode,
        (long long)g_audio_capture.total_frames,
        (long long)g_audio_capture.xrun_count);
    return env->NewStringUTF(buf);
}

/* ═══════════════════════════════════════════════════════════════════
 * CLEANUP ALL (extended to include trackers, writer, audio)
 * ═══════════════════════════════════════════════════════════════════ */
JNIEXPORT void JNICALL
Java_com_aevumdefluo_etsensor_EtSensor_cleanupAll(
        JNIEnv *env, jclass clazz) {
    (void)env; (void)clazz;

    /* Close audio */
    if (g_audio_initialized) {
        et_audio_stop(&g_audio_capture);
        et_audio_close(&g_audio_capture);
        g_audio_initialized = 0;
    }

    /* Close .etsf writer */
    if (g_etsf_writer_open) {
        et_etsf_writer_close(&g_etsf_writer);
        g_etsf_writer_open = 0;
    }

    /* Clear trackers */
    for (int i = 0; i < g_tracker_count; i++) {
        if (g_tracker_initialized[i]) {
            et_tracker_clear(&g_trackers[i]);
            g_tracker_initialized[i] = 0;
        }
    }
    g_tracker_count = 0;

    /* Clear projectors (from original cleanup) */
    for (int i = 0; i < g_projector_count; i++) {
        if (g_projector_initialized[i]) {
            et_sensor_projector_clear(&g_projectors[i]);
            g_projector_initialized[i] = 0;
        }
    }
    g_projector_count = 0;

    if (g_base_initialized) {
        et_projector_clear(&g_base_projector);
        g_base_initialized = 0;
    }

    LOGI("All native resources cleaned up");
}

} /* extern "C" */
