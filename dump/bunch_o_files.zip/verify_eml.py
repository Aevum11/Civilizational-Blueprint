"""
Verify EML paper's identities and project its K-values onto the ET lattice.
"""
import math
import cmath
from math import gcd, log2
from fractions import Fraction

N_ET = 12

def project_real(r, N=N_ET):
    if r <= 0:
        return None
    log2r = log2(r)
    exact = N * log2r
    k = int(round(exact))
    g = gcd(abs(k), N) if k != 0 else N
    d = N // g
    eps_cents = (exact - k) * (1200.0 / N)
    return {'k': k, 'd': d, 'eps_cents': eps_cents, 'g': g, 'log2_r': log2r}

# 1) Verify the paper's EML identities numerically
print("=" * 70)
print("VERIFICATION OF EML IDENTITIES (paper eq. 3, 4, 5)")
print("=" * 70)

def eml(x, y):
    # Complex domain to handle ln of negatives/zero properly
    return cmath.exp(x) - cmath.log(y)

# e = eml(1,1) = exp(1) - ln(1) = e - 0
v = eml(1, 1)
print(f"eml(1,1)       = {v}    expected e ≈ {math.e}")
print(f"                 real residual = {abs(v.real - math.e):.3e}")

# e^x = eml(x, 1)
x = 2.5
v = eml(x, 1)
print(f"eml({x},1)    = {v}    expected e^{x} ≈ {math.exp(x)}")

# ln(x) = eml(1, eml(eml(1,x), 1))
x = 7.3
inner   = eml(1, x)
middle  = eml(inner, 1)
outer   = eml(1, middle)
print(f"eml(1,eml(eml(1,{x}),1)) = {outer}    expected ln({x}) = {math.log(x)}")
print(f"                             real residual = {abs(outer.real - math.log(x)):.3e}")

# 2) Project the RPN K-values from Table 4 onto the 12ET lattice
print()
print("=" * 70)
print("LATTICE PROJECTION of EML's RPN complexity K-values (from Table 4)")
print("=" * 70)

table4 = [
    # (K_direct, expression, "Constant/Function/Operator")
    (1,   "constant 1",        "C"),
    (7,   "constant 0",        "C"),
    (17,  "constant -1",       "C"),
    (19,  "constant 2",        "C"),
    (27,  "constant -2",       "C"),
    (35,  "constant 1/2",      "C"),
    (37,  "constant -1/2",     "C"),
    (39,  "constant 2/3",      "C"),
    (47,  "constant -2/3",     "C"),
    (3,   "function e^x",      "F"),
    (7,   "function ln x",     "F"),
    (15,  "function -x",       "F"),
    (15,  "function 1/x",      "F"),
    (11,  "function x-1",      "F"),
    (19,  "function x+1",      "F"),
    (27,  "function x/2",      "F"),
    (19,  "function 2x",       "F"),
    (17,  "function x²",       "F"),
    (11,  "operator x-y",      "O"),
    (19,  "operator x+y",      "O"),
    (17,  "operator x×y",      "O"),
    (17,  "operator x/y",      "O"),
]
print(f"{'K':>4}  {'Expression':<22}  {'k':>5}  {'d':>3}  {'ε(¢)':>8}  reading")
print("-" * 70)
for K, expr, kind in table4:
    p = project_real(K)
    print(f"{K:>4}  {expr:<22}  {p['k']:>5}  {p['d']:>3}  {p['eps_cents']:>+8.2f}")

# 3) Key constants that EML needs to generate
print()
print("=" * 70)
print("LATTICE PROJECTION of EML's generated fundamental constants")
print("=" * 70)
constants = [
    ("1",  1.0),
    ("e",  math.e),
    ("π",  math.pi),
    ("2",  2.0),
    ("√2", math.sqrt(2)),
    ("e^π", math.exp(math.pi)),
    ("golden φ", (1+math.sqrt(5))/2),
    ("Catalan's const G", 0.9159655941772190),  # not in paper but elementary
    ("ln 2", math.log(2)),
]
print(f"{'const':<12}  {'value':>20}  {'k':>5}  {'d':>3}  {'ε(¢)':>9}")
print("-" * 70)
for name, val in constants:
    p = project_real(val)
    if p:
        print(f"{name:<12}  {val:>20.10f}  {p['k']:>5}  {p['d']:>3}  {p['eps_cents']:>+9.3f}")

# 4) Verify the coincidence I suspect: K=3 (EML's three simplest expressions
#    e^x, ln x, e) all sit at the perfect-fifth-class d=12 lattice position
print()
print("=" * 70)
print("CHECK: EML simplest-expression K values vs ET lattice attractors")
print("=" * 70)
# K values that recur in Table 4
from collections import Counter
k_counter = Counter()
for K, _, _ in table4:
    k_counter[K] += 1
print("Most common K values in Table 4:")
for K, cnt in k_counter.most_common(8):
    p = project_real(K)
    if p:
        print(f"  K={K:>3} (count={cnt}):  lattice k={p['k']:>4}  d={p['d']:>3}  ε={p['eps_cents']:>+7.2f}¢")

# 5) Check the paper's claim about SR-recovery rates at tree depths
print()
print("=" * 70)
print("Paper's empirical SR recovery rates vs. ET cascade stability limits")
print("=" * 70)
# From the paper §4.3: depth 2 → 100%, depth 3-4 → ~25%, depth 5 → <1%, depth 6 → 0%
# ET's cascade stability: n_max_θ = 2 at 12ET (Part XV §68)
# The depth at which EML's SR blindly fails (depth 5-6) is well beyond ET's
# cascade stability for the imaginary axis (n_max_θ = 2).
depths = [(2, "100%"), (3, "~25%"), (4, "~25%"), (5, "<1%"), (6, "0%")]
print(f"{'depth':>6}  {'SR recovery':>12}  ET cascade (n_max_θ=2) regime")
for d, rate in depths:
    inside = "inside" if d <= 2 else "OUTSIDE"
    print(f"{d:>6}  {rate:>12}  {inside} imaginary-axis cascade stability")

