/* ============================================================================
 * libet_med — ET-native medical projection library
 * ----------------------------------------------------------------------------
 *  Identification Principle: this library projects measurements of a human
 *  body (P_body, D_body, T_body) onto the ET lattice. Every function carries
 *  the Three Tools (Identification, Descriptor Gap, Subsumption) inline as
 *  comments at the call sites.
 *
 *  Subsumption Law: every conventional medical scalar is an ET value
 *  expressed in domain vocabulary; corpus-grounded derivation precedes any
 *  use of an external reference.
 *
 *  Descriptor Gap Principle: |epsilon| in cents is the residual between an
 *  arbitrary measurement and its lattice attractor; its sign and magnitude
 *  drive the Four Manifold States classification.
 *
 *  This header is the single public interface — applications and FFI
 *  wrappers (Android JNI, Windows P/Invoke, WebAssembly) include this file
 *  exclusively. ABI is C, no C++ name mangling.
 * ========================================================================= */
#ifndef LIBET_MED_H
#define LIBET_MED_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ----------------------------------------------------------------------------
 * Visibility / linkage
 * ------------------------------------------------------------------------- */
#if defined(_WIN32) && defined(LIBET_MED_BUILD_DLL)
#  define LIBET_MED_API __declspec(dllexport)
#elif defined(_WIN32) && defined(LIBET_MED_USE_DLL)
#  define LIBET_MED_API __declspec(dllimport)
#else
#  define LIBET_MED_API
#endif

/* ----------------------------------------------------------------------------
 * Library version
 * ------------------------------------------------------------------------- */
#define LIBET_MED_VERSION_MAJOR 1
#define LIBET_MED_VERSION_MINOR 0
#define LIBET_MED_VERSION_PATCH 0
#define LIBET_MED_VERSION_STRING "1.0.0"

/* ============================================================================
 * Module 43.1 — Manifold Constants
 *  These are NOT chosen — they are the primitives of ET. Three primitives
 *  (P, D, T) ; four manifold states ({}, {P,D}, {D,T}, {P,T}, {P,D,T} where
 *  empty is the unmanifested ground); base 12-fold manifold ; V = 1/12 base
 *  variance ; Koide K = 2/3 ; A_0 = 137 = 12^2 - 12 + 5 (the local-EM
 *  binding constant from the Fine Structure Constant derivation).
 *
 *  Biological floor 420 = LCM(1..7) = (5,7) co-binding floor for biological
 *  substrates (Projection Guide §75). Cortical floor 27720 = LCM(1..11) for
 *  Blue Brain 11D cliques (Projection Guide §26.5).
 * ========================================================================= */
LIBET_MED_API extern const int    ET_N_PRIMITIVES;     /* = 3   (P, D, T)              */
LIBET_MED_API extern const int    ET_S_STATES;         /* = 4   active manifold states */
LIBET_MED_API extern const int    ET_N_MANIFOLD_12;    /* = 12  base manifold          */
LIBET_MED_API extern const double ET_V_BASE;           /* = 1/12 base variance         */
LIBET_MED_API extern const double ET_K_KOIDE;          /* = 2/3 Koide ratio            */
LIBET_MED_API extern const int    ET_A0_LOCAL_EM;      /* = 137                        */
LIBET_MED_API extern const int    ET_BIOLOGICAL_FLOOR; /* = 420                        */
LIBET_MED_API extern const int    ET_CORTICAL_FLOOR;   /* = 27720                      */

/* ============================================================================
 * Error model (Module 43.7 — must come before functions that return it)
 *  Per Rule 33 and the ET_FRACTAL_GENERATOR convention: every fallback path
 *  is logged via _et_error(fatal=false); silent fallbacks are forbidden.
 * ========================================================================= */
typedef enum et_error_e {
    ET_OK                              =  0,
    ET_ERR_INVALID_RATIO               =  1,  /* r <= 0                              */
    ET_ERR_INVALID_N                   =  2,  /* N not in {12,60,84,420,2520,27720}  */
    ET_ERR_INVALID_ARG                 =  3,  /* NULL pointer or out-of-range scalar */
    ET_ERR_OUT_OF_MEMORY               =  4,
    ET_ERR_UNKNOWN_TOWER               =  5,
    ET_ERR_INCOMPLETE_BASELINE         =  6,  /* required field missing/non-finite   */
    ET_ERR_FALLBACK_USED               =  7,  /* logged non-fatal informational      */
    ET_ERR_CASCADE_STABILITY_EXCEEDED  =  8,  /* active-system iteration overflow    */
    ET_ERR_OFF_LATTICE                 =  9,  /* projection outside finite domain    */
    ET_ERR_NUMERIC                     = 10,  /* nan/inf produced                    */
    ET_ERR_LAST                        = 11
} et_error_t;

LIBET_MED_API const char* et_error_string(et_error_t err);

/* Optional logging callback. NULL by default; if set, every internal fallback
 * invokes it. This is the `_et_error(fatal=false)` channel. */
typedef void (*et_log_fn)(et_error_t err, const char* file, int line,
                          const char* func, const char* message,
                          void* user_data);

LIBET_MED_API void et_set_log_callback(et_log_fn fn, void* user_data);
LIBET_MED_API et_log_fn et_get_log_callback(void);

/* Counters (introspection only — never used to silently swallow errors). */
LIBET_MED_API size_t et_fallback_count(void);
LIBET_MED_API void   et_reset_fallback_count(void);

/* ============================================================================
 * Module 43.2 — Projection Primitives
 *  Identification: r = ratio of two like-dimensioned quantities (R0-cancelled).
 *  Descriptor Gap: epsilon_cents = (N*log2(r) - k) * 1200/N.
 *  Subsumption: any musical, biological, or numerical ratio is the same
 *  formula — only N and the meaning of r change.
 * ========================================================================= */
typedef struct et_projection_s {
    double r;          /* input ratio (positive)                 */
    double log2_r;     /* log2(r)                                */
    double exact_pos;  /* N * log2(r)                            */
    int    k;          /* lattice coordinate = round(N*log2(r))  */
    int    g;          /* gcd(|k|, N)  ; for k==0 we set g = N   */
    int    d;          /* sublattice family = N / g              */
    double eps_cents;  /* (N*log2(r) - k) * 1200/N               */
    int    N;          /* lattice resolution                     */
} et_projection_t;

/* Real-axis projection. Returns ET_ERR_INVALID_RATIO if r <= 0 or non-finite,
 * ET_ERR_INVALID_N if N is not a supported resolution, ET_ERR_INVALID_ARG if
 * out is NULL. */
LIBET_MED_API et_error_t et_project_real(double r, int N, et_projection_t* out);

/* Imaginary-axis (D-T phase) projection. theta is in radians (mod 2pi).
 * Internal: maps theta to a positive ratio via 2^(theta/(2pi)) and projects. */
LIBET_MED_API et_error_t et_project_imag(double theta, int N, et_projection_t* out);

typedef struct et_complex_projection_s {
    et_projection_t real;
    et_projection_t imag;
    int    k_r, k_theta;
    int    d_r, d_theta;
    int    d_combined;   /* lcm(d_r, d_theta) ; the FQG cell family */
    double alpha;        /* D-T gradient angle in radians           */
    double D_fraction;   /* cos^2(alpha)                            */
    double T_fraction;   /* sin^2(alpha)                            */
    int    N;
} et_complex_projection_t;

LIBET_MED_API et_error_t et_project_complex(double r, double theta, int N,
                                            et_complex_projection_t* out);

/* Multi-resolution projection across the canonical LCM landmark tower
 * {12, 60, 84, 420, 2520, 27720}. out must hold at least 6 entries; the
 * actual number filled is written to *count_out. */
LIBET_MED_API et_error_t et_project_multi(double r,
                                          et_projection_t* out,
                                          int max_lattices,
                                          int* count_out);

/* Canonical LCM landmark tower — exposed for wrappers that want to enumerate. */
LIBET_MED_API int et_lcm_tower(int* out_resolutions, int max_count);

/* ============================================================================
 * Module 43.3 — Elegance and Magical Impedance
 *  Elegance Score (Projection Guide §41) measures how close a ratio is to
 *  being a rational p/q with small p+q on a tight lattice attractor.
 *
 *  Magical Impedance xi(d) = A0 / ((d-1)^2 + S^2) is the per-sublattice-family
 *  binding strength (Projection Guide §43, corrected form). For (S=4, A0=137):
 *      xi(1) = 137/16 = 8.5625    (gravitational class — strongest binding)
 *      xi(2) = 137/17 = 8.0588
 *      xi(7) = 137/52 = 2.6346
 *      xi(12)= 137/137 = 1.0000   (unit reference)
 * ========================================================================= */
typedef struct et_elegance_s {
    double r;
    int    p, q;                /* best rational approximation                */
    int    p_plus_q;
    int    d;                   /* sublattice family of the projection        */
    double eps_cents;
    double symmetry_factor;     /* N / d                                       */
    double tightness_factor;    /* 100 / (100 + |eps|)                         */
    double simplicity_factor;   /* 100 / (p + q)                               */
    double elegance;            /* product of the three factors                */
} et_elegance_t;

LIBET_MED_API et_error_t et_elegance_score(double r, int N, int max_denom,
                                           et_elegance_t* out);

/* Magical impedance. Pass S=ET_S_STATES, A0_local=ET_A0_LOCAL_EM for the
 * canonical local-EM form. For other complexes (e.g. nuclear strong) the
 * caller supplies the appropriate A0_local. */
LIBET_MED_API double et_magical_impedance(int d, int S, int A0_local);

/* Best p/q approximation by continued fractions, |q| <= max_denom. */
LIBET_MED_API et_error_t et_best_rational(double r, int max_denom,
                                          int* p_out, int* q_out);

/* ============================================================================
 * Module 43.4 — Active-System Dynamics
 *  Tightness function t(z) = 100/(100+|eps_n|). Boundary detection: |eps_n|
 *  approaching 50 cents flags a Mediation/Incoherence transit.
 *
 *  Palindromic cascade (Projection Guide §17): the d-family of the n-th
 *  generator-7 step on the 12-fold lattice follows the palindromic sequence
 *      [12, 6, 4, 3, 12, 2, 12, 3, 4, 6, 12, 1]
 *  This is a structural theorem proven via GCD complementary identity, not
 *  a fit. Used as a matching filter against longitudinal data.
 *
 *  Shimmer modulation Psi_n: per-step interference term that arises from the
 *  bilateral D-folding of the manifold (Projection Guide §57). Its envelope
 *  scales with cascade depth.
 * ========================================================================= */
typedef struct et_active_state_s {
    double z_real;     /* current real component (e.g. ratio of measurement to baseline) */
    double z_imag;     /* current imaginary component (D-T phase)                        */
    int    n;          /* step number (cycle index)                                       */
    int    N;          /* lattice resolution                                              */
    double eps_history[64]; /* circular buffer of last |eps| values                       */
    int    history_len;     /* number of valid entries (<= 64)                            */
    int    history_head;    /* write index (0..63)                                        */
    int    cascade_depth;   /* number of dI-boundary crossings observed                   */
} et_active_state_t;

LIBET_MED_API et_error_t et_active_state_init(et_active_state_t* state, int N);

/* Tightness at current state. */
LIBET_MED_API double et_tightness(const et_active_state_t* state);

/* dI boundary test: 1 if |eps| is within tolerance of 50 cents. */
LIBET_MED_API int et_is_at_dI_boundary(const et_active_state_t* state, double tol_cents);

/* Palindromic cascade lookup. n_mod_12 in [0, 11]; returns d in
 * {12, 6, 4, 3, 12, 2, 12, 3, 4, 6, 12, 1}. */
LIBET_MED_API int et_palindrome_d(int n_mod_12);

/* Shimmer modulation at step n. */
LIBET_MED_API double et_shimmer(int n);

/* One step of the active-system iteration. Updates z, n, eps_history, and
 * cascade_depth in-place. Returns ET_ERR_CASCADE_STABILITY_EXCEEDED if the
 * accumulated cascade depth crosses the per-tower stability ceiling. */
LIBET_MED_API et_error_t et_active_step(et_active_state_t* state, double next_r);

/* ============================================================================
 * Module 43.5 — Medical Towers
 *  Each tower has a substrate-derived R0 (the smallest closed T-traversal
 *  loop of that subsystem). The Universal Human Tower is ET_TOWER_CARDIAC;
 *  its R0 IS the personal cardiac period at rest = 60 / HR_rest seconds.
 *
 *  Identification: (P, D, T) decomposition for each subsystem is documented
 *  in the Master Design Document Part II §7.
 * ========================================================================= */
typedef enum et_tower_e {
    ET_TOWER_CARDIAC = 0,        /* Universal Human Tower — R0 = 60/HR_rest s        */
    ET_TOWER_RESPIRATORY,        /* R0 = 60/RR_rest s                                */
    ET_TOWER_NEURAL,             /* R0 = 1/40 s = 25 ms (gamma binding) ; N=27720    */
    ET_TOWER_ENDOCRINE,          /* R0 = 1 sidereal day                              */
    ET_TOWER_IMMUNE,             /* R0 = 1 day (working) ; N=420                     */
    ET_TOWER_DIGESTIVE,          /* R0 = 1 sidereal day                              */
    ET_TOWER_RENAL,              /* R0 = full-blood-volume filtration cycle ~30 min  */
    ET_TOWER_MUSCULOSKELETAL,    /* R0 = 1 gait cycle ~1 s                           */
    ET_TOWER_REPRODUCTIVE,       /* R0 = 28 d (female) / 74 d (male)                 */
    ET_TOWER_DEVELOPMENTAL,      /* R0 = 1 generation ~25 yr                         */
    ET_TOWER_COUNT
} et_tower_t;

LIBET_MED_API const char* et_tower_name(et_tower_t tower);

/* Default (population-baseline) R0 in seconds for each tower. Returns NaN
 * for ET_TOWER_COUNT or invalid input (and logs a fallback). */
LIBET_MED_API double et_tower_default_R0(et_tower_t tower);

/* Sex enum used in baseline. */
typedef enum et_sex_e {
    ET_SEX_FEMALE      = 0,
    ET_SEX_MALE        = 1,
    ET_SEX_UNSPECIFIED = 2
} et_sex_t;

/* Patient baseline. Fields with non-finite values are treated as missing;
 * et_derive_personal_R0 returns ET_ERR_INCOMPLETE_BASELINE if the field
 * required for the requested tower is absent. */
typedef struct et_patient_baseline_s {
    double hr_rest_bpm;          /* Resting heart rate (bpm)                         */
    double rr_rest_per_min;      /* Resting respiratory rate (per min)               */
    double temperature_c;        /* Core body temperature (Celsius)                  */
    double sbp_rest_mmhg;        /* Resting systolic blood pressure (mmHg)           */
    double dbp_rest_mmhg;        /* Resting diastolic blood pressure (mmHg)          */
    double spo2_pct;             /* Pulse-ox saturation (%)                          */
    double gait_cycle_s;         /* 1 gait cycle period (s)                          */
    double menstrual_cycle_d;    /* Menstrual cycle length (days, female)            */
    double age_years;
    et_sex_t sex;
} et_patient_baseline_t;

LIBET_MED_API void et_patient_baseline_init(et_patient_baseline_t* baseline);

/* Derive the personal R0 in seconds for the given tower from the baseline.
 * Falls back to et_tower_default_R0 (logged) if the relevant field is
 * missing AND fallback_allowed is non-zero; otherwise returns
 * ET_ERR_INCOMPLETE_BASELINE. */
LIBET_MED_API et_error_t et_derive_personal_R0(const et_patient_baseline_t* baseline,
                                               et_tower_t tower,
                                               int fallback_allowed,
                                               double* R0_out);

/* The tower's preferred lattice resolution N. */
LIBET_MED_API int et_tower_resolution(et_tower_t tower);

/* Population-reference baseline VALUE (in the measurement's natural units,
 * not seconds). Used by UI for normal-value display and by classification
 * fallback when the patient-specific baseline is missing. Returns:
 *   CARDIAC         -> 60.0   (bpm, resting)
 *   RESPIRATORY     -> 12.0   (per min, resting)
 *   ENDOCRINE       -> 36.85  (°C, core temperature — the endocrine tower's
 *                              thermostat setpoint is the population-shared
 *                              ET attractor value per Translation Layer)
 *   MUSCULOSKELETAL -> 1.0    (s, gait cycle)
 *   Other towers    -> NaN (no natural scalar outside the R0 itself).
 */
LIBET_MED_API double et_tower_reference_baseline_value(et_tower_t tower);

/* The full multifold signature (10 R0s + scalars). */
typedef struct et_multifold_signature_s {
    double R0_seconds[ET_TOWER_COUNT];
    int    R0_present[ET_TOWER_COUNT]; /* 1 if derived from baseline, 0 if defaulted */
    /* Pairwise elegance scores (i<j flat indexing).
     * Index for pair (i,j) with i<j is i*(2*ET_TOWER_COUNT - i - 1)/2 + (j - i - 1). */
    et_elegance_t pairwise[ET_TOWER_COUNT * (ET_TOWER_COUNT - 1) / 2];
    double multifold_scalar;         /* geometric mean of pairwise elegance (scale-invariant) */
    double multifold_log_scalar;     /* sum of log(elegance) (numerically safe product)       */
    double multifold_normalized;     /* observed geo-mean / reference geo-mean — the L5-coherence signal:
                                        1.0 = healthy, <1 = drift, << 1 = collapse */
    int    pair_count_valid;         /* number of pairs with a finite positive elegance       */
} et_multifold_signature_t;

LIBET_MED_API et_error_t et_compute_multifold_signature(const et_patient_baseline_t* baseline,
                                                        int fallback_allowed,
                                                        et_multifold_signature_t* out);

/* Helper: flat index for the (i, j) elegance pair (i<j). */
LIBET_MED_API int et_pair_index(int i, int j);

/* ============================================================================
 * Module 43.6 — Findings
 *  A Finding is the result of classifying a single measurement (or pair of
 *  measurements) against a tower and a lattice resolution. Each finding
 *  records its lattice projection, its Four Manifold State, its Incoherence
 *  Filter level (if any), its severity score, and ontology links.
 *
 *  Severity score (§34 of Master Design):
 *      S = alpha * |eps|/50 + beta * xi(d) + gamma * |w|^2/|w|^2_max
 *          + delta * cascade_depth/n_max
 *  with (alpha, beta, gamma, delta) = (1/12, 1/16, 1/132, 1/12) — all
 *  derived from manifold constants, NOT tuned (Rule 12).
 * ========================================================================= */
typedef enum et_manifold_state_e {
    ET_STATE_EXCEPTION       = 0,  /* {P,D,T} baseline / healthy        */
    ET_STATE_UNSUBSTANTIATED = 1,  /* {P,D} latent risk                  */
    ET_STATE_MEDIATION       = 2,  /* {D,T} active process / in transit  */
    ET_STATE_INCOHERENCE     = 3   /* {P,T} active pathology             */
} et_manifold_state_t;

LIBET_MED_API const char* et_manifold_state_name(et_manifold_state_t s);

typedef enum et_incoherence_level_e {
    ET_INCOH_NONE             = 0,
    ET_INCOH_L1_CATEGORICAL   = 1, /* type/category mismatch                */
    ET_INCOH_L2_BINDING       = 2, /* binding-strength misalignment         */
    ET_INCOH_L3_CASCADE       = 3, /* cascade-depth instability             */
    ET_INCOH_L4_STABILITY     = 4, /* dI boundary trespass                  */
    ET_INCOH_L5_COHERENCE     = 5  /* chronic loss of multi-tower coherence */
} et_incoherence_level_t;

LIBET_MED_API const char* et_incoherence_level_name(et_incoherence_level_t l);

/* A measurement: a (current_value, baseline_value, units, tower, name) tuple.
 * The library forms r = current / baseline and projects against the tower's
 * preferred resolution. */
typedef struct et_measurement_s {
    char        name[64];            /* short name e.g. "HR" "RR" "Temp"     */
    double      current_value;
    double      baseline_value;      /* if 0 or non-finite, derived from tower */
    char        units[16];
    et_tower_t  tower;
    int         resolution_override; /* 0 = use tower default; else explicit N */
    /* Optional time stamp (Unix seconds). 0 if not provided. */
    double      timestamp_s;
} et_measurement_t;

LIBET_MED_API void et_measurement_init(et_measurement_t* m);

#define ET_FINDING_NAME_MAX 96
#define ET_FINDING_DESC_MAX 256
#define ET_FINDING_CODE_MAX 32

typedef struct et_finding_s {
    char  name[ET_FINDING_NAME_MAX];
    char  description[ET_FINDING_DESC_MAX];

    et_manifold_state_t    state;
    et_incoherence_level_t incoherence_level;
    et_tower_t             tower;
    int                    lattice_resolution;
    et_projection_t        projection;

    double severity_score_raw;       /* unnormalized (0 .. ~0.708)           */
    double severity_score_pct;       /* normalized to [0, 100]               */
    int    urgency_rank;             /* 1 = highest                          */

    char   icd11_code[ET_FINDING_CODE_MAX];
    char   icf_code  [ET_FINDING_CODE_MAX];
    char   snomed_code[ET_FINDING_CODE_MAX];

    char   laterality      [ET_FINDING_CODE_MAX];
    char   severity_text   [ET_FINDING_CODE_MAX];
    char   specific_anatomy[ET_FINDING_CODE_MAX];
    char   histopathology  [ET_FINDING_CODE_MAX];
    char   temporal_pattern[ET_FINDING_CODE_MAX];
} et_finding_t;

LIBET_MED_API void et_finding_init(et_finding_t* f);

/* Classify a single measurement into a finding. baseline must have been set
 * (or the measurement must carry a non-zero baseline_value).  */
LIBET_MED_API et_error_t et_classify_measurement(const et_measurement_t* m,
                                                 const et_patient_baseline_t* baseline,
                                                 int fallback_allowed,
                                                 et_finding_t* out);

/* Generate findings for a set of measurements. Caller frees with
 * et_free_findings. Findings are returned sorted by urgency (1 = highest
 * urgency first). */
LIBET_MED_API et_error_t et_generate_findings(const et_measurement_t* measurements,
                                              int measurement_count,
                                              const et_patient_baseline_t* baseline,
                                              int fallback_allowed,
                                              et_finding_t** findings_out,
                                              int* count_out);

LIBET_MED_API void et_free_findings(et_finding_t* findings, int count);

/* Severity score — exposed individually for testing. */
LIBET_MED_API double et_severity_score_raw(double abs_eps_cents,
                                           int d,
                                           double w_norm_squared,
                                           double w_norm_squared_max,
                                           int cascade_depth,
                                           int n_max);

LIBET_MED_API double et_severity_score_pct(double raw);

/* Severity normalization constant (the maximum raw score reachable). */
LIBET_MED_API double et_severity_score_max_raw(void);

/* The Four Manifold State classification rule. Pure function — depends only
 * on |eps_cents|, d, and tightness. */
LIBET_MED_API et_manifold_state_t et_classify_state(double abs_eps_cents,
                                                    int    d,
                                                    double tightness);

/* The Incoherence Level rule. Returns ET_INCOH_NONE if state != INCOHERENCE. */
LIBET_MED_API et_incoherence_level_t et_classify_incoherence_level(
    et_manifold_state_t state,
    double abs_eps_cents,
    int    d,
    int    cascade_depth,
    double multifold_scalar);

#ifdef __cplusplus
} /* extern "C" */
#endif

#endif /* LIBET_MED_H */
