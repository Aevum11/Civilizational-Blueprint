#!/usr/bin/env python3
"""
Exception Theory Library Structure Verification Script
Verifies all files are present and correct before installation.
"""

import os
import sys
from pathlib import Path

def verify_structure():
    """Verify the complete library structure."""
    print("=" * 70)
    print("EXCEPTION THEORY v3.0 - STRUCTURE VERIFICATION")
    print("=" * 70)
    print()
    
    errors = []
    warnings = []
    
    # Expected structure
    expected_files = {
        'Package Config': [
            'setup.py',
            'pyproject.toml',
            'requirements.txt',
            'LICENSE',
            'MANIFEST.in'
        ],
        'Documentation': [
            'README.md',
            'PROJECT_SUMMARY.md',
            'LIBRARY_STRUCTURE.md',
            'QUICK_START.md',
            'DIRECTORY_TREE.txt',
            'COMPLETE_DIRECTORY_STRUCTURE.md',
            'BATCH3_INTEGRATION_CHANGELOG.md'
        ],
        'Examples': [
            'examples.py'
        ],
        'Core Package': [
            'exception_theory/__init__.py',
            'exception_theory/core/__init__.py',
            'exception_theory/core/constants.py',
            'exception_theory/core/mathematics.py',
            'exception_theory/core/primitives.py',
            'exception_theory/classes/__init__.py',
            'exception_theory/classes/batch1.py',
            'exception_theory/classes/batch2.py',
            'exception_theory/classes/batch3.py',
            'exception_theory/engine/__init__.py',
            'exception_theory/engine/sovereign.py',
            'exception_theory/utils/__init__.py',
            'exception_theory/utils/calibration.py',
            'exception_theory/utils/logging.py',
            'exception_theory/tests/__init__.py',
            'exception_theory/tests/test_basic.py'
        ]
    }
    
    build_artifacts = [
        'batch1_classes.py',
        'batch1_part1.txt',
        'batch2_classes.py',
        'engine_extracted.txt',
        'et_core_full.py',
        'et_engine_full.py',
        'etmath_extracted.py',
        'reference_v2_2.py',
        'utils_classes.py'
    ]
    
    # Verify each category
    for category, files in expected_files.items():
        print(f"Checking {category}...")
        found = 0
        for filepath in files:
            if os.path.exists(filepath):
                found += 1
                print(f"  ✅ {filepath}")
            else:
                errors.append(f"Missing: {filepath}")
                print(f"  ❌ {filepath}")
        print(f"  → {found}/{len(files)} found")
        print()
    
    # Check for build artifacts
    print("Checking for build artifacts (these can be deleted)...")
    artifact_count = 0
    for artifact in build_artifacts:
        if os.path.exists(artifact):
            artifact_count += 1
            warnings.append(f"Build artifact present: {artifact}")
            print(f"  ⚠️  {artifact}")
    
    if artifact_count == 0:
        print(f"  ✅ No build artifacts found (clean)")
    else:
        print(f"  ⚠️  {artifact_count} build artifacts found (can be deleted)")
    print()
    
    # Verify line counts for key files
    print("Verifying key file line counts...")
    key_files = {
        'exception_theory/core/constants.py': 210,
        'exception_theory/core/mathematics.py': 908,
        'exception_theory/core/primitives.py': 289,
        'exception_theory/classes/batch1.py': 848,
        'exception_theory/classes/batch2.py': 859,
        'exception_theory/classes/batch3.py': 931,
        'exception_theory/engine/sovereign.py': 1879,
        'exception_theory/utils/calibration.py': 172,
        'exception_theory/utils/logging.py': 94,
        'exception_theory/tests/test_basic.py': 212
    }
    
    total_lines = 0
    for filepath, expected_lines in key_files.items():
        if os.path.exists(filepath):
            with open(filepath, 'r') as f:
                actual_lines = len(f.readlines())
            total_lines += actual_lines
            
            # Allow ±5 lines variance (for minor edits)
            if abs(actual_lines - expected_lines) <= 5:
                print(f"  ✅ {filepath}: {actual_lines} lines (expected ~{expected_lines})")
            else:
                diff = actual_lines - expected_lines
                warnings.append(f"{filepath}: {actual_lines} lines (expected {expected_lines}, diff: {diff:+d})")
                print(f"  ⚠️  {filepath}: {actual_lines} lines (expected {expected_lines}, diff: {diff:+d})")
        else:
            errors.append(f"Cannot verify lines: {filepath} missing")
    
    print(f"  → Total lines in key files: {total_lines}")
    print()
    
    # Test import
    print("Testing package import...")
    try:
        sys.path.insert(0, '.')
        from exception_theory import ETSovereign
        print("  ✅ ETSovereign imports successfully")
        
        # Count methods
        sovereign = ETSovereign()
        methods = [m for m in dir(sovereign) if not m.startswith('_')]
        print(f"  ✅ ETSovereign has {len(methods)} public methods (expected 101)")
        
        if len(methods) != 101:
            warnings.append(f"Method count mismatch: {len(methods)} vs expected 101")
        
        sovereign.close()
        
        # Test batch imports
        from exception_theory.classes.batch1 import TraverserEntropy
        from exception_theory.classes.batch2 import TeleologicalSorter
        from exception_theory.classes.batch3 import SwarmConsensus
        print("  ✅ All batch classes import successfully")
        
    except Exception as e:
        errors.append(f"Import test failed: {e}")
        print(f"  ❌ Import failed: {e}")
    
    print()
    
    # Summary
    print("=" * 70)
    print("VERIFICATION SUMMARY")
    print("=" * 70)
    
    if not errors and not warnings:
        print("✅ ALL CHECKS PASSED - Library structure is perfect!")
        print()
        print("The library is ready for:")
        print("  • Installation: pip install -e .")
        print("  • Distribution: python setup.py sdist bdist_wheel")
        print("  • Publishing: twine upload dist/*")
        return 0
    
    if errors:
        print(f"❌ {len(errors)} ERROR(S) FOUND:")
        for error in errors:
            print(f"  • {error}")
        print()
    
    if warnings:
        print(f"⚠️  {len(warnings)} WARNING(S):")
        for warning in warnings:
            print(f"  • {warning}")
        print()
    
    if not errors:
        print("✅ No critical errors - library should work")
        if warnings:
            print("⚠️  Warnings are informational only")
        return 0
    else:
        print("❌ Critical errors found - fix before using")
        return 1


if __name__ == "__main__":
    sys.exit(verify_structure())
