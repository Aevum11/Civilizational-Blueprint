"""
et_bridge/et_logger.py
ET32 Bridge — Structured Logger with ET Metrics

All log entries carry ET variance metadata.
V(E) = 0 in log entries means the operation completed as an Exception.
"""

import logging
import sys
import os
import time
from typing import Optional, Any, Dict
from .et_math import V_BASE, K, S


# Custom log levels mapped to ET states:
#   DEBUG   → Mediation ({D,T}) — traversal in progress
#   INFO    → Exception ({P,D,T}) — grounded completion
#   WARNING → approaching ∂I (V approaching K=2/3)
#   ERROR   → Incoherence boundary ({P,T})
#   CRITICAL → Incoherence collapse

ET_LEVEL_MAP = {
    "DEBUG":    logging.DEBUG,
    "INFO":     logging.INFO,
    "WARNING":  logging.WARNING,
    "ERROR":    logging.ERROR,
    "CRITICAL": logging.CRITICAL,
}


class ETLogFormatter(logging.Formatter):
    """
    Log formatter that includes ET variance in each record.
    Format: [timestamp] [LEVEL] [V=x.xxxx] [module] message
    """
    def format(self, record: logging.LogRecord) -> str:
        variance = getattr(record, "et_variance", 0.0)
        state    = getattr(record, "et_state", "")

        if variance == 0.0:
            vs = "E"        # Exception
        elif variance < V_BASE:
            vs = "M"        # near-Exception Mediation
        elif variance < K:
            vs = "D"        # Mediation
        elif variance < 1.0:
            vs = "∂I"       # near-Incoherence
        else:
            vs = "I"        # Incoherence

        state_str = f"[{vs}]" if not state else f"[{vs}:{state}]"

        ts = time.strftime("%H:%M:%S", time.localtime(record.created))
        ms = int((record.created % 1) * 1000)

        return (
            f"[{ts}.{ms:03d}] "
            f"[{record.levelname[:4]}] "
            f"{state_str} "
            f"[{record.name}] "
            f"{record.getMessage()}"
        )


def get_logger(name: str, level: str = "INFO", log_file: str = None) -> logging.Logger:
    """Create or retrieve an ET-structured logger."""
    logger = logging.getLogger(f"ET32Bridge.{name}")
    logger.setLevel(ET_LEVEL_MAP.get(level, logging.INFO))

    if not logger.handlers:
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(ETLogFormatter())
        logger.addHandler(handler)

        if log_file:
            fh = logging.FileHandler(log_file, encoding="utf-8")
            fh.setFormatter(ETLogFormatter())
            logger.addHandler(fh)

    return logger


class ETLog:
    """
    Convenience wrapper around the logger that automatically attaches ET metadata.
    """
    def __init__(self, name: str, level: str = "INFO", log_file: str = None):
        self._logger = get_logger(name, level, log_file)

    def _log(self, level: int, msg: str, variance: float = 0.0, state: str = ""):
        extra = {"et_variance": variance, "et_state": state}
        self._logger.log(level, msg, extra=extra)

    def exception_state(self, msg: str):
        """V=0, grounded Exception."""
        self._log(logging.INFO, msg, 0.0, "EXCEPTION")

    def mediation(self, msg: str, variance: float = None):
        """Active traversal, {D,T} state."""
        v = variance if variance is not None else V_BASE / 2
        self._log(logging.DEBUG, msg, v, "MEDIATION")

    def warning_di(self, msg: str):
        """Approaching Incoherence boundary."""
        self._log(logging.WARNING, msg, K, "∂I")

    def incoherence(self, msg: str):
        """Incoherent state — bridge failure."""
        self._log(logging.ERROR, msg, 1.0, "INCOHERENCE")

    def info(self, msg: str, variance: float = 0.0):
        self._log(logging.INFO, msg, variance)

    def debug(self, msg: str, variance: float = 0.0):
        self._log(logging.DEBUG, msg, variance)

    def error(self, msg: str, variance: float = 1.0):
        self._log(logging.ERROR, msg, variance)

    def critical(self, msg: str):
        self._log(logging.CRITICAL, msg, 1.0, "COLLAPSE")
