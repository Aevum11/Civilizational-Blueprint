"""
Test the deeper claim: EML's two inputs and the lattice's two axes 
both reflect the substrate's 2-dimensionality. Are they operationally
mappable in a clean way?

The substrate is (C\{0}, ×) = (R+, ×) × (U(1), ×), which is genuinely
2-dimensional: every nonzero complex z = r·e^(iθ) is (|z|, arg(z)).

EML eml(x, y) takes two scalar inputs.
Lattice projection takes one complex z (= two reals: |z|, θ).

Can we use BOTH inputs of EML simultaneously to encode BOTH axes
of the lattice? Test by building complex z from (x, y) inputs.
"""
import math, cmath
from math import gcd

# ============ The natural 2-input → 2-axis encoding ============
# If x encodes log(magnitude) and y encodes phase, then:
#   z = exp(x + i·y) = exp(x) · exp(i·y) = magnitude · e^(i·θ)
# This uses BOTH inputs simultaneously, mapping each to one axis.

def z_from_xy(x, y):
    """Build complex z from (x, y): x → real-axis (log-magnitude), y → imag-axis (phase)."""
    return cmath.exp(complex(x, y))

# This is NOT EML; it's the natural encoding the lattice expects.
# EML eml(x, y) = exp(x) - ln(y) does NOT produce this z directly.

# But: can we build z_from_xy USING EML operators?
# z = exp(x) · exp(i·y) = e^x · cos(y) + i·e^x·sin(y)
# We need exp, sin, cos — all of which the paper proves are EML-expressible.
# So YES: z_from_xy is EML-implementable, but as a COMPOUND tree of EML calls,
# not as a single eml(x, y) application.

# ============ The asymmetry between EML's inputs ============
# EML's two inputs are NOT symmetric: x feeds exp, y feeds ln.
# The lattice's two axes ARE symmetric in their projection formula
# (both use round(N·log₂)) but ASYMMETRIC in their PDT character
# (real = D, imaginary = T).
#
# Both systems have asymmetric two-fold structure.
# But the asymmetries are categorically different:
#   EML asymmetry:    operational (which branch the input feeds)
#   Lattice asymmetry: ontological (D vs T category)

# ============ Working two-axis projection via EML compound expressions ============
def project_complex_via_eml(x, y, N=12):
    """
    Project z = exp(x + i·y) onto the ET complex lattice.
    Builds z via compound EML operations (exp + Euler's formula).
    Then applies the standard projection on each axis.
    
    Inputs: x = log-magnitude, y = phase angle (radians)
    """
    # Build z using EML-expressible primitives: exp, cos, sin
    # (per paper Fig 1, all three are derivable from the EML chain)
    # For demonstration we use math.cos/math.sin directly; these have
    # canonical EML expressions per paper Table 4.
    magnitude = math.exp(x)            # exp_eml(x) — EML
    real_part = magnitude * math.cos(y)  # cos via Euler
    imag_part = magnitude * math.sin(y)  # sin via Euler
    z = complex(real_part, imag_part)
    
    # Now apply the standard ET complex projection
    r = abs(z)
    if r <= 0:
        return None
    theta = cmath.phase(z) % (2 * math.pi)
    
    # Real-axis projection (magnitude)
    log2_r = math.log2(r)               # EML-expressible (continuous D)
    exact_r = N * log2_r                # EML-expressible (×)
    k_r = round(exact_r)                # T's act (NOT EML)
    g_r = gcd(abs(k_r), N) if k_r != 0 else N  # discrete-D (NOT EML)
    d_r = N // g_r
    eps_r = (exact_r - k_r) * (1200.0 / N)
    
    # Imaginary-axis projection (phase)
    exact_t = N * theta / (2 * math.pi) # EML-expressible (×)
    k_t = round(exact_t) % N            # T's act (NOT EML)
    g_t = gcd(abs(k_t), N) if k_t != 0 else N  # discrete-D (NOT EML)
    d_t = N // g_t
    eps_t = (exact_t - round(exact_t)) * (1200.0 / N)
    
    # Combined sublattice (LCM amplification)
    d_combined = (d_r * d_t) // gcd(d_r, d_t)
    
    # D-T gradient
    alpha = math.atan2(k_t, k_r) if (k_r != 0 or k_t != 0) else 0.0
    
    return dict(
        x_input=x, y_input=y,
        z=z, r=r, theta=theta,
        k_r=k_r, d_r=d_r, eps_r=eps_r,
        k_theta=k_t, d_theta=d_t, eps_theta=eps_t,
        d_combined=d_combined,
        alpha_deg=math.degrees(alpha),
        D_fraction=math.cos(alpha)**2,
        T_fraction=math.sin(alpha)**2,
    )

# ============ Demonstration: 2-input → 2-axis projection ============
print("=" * 76)
print("TWO-INPUT → TWO-AXIS PROJECTION via EML compound expressions")
print("=" * 76)
print(f"\n{'(x, y) inputs':<22}  {'(k_r, d_r)':<12}  {'(k_θ, d_θ)':<12}  "
      f"{'d_comb':>6}  {'α (°)':>7}  reading")
print("-" * 92)

cases = [
    # (x, y, label) — x is log-magnitude, y is phase angle in radians
    (math.log(1.5), 0,             "(log 1.5, 0):   pure real, perfect 5th"),
    (math.log(2),   0,             "(log 2,   0):   pure real, octave"),
    (0,             math.pi/2,     "(0, π/2):       unit magnitude, 90° phase"),
    (0,             math.pi,       "(0, π):         unit magnitude, 180° (= -1)"),
    (math.log(2),   math.pi/3,     "(log 2, π/3):   doubled magn, 60° phase"),
    (math.log(1.5), math.pi/2,     "(log 1.5, π/2): perfect 5th magn, 90° phase"),
    (math.log(math.e), math.pi/4,  "(1, π/4):       e magnitude, 45° phase"),
]

for x, y, label in cases:
    p = project_complex_via_eml(x, y)
    if p:
        print(f"{label:<54}  ({p['k_r']:>+3},{p['d_r']:>2})   "
              f"({p['k_theta']:>+3},{p['d_theta']:>2})   "
              f"{p['d_combined']:>4}   {p['alpha_deg']:>+6.1f}")

print()
print("=" * 76)
print("FINDING:")
print("=" * 76)
print("""  Mike's intuition (one EML input per lattice axis) maps cleanly when
  read as:  x = log-magnitude → real axis;  y = phase → imaginary axis.
  
  This requires building z = exp(x + iy) via Euler's formula,
  which is an EML compound (exp, cos, sin all EML-expressible per Fig 1).
  
  Pure eml(x, y) = exp(x) - ln(y) does NOT give the (mag, phase) decomposition
  in one application — the operator combines them via subtraction, not via
  the polar product.  But COMPOUND EML trees give the polar form, and from
  there the standard 2-axis projection runs.
  
  The two-fold structure of EML and the two-fold structure of the lattice
  are both forced by dim(C\\{0}) = 2.  The arities match for the same
  structural reason; the operational mapping requires compound EML, not
  a single application.""")
