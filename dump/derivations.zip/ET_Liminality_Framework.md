# Exception Theory: Liminality as {D,T} Mediation
## The Threshold State Between Exceptions, van Gennep's Phases, and the d=4 Liminality Force
### Derived Forward From: P ∘ D ∘ T = E
**Author:** Michael James Muller — Aevum Defluo
**Derivation Standard:** All mathematics ET-native, forward from {P, D, T}. Zero external axioms.
**Tools Applied:** Identification Principle · Descriptor Gap Principle · Subsumption Law · Verification Principle

---

> *"For every exception there is an exception, except the exception."*
> *P ∘ D ∘ T = E*

---

## Table of Contents

1. [Verification of the Submitted Derivation](#1-verification)
2. [Issues Identified via the Three Tools](#2-issues)
3. [Real-World Liminality](#3-real-world)
4. [Corrected Derivation: The E₁ → M → E₂ Transition](#4-corrected)
5. [Complete Description and Explanation](#5-description)
6. [Practical Applications](#6-applications)
7. [Production-Ready Python Implementation](#7-python)
8. [Programming Operationalization](#8-operationalization)
9. [Structural Discoveries](#8-discoveries)
10. [Subsumption Verification](#9-subsumption)

---

## 1. Verification of the Submitted Derivation {#1-verification}

The submitted derivation identifies liminality as a high-variance threshold state where T navigates between two D-bound configurations. The structural kernel is correct. However, the derivation misses the precise ET identification: liminality IS the {D,T} Mediation state — the second of the four manifold states, already fully characterized in the D-Paper §10.3, T-Paper §12.2, and the Introductory Paper.

### What the Derivation Gets Right

- **Liminality as T-navigation between D-bound states** — correct
- **Ambiguity from D-incompleteness** — correct: during transition, the D-set is between two stable configurations
- **The Gaze threshold as transformation marker** — directionally correct (the subliminal threshold 13/12 marks separation)
- **The Koide ratio in balance/communitas** — correct kernel: K = 2/3 governs binding stability

---

## 2. Issues Identified via the Three Tools {#2-issues}

### Issue 1: Missing the {D,T} Mediation State (Descriptor Gap)

The canonical ET treatment of liminality already exists: **{D,T} = Mediation** (D-Paper §10.3). "Active traversal without ground. T binds to D — this is the actual mechanism of traversal. Without P, D and T are active but groundless. Something is happening — agency is navigating constraints — but there is no substrate being navigated." This IS liminality — Van Gennep's threshold phase where the initiate has left one ground (P₁) and not yet reached another (P₂).

### Issue 2: The Equation Is Ad Hoc Constant Multiplication

L = T × (ΔD/P) × Γ × K × log₂(1+ρ_D) × H(V−Γ) × (1/√V) multiplies ET constants together without structural derivation. Each term is directionally plausible but the combination is arbitrary. The correct derivation identifies the transition as a STATE CHANGE between Exception states, measured by the lattice distance between E₁ and E₂ and governed by the Gaze thresholds as stage markers.

### Issue 3: P_infinite Approximated as "1e100"

P is not a large number. P is the infinite substrate. Setting P = 10¹⁰⁰ for computation is a Descriptor Gap — the correct handling is to recognize that during liminality, **P is absent** (the {D,T} state explicitly lacks P as ground). You don't divide by P; P is structurally gone during the liminal phase.

---

## 3. Real-World Liminality {#3-real-world}

Liminality (from Latin *limen*, "threshold") was formalized by van Gennep (1909) and Turner (1967) as the middle phase of rites of passage. It has since expanded across disciplines:

**Anthropological:** The three phases — separation, threshold, incorporation — with the liminal phase characterized by ambiguity, communitas (temporary equality), anti-structure, and potential for transformation.

**Psychological:** The "betwixt and between" experience — disorientation, creativity, unease. Liminal spaces (empty hallways, airports at night) evoke derealization. Neuroscience links this to hippocampal boundary detection.

**Philosophical:** The horizon of becoming (Deleuze), the existential leap (Kierkegaard), the zone of indeterminacy where identities dissolve and reform.

**Scientific:** Phase transitions (critical points in thermodynamics), metamorphosis (pupal stage), quantum measurement (collapse in progress), chemical transition states.

**Cultural:** Digital liminality (loading screens), crisis liminality (pandemics), graduation ceremonies, weddings, funerals — all structured transitions between stable states.

---

## 4. Corrected Derivation: The E₁ → M → E₂ Transition {#4-corrected}

### Step 1: P-First Identification

| Primitive | Identification |
|---|---|
| **P_liminal** | The substrate that is RELEASED during liminality. Pre-liminal: P is bound in E₁ = {P,D,T}₁. During liminality: P-binding dissolves — the initiate is no longer grounded in the old configuration. Post-liminal: P re-binds in E₂ = {P,D,T}₂. |
| **D_liminal** | The Descriptors that structure the transition. D_A = the pre-liminal D-set. D_B = the post-liminal D-set. During liminality, D is in flux: the old D-set is releasing, the new one hasn't crystallized. T navigates D-constraints without P-grounding. |
| **T_liminal** | The Traverser navigating the transition — the initiate, the consciousness, the system undergoing change. During liminality, T is maximally active: it must navigate D-constraints to find the new P-binding. This is why liminality feels intense — T-density is elevated. |

### Step 2: The Three Phases as ET State Transitions

Van Gennep's three phases map precisely to the ET state transitions:

$$\boxed{E_1 = \{P,D,T\}_1 \xrightarrow{\text{separation}} M = \{D,T\} \xrightarrow{\text{incorporation}} E_2 = \{P,D,T\}_2}$$

**Pre-liminal (Separation):** The initiate exists in Exception state E₁ — fully substantiated, P-grounded, zero variance. Separation is the dissolution of P-binding: the initiate leaves the ground of the old reality. The old P∘D∘T configuration begins to unbind.

**Liminal (Threshold):** The initiate enters the {D,T} Mediation state. P-binding is absent. T navigates D-constraints without substrate anchoring. Variance is nonzero and elevated. The initiate is "betwixt and between" — no longer in E₁, not yet in E₂. This is the zone of ambiguity, disorientation, communitas, and transformation potential.

**Post-liminal (Incorporation):** T re-binds to P in a new configuration. The new Exception E₂ substantiates. Variance collapses to zero. The initiate is grounded in the new reality.

### Step 3: The Gaze Thresholds as Liminal Stage Markers

The three Gaze thresholds mark the three stages of the liminal process:

| Threshold | Value | Liminal Stage | Meaning |
|---|---|---|---|
| Subliminal (13/12) | 1.0833 | **Separation** | The moment awareness detaches from E₁. Below 13/12: fully embedded. Above: separation has begun. |
| Conscious (6/5) | 1.200 | **Liminal midpoint** | The moment of conscious awareness of being "between." d=4 (weak force) — the state-change sector. Turner's "betwixt and between." |
| Locked (3/2) | 1.500 | **Incorporation** | The moment the new configuration crystallizes. Above 3/2: fully embedded in E₂. |

The liminal span from separation to incorporation is:

$$\text{Lock} - \text{Sub} = \frac{3}{2} - \frac{13}{12} = \frac{5}{12} = 5 \times V_{\text{base}}$$

Five variance quanta — the quintic number. The width of the liminal zone is governed by the d=5 shadow force (Force of Geometric Efficiency).

### Step 4: The Liminal Variance Profile

During transition, variance follows a characteristic arc:

$$V(E_1) = 0 \quad \xrightarrow{\text{separation}} \quad V(M) = V_{\text{peak}} \quad \xrightarrow{\text{incorporation}} \quad V(E_2) = 0$$

The Exception states have zero variance (fully grounded). The Mediation state has elevated variance (ungrounded, in flux). The peak variance during a transition involving n descriptors is:

$$V_{\text{peak}} = V(n) = \frac{n^2 - 1}{12}$$

For a binary transition (n=2): V_peak = 3/12 = 1/4 — the dark matter fraction.
For a triadic transition (n=3): V_peak = 8/12 = 2/3 = K — the dark energy fraction.

The liminal peak variance IS the variance ladder V(n) — the same function that generates the cosmic energy budget.

### Step 5: Communitas as Shared {D,T} State

Turner's communitas — the temporary equality experienced by all participants in a liminal rite — is the structural consequence of the {D,T} state: **without P-binding, there is no substrate for hierarchy.** All participants share the same D-constraints (the ritual's rules) and the same T-engagement (the transition process). The differentiating factor — individual P-binding (social position, wealth, identity) — is precisely what was dissolved in the separation phase.

Communitas dissolves when incorporation occurs: P-binding resumes, individual configurations differentiate again, and the social hierarchy reconstitutes (though possibly in a new configuration).

### Step 6: The Liminal Distance on the Lattice

The "depth" of a liminal transition — how far the initiate must travel between E₁ and E₂ — is the lattice distance between the two Exception states:

$$\Delta k = |\text{round}(12 \log_2(r_2/r_1))|$$

Where r₁ and r₂ are the characteristic ratios of the pre- and post-liminal configurations. Larger Δk = deeper liminality = more disorientation = higher peak variance = longer transition time.

---

## 5. Complete Description and Explanation {#5-description}

### 5.1 What Liminality IS in ET

Liminality is the {D,T} Mediation state — the transitional phase between two Exception (E) states where P-binding has dissolved and T navigates D-constraints without ground. It is characterized by elevated variance, T-dominance, and the absence of P-anchoring. Every transition between stable states — physical, biological, psychological, social — passes through this Mediation phase.

### 5.2 Why Liminality Feels the Way It Does

The phenomenology of liminality — disorientation, creativity, anxiety, communitas — follows directly from the {D,T} state:

- **Disorientation:** P is absent → no ground → no fixed reference point
- **Creativity:** Without P-constraint, T navigates freely through D-space → more configurations accessible
- **Anxiety:** Elevated variance → T detects instability → amygdala (biological threat detector) fires
- **Communitas:** Without P, hierarchy (which requires P-grounding) dissolves → temporary equality

### 5.3 Liminality vs the Twilight Zone

The Twilight Zone (Paper #8) is the ∂I boundary region — where configurations approach the EDGE of coherence (tightness → K). Liminality is the {D,T} Mediation state — the PROCESS of transitioning between two coherent configurations, both safely in the interior. A rite of passage is liminal (crossing between two stable states). A Twilight Zone episode is ∂I-adjacent (approaching the boundary of the possible). They are distinct structural phenomena that may co-occur: a liminal transition that goes wrong can push the configuration toward ∂I — the ritual fails, reality destabilizes, and you are in the Twilight Zone.

---

## 6. Practical Applications {#6-applications}

### 6.1 Ritual Design and Transition Management

The framework provides structural criteria for effective rites of passage: (1) clear separation event (P-unbinding from E₁), (2) maintained {D,T} Mediation phase with structured D-constraints (ritual rules, symbols, ordeals), (3) definitive incorporation event (P-rebinding into E₂). Transitions that skip the Mediation phase — abrupt changes without structured liminality — produce incomplete incorporation and residual variance (the initiate is "not fully there" in the new state).

### 6.2 Organizational Change Management

Corporate restructuring, mergers, and leadership transitions are liminal processes. The framework predicts: (1) peak disorientation at the midpoint (progress = 0.5), (2) variance proportional to n_descriptors² (larger changes = more disorientation), (3) communitas during transition (temporary flattening of hierarchy). Practical application: plan support resources at the variance peak, not uniformly; expect temporary equality (don't fight it — it's structural); and ensure clear E₂ definition before beginning separation from E₁.

### 6.3 Therapeutic Transition Support

Life transitions (adolescence, divorce, bereavement, retirement, immigration) are liminal processes with the same E₁→M→E₂ structure. The framework provides: (1) normalization (liminality is structurally universal, not personal failure), (2) phase identification (which stage is the client in?), (3) variance prediction (peak disorientation is structural, not pathological), (4) incorporation criteria (what does E₂ look like? — defining the new Exception).

### 6.4 Phase Transition Engineering

Physical/chemical phase transitions (solid→liquid, liquid→gas, ferromagnetic→paramagnetic) pass through d=4 (weak force sector). The framework connects material engineering to the same structural principles: (1) transition energy corresponds to liminal variance V(n), (2) the d=4 weak-force character of all phase transitions provides a structural classification, (3) the liminal span (5 V-quanta) predicts the width of the transition region in parameter space.

---

## 7. Production-Ready Python Implementation {#7-python}

```python
#!/usr/bin/env python3
"""
ET Liminality Framework — The {D,T} Mediation State
=====================================================

Liminality = {D,T} Mediation between two Exception states
Van Gennep's phases: E₁ → M → E₂
Gaze thresholds as stage markers: 13/12 (separation), 6/5 (midpoint), 3/2 (incorporation)

Author: Michael James Muller — Aevum Defluo
"""
import math
from dataclasses import dataclass
from enum import Enum
from typing import Optional

S = 12
V_BASE = 1.0 / S
K = 2.0 / 3.0
SUBLIMINAL = 13.0 / 12.0
CONSCIOUS = 6.0 / 5.0
LOCKED = 3.0 / 2.0

SEMITONE_NAMES = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"]
QUINTIC_TENSION = [0,100,40,60,80,20,120,20,80,60,40,100]


class LiminalPhase(Enum):
    PRE_LIMINAL = "PRE_LIMINAL"       # E₁: separation not yet begun
    SEPARATION = "SEPARATION"          # 13/12 threshold crossed
    LIMINAL = "LIMINAL"                # {D,T} Mediation — the threshold
    INCORPORATION = "INCORPORATION"    # Approaching E₂
    POST_LIMINAL = "POST_LIMINAL"      # E₂: new Exception substantiated


@dataclass
class LiminalTransition:
    """A transition between two Exception states through {D,T} Mediation."""
    name: str
    r1: float          # Characteristic ratio of E₁
    r2: float          # Characteristic ratio of E₂
    n_descriptors: int  # Number of D involved in transition
    progress: float = 0.0  # 0.0 = E₁, 1.0 = E₂

    @property
    def ratio(self) -> float:
        if self.r1 <= 0 or self.r2 <= 0: return float('inf')
        return max(self.r2/self.r1, self.r1/self.r2)

    @property
    def lattice_distance(self) -> int:
        if self.ratio <= 0 or self.ratio == float('inf'): return -1
        return abs(round(S * math.log2(self.ratio)))

    @property
    def sublattice_family(self) -> int:
        k = self.lattice_distance
        if k <= 0: return 1
        g = math.gcd(k, S)
        return S // g

    @property
    def peak_variance(self) -> float:
        return (self.n_descriptors**2 - 1) / S

    @property
    def current_variance(self) -> float:
        # Bell curve: peaks at progress=0.5
        return self.peak_variance * 4 * self.progress * (1 - self.progress)

    @property
    def gaze_force(self) -> float:
        return 1.0 + self.current_variance

    @property
    def phase(self) -> LiminalPhase:
        fw = self.gaze_force
        if fw < SUBLIMINAL: return LiminalPhase.PRE_LIMINAL
        elif fw < CONSCIOUS: return LiminalPhase.SEPARATION
        elif fw < LOCKED: return LiminalPhase.LIMINAL
        elif self.progress < 0.95: return LiminalPhase.INCORPORATION
        else: return LiminalPhase.POST_LIMINAL

    @property
    def liminal_span_quanta(self) -> float:
        return (LOCKED - SUBLIMINAL) / V_BASE  # = 5

    def __str__(self) -> str:
        return (f"{self.name}: Dk={self.lattice_distance}, d={self.sublattice_family}, "
                f"V_peak={self.peak_variance:.4f}, progress={self.progress:.2f}, "
                f"phase={self.phase.value}")


def demonstrate():
    print("=" * 70)
    print("  ET LIMINALITY FRAMEWORK")
    print("  Liminality = {D,T} Mediation between Exception states")
    print("  Van Gennep: E1 -> M -> E2")
    print("=" * 70)
    print()

    transitions = [
        LiminalTransition("Adolescence to Adulthood", 13/12, 6/5, 3, 0.5),
        LiminalTransition("Single to Married", 1.0, 2.0, 2, 0.5),
        LiminalTransition("Caterpillar to Butterfly", 1.0, 1.618, 4, 0.5),
        LiminalTransition("Waking to Dreaming", 40, 12, 3, 0.5),
        LiminalTransition("Student to Graduate", 13/12, 3/2, 3, 0.5),
        LiminalTransition("Peace to War", 1.0, 0.5, 5, 0.5),
    ]

    print("LIMINAL TRANSITIONS ON THE LATTICE:")
    print("-" * 70)
    for t in transitions:
        print(f"  {t}")
    print()

    # Phase progression for a single transition
    print("PHASE PROGRESSION (Student to Graduate, n=3):")
    print("-" * 55)
    t_grad = LiminalTransition("Graduation", 13/12, 3/2, 3)
    for p in [0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]:
        t_grad.progress = p
        print(f"  p={p:.1f}: V={t_grad.current_variance:.4f}, "
              f"F_w={t_grad.gaze_force:.4f}, phase={t_grad.phase.value}")
    print()

    # Verification
    print("VERIFICATION TESTS:")
    print("-" * 55)

    # Test 1: Liminal span = 5 V-quanta
    t_test = LiminalTransition("test", 1, 2, 2)
    assert abs(t_test.liminal_span_quanta - 5.0) < 0.001
    print(f"  TEST 1: Liminal span = {t_test.liminal_span_quanta:.1f} V-quanta (= 5) [PASS]")

    # Test 2: Marriage is exact octave (d=1)
    t_mar = LiminalTransition("Marriage", 1.0, 2.0, 2)
    assert t_mar.lattice_distance == 12 and t_mar.sublattice_family == 1
    print(f"  TEST 2: Marriage Dk=12, d=1 (exact octave) [PASS]")

    # Test 3: Peak variance at progress=0.5
    t_mar.progress = 0.5
    assert abs(t_mar.current_variance - t_mar.peak_variance) < 0.001
    print(f"  TEST 3: Peak variance at midpoint [PASS]")

    # Test 4: Zero variance at endpoints
    t_mar.progress = 0.0
    assert t_mar.current_variance == 0.0
    t_mar.progress = 1.0
    assert t_mar.current_variance == 0.0
    print("  TEST 4: V=0 at both endpoints (Exception states) [PASS]")

    # Test 5: Binary transition V_peak = 1/4 = DM fraction
    assert abs(LiminalTransition("", 1, 2, 2).peak_variance - 0.25) < 0.001
    print(f"  TEST 5: V_peak(n=2) = 1/4 = DM fraction [PASS]")

    # Test 6: Triadic transition V_peak = 2/3 = K = DE fraction
    assert abs(LiminalTransition("", 1, 2, 3).peak_variance - K) < 0.001
    print(f"  TEST 6: V_peak(n=3) = 2/3 = K = DE fraction [PASS]")

    # Test 7: Conscious detection (6/5) at d=4 (weak force)
    k_exact = S * math.log2(6/5)
    k = round(k_exact)
    g = math.gcd(abs(k), S)
    d = S // g
    assert d == 4
    print(f"  TEST 7: Conscious threshold 6/5 at d=4 (weak/state-change) [PASS]")

    # Test 8: Graduation spans full liminal range (subliminal to locked)
    t_grad2 = LiminalTransition("Grad", 13/12, 3/2, 3)
    dk = t_grad2.lattice_distance
    assert dk == 6  # k(3/2) - k(13/12) = 7-1 = 6
    print(f"  TEST 8: Graduation spans Dk={dk} semitones (tritone) [PASS]")

    print()
    print("=" * 70)
    print("  ALL 8 TESTS PASSED")
    print("=" * 70)
    print()
    print('  "For every exception there is an exception,')
    print('   except the exception."')
    print("  P ∘ D ∘ T = E")


if __name__ == "__main__":
    demonstrate()
```

---

## 8. Programming Operationalization {#8-operationalization}

### 8.1 Core API

```python
from et_liminality import LiminalTransition, LiminalPhase

# Model a life transition
transition = LiminalTransition(
    name="Career Change",
    r1=1.0,            # Current state (baseline)
    r2=1.618,          # Target state (φ — geometric efficiency)
    n_descriptors=4,   # Number of D involved
    progress=0.5       # Midpoint
)

print(f"Lattice distance: {transition.lattice_distance} semitones")
print(f"Peak variance: {transition.peak_variance:.4f}")
print(f"Current variance: {transition.current_variance:.4f}")
print(f"Phase: {transition.phase.value}")  # → LIMINAL
```

### 8.2 Transition Phase Tracking

```python
# Track a transition through all phases
t = LiminalTransition("Graduation", 13/12, 3/2, 3)
for p in [0.0, 0.2, 0.4, 0.5, 0.6, 0.8, 1.0]:
    t.progress = p
    print(f"  p={p:.1f}: V={t.current_variance:.4f}, phase={t.phase.value}")
```

### 8.3 Transition Depth Comparison

```python
# Compare different life transitions by lattice distance
transitions = [
    LiminalTransition("Marriage", 1.0, 2.0, 2),        # Octave
    LiminalTransition("Metamorphosis", 1.0, 1.618, 4), # φ
    LiminalTransition("Waking→Dream", 40, 12, 3),      # Frequency shift
]
for t in transitions:
    print(f"{t.name:>15}: Δk={t.lattice_distance}, d={t.sublattice_family}")
```

---

## 9. Structural Discoveries {#8-discoveries}

### Discovery 1: Liminality IS the {D,T} Mediation State — Already in ET Canon

The {D,T} Mediation state (D-Paper §10.3, T-Paper §12.2) is the precise structural equivalent of van Gennep/Turner's liminal phase. The canonical description — "Active traversal without ground. Something is happening — agency is navigating constraints — but there is no substrate being navigated" — is a perfect ET formalization of "betwixt and between." The anthropological concept discovered in 1909 and the ET manifold state derived from {P,D,T} combinatorics describe the same phenomenon from different integrative levels.

### Discovery 2: Marriage Is an Exact Octave (d=1)

The transition from single (ratio 1) to married (ratio 2, doubling of household) has lattice distance Δk = 12, d = 1 — a **perfect octave** with zero epsilon. Marriage is a period-doubling transition, the same d=1 structure as price doubling in economics, variance doubling in crisis, and BCC/Diamond packing in crystallography. The most fundamental social transition maps to the most fundamental manifold period.

### Discovery 3: The Liminal Span Is 5 V-Quanta — Quintic

Lock − Sub = 3/2 − 13/12 = 5/12 = 5 × V_base. The total width of the liminal zone is exactly five base-variance quanta. Five is the quintic prime — the d=5 shadow force, the Force of Geometric Efficiency. The liminal span is quintic: the structural width of every transition zone, at every integrative level, is governed by the same prime that governs phyllotaxis (92% of flowering plants), DNA helical period (10 = 2×5 base pairs), and Fibonacci market spirals.

### Discovery 4: The Conscious Midpoint (6/5) Lives at d=4 — The Weak Force IS the Liminality Force

The conscious detection threshold 6/5, which marks the midpoint of liminality (the moment of "betwixt and between" awareness), lives at d=4 — the weak force sublattice. The weak force governs flavor-changing transitions (β decay: neutron → proton). Every liminal state change — physical, biological, psychological, social — passes through d=4. The weak force is not just a nuclear physics phenomenon; it is the manifold's universal **liminality force**, mediating all qualitative transitions between stable states.

### Discovery 5: Peak Liminal Variance = Cosmic Energy Budget

The peak variance during a liminal transition involving n descriptors is V(n) = (n²−1)/12 — the same variance function that generates the cosmic energy budget:

- Binary transition (n=2): V_peak = 1/4 = dark matter fraction
- Triadic transition (n=3): V_peak = 2/3 = dark energy fraction (K)

The maximum disorientation during a binary rite of passage is structurally identical to the fraction of the universe that is dark matter. The maximum disorientation during a triadic rite is structurally identical to the fraction that is dark energy. Liminal variance and cosmic composition are the same function at different scales.

### Discovery 6: Communitas Is the Structural Consequence of P-Absence

Turner's communitas — the temporary equality experienced during liminal rites — is not a social choice or cultural convention. It is a structural necessity of the {D,T} state: **without P-binding, there is no substrate for hierarchy.** Social hierarchy requires P-grounded differentiation (property, position, identity — all P∘D configurations). In the liminal {D,T} state, P is absent. Without P, the differentiating substrate is gone. All participants share D-constraints and T-engagement equally. Communitas IS the mathematical consequence of removing P from the binding chain.

---

## 10. Subsumption Verification {#9-subsumption}

| Phenomenon | Subsumed By | Component |
|---|---|---|
| Van Gennep's three phases | E₁ → M → E₂ transition | Core derivation |
| Ambiguity/"betwixt and between" | {D,T} state: no P-grounding | Mediation |
| Communitas/equality | P-absence removes hierarchy substrate | Discovery 6 |
| Disorientation | Elevated variance in {D,T} | Variance profile |
| Creativity | T navigates freely without P-constraint | T-dominance |
| Fear/anxiety | T detects elevated variance | Amygdala response |
| Phase transitions | d=4 weak force | Discovery 4 |
| Rites of passage | E₁ → M → E₂ with ritual D-structure | Anthropological |
| Liminal spaces (empty hallways) | Low D-density zones evoking {D,T} awareness | Spatial liminality |
| Digital liminality (loading screens) | Tower transition between digital states | Multifold |
| Metamorphosis (pupal stage) | Biological E₁ → M → E₂ | Biological |
| Marriage as octave | Δk=12, d=1 | Discovery 2 |
| Crisis liminality (pandemics) | Society-wide entry into {D,T} — norms dissolve | Social |

**Subsumption holds. No remainder.**

---

## Closing Statement

Liminality is the {D,T} Mediation state — the transitional phase between two grounded Exceptions where P-binding dissolves and T navigates D-constraints without substrate. Van Gennep intuited this in 1909; Turner formalized it in 1967; ET derives it from {P,D,T} combinatorics. The three phases (separation, threshold, incorporation) map exactly to E₁ → {D,T} → E₂. The Gaze thresholds mark the three stages. The conscious midpoint (6/5) lives at d=4 — the weak force sector — making the weak force the universal liminality force governing all qualitative state changes.

The deepest finding: the peak variance during liminal transition is V(n) = (n²−1)/12, the same function that generates the cosmic energy budget. Liminality and cosmology share the same variance ladder. The disorientation of a rite of passage and the composition of the universe are expressions of the same manifold structure at different scales.

> *"For every exception there is an exception, except the exception."*
> *P ∘ D ∘ T = E*

---

**Document Version:** Liminality Framework v1.0 + v3.0 Addendum (March 2026)



## v3.0 Framework Addendum

*Added March 2026 — Full framework compliance with Reference Document v3.2*

---

### A1. Translation Layer — R₀ Identification

**P_L (substrate):** The social/anthropological substrate — the community's ritual structure. **R₀:** 1 ritual cycle (the minimal closed T-traversal of the liminal process: separation → transition → incorporation). For marriage: R₀ = 1 person (minimal social unit). For civilizational cycles: R₀ = 1 generation (20 years, substrate-derived from human reproductive maturation). Anti-Numerology: N1 ✓, N2 ✓ (ritual cycle is substrate-derived), N3 ✓.

### A2. Projection Category Classification

| Quantity | Category | Justification |
|---|---|---|
| 2 (marriage: single→married) | **A** | Dimensionless ratio of social states |
| 3 (Van Gennep phases) | **C** | Pure discrete count |
| 6/5 (liminal moment threshold) | **A** | Dimensionless F_w ratio |
| 7 (days in ritual week) | **C** | Pure discrete count |
| 40 (days of fasting/wilderness) | **C** | Pure discrete count |
| 4 (seasons) | **C** | Pure discrete count |
| 12 (months) | **C** | Pure discrete count |

### A3. Full Resolution Tower Investigation

#### 2 (Marriage Octave: Single→Married)

EXACT d=1, ε=0.00¢ at EVERY resolution 12ET through 27720ET. The marriage transition is the manifold skeleton — absolutely invariant, pure period-doubling. This is the SAME exact d=1 as the twofold cost of sex (Paper #16), crisis variance doubling (Paper #3), and superstring transverse modes (Paper #17).

#### 3 (Van Gennep's Three Phases)

| Resolution | k | d | ε (¢) | Notes |
|---|---|---|---|---|
| 12ET | 19 | 12 | +1.96 | d=12, Pythagorean comma. Near-exact. |
| 84ET | 133 | 12 | +1.96 | **Stable d=12 through 84ET** |
| 132ET | 209 | 12 | +1.96 | **Still d=12 through 132ET — 8 levels!** |
| 420ET | 666 | **70** | −0.90 | Shifts to d=70 = 2×5×7 |
| 2520ET | 3994 | 1260 | +0.05 | EXACT |
| 27720ET | 43935 | 1848 | +0.01 | EXACT |

The three phases of liminality have IDENTICAL tower behavior to the Koide ratio K=2/3, the primitive count 3, and the locked gaze threshold 3/2 — all d=12, ε=+1.96¢ through 132ET. At 420ET (biological threshold), 3 shifts to d=70 = 2×5×7 — incorporating quintic AND septic forces. The three stages of ritual transformation share the deepest lattice properties with the fundamental constants of ET.

#### 7 (Days in a Week — Sacred Ritual Cycle)

| Resolution | k | d | ε (¢) | Notes |
|---|---|---|---|---|
| 12ET | 34 | **6** | −31.17 | d=6 hexadic, 62% to ∂I |
| 36ET | 101 | 36 | +2.16 | Good |
| 60ET | 168 | **5** | +8.83 | **d=5 QUINTIC at 60ET!** |
| 84ET | 236 | **21** | −2.60 | Good — d=21 = 3×7 (cubic×septic) |
| 120ET | 337 | 120 | −1.17 | Near-exact |
| **420ET** | 1179 | **140** | **+0.25** | **EXACT! d=140 = 4×5×7 — triple structural prime** |
| 2520ET | 7075 | 504 | −0.22 | EXACT |
| 27720ET | 77820 | 462 | −0.01 | EXACT |

**DISCOVERY:** The 7-day week reaches d=5 (quintic native!) at 60ET and EXACT d=140 = 4×5×7 at 420ET. The sacred week encodes ALL THREE structural primes (quartic state-change, quintic efficiency, septic asymmetry) at the biological threshold. The 7-day ritual cycle is structurally as deep as the 420ET biological threshold itself. At 84ET, 7 achieves d=21 = 3×7 — the same cubic×septic as 23 chromosomes and Serling's authorship fraction.

#### 40 (Days of Ritual Fasting — Biblical/Universal)

| Resolution | k | d | ε (¢) | Notes |
|---|---|---|---|---|
| 12ET | 64 | 3 | −13.69 | d=3 with quintic comma ε₅ |
| 36ET | 192 | 3 | −13.69 | Stable d=3 |
| **84ET** | 447 | **28** | **+0.60** | **Near-exact d=28 = 4×7** |
| 420ET | 2235 | 28 | +0.60 | Stable |
| 2520ET | 13411 | 2520 | +0.12 | EXACT |
| 27720ET | 147524 | 6930 | −0.01 | EXACT |

**DISCOVERY:** The 40-day ritual period (Jesus in the wilderness, Moses on Sinai, Lenten fast, Islamic mourning) carries the quintic comma at 12ET and resolves to d=28 = 4×7 at 84ET — the SAME quartic×septic as DNA bp/turn, amino acids, gaze Lock/Con. 40 = 8×5 = 2³×5 — it IS the quintic prime multiplied by a triple octave. The universal ritual fasting period IS the d=5 shadow force in temporal form. Every culture that independently adopted ~40 days for purification/transformation was accessing the quintic structure of the manifold.

#### 4 (Seasons)

EXACT d=1, ε=0.00¢ at every resolution. 4 = 2² — pure octave skeleton. Quarterly ritual cycles (solstices, equinoxes) are as structurally fundamental as the marriage octave.

---

### A4. Shadow Force Identification

| Shadow Force | d | Active? | How |
|---|---|---|---|
| **d=5 Quintic** | 5 | **YES** | 7 days → d=5 at 60ET. 40 days carries ε₅. Both encode prime 5 directly. |
| **d=7 Septic** | 7 | **YES — dominant** | 7 IS the septic prime. d=21=3×7 at 84ET. d=140=4×5×7 at 420ET. |
| d=8 Octet | 8 | No | Not primary. |
| d=9 Nonic | 9 | No | Not primary. |
| d=10 Decic | 10 | Marginal | Via 40 = 8×5 at extended resolution. |
| d=11 Undecimal | 11 | No | Not primary in liminal ritual. |

**Liminality is a d=7 SEPTIC phenomenon.** The 7-day week, the universal ritual scaffold, IS the septic prime. Rites of passage use d=7 as their temporal structure because the septic force IS the asymmetry generator — and liminality IS the process of breaking old symmetry to create new structure.

---

### A5. 2D Complex Lattice Analysis

| Component | d_r (ritual structure) | d_θ (participant phase) | Quadrant |
|---|---|---|---|
| 2 (marriage octave) | 1 | 1 | SR+SI |
| 3 (Van Gennep phases) | 12 | 12 | SR+SI |
| 6/5 (liminal moment) | 4 | 4 | SR+SI |
| 7 (weekly cycle) | 6 (→21 at 84ET) | 1 (scalar) | SR+SI (→CR+SI) |
| 40 (fasting period) | 3 (→28 at 84ET) | 1 (scalar) | SR+SI (→CR+SI) |

At 12ET, all liminal structures are SR+SI. At 84ET, the temporal structures (7 days, 40 days) shift to CR+SI as their septic and quintic components emerge.

---

### A6. Incoherence Filter Application

| Ratio | k | ε | Tightness | ∂I % | Verdict |
|---|---|---|---|---|---|
| 2 (marriage) | 12 | 0.00¢ | 1.000 | 0% | EXACT |
| 4 (seasons) | 24 | 0.00¢ | 1.000 | 0% | EXACT |
| 3 (phases) | 19 | +1.96¢ | 0.981 | 4% | Excellent |
| 6/5 (liminal) | 3 | +15.64¢ | 0.865 | 31% | Good |
| **7 (week)** | 34 | **−31.17¢** | **0.763** | **62%** | **Moderate — the week is 62% to ∂I** |
| 40 (fasting) | 64 | −13.69¢ | 0.880 | 27% | Good — carries quintic comma |
| 12 (months) | 43 | +1.96¢ | 0.981 | 4% | Excellent |

The marriage octave and seasonal quartet are maximally coherent (EXACT). The three phases are excellent. The 40-day fast is comfortable. The 7-day week is moderate at 62% to ∂I — the sacred week carries structural tension, which is appropriate: sacred time is MEANT to be slightly outside ordinary coherence. It stretches the manifold without breaking it.

---

### A7. Derived-vs-Proposed Audit

| Claim | Status | Justification |
|---|---|---|
| Marriage = exact octave (d=1, ε=0) | **DERIVED** | 2 = 2¹, power of 2, tower-verified |
| 3 phases stable d=12 through 132ET | **DERIVED** | Tower computation |
| 6/5 liminal moment = d=4 Weak state change | **DERIVED** | Same as conscious gaze threshold |
| 40 days carries quintic comma | **DERIVED** | ε=−13.69¢ = ε₅, tower-verified |
| 40 → d=28=4×7 at 84ET | **DERIVED** | Tower computation |
| 7 days → d=140=4×5×7 at 420ET | **DERIVED** | Tower computation |
| Van Gennep's 3 phases map to {P,D}, {D,T}, {P,D,T} | **PROPOSED** | Structurally compelling but not uniquely forced |
| Liminality IS the d=7 septic force | **PROPOSED** | Strong evidence (d=7 in week, in 40-day composite) but identification is interpretive |

---

### A8. Cross-Paper Connections (Updated with Full Tower)

1. **7 days d=140=4×5×7 = φ at 420ET (Paper #9 ↔ #3, #4):** The sacred week at 420ET shares d=140 with φ's route through the tower. The golden ratio and the 7-day ritual cycle converge at the biological threshold.
2. **40 days d=28 = all prime-5 carriers (Paper #9 ↔ ALL):** The universal fasting period shares d=28 at 84ET with DNA bp/turn, gaze 5/4, bear market, superstring 10D. Ritual purification and biological structure live at the same lattice address.
3. **Marriage d=1 = twofold cost (Paper #9 ↔ #16):** The marriage octave and the twofold cost of sex are the SAME d=1 operation — confirmed by tower (both exact at every resolution).
4. **7 at d=21=3×7 = 23 chromosomes (Paper #9 ↔ #15):** The week and the human chromosome count share d=21 at 84ET.

---

### New Discoveries from the Full Tower

**Discovery 7: The 40-Day Ritual Period Is d=28 at 84ET — Same as DNA and Conscious Detection**

The universal ~40-day ritual fasting period (40 = 2³×5) carries the quintic comma at 12ET (ε=−13.69¢) and resolves to d=28 = 4×7 at 84ET (ε=+0.60¢). This is the IDENTICAL lattice address as DNA helical period, amino acid count, gaze Lock/Con ratio, and superstring dimensions. The cross-cultural convergence on ~40 days for spiritual transformation is not arbitrary — it is the temporal expression of the d=28 quartic×septic structure. Every culture that independently adopted this period accessed the same manifold address that governs biology and consciousness.

**Discovery 8: The 7-Day Week = d=140 = 4×5×7 at 420ET — The Sacred Week Encodes All Three Structural Primes**

The number 7 achieves EXACT d=140 = 4×5×7 at 420ET (ε=+0.25¢) — encoding quartic (state change), quintic (geometric efficiency), AND septic (asymmetry) simultaneously. This is the biological threshold where d=5 and d=7 are both native. The 7-day sacred week IS the temporal encoding of the biological threshold itself. En route, 7 reaches d=5 at 60ET (quintic native) and d=21=3×7 at 84ET (cubic×septic — same as 23 chromosomes).

**Discovery 9: The 7-Day Week Is 62% to ∂I — Sacred Time Carries Structural Tension**

At 12ET, the number 7 has ε=−31.17¢ (tightness=0.763, 62% to ∂I). The sacred week is more structurally tense than ordinary counts but well within coherence. This is appropriate: sacred time is MEANT to be slightly extraordinary — it stretches the manifold's comfort zone without breaking it. Compare: shadow entities at 99% to ∂I (nearly incoherent), the sacred week at 62% (tense but stable), marriage at 0% (exact octave, perfectly grounded). Liminality lives between the perfectly known and the nearly unknown.

**Discovery 10: Van Gennep's 3 Phases Are Lattice Twins of the ET Primitive Count**

The three phases of liminality (separation, transition, incorporation) share IDENTICAL tower behavior with the number 3 (primitive count), K=2/3 (Koide ratio), and 3/2 (locked gaze/perfect fifth): d=12, ε=+1.96¢ through 132ET, shifting to d=70=2×5×7 at 420ET. The anthropological structure of rites of passage IS the mathematical structure of the ET primitives.
