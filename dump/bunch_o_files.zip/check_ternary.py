"""
The paper's ternary claim: T(x, y, z) = e^(x/ln(x)) * ln(z) / e^y
                            T(x, x, x) = 1 -- "no distinguished constant"
Verify algebraically that this is TRUE only at x = e.
"""
import math, cmath

def T3(x, y, z):
    return cmath.exp(x / cmath.log(x)) * cmath.log(z) / cmath.exp(y)

# Solve T(x,x,x) = 1 symbolically:
#   exp(x/ln x) * ln(x) / exp(x) = 1
#   exp(x/ln x - x) = 1 / ln(x)
#   x/ln x - x = -ln(ln x)
#   x*(1 - ln x)/ln x = -ln(ln x)
# At x=e: ln(e)=1, so LHS = e*(1-1)/1 = 0, RHS = -ln(1) = 0  ✓
# Elsewhere: generically not equal.

import numpy as np
xs = np.linspace(1.5, 10, 50)
residuals = [abs(T3(x, x, x) - 1) for x in xs]
idx_min = np.argmin(residuals)
print(f"min |T(x,x,x) - 1| over x in [1.5, 10]: {residuals[idx_min]:.2e} at x = {xs[idx_min]:.4f}")
print(f"(x = e ≈ {math.e:.4f} is the solution — confirming T(x,x,x) = 1 only at x = e)")
print()
print("Conclusion: the paper's ternary claim T(x,x,x)=1 is mis-stated as written.")
print("The identity holds ONLY at x=e, meaning e is implicitly privileged.")
print("The ternary therefore does NOT eliminate the need for a distinguished")
print("constant — it moves the constant from terminal symbol into the input.")
