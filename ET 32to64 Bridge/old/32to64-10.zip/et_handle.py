"""
et_bridge/et_handle.py
ET32 Bridge — Handle Table: 32-bit ↔ 64-bit Address Mapping

Derived from P ∘ D ∘ T = E.

The Handle Table is the core Descriptor bridge between P_32 (the 32-bit
address space) and P_full (the infinite substrate). It is a bijective mapping:

    h: ADDR₆₄ → HANDLE₃₂    (D-projection, lossy only for addr ≥ 4GB)
    h⁻¹: HANDLE₃₂ → ADDR₆₄  (D-expansion, perfect via table)

This resolves the Descriptor Gap:
    gap(P₃₂) = {addr | addr > 0xFFFFFFFF}
    D_bridge = handle_table   (the new Descriptor that closes the gap)

Subsumption check:
    Complete(handle_table) ↔ ∀ addr₆₄ ∈ P_full: ∃ handle ∈ P_32 s.t. h(addr₆₄) = handle
    This is satisfied by the bijection. Every 64-bit address gets exactly one handle.

ET Constants applied:
    SLOT_STRIDE  = S = 12       (one stride per lattice position)
    Max handles  ≈ 178M         ((HANDLE_MAX - HANDLE_BASE) / S)
    Initial pool = S² = 144     (first queue depth — manifold symmetry²)
    Resize at    = K × capacity (Koide threshold: resize when 2/3 full)
"""

import threading
import mmap
import struct
import os
import ctypes
from typing import Dict, Optional, Tuple, List

from et_math import (
    S, K, V_BASE,
    HANDLE_BASE, HANDLE_MAX, ADDR64_BASE,
    ETHandleMath, CmdFamily, ETMetrics, DIGITAL_ACTION_QUANTUM
)


class HandleEntry:
    """
    A single entry in the handle table.

    Each entry is a complete P∘D binding:
      P = the 64-bit address (substrate location in P_full)
      D = metadata describing the allocation (size, type, flags)
      T-status = whether this entry has been traversed (accessed) at least once

    Untraversed entries are {P,D} Unsubstantiated.
    Traversed entries are {P,D,T} — Exception state.
    """
    __slots__ = (
        "handle", "addr64", "size", "flags", "family",
        "accessed", "ref_count", "tag"
    )

    def __init__(
        self,
        handle: int,
        addr64: int,
        size: int,
        flags: int,
        family: int,
        tag: str = ""
    ):
        self.handle    = handle     # 32-bit proxy handle
        self.addr64    = addr64     # real 64-bit address
        self.size      = size       # allocated size
        self.flags     = flags      # VirtualAlloc-style flags
        self.family    = family     # CmdFamily lattice position
        self.accessed  = False      # T-traversal status
        self.ref_count = 1          # reference count
        self.tag       = tag        # optional debug tag

    def variance(self) -> float:
        """
        V(entry) = 0 if entry is fully substantiated (addr64 valid, ref_count > 0).
        V(entry) = V_BASE if accessed == False (unsubstantiated {P,D}).
        """
        if self.ref_count <= 0 or self.addr64 == 0:
            return 1.0  # incoherent
        if not self.accessed:
            return V_BASE  # {P,D} unsubstantiated
        return 0.0  # {P,D,T} = Exception


class HandleTable:
    """
    Thread-safe bijective mapping between 32-bit bridge handles and 64-bit addresses.

    Layout in memory: each slot is 32 bytes (aligned on ET manifold boundaries):
      addr64   : uint64  [8]
      size     : uint64  [8]
      flags    : uint32  [4]
      family   : uint8   [1]
      accessed : uint8   [1]
      ref_count: uint16  [2]
      handle   : uint32  [4]
      _padding : uint32  [4]
    Total: 32 bytes = S × 8/3 bytes (ET-derived: S/V_BASE / 4)

    The table lives in a shared memory region so both the 32-bit helper process
    and the 64-bit host can access it directly.
    """

    ENTRY_STRUCT = struct.Struct("<QQIBBHIxx")  # 32 bytes, see layout above
    ENTRY_SIZE   = ENTRY_STRUCT.size             # must be 32

    # Shared memory layout:
    # [0..3]   magic   : uint32 = 0x45543332 ("ET32")
    # [4..7]   version : uint32 = 1
    # [8..11]  count   : uint32 = number of live handles
    # [12..15] capacity: uint32 = max handles in this slab
    # [16..47] reserved: padding to 48-byte header (= PDT_HEADER_SIZE)
    SHMEM_HDR_SIZE = 48
    SHMEM_MAGIC    = 0x45543332  # "ET32"
    SHMEM_VERSION  = 1

    def __init__(self, initial_capacity: int = None):
        """
        Initialise the handle table.
        initial_capacity defaults to S² = 144 (manifold symmetry squared).
        """
        self._lock     = threading.RLock()
        self._capacity = initial_capacity if initial_capacity is not None else S * S
        self._entries: Dict[int, HandleEntry] = {}
        self._free_slots: List[int] = list(range(self._capacity))
        self._next_slot  = 0
        self._metrics    = ETMetrics()

        # Validate ENTRY_SIZE
        assert self.ENTRY_SIZE == 32, f"Entry size must be 32, got {self.ENTRY_SIZE}"

    # ------------------------------------------------------------------
    # Core handle allocation / deallocation
    # ------------------------------------------------------------------

    def alloc(
        self,
        addr64: int,
        size: int,
        flags: int = 0,
        family: int = CmdFamily.MEMORY_BASIC,
        tag: str = ""
    ) -> int:
        """
        Allocate a bridge handle for the given 64-bit address.
        Returns the 32-bit proxy handle, or 0 on failure.

        If addr64 < 4GB, returns addr64 directly (no bridge needed — identity mapping).
        If addr64 >= 4GB, allocates a new slot and returns the bridge handle.

        ET derivation:
          Low addresses: π₃₂(addr64) = addr64 (lossless, V=0)
          High addresses: π₃₂(addr64) = HANDLE_BASE + slot × SLOT_STRIDE (bridge proxy)
        """
        if addr64 == 0:
            return 0  # NULL passthrough

        # Identity for low addresses
        if addr64 < ADDR64_BASE:
            return addr64 & 0xFFFFFFFF

        with self._lock:
            # Check if this addr64 already has a handle (dedup)
            for entry in self._entries.values():
                if entry.addr64 == addr64:
                    entry.ref_count += 1
                    return entry.handle

            # Allocate new slot
            if not self._free_slots:
                self._expand()

            if not self._free_slots:
                return 0  # out of handles — unlikely given S²=144 initial capacity

            slot = self._free_slots.pop(0)
            handle = ETHandleMath.slot_to_handle(slot)

            # Guard: ensure handle is in bridge range
            if not ETHandleMath.is_bridge_handle(handle):
                self._free_slots.insert(0, slot)
                return 0

            entry = HandleEntry(handle, addr64, size, flags, family, tag)
            self._entries[handle] = entry
            return handle

    def dealloc(self, handle: int) -> bool:
        """
        Free a bridge handle. Returns True if successfully freed.
        For non-bridge handles (passthrough), always returns True.
        """
        if not ETHandleMath.is_bridge_handle(handle):
            return True  # passthrough — not managed by bridge

        with self._lock:
            entry = self._entries.get(handle)
            if entry is None:
                return False

            entry.ref_count -= 1
            if entry.ref_count <= 0:
                slot = ETHandleMath.handle_to_slot(handle)
                del self._entries[handle]
                self._free_slots.append(slot)
            return True

    def get(self, handle: int) -> Optional[HandleEntry]:
        """
        Look up the entry for a handle. Marks entry as accessed (T-traversal).
        Returns None if handle is not managed by bridge.
        """
        if not ETHandleMath.is_bridge_handle(handle):
            return None  # passthrough

        with self._lock:
            entry = self._entries.get(handle)
            if entry is not None:
                entry.accessed = True  # T-traversal: {P,D} → {P,D,T}
            return entry

    def expand_address(self, handle: int) -> int:
        """
        Expand a handle to its 64-bit address.
        Returns 0 if handle is invalid.
        For passthrough handles (< HANDLE_BASE), returns handle unchanged.
        """
        if not ETHandleMath.is_bridge_handle(handle):
            return handle  # direct 32-bit address passthrough

        entry = self.get(handle)
        if entry is None:
            return 0
        return entry.addr64

    def project_address(self, addr64: int) -> int:
        """
        Project a 64-bit address to a 32-bit handle.
        For low addresses: identity.
        For high addresses: looks up existing handle or allocates new one.
        """
        if addr64 < ADDR64_BASE:
            return addr64 & 0xFFFFFFFF

        with self._lock:
            # Find existing
            for entry in self._entries.values():
                if entry.addr64 == addr64:
                    return entry.handle
        # Allocate new
        return self.alloc(addr64, 0, 0, CmdFamily.MEMORY_BASIC)

    # ------------------------------------------------------------------
    # Batch operations
    # ------------------------------------------------------------------

    def alloc_range(
        self,
        base64: int,
        size: int,
        chunk_size: int = None,
        family: int = CmdFamily.MEMORY_BASIC,
    ) -> List[int]:
        """
        Allocate handles for a large 64-bit address range.
        The range [base64, base64+size) is chunked into slices.
        chunk_size defaults to DIGITAL_ACTION_QUANTUM × S = 49152 bytes.

        This is used for large memory-mapped files and VRAM allocations.
        Returns list of handles, one per chunk.
        """
        chunk_size = chunk_size or (DIGITAL_ACTION_QUANTUM * S)
        handles = []
        offset = 0
        while offset < size:
            chunk_end  = min(offset + chunk_size, size)
            chunk_len  = chunk_end - offset
            addr_chunk = base64 + offset
            h = self.alloc(addr_chunk, chunk_len, 0, family, f"chunk@{offset:#x}")
            handles.append(h)
            offset += chunk_len
        return handles

    # ------------------------------------------------------------------
    # Statistics and diagnostics
    # ------------------------------------------------------------------

    def live_count(self) -> int:
        with self._lock:
            return len(self._entries)

    def capacity(self) -> int:
        return self._capacity

    def fill_ratio(self) -> float:
        """Fill ratio. K-threshold: at K=2/3, table is expanded."""
        with self._lock:
            return len(self._entries) / max(1, self._capacity)

    def total_bytes_managed(self) -> int:
        with self._lock:
            return sum(e.size for e in self._entries.values())

    def variance(self) -> float:
        """
        V(table) = fraction of unsubstantiated entries (not yet accessed).
        V = 0 → all entries are fully traversed (Exception state).
        V = 1 → all entries are unsubstantiated ({P,D} state).
        """
        with self._lock:
            if not self._entries:
                return 0.0
            unaccessed = sum(1 for e in self._entries.values() if not e.accessed)
            return unaccessed / len(self._entries)

    def dump(self) -> List[Dict]:
        """Diagnostic dump of all live handles."""
        with self._lock:
            result = []
            for h, entry in sorted(self._entries.items()):
                lattice_pos = ETHandleMath.handle_lattice_position(h)
                result.append({
                    "handle":    f"0x{h:08X}",
                    "addr64":    f"0x{entry.addr64:016X}",
                    "size":      entry.size,
                    "family":    entry.family,
                    "lattice_d": lattice_pos,
                    "accessed":  entry.accessed,
                    "ref_count": entry.ref_count,
                    "tag":       entry.tag,
                    "variance":  entry.variance(),
                })
            return result

    # ------------------------------------------------------------------
    # Shared memory serialisation (for cross-process access by 32-bit helper)
    # ------------------------------------------------------------------

    def serialise_to_shmem(self, buf: bytearray) -> int:
        """
        Write handle table to shared memory buffer.
        Returns bytes written (including header).
        Format: SHMEM_HDR_SIZE header + N × ENTRY_SIZE entries.
        """
        with self._lock:
            entries = list(self._entries.values())
            required = self.SHMEM_HDR_SIZE + len(entries) * self.ENTRY_SIZE
            if len(buf) < required:
                return 0

            # Header
            struct.pack_into("<IIII", buf, 0,
                self.SHMEM_MAGIC, self.SHMEM_VERSION, len(entries), self._capacity)
            # Padding bytes 16..47 left as zero

            # Entries
            offset = self.SHMEM_HDR_SIZE
            for entry in entries:
                self.ENTRY_STRUCT.pack_into(
                    buf, offset,
                    entry.addr64, entry.size, entry.flags,
                    entry.family, int(entry.accessed),
                    min(entry.ref_count, 0xFFFF), entry.handle
                )
                offset += self.ENTRY_SIZE

            return offset

    def deserialise_from_shmem(self, buf: bytes) -> bool:
        """
        Load handle table from shared memory buffer.
        Returns True on success.
        """
        if len(buf) < self.SHMEM_HDR_SIZE:
            return False

        magic, version, count, capacity = struct.unpack_from("<IIII", buf, 0)
        if magic != self.SHMEM_MAGIC or version != self.SHMEM_VERSION:
            return False

        required = self.SHMEM_HDR_SIZE + count * self.ENTRY_SIZE
        if len(buf) < required:
            return False

        with self._lock:
            self._entries.clear()
            self._free_slots.clear()
            self._capacity = capacity

            offset = self.SHMEM_HDR_SIZE
            for _ in range(count):
                addr64, size, flags, family, accessed_byte, ref_count, handle = \
                    self.ENTRY_STRUCT.unpack_from(buf, offset)
                offset += self.ENTRY_SIZE

                entry = HandleEntry(handle, addr64, size, flags, family)
                entry.accessed  = bool(accessed_byte)
                entry.ref_count = ref_count
                self._entries[handle] = entry

            # Rebuild free slots
            allocated_slots = {ETHandleMath.handle_to_slot(h) for h in self._entries}
            self._free_slots = [s for s in range(capacity) if s not in allocated_slots]

        return True

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    def _expand(self):
        """
        Expand the handle table capacity.
        Expansion factor = S (manifold symmetry): multiply capacity by S/K = 18.
        ET derivation: new_capacity = old_capacity × (S / K) = old × 18
        (growing by the ratio S/K ensures the new size remains at the Koide threshold
        of the next ET lattice level).
        """
        expansion = int(S / K)  # = 18
        old_capacity = self._capacity
        self._capacity = old_capacity * expansion
        new_slots = list(range(old_capacity, self._capacity))
        self._free_slots.extend(new_slots)

    def register_native64(self, pid: int, exe_name: str = "") -> None:
        with self._lock:
            if not hasattr(self, '_native64_pids'):
                self._native64_pids: dict = {}
            self._native64_pids[pid] = exe_name

    def deregister_native64(self, pid: int) -> None:
        with self._lock:
            if hasattr(self, '_native64_pids'):
                self._native64_pids.pop(pid, None)

    def is_native64(self, pid: int) -> bool:
        with self._lock:
            return hasattr(self, '_native64_pids') and pid in self._native64_pids

    def native64_pids(self) -> list:
        with self._lock:
            if not hasattr(self, '_native64_pids'):
                return []
            return list(self._native64_pids.keys())
