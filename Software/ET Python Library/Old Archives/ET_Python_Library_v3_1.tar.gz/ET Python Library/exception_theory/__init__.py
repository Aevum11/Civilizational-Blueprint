"""
Exception Theory - A Comprehensive Mathematical Framework

Exception Theory is a complete ontological framework built on three fundamental primitives:
- P (Point): The substrate of existence
- D (Descriptor): Constraints and properties
- T (Traverser): Agency and navigation

These combine to form: PDT = EIM = S
(Point-Descriptor-Traverser = Exception-Incoherence-Mediation = Something)

From: "For every exception there is an exception, except the exception."

Author: Derived from M.J.M.'s Exception Theory
Version: 3.1.0

Batch Structure:
- Batch 1: Computational Exception Theory (The Code of Reality)
- Batch 2: Advanced Manifold Architectures (Code of the Impossible)
- Batch 3: Distributed Consciousness (The Code of Connection)
- Batch 4: Quantum Mechanics Foundations (The Code of the Atom)
- Batch 5: Electromagnetism (The Code of Forces)
- Batch 6: Hydrogen Atom Core (The Code of Matter)
- Batch 7: Spectroscopy (The Code of Light)
- Batch 8: Fine Structure & Corrections (The Code of Precision)
"""

__version__ = "3.1.0"
__author__ = "M.J.M. (Exception Theory) / ET Development Team (Implementation)"
__license__ = "MIT"

# Core imports
from .core import (
    # Mathematics
    ETMathV2,
    ETMathV2Quantum,
    
    # Primitives
    PrimitiveType,
    Point,
    Descriptor,
    Traverser,
    Exception as ETException,
    bind_pdt,
    create_point,
    create_descriptor,
    create_traverser,
    
    # Constants (all exposed from core.constants)
    BASE_VARIANCE,
    MANIFOLD_SYMMETRY,
    KOIDE_RATIO,
    VERSION,
    
    # Quantum/EM Constants (v3.1)
    PLANCK_CONSTANT_HBAR,
    PLANCK_CONSTANT_H,
    ELEMENTARY_CHARGE,
    FINE_STRUCTURE_CONSTANT,
    BOHR_RADIUS,
    RYDBERG_ENERGY,
    RYDBERG_CONSTANT,
    SPEED_OF_LIGHT,
    ELECTRON_MASS,
    PROTON_MASS,
)

# Class imports (all batches)
from .classes import (
    # Batch 1: Computational Exception Theory
    TraverserEntropy,
    TrinaryState,
    ChameleonObject,
    TraverserMonitor,
    RealityGrounding,
    TemporalCoherenceFilter,
    EvolutionarySolver,
    PNumber,
    
    # Batch 2: Advanced Manifold Architectures
    TeleologicalSorter,
    ProbabilisticManifold,
    HolographicValidator,
    ZeroKnowledgeProtocol,
    ContentAddressableStorage,
    ReactivePoint,
    GhostSwitch,
    UniversalAdapter,
    
    # Batch 3: Distributed Consciousness
    SwarmConsensus,
    PrecognitiveCache,
    ImmortalSupervisor,
    SemanticManifold,
    VarianceLimiter,
    ProofOfTraversal,
    EphemeralVault,
    ConsistentHashingRing,
    TimeTraveler,
    FractalReality,
    
    # Batch 4: Quantum Mechanics Foundations
    QuantumState,
    UncertaintyAnalyzer,
    OperatorAlgebra,
    CoulombPotential,
    HydrogenEnergyCalculator,
    BohrRadiusCalculator,
    FineStructureCalculator,
    RydbergWavelengthCalculator,
    WavefunctionNormalizer,
    QuantumMeasurement,
    
    # Batch 5: Electromagnetism
    CoulombForceCalculator,
    ElectricPotentialField,
    ElectricFieldCalculator,
    MagneticFieldCalculator,
    LorentzForceCalculator,
    EMEnergyCalculator,
    FineStructureConstant,
    VacuumImpedance,
    CoulombConstantCalculator,
    MagneticConstantCalculator,
    
    # Batch 6: Hydrogen Atom Core
    ReducedMassCalculator,
    HydrogenEnergyLevels,
    BohrRadiusSystem,
    HydrogenHamiltonian,
    RadialWavefunction,
    SphericalHarmonicCalculator,
    HydrogenWavefunction,
    OrbitalAngularMomentumCalculator,
    TotalAngularMomentumCoupling,
    QuantumNumberValidator,
    
    # Batch 7: Spectroscopy
    RydbergSeriesCalculator,
    TransitionCalculator,
    WavelengthCalculator,
    FrequencyCalculator,
    LymanSeries,
    BalmerSeries,
    PaschenSeries,
    SelectionRules,
    OscillatorStrength,
    SpectralLineIntensity,
    
    # Batch 8: Fine Structure & Corrections
    SpinOrbitCoupling,
    RelativisticCorrection,
    FineStructureShift,
    LambShiftCalculator,
    HyperfineSplitting,
    Hydrogen21cmLine,
    AngularMomentumCoupler,
    ZeemanEffect,
    StarkEffect,
    IsotopeShift,
)

# Engine import
from .engine import ETSovereign

# Utilities
from .utils import (
    ETBeaconField,
    ETContainerTraverser,
    get_logger,
    set_log_level,
    enable_debug,
    enable_info,
    enable_warning,
    disable_logging,
)

__all__ = [
    # Version
    '__version__',
    '__author__',
    '__license__',
    
    # Core - Mathematics
    'ETMathV2',
    'ETMathV2Quantum',
    
    # Core - Primitives
    'PrimitiveType',
    'Point',
    'Descriptor',
    'Traverser',
    'ETException',
    'bind_pdt',
    'create_point',
    'create_descriptor',
    'create_traverser',
    
    # Core - Key Constants
    'BASE_VARIANCE',
    'MANIFOLD_SYMMETRY',
    'KOIDE_RATIO',
    'VERSION',
    
    # Core - Quantum/EM Constants (v3.1)
    'PLANCK_CONSTANT_HBAR',
    'PLANCK_CONSTANT_H',
    'ELEMENTARY_CHARGE',
    'FINE_STRUCTURE_CONSTANT',
    'BOHR_RADIUS',
    'RYDBERG_ENERGY',
    'RYDBERG_CONSTANT',
    'SPEED_OF_LIGHT',
    'ELECTRON_MASS',
    'PROTON_MASS',
    
    # Classes - Batch 1: Computational Exception Theory
    'TraverserEntropy',
    'TrinaryState',
    'ChameleonObject',
    'TraverserMonitor',
    'RealityGrounding',
    'TemporalCoherenceFilter',
    'EvolutionarySolver',
    'PNumber',
    
    # Classes - Batch 2: Manifold Architectures
    'TeleologicalSorter',
    'ProbabilisticManifold',
    'HolographicValidator',
    'ZeroKnowledgeProtocol',
    'ContentAddressableStorage',
    'ReactivePoint',
    'GhostSwitch',
    'UniversalAdapter',
    
    # Classes - Batch 3: Distributed Consciousness
    'SwarmConsensus',
    'PrecognitiveCache',
    'ImmortalSupervisor',
    'SemanticManifold',
    'VarianceLimiter',
    'ProofOfTraversal',
    'EphemeralVault',
    'ConsistentHashingRing',
    'TimeTraveler',
    'FractalReality',
    
    # Classes - Batch 4: Quantum Mechanics
    'QuantumState',
    'UncertaintyAnalyzer',
    'OperatorAlgebra',
    'CoulombPotential',
    'HydrogenEnergyCalculator',
    'BohrRadiusCalculator',
    'FineStructureCalculator',
    'RydbergWavelengthCalculator',
    'WavefunctionNormalizer',
    'QuantumMeasurement',
    
    # Classes - Batch 5: Electromagnetism
    'CoulombForceCalculator',
    'ElectricPotentialField',
    'ElectricFieldCalculator',
    'MagneticFieldCalculator',
    'LorentzForceCalculator',
    'EMEnergyCalculator',
    'FineStructureConstant',
    'VacuumImpedance',
    'CoulombConstantCalculator',
    'MagneticConstantCalculator',
    
    # Classes - Batch 6: Hydrogen Atom
    'ReducedMassCalculator',
    'HydrogenEnergyLevels',
    'BohrRadiusSystem',
    'HydrogenHamiltonian',
    'RadialWavefunction',
    'SphericalHarmonicCalculator',
    'HydrogenWavefunction',
    'OrbitalAngularMomentumCalculator',
    'TotalAngularMomentumCoupling',
    'QuantumNumberValidator',
    
    # Classes - Batch 7: Spectroscopy
    'RydbergSeriesCalculator',
    'TransitionCalculator',
    'WavelengthCalculator',
    'FrequencyCalculator',
    'LymanSeries',
    'BalmerSeries',
    'PaschenSeries',
    'SelectionRules',
    'OscillatorStrength',
    'SpectralLineIntensity',
    
    # Classes - Batch 8: Fine Structure
    'SpinOrbitCoupling',
    'RelativisticCorrection',
    'FineStructureShift',
    'LambShiftCalculator',
    'HyperfineSplitting',
    'Hydrogen21cmLine',
    'AngularMomentumCoupler',
    'ZeemanEffect',
    'StarkEffect',
    'IsotopeShift',
    
    # Engine
    'ETSovereign',
    
    # Utilities
    'ETBeaconField',
    'ETContainerTraverser',
    'get_logger',
    'set_log_level',
    'enable_debug',
    'enable_info',
    'enable_warning',
    'disable_logging',
]
