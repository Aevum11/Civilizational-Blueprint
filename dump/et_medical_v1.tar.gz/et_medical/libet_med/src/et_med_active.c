/* ============================================================================
 * et_med_active.c — Active-System Dynamics
 * ----------------------------------------------------------------------------
 *  Identification: a *living* system is not a static projection. It is an
 *  active trajectory through the lattice. At each step n the system has a
 *  state z_n = (real, imag), an epsilon residual, and a cascade depth (count
 *  of dI-boundary crossings).
 *
 *  Descriptor Gap: the tightness function t(eps) = 100/(100+|eps|) measures
 *  attractor proximity in [0, 1]. The dI boundary at |eps| = 50¢ is the
 *  bisecting locus between Mediation (active process) and Incoherence
 *  (active pathology) — same magnitude, different sign-dependent class.
 *
 *  Subsumption: the palindromic cascade applies to ANY generator-7 trajectory
 *  on the 12-fold lattice — Krebs cycle, weekly rhythms, gait phase, EEG
 *  cycles. The same theorem governs all of them.
 *
 *  Shimmer Psi_n is the per-step bilateral-D-folding interference. Its
 *  envelope grows with cascade depth — a chronic shimmer is the longitudinal
 *  signature of accumulated descriptor-gap.
 * ========================================================================= */
#include "libet_med.h"
#include "et_med_internal.h"

#include <math.h>
#include <string.h>

/* ----------------------------------------------------------------------------
 * Palindromic cascade
 *  PALINDROME = [12, 6, 4, 3, 12, 2, 12, 3, 4, 6, 12, 1] from generator g=7
 *  on the 12-fold lattice (Projection Guide §17). Proven via GCD complementary
 *  identity: d(7n mod 12) = 12/gcd(7n mod 12, 12), and the orbit of 7n mod 12
 *  visits all 12 cosets in the order 7, 2, 9, 4, 11, 6, 1, 8, 3, 10, 5, 0,
 *  giving the d-sequence directly.
 * ------------------------------------------------------------------------- */
static const int ET_PALINDROME[12] = {
    12, 6, 4, 3, 12, 2, 12, 3, 4, 6, 12, 1
};

LIBET_MED_API int et_palindrome_d(int n_mod_12) {
    /* Identification: this is a closed-form lookup, not a fit. */
    int n = n_mod_12 % 12;
    if (n < 0) n += 12;
    return ET_PALINDROME[n];
}

/* ----------------------------------------------------------------------------
 * Shimmer modulation
 *  Psi_n = sin(2*pi*n / N) * cos(2*pi*n / (2N))
 *  This is the Projection Guide §57 form: a bilateral-D-folding interference
 *  with octave-doubling envelope. The base period is N steps; the envelope
 *  modulates over 2N steps.
 * ------------------------------------------------------------------------- */
LIBET_MED_API double et_shimmer(int n) {
    static const double TWO_PI = 6.283185307179586476925286766559;
    /* Default reference is base-12 manifold; for other resolutions, the
     * caller scales n appropriately. */
    double phase_inner = TWO_PI * (double)n / 12.0;
    double phase_outer = TWO_PI * (double)n / 24.0;
    return sin(phase_inner) * cos(phase_outer);
}

/* ----------------------------------------------------------------------------
 * Active state init
 * ------------------------------------------------------------------------- */
LIBET_MED_API et_error_t et_active_state_init(et_active_state_t* state, int N) {
    if (state == NULL) {
        _et_error(ET_ERR_INVALID_ARG, "et_active_state_init needs non-null state");
        return ET_ERR_INVALID_ARG;
    }
    et_error_t e = et_validate_N(N);
    if (e == ET_ERR_INVALID_N) return e;

    memset(state, 0, sizeof(*state));
    state->z_real         = 1.0;        /* baseline = unison */
    state->z_imag         = 0.0;        /* phase 0           */
    state->n              = 0;
    state->N              = N;
    state->history_len    = 0;
    state->history_head   = 0;
    state->cascade_depth  = 0;
    return ET_OK;
}

/* ----------------------------------------------------------------------------
 * Tightness — pure function of last |eps|.
 *  If no history, returns 1.0 (the system is on its attractor).
 * ------------------------------------------------------------------------- */
LIBET_MED_API double et_tightness(const et_active_state_t* state) {
    if (state == NULL) {
        _et_error(ET_ERR_INVALID_ARG, "et_tightness needs non-null state");
        return NAN;
    }
    if (state->history_len == 0) return 1.0;
    /* most recent eps is at (history_head - 1) mod 64 */
    int idx = (state->history_head - 1 + 64) % 64;
    double eps_abs = fabs(state->eps_history[idx]);
    return 100.0 / (100.0 + eps_abs);
}

/* ----------------------------------------------------------------------------
 * dI boundary detection. tol_cents default suggestion: 5.0.
 *  Tests proximity to the ET-derived boundary at |eps| = 50 * K_Koide = 100/3.
 * ------------------------------------------------------------------------- */
LIBET_MED_API int et_is_at_dI_boundary(const et_active_state_t* state, double tol_cents) {
    if (state == NULL) {
        _et_error(ET_ERR_INVALID_ARG, "et_is_at_dI_boundary needs non-null state");
        return 0;
    }
    if (state->history_len == 0) return 0;
    int idx = (state->history_head - 1 + 64) % 64;
    double eps_abs = fabs(state->eps_history[idx]);
    const double ET_DI_EVENT_CENTS = 50.0 * 2.0 / 3.0;   /* = 100/3 */
    return (fabs(eps_abs - ET_DI_EVENT_CENTS) <= tol_cents) ? 1 : 0;
}

/* ----------------------------------------------------------------------------
 * One step of the active-system iteration.
 *  next_r is the next observed ratio (e.g. next RR-interval / baseline).
 *  Updates: z_real = next_r, z_imag = shimmer envelope, n++,
 *           appends new eps to circular history,
 *           increments cascade_depth on every dI-boundary trespass.
 *
 *  Cascade ceiling: per Projection Guide §59, a stable trajectory tolerates
 *  up to 2N cumulative dI crossings before flagging chronic instability.
 *  At N=12 the ceiling is 24; at N=420 it is 840; at N=27720 it is 55440.
 * ------------------------------------------------------------------------- */
LIBET_MED_API et_error_t et_active_step(et_active_state_t* state, double next_r) {
    if (state == NULL) {
        _et_error(ET_ERR_INVALID_ARG, "et_active_step needs non-null state");
        return ET_ERR_INVALID_ARG;
    }
    if (!et_is_finite(next_r) || next_r <= 0.0) {
        _et_error(ET_ERR_INVALID_RATIO, "next_r must be > 0 and finite");
        return ET_ERR_INVALID_RATIO;
    }

    /* Project the new ratio. */
    et_projection_t proj;
    et_error_t e = et_project_real(next_r, state->N, &proj);
    if (e != ET_OK) return e;

    /* Append eps to circular buffer. */
    state->eps_history[state->history_head] = proj.eps_cents;
    state->history_head = (state->history_head + 1) % 64;
    if (state->history_len < 64) state->history_len += 1;

    /* dI crossing test BEFORE updating state — compare last and current.
     *
     * Identification: the ∂I boundary in the corpus is defined as the locus
     * where the tightness function t = 100/(100+|eps|) equals the Koide
     * ratio K = 2/3 — i.e. |eps| = 50¢ exactly. But mathematically the
     * banker-rounded projection bounds |eps| <= 50¢; values ABOVE 50¢ cannot
     * be reached (past pos = k+0.5 the rounding flips to k+1 and eps
     * re-enters the (-50, 50] range on the other side).
     *
     * The event-detection threshold is therefore the Koide-derived value
     * INSIDE the half-octave: |eps|_crossing = 50 * K_Koide = 50 * 2/3
     * = 100/3 ≈ 33.333¢. This is where the trajectory has progressed K of
     * the way from the attractor to the asymptote — the Descriptor-Gap
     * Principle locus between "in the attractor basin" (|eps| < 50K) and
     * "approaching the boundary" (|eps| >= 50K). Derived, not tuned. */
    static const double ET_DI_EVENT_CENTS = 50.0 * 2.0 / 3.0;   /* 100/3 */
    if (state->history_len >= 2) {
        int idx_prev = (state->history_head - 2 + 64) % 64;
        int idx_curr = (state->history_head - 1 + 64) % 64;
        double e_prev = state->eps_history[idx_prev];
        double e_curr = state->eps_history[idx_curr];
        int prev_in  = fabs(e_prev) <  ET_DI_EVENT_CENTS;
        int curr_in  = fabs(e_curr) <  ET_DI_EVENT_CENTS;
        if (prev_in != curr_in) {
            state->cascade_depth += 1;
        }
    }

    state->z_real = next_r;
    state->z_imag = et_shimmer(state->n + 1);
    state->n += 1;

    /* Cascade ceiling check. */
    int ceiling = 2 * state->N;
    if (state->cascade_depth > ceiling) {
        _et_error(ET_ERR_CASCADE_STABILITY_EXCEEDED,
                  "cascade depth exceeded 2N stability ceiling");
        return ET_ERR_CASCADE_STABILITY_EXCEEDED;
    }

    return ET_OK;
}
