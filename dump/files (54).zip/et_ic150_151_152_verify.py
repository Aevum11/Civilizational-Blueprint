#!/usr/bin/env python3
"""
IC-150, IC-151, IC-152 Verification Suite
==========================================
Exception Theory — Michael James Muller — Exception Theory LLC
P ∘ D ∘ T = E

IC-150: Octave ε-Invariance — ε(r·2ⁿ) = ε(r) ∀ n ∈ ℤ
IC-151: Cascade ε-Antisymmetry — ε_n = −ε_{m'−n} ∀ prime m'
IC-152: Sub-Planckian Mirror Theorem — Π_N(1/r) = (−k, d, −ε)
"""
from mpmath import mp, mpf, log, nint, fabs, power
from math import gcd
from fractions import Fraction

mp.dps = 400

N = 12
LN2 = log(mpf(2))
TOL = mpf(10) ** (-390)

def proj(r):
    x = N * log(r) / LN2
    k = int(nint(x))
    d = N // (gcd(abs(k), N) if k else N)
    eps = (x - k) * 100
    return k, d, eps

passed = failed = total = 0

# ══════════════════════════════════════════════════════════════
# IC-150: Octave ε-Invariance
# ══════════════════════════════════════════════════════════════
print("=" * 60)
print("IC-150: ε(r·2ⁿ) = ε(r) ∀ n ∈ ℤ")
print("=" * 60)

for r in [mpf('3')/2, mpf('137')/mpf('100'), mpf('1836')/mpf('1000')]:
    k0, d0, e0 = proj(r)
    for n in [-10000, -1000, -7, -1, 0, 1, 5, 100, 1000, 10000]:
        r_shifted = r * power(mpf(2), n)
        k1, d1, e1 = proj(r_shifted)
        total += 1
        if fabs(e1 - e0) < TOL and d1 == d0:
            passed += 1
        else:
            failed += 1
            print(f"  FAIL: r={float(r):.3f}, n={n}")
        # Also verify k shifts by exactly nN
        if k1 != k0 + n * N:
            print(f"  FAIL k-shift: expected {k0 + n*N}, got {k1}")

print(f"  {passed}/{total} PASSED")

# Comma survival
r_deep = mpf(3)**7 / mpf(2)**20000
k_d, d_d, e_d = proj(r_deep)
k_f, d_f, e_f = proj(mpf(3)/2)
total += 1
if fabs(e_d - 7 * e_f) < TOL:
    passed += 1
    print(f"  Comma survival: ε(3⁷/2²⁰⁰⁰⁰) = {float(e_d):.4f}¢ = 7×{float(e_f):.4f}¢ PASS")
else:
    failed += 1

# ══════════════════════════════════════════════════════════════
# IC-151: Cascade ε-Antisymmetry
# ══════════════════════════════════════════════════════════════
print("\n" + "=" * 60)
print("IC-151: ε_n = −ε_{m'−n} ∀ prime m'")
print("=" * 60)

def fold(fr):
    fl = fr - Fraction(fr.numerator // fr.denominator)
    if fl > Fraction(1, 2): return (fl - 1) * 100
    if fl < Fraction(1, 2): return fl * 100
    return Fraction(50)

for mprime in [5, 7, 11, 13, 17, 19, 23]:
    fwd = [fold(Fraction(n, mprime)) for n in range(1, mprime)]
    ok = all(fwd[n-1] == -fwd[mprime-n-1] for n in range(1, mprime))
    total += 1
    if ok:
        passed += 1
        print(f"  m'={mprime}: ε_n = −ε_{{m'−n}} PASS (exact Fraction)")
    else:
        failed += 1
        print(f"  m'={mprime}: FAIL")

# ══════════════════════════════════════════════════════════════
# IC-152: Sub-Planckian Mirror Theorem
# ══════════════════════════════════════════════════════════════
print("\n" + "=" * 60)
print("IC-152: Π_N(1/r) = (−k, d, −ε)")
print("=" * 60)

# Mirror at multiple depths including extreme sub-Planckian
mirror_tests = [
    mpf(3) / 2,
    mpf(137) / mpf(100),
    mpf(3)**7 / mpf(2)**20000,
    mpf(5)**3 / mpf(2)**777,
    mpf(7)**11 / mpf(2)**50000,
]

for r in mirror_tests:
    k1, d1, e1 = proj(r)
    k2, d2, e2 = proj(1 / r)
    total += 1
    if k2 == -k1 and d2 == d1 and fabs(e1 + e2) < TOL:
        passed += 1
        print(f"  r=...({k1}): (−k,d,−ε) = ({k2},{d2},{float(e2):.2f}¢) PASS")
    else:
        failed += 1
        print(f"  FAIL at k={k1}")

# Conjugate closure
for r in mirror_tests:
    k0, d0, e0 = proj(r * (1/r))
    total += 1
    if k0 == 0 and d0 == 1 and fabs(e0) < TOL:
        passed += 1
    else:
        failed += 1
        print(f"  Conjugate closure FAIL")

print(f"  Conjugate closure r·(1/r) → (0,1,0): {len(mirror_tests)}/{len(mirror_tests)} PASS")

# Lossless round-trip at extreme depth
def tw(v): return mp.nstr(v, 200)
r_extreme = mpf(3)**7 / mpf(2)**20000
k_e, d_e, e_e = proj(r_extreme)
r_rec = mpf(2) ** ((mpf(k_e) + e_e * mpf(N) / mpf(1200)) / mpf(N))
total += 1
if tw(r_rec) == tw(r_extreme):
    passed += 1
    print(f"  Lossless round-trip at k={k_e} (20,000 octaves below Planck): PASS")
else:
    failed += 1

print("\n" + "=" * 60)
print(f"TOTAL: {passed}/{total} PASSED")
if failed == 0:
    print("ALL TESTS PASSED — residual is zero")
else:
    print(f"FAILURES: {failed}")
    import sys; sys.exit(1)
