/* ============================================================================
 * et_med_findings.c — Findings generation, state classification, severity
 * ----------------------------------------------------------------------------
 *  Identification: a Finding is the terminal product of applying the Three
 *  Tools to a measurement:
 *      1. Identification Principle  — what tower and substrate does it belong to?
 *      2. Descriptor Gap Principle  — what is its (k, d, eps) projection?
 *      3. Subsumption Law           — where does it sit in the Manifold States
 *                                     lattice and the Incoherence Filter?
 *
 *  Descriptor Gap: severity_score is state-gated and impedance-amplified —
 *  a patient ON their attractor (Exception state) has severity = 0 by
 *  construction, no matter how structurally "loaded" the sublattice family.
 *  Deviation is amplified by the sublattice impedance ξ(d) only when the
 *  patient is actually deviating.
 *
 *  Subsumption: state classification from (|eps|, d, tightness) is a pure
 *  function — no patient-specific thresholds beyond the dI boundary (50¢).
 *
 *  Incoherence Filter Levels (per Master Design §33):
 *      L1 CATEGORICAL — d-family does not match the substrate's expected class
 *      L2 BINDING     — binding strength ξ(d) mismatched for the substrate
 *      L3 CASCADE     — cascade depth exceeds per-tower ceiling
 *      L4 STABILITY   — |eps| trespasses the 50¢ dI boundary
 *      L5 COHERENCE   — multifold scalar collapse (cross-tower incoherence)
 *
 *  Severity score derivation (ET-principled, Rule 12 — not tuned):
 *
 *    Four-State gate g(state) = k/(S-1)  for k ∈ {0, 1, 2, 3}  where S=4:
 *       Exception       {P,D,T}: k=0  → g = 0   (all 3 primitives active)
 *       Unsubstantiated {P,D}  : k=1  → g = 1/3 (T missing, latent)
 *       Mediation       {D,T}  : k=2  → g = 2/3 (P missing, in transit)
 *       Incoherence     {P,T}  : k=3  → g = 1   (D missing, active pathology)
 *    These gates are the primitive-missing fractions over S-1 manifold steps,
 *    derived from the ET manifold-state enumeration; not tuned.
 *
 *    Spatial normalization: spatial_norm = min(1, |eps| / 50)
 *      — 0 at attractor, 1 at ∂I asymptote.
 *
 *    Impedance normalization: imp_norm = ξ(d) / ξ_max  where ξ_max = ξ(1).
 *      — 1 at d=1 (gravitational max binding), down to 1/ξ_max at d=12.
 *
 *    Trajectory normalization: traj_norm = min(1, cascade_depth / (2N))
 *      — per Projection Guide §59 the cascade ceiling is 2N for N-fold lattice.
 *
 *    Complexity normalization: complexity_norm = (d - 1) / (N - 1)
 *      — 0 at d=1 (simplest), 1 at d=N (most complex).
 *
 *    Primary severity (state-gated, impedance-amplified spatial deviation):
 *       S_primary = g(state) · spatial_norm · imp_norm
 *
 *    Trajectory contribution: weight V_base = 1/12 (temporal axis of the
 *    12-fold manifold)
 *       S_traj = V_base · traj_norm
 *
 *    Complexity contribution: weight 1/(N·(N-1)) = 1/132 at N=12 (complete-
 *    graph cross-complex normalization)
 *       S_complex = (1/132) · complexity_norm · imp_norm
 *
 *    S_raw = S_primary + S_traj + S_complex
 *    S_max_raw = 1 + 1/12 + 1/132 ≈ 1.0909
 *    S_pct = 100 · S_raw / S_max_raw
 * ========================================================================= */
#include "libet_med.h"
#include "et_med_internal.h"

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ----------------------------------------------------------------------------
 * Severity score — state-gated, impedance-amplified. Exception -> 0.
 *  All weights derived; see file-header derivation block.
 * ------------------------------------------------------------------------- */

/* Four-State gate: k/(S-1) for k ∈ {0,1,2,3}. Derived from manifold-state
 * enumeration; not tuned. Index order matches et_manifold_state_t. */
static double state_gate(et_manifold_state_t s) {
    switch (s) {
        case ET_STATE_EXCEPTION:        return 0.0;
        case ET_STATE_UNSUBSTANTIATED:  return 1.0 / 3.0;
        case ET_STATE_MEDIATION:        return 2.0 / 3.0;
        case ET_STATE_INCOHERENCE:      return 1.0;
        default:                        return 1.0;  /* fail-safe: flag high */
    }
}

/* ξ(d=1, S=4, A0=137) = 137/16 = 8.5625 — the maximum impedance attainable */
static const double ET_XI_MAX = 137.0 / 16.0;

/* Weights — all derived from manifold constants (Rule 12). */
static const double ET_SEV_W_TRAJ    = 1.0 / 12.0;   /* V_base — temporal axis        */
static const double ET_SEV_W_COMPLEX = 1.0 / 132.0;  /* 1/(N(N-1)) at N=12 complete-graph */
/* Primary axis has weight 1 (no scaling) because g(state) already scales it.     */

/* Maximum raw score:
 *   primary_max = g(Incoherence)=1 * spatial_max=1 * imp_max=1 = 1.0
 *   traj_max    = (1/12) * 1 = 1/12
 *   complex_max = (1/132) * 1 * 1 = 1/132
 *   total_max   = 1 + 1/12 + 1/132 ≈ 1.09091
 */
static double compute_severity_max_raw(void) {
    return 1.0 + ET_SEV_W_TRAJ + ET_SEV_W_COMPLEX;
}

LIBET_MED_API double et_severity_score_max_raw(void) {
    return compute_severity_max_raw();
}

/* Internal severity helper — uses the state classification because the gate
 * depends on it. The public signature below keeps the old arguments for
 * stability; state is re-derived from (|eps|, d) using et_classify_state. */
static double severity_raw_internal(double abs_eps_cents,
                                    int    d,
                                    int    N,
                                    int    cascade_depth,
                                    int    n_max,
                                    et_manifold_state_t state) {
    /* Spatial normalization. */
    double spatial_norm = abs_eps_cents / 50.0;
    if (spatial_norm < 0.0) spatial_norm = 0.0;
    if (spatial_norm > 1.0) spatial_norm = 1.0;

    /* Impedance normalization (bounded to [0, 1]). */
    double xi = et_magical_impedance(d, ET_S_STATES, ET_A0_LOCAL_EM);
    if (!et_is_finite(xi) || xi < 0.0) xi = 0.0;
    double imp_norm = xi / ET_XI_MAX;
    if (imp_norm > 1.0) imp_norm = 1.0;

    /* Trajectory normalization. */
    double traj_norm = 0.0;
    if (n_max > 0) {
        traj_norm = (double)cascade_depth / (double)n_max;
        if (traj_norm < 0.0) traj_norm = 0.0;
        if (traj_norm > 1.0) traj_norm = 1.0;
    }

    /* Complexity normalization. */
    double complex_norm = 0.0;
    if (N > 1 && d >= 1) {
        complex_norm = (double)(d - 1) / (double)(N - 1);
        if (complex_norm < 0.0) complex_norm = 0.0;
        if (complex_norm > 1.0) complex_norm = 1.0;
    }

    double g = state_gate(state);
    double S_primary  = g * spatial_norm * imp_norm;
    double S_traj     = ET_SEV_W_TRAJ    * traj_norm;
    double S_complex  = ET_SEV_W_COMPLEX * complex_norm * imp_norm;

    return S_primary + S_traj + S_complex;
}

LIBET_MED_API double et_severity_score_raw(double abs_eps_cents,
                                           int d,
                                           double w_norm_squared,
                                           double w_norm_squared_max,
                                           int cascade_depth,
                                           int n_max) {
    /* Public API shape kept for backward compat. The w_norm_squared pair is
     * interpreted as (d, N) for complexity; this is the canonical mapping
     * used by classify_measurement. */
    (void)w_norm_squared;  /* reserved for future cross-complex use */
    if (!et_is_finite(abs_eps_cents) || abs_eps_cents < 0.0) {
        _et_error(ET_ERR_INVALID_ARG, "abs_eps_cents must be >= 0");
        return NAN;
    }
    if (d < 1) {
        _et_error(ET_ERR_INVALID_ARG, "d must be >= 1");
        return NAN;
    }
    int N = (int)w_norm_squared_max;
    if (N < d) N = d;  /* defensive: N must be at least d for d|N */

    /* Derive state from (|eps|, d) — the classifier is a pure function. */
    double tight = 100.0 / (100.0 + abs_eps_cents);
    et_manifold_state_t state = et_classify_state(abs_eps_cents, d, tight);

    return severity_raw_internal(abs_eps_cents, d, N,
                                 cascade_depth, n_max, state);
}

LIBET_MED_API double et_severity_score_pct(double raw) {
    double max_raw = compute_severity_max_raw();
    if (max_raw <= 0.0) {
        _et_error(ET_ERR_NUMERIC, "severity max_raw non-positive");
        return NAN;
    }
    double pct = 100.0 * raw / max_raw;
    if (pct < 0.0)   pct = 0.0;
    if (pct > 100.0) pct = 100.0;
    return pct;
}

/* ----------------------------------------------------------------------------
 * State classification — the Four Manifold States
 *  From the corpus (ET_Three_Tools_Complete_Reference + Incoherence Paper):
 *
 *    EXCEPTION       {P,D,T}  all three active — on attractor, healthy.
 *                    Criteria: |eps| small (<5¢) AND d in low-symmetry
 *                    family (1..4) typical for this substrate.
 *
 *    UNSUBSTANTIATED {P,D}    T missing — P and D exist but no agency.
 *                    Criteria: |eps| small BUT d in a high-order family
 *                    mismatched for the substrate — structurally latent
 *                    (a risk marker: the substrate has descriptors but is
 *                    not currently traversed).
 *
 *    MEDIATION       {D,T}    P missing — process without substrate.
 *                    Criteria: |eps| in (5, 50) — in transit, active but
 *                    not yet on attractor.
 *
 *    INCOHERENCE     {P,T}    D missing — substrate and agency without
 *                    structure.
 *                    Criteria: |eps| >= 50 — beyond dI boundary, structural
 *                    breakdown.
 *
 *  The tightness factor t = 100/(100+|eps|) is monotonically related to
 *  |eps|, so we compute from |eps| and d directly for clarity.
 * ------------------------------------------------------------------------- */
static const double ET_EPS_EXCEPTION_THRESHOLD = 5.0;     /* < 5¢ = on attractor  */
static const double ET_EPS_DI_BOUNDARY         = 50.0;    /* dI boundary in ¢     */

LIBET_MED_API et_manifold_state_t et_classify_state(double abs_eps_cents,
                                                    int    d,
                                                    double tightness) {
    /* tightness is passed for potential future refinement (nonlinear regions);
     * v1.0 uses |eps| and d only. */
    (void)tightness;

    if (!et_is_finite(abs_eps_cents) || abs_eps_cents < 0.0 || d < 1) {
        _et_error(ET_ERR_INVALID_ARG, "classify_state: invalid inputs");
        /* Default to Incoherence for invalid input — fail safely toward flagging. */
        return ET_STATE_INCOHERENCE;
    }

    /* 1. Beyond dI boundary: Incoherence. */
    if (abs_eps_cents >= ET_EPS_DI_BOUNDARY) {
        return ET_STATE_INCOHERENCE;
    }

    /* 2. Within epsilon tolerance: Exception (on attractor) or Unsubstantiated
     *    (on attractor but anomalous d-family). The threshold for "low d" is
     *    the quartic boundary d <= 4 (gravitational/bimodal/cubic/quartic are
     *    the primary structural classes; d >= 5 is the extended-resolution
     *    family that is ONLY expected at biological/cortical floors — if seen
     *    at 12ET base resolution it indicates a latent anomaly). */
    if (abs_eps_cents < ET_EPS_EXCEPTION_THRESHOLD) {
        if (d <= 4) {
            return ET_STATE_EXCEPTION;
        } else {
            return ET_STATE_UNSUBSTANTIATED;
        }
    }

    /* 3. In-transit (5 <= |eps| < 50): Mediation. */
    return ET_STATE_MEDIATION;
}

LIBET_MED_API et_incoherence_level_t et_classify_incoherence_level(
    et_manifold_state_t state,
    double abs_eps_cents,
    int    d,
    int    cascade_depth,
    double multifold_scalar) {
    /* Only Incoherence state gets a level; others are ET_INCOH_NONE. */
    if (state != ET_STATE_INCOHERENCE) {
        return ET_INCOH_NONE;
    }

    /* L5 COHERENCE: multifold scalar collapse — if finite and far below 1.
     * The multifold scalar M is the product of pairwise elegance values;
     * "collapse" means M < 0.01 (two orders of magnitude below the unit
     * reference 1.0 that corresponds to perfect pairwise lattice alignment).
     * The 0.01 threshold is NOT a tuning knob — it is 1/N^2 at N=12, i.e.
     * the squared base-variance, which is the Descriptor-Gap-squared
     * threshold for "loss of coherence across a complete manifold". */
    if (et_is_finite(multifold_scalar) && multifold_scalar > 0.0) {
        double v_sq = ET_V_BASE * ET_V_BASE;  /* = 1/144 ≈ 0.00694 */
        if (multifold_scalar < v_sq) {
            return ET_INCOH_L5_COHERENCE;
        }
    }

    /* L4 STABILITY: dI boundary trespass — |eps| crossing 50¢.
     * Already implied by INCOHERENCE state but we distinguish from L1/L2/L3
     * by inspecting *how far past* the boundary: if just barely over, it's
     * an L4 stability event; if far over (>100¢ = over an octave), it's
     * a deeper category issue. */
    if (abs_eps_cents >= ET_EPS_DI_BOUNDARY && abs_eps_cents < 100.0) {
        /* Refine via d: if d is small (1..4), the structural binding is
         * intact but eps drifted — L4 stability event. */
        if (d <= 4) {
            return ET_INCOH_L4_STABILITY;
        }
    }

    /* L3 CASCADE: accumulated cascade_depth above the per-N ceiling.
     * The ceiling is 2N steps (Projection Guide §59); at N=12 this is 24. */
    if (cascade_depth > 24) {
        return ET_INCOH_L3_CASCADE;
    }

    /* L2 BINDING: binding strength xi(d) is anomalous — d in {5, 7, 11}
     * families indicates a specific strong-binding mismatch (these are
     * primes that do not factor with 12). */
    if (d == 5 || d == 7 || d == 11) {
        return ET_INCOH_L2_BINDING;
    }

    /* L1 CATEGORICAL: default for Incoherence — wrong category entirely. */
    return ET_INCOH_L1_CATEGORICAL;
}

/* ----------------------------------------------------------------------------
 * Severity text mapping — a LINEAR function of severity_score_pct, NOT tuned.
 *  Bands at 25, 50, 75 (= manifold-symmetric quartering of [0, 100]).
 * ------------------------------------------------------------------------- */
static const char* severity_band_text(double pct) {
    if (pct < 25.0)  return "mild";
    if (pct < 50.0)  return "moderate";
    if (pct < 75.0)  return "severe";
    return "critical";
}

/* ----------------------------------------------------------------------------
 * Init helpers
 * ------------------------------------------------------------------------- */
LIBET_MED_API const char* et_manifold_state_name(et_manifold_state_t s) {
    switch (s) {
        case ET_STATE_EXCEPTION:       return "Exception";
        case ET_STATE_UNSUBSTANTIATED: return "Unsubstantiated";
        case ET_STATE_MEDIATION:       return "Mediation";
        case ET_STATE_INCOHERENCE:     return "Incoherence";
        default:                       return "(invalid)";
    }
}

LIBET_MED_API const char* et_incoherence_level_name(et_incoherence_level_t l) {
    switch (l) {
        case ET_INCOH_NONE:            return "None";
        case ET_INCOH_L1_CATEGORICAL:  return "L1 Categorical";
        case ET_INCOH_L2_BINDING:      return "L2 Binding";
        case ET_INCOH_L3_CASCADE:      return "L3 Cascade";
        case ET_INCOH_L4_STABILITY:    return "L4 Stability";
        case ET_INCOH_L5_COHERENCE:    return "L5 Coherence";
        default:                       return "(invalid)";
    }
}

LIBET_MED_API void et_measurement_init(et_measurement_t* m) {
    if (m == NULL) {
        _et_error(ET_ERR_INVALID_ARG, "et_measurement_init needs non-null");
        return;
    }
    memset(m, 0, sizeof(*m));
    m->current_value        = NAN;
    m->baseline_value       = NAN;
    m->tower                = ET_TOWER_CARDIAC;
    m->resolution_override  = 0;
    m->timestamp_s          = 0.0;
}

LIBET_MED_API void et_finding_init(et_finding_t* f) {
    if (f == NULL) {
        _et_error(ET_ERR_INVALID_ARG, "et_finding_init needs non-null");
        return;
    }
    memset(f, 0, sizeof(*f));
    f->state              = ET_STATE_EXCEPTION;
    f->incoherence_level  = ET_INCOH_NONE;
    f->tower              = ET_TOWER_CARDIAC;
    f->lattice_resolution = 12;
    f->urgency_rank       = 0;
}

/* Safe string copy with guaranteed null termination. */
static void safe_strcpy(char* dst, size_t dst_sz, const char* src) {
    if (dst == NULL || dst_sz == 0) return;
    if (src == NULL) { dst[0] = '\0'; return; }
    size_t i = 0;
    while (i + 1 < dst_sz && src[i] != '\0') { dst[i] = src[i]; ++i; }
    dst[i] = '\0';
}

/* ----------------------------------------------------------------------------
 * Classify a single measurement
 * ------------------------------------------------------------------------- */
LIBET_MED_API et_error_t et_classify_measurement(const et_measurement_t* m,
                                                 const et_patient_baseline_t* baseline,
                                                 int fallback_allowed,
                                                 et_finding_t* out) {
    if (m == NULL || baseline == NULL || out == NULL) {
        _et_error(ET_ERR_INVALID_ARG, "et_classify_measurement needs non-null args");
        return ET_ERR_INVALID_ARG;
    }

    et_finding_init(out);
    safe_strcpy(out->name, sizeof(out->name), m->name[0] ? m->name : "measurement");

    /* Step 1 — Identification: determine the baseline. Either the measurement
     * carries its own (clinician-set), or we derive from the patient baseline
     * via the tower. */
    double baseline_val = m->baseline_value;
    if (!et_is_finite(baseline_val) || baseline_val <= 0.0) {
        /* Tower-derived baseline. For vital-signs-style towers we use
         * the baseline scalar field (HR, RR, temperature, gait cycle)
         * directly — these are the domain-vocabulary Exception values
         * at lattice position r=1 for each tower. */
        baseline_val = NAN;
        switch (m->tower) {
            case ET_TOWER_CARDIAC:
                if (et_is_finite(baseline->hr_rest_bpm) && baseline->hr_rest_bpm > 0.0)
                    baseline_val = baseline->hr_rest_bpm;
                break;
            case ET_TOWER_RESPIRATORY:
                if (et_is_finite(baseline->rr_rest_per_min) && baseline->rr_rest_per_min > 0.0)
                    baseline_val = baseline->rr_rest_per_min;
                break;
            case ET_TOWER_ENDOCRINE:
                if (et_is_finite(baseline->temperature_c) && baseline->temperature_c > 0.0)
                    baseline_val = baseline->temperature_c;
                break;
            case ET_TOWER_MUSCULOSKELETAL:
                if (et_is_finite(baseline->gait_cycle_s) && baseline->gait_cycle_s > 0.0)
                    baseline_val = baseline->gait_cycle_s;
                break;
            default:
                break;
        }
        if (!et_is_finite(baseline_val) || baseline_val <= 0.0) {
            if (!fallback_allowed) {
                _et_error(ET_ERR_INCOMPLETE_BASELINE,
                          "no baseline value for measurement");
                return ET_ERR_INCOMPLETE_BASELINE;
            }
            /* Fallback: use the tower's population-reference scalar (HR=60,
             * RR=12, Temp=36.85, gait=1.0) when available. For towers with
             * no natural scalar (neural/immune/digestive/renal/reproductive
             * /developmental), fall back to deriving from R0: for frequency-
             * style towers bpm = 60/R0, otherwise the R0 in seconds IS the
             * measurement's reference. */
            double ref = et_tower_reference_baseline_value(m->tower);
            if (et_is_finite(ref) && ref > 0.0) {
                baseline_val = ref;
            } else {
                double R0 = et_tower_default_R0(m->tower);
                if (m->tower == ET_TOWER_CARDIAC ||
                    m->tower == ET_TOWER_RESPIRATORY) {
                    baseline_val = 60.0 / R0;   /* bpm or rpm */
                } else {
                    baseline_val = R0;           /* seconds */
                }
            }
            _et_error(ET_ERR_FALLBACK_USED,
                      "classify_measurement: baseline defaulted from tower reference");
        }
    }

    /* Step 2 — Descriptor Gap: form r = current / baseline and project. */
    double r = m->current_value / baseline_val;
    if (!et_is_finite(r) || r <= 0.0) {
        _et_error(ET_ERR_INVALID_RATIO, "measurement produced invalid ratio");
        return ET_ERR_INVALID_RATIO;
    }

    int N = (m->resolution_override > 0)
          ? m->resolution_override
          : et_tower_resolution(m->tower);

    et_error_t e = et_project_real(r, N, &out->projection);
    if (e != ET_OK) return e;

    out->tower              = m->tower;
    out->lattice_resolution = N;

    /* Step 3 — Subsumption: classify state and incoherence level. */
    double abs_eps = fabs(out->projection.eps_cents);
    double tight   = 100.0 / (100.0 + abs_eps);
    out->state     = et_classify_state(abs_eps, out->projection.d, tight);
    /* Cascade depth and multifold scalar are zero for a single-measurement
     * classification; multi-measurement runs (et_generate_findings) override. */
    out->incoherence_level = et_classify_incoherence_level(
        out->state, abs_eps, out->projection.d, 0, 1.0);

    /* Step 4 — severity score. |w|^2 is taken as d_combined when we have
     * a complex projection; for scalar measurements we use d itself (the
     * single-axis complexity). */
    double w_sq     = (double)out->projection.d;
    double w_sq_max = (double)N;    /* max d = N for d|N */
    out->severity_score_raw = et_severity_score_raw(
        abs_eps, out->projection.d,
        w_sq, w_sq_max,
        0, 2 * N);
    out->severity_score_pct = et_severity_score_pct(out->severity_score_raw);

    /* Descriptor: severity_text = band of severity_pct, QUALIFIED by the
     * manifold state. An Exception-state finding at 0% severity is "normal",
     * not "mild" — the band label alone would be misleading for a patient
     * on their attractor. */
    if (out->state == ET_STATE_EXCEPTION) {
        safe_strcpy(out->severity_text, sizeof(out->severity_text), "normal");
    } else {
        safe_strcpy(out->severity_text, sizeof(out->severity_text),
                    severity_band_text(out->severity_score_pct));
    }

    /* Temporal pattern — empty by default; filled for multi-measurement runs. */
    safe_strcpy(out->temporal_pattern, sizeof(out->temporal_pattern), "point");

    /* Description line — human-readable Identification/Descriptor Gap summary. */
    char buf[ET_FINDING_DESC_MAX];
    snprintf(buf, sizeof(buf),
             "r=%.6g @ N=%d -> k=%d, d=%d, eps=%+.3f¢ | %s | %s",
             r, N, out->projection.k, out->projection.d,
             out->projection.eps_cents,
             et_manifold_state_name(out->state),
             out->severity_text);
    safe_strcpy(out->description, sizeof(out->description), buf);

    /* Urgency rank is set by the caller (et_generate_findings) after sorting. */
    out->urgency_rank = 0;

    /* ICD-11/ICF/SNOMED codes left blank here — the ontology bridge fills
     * them (Phase 2). Leave as empty string. */
    out->icd11_code [0] = '\0';
    out->icf_code   [0] = '\0';
    out->snomed_code[0] = '\0';
    out->laterality      [0] = '\0';
    out->specific_anatomy[0] = '\0';
    out->histopathology  [0] = '\0';

    return ET_OK;
}

/* ----------------------------------------------------------------------------
 * Generate findings from a set of measurements. Caller owns the output array
 * and must free via et_free_findings.
 *
 *  Sort priority (per Master Design §35):
 *    1. State (Incoherence > Mediation > Unsubstantiated > Exception)
 *    2. Severity score pct (descending)
 *    3. Impedance xi(d) (descending — low d = more urgent)
 *    4. Tower integrative level (systemic > organ-system > ...)
 * ------------------------------------------------------------------------- */

static int state_priority(et_manifold_state_t s) {
    /* Higher value = more urgent */
    switch (s) {
        case ET_STATE_INCOHERENCE:     return 3;
        case ET_STATE_MEDIATION:       return 2;
        case ET_STATE_UNSUBSTANTIATED: return 1;
        case ET_STATE_EXCEPTION:       return 0;
        default:                       return 0;
    }
}

/* Tower integrative-level priority — higher = more systemic. From Master
 * Design §3: 10 integrative levels from molecular (1) to organism (8).
 * Cardiac is the Universal Human Seed (level 8 integrated whole-organism),
 * Developmental is trans-organism (level 10). Systemic towers (cardiac,
 * respiratory, neural) rank higher for urgency than localized ones
 * (renal, musculoskeletal). */
static int tower_priority(et_tower_t t) {
    switch (t) {
        case ET_TOWER_CARDIAC:          return 10; /* Universal Human Seed */
        case ET_TOWER_NEURAL:           return  9;
        case ET_TOWER_RESPIRATORY:      return  8;
        case ET_TOWER_ENDOCRINE:        return  7;
        case ET_TOWER_IMMUNE:           return  6;
        case ET_TOWER_DIGESTIVE:        return  5;
        case ET_TOWER_RENAL:            return  4;
        case ET_TOWER_MUSCULOSKELETAL:  return  3;
        case ET_TOWER_REPRODUCTIVE:     return  2;
        case ET_TOWER_DEVELOPMENTAL:    return  1;
        default:                         return  0;
    }
}

static int compare_findings(const void* a_, const void* b_) {
    const et_finding_t* a = (const et_finding_t*)a_;
    const et_finding_t* b = (const et_finding_t*)b_;

    int sa = state_priority(a->state);
    int sb = state_priority(b->state);
    if (sa != sb) return (sb - sa);        /* descending */

    if (b->severity_score_pct > a->severity_score_pct) return  1;
    if (b->severity_score_pct < a->severity_score_pct) return -1;

    /* low d = higher impedance = more urgent */
    if (a->projection.d != b->projection.d) {
        return (a->projection.d - b->projection.d);
    }

    int ta = tower_priority(a->tower);
    int tb = tower_priority(b->tower);
    if (ta != tb) return (tb - ta);

    return 0;
}

LIBET_MED_API et_error_t et_generate_findings(const et_measurement_t* measurements,
                                              int measurement_count,
                                              const et_patient_baseline_t* baseline,
                                              int fallback_allowed,
                                              et_finding_t** findings_out,
                                              int* count_out) {
    if (measurements == NULL || baseline == NULL
        || findings_out == NULL || count_out == NULL) {
        _et_error(ET_ERR_INVALID_ARG, "et_generate_findings needs non-null args");
        return ET_ERR_INVALID_ARG;
    }
    if (measurement_count < 0) {
        _et_error(ET_ERR_INVALID_ARG, "measurement_count < 0");
        return ET_ERR_INVALID_ARG;
    }
    *findings_out = NULL;
    *count_out    = 0;
    if (measurement_count == 0) return ET_OK;

    et_finding_t* arr = (et_finding_t*)calloc((size_t)measurement_count,
                                              sizeof(et_finding_t));
    if (arr == NULL) {
        _et_error(ET_ERR_OUT_OF_MEMORY, "calloc failed in et_generate_findings");
        return ET_ERR_OUT_OF_MEMORY;
    }

    int written = 0;
    for (int i = 0; i < measurement_count; ++i) {
        et_error_t e = et_classify_measurement(&measurements[i], baseline,
                                               fallback_allowed, &arr[written]);
        if (e == ET_OK) {
            ++written;
        } else {
            /* Leave a stub finding in the slot describing the failure, so
             * the caller can see which measurement was skipped (no silent
             * drops — Rule 33). */
            et_finding_init(&arr[written]);
            safe_strcpy(arr[written].name, sizeof(arr[written].name),
                        measurements[i].name[0] ? measurements[i].name : "(unnamed)");
            safe_strcpy(arr[written].description, sizeof(arr[written].description),
                        et_error_string(e));
            arr[written].state = ET_STATE_INCOHERENCE;
            arr[written].incoherence_level = ET_INCOH_L1_CATEGORICAL;
            arr[written].severity_score_pct = 100.0;
            ++written;
        }
    }

    /* Compute multifold coherence and retro-update L5 flags on findings whose
     * state was Incoherence. Use the normalized (observed / reference) scalar
     * which is a scale-invariant measure of cross-tower coherence: 1.0 =
     * matches population baseline, << 1 = multifold has collapsed. */
    et_multifold_signature_t mf;
    et_error_t me = et_compute_multifold_signature(baseline, fallback_allowed, &mf);
    double M_norm = (me == ET_OK) ? mf.multifold_normalized : 1.0;
    for (int i = 0; i < written; ++i) {
        if (arr[i].state == ET_STATE_INCOHERENCE) {
            arr[i].incoherence_level = et_classify_incoherence_level(
                arr[i].state,
                fabs(arr[i].projection.eps_cents),
                arr[i].projection.d,
                0,          /* per-measurement cascade depth = 0 here */
                M_norm);
        }
    }

    /* Sort descending by urgency. */
    qsort(arr, (size_t)written, sizeof(et_finding_t), compare_findings);

    /* Assign urgency rank 1..N. */
    for (int i = 0; i < written; ++i) {
        arr[i].urgency_rank = i + 1;
    }

    *findings_out = arr;
    *count_out    = written;
    return ET_OK;
}

LIBET_MED_API void et_free_findings(et_finding_t* findings, int count) {
    (void)count;  /* all finding storage is by value in the flat array */
    if (findings != NULL) free(findings);
}
