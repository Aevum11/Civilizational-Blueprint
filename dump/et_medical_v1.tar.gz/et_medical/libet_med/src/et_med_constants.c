/* ============================================================================
 * et_med_constants.c — Manifold constants
 * ----------------------------------------------------------------------------
 *  Identification: these are the primitives of ET. They are derived, not
 *  chosen.
 *      ET_N_PRIMITIVES   = 3   (P, D, T  ;  identity of the framework)
 *      ET_S_STATES       = 4   (manifested states ; {P,D}, {D,T}, {P,T},
 *                              {P,D,T} ; the ground {} is the unmanifested
 *                              substrate that does not enter active counts)
 *      ET_N_MANIFOLD_12  = 12  (base manifold ; 12 = 4 states x 3 primitives;
 *                              also the only size that admits the Six-Family
 *                              Closure Theorem on divisors)
 *      ET_V_BASE         = 1/12 (base variance = inverse of N at 12-fold)
 *      ET_K_KOIDE        = 2/3 (binding-stability ratio across all complexes;
 *                              proven cross-domain in the corpus)
 *      ET_A0_LOCAL_EM    = 137 (= A_0 in the Fine Structure Constant
 *                              derivation: alpha^-1 = A_0 + A_1 - A_1.5
 *                              - A_2 - A_3 ; the local-EM zeroth term)
 *      ET_BIOLOGICAL_FLOOR = 420 = LCM(1..7) — the (5,7) co-binding floor
 *                              (Projection Guide §75 ; biological substrates
 *                              co-bind quintic and septic families at this
 *                              floor)
 *      ET_CORTICAL_FLOOR   = 27720 = LCM(1..11) — Blue Brain 11D cliques
 *                              (Projection Guide §26.5)
 *
 *  Subsumption: any conventional reference value (60 bpm, 12 breaths/min,
 *  1 day) is an ET-derived value expressed in domain vocabulary. Those go
 *  in et_med_towers.c, not here. THIS file only carries primitives.
 * ========================================================================= */
#include "libet_med.h"

const int    ET_N_PRIMITIVES     = 3;
const int    ET_S_STATES         = 4;
const int    ET_N_MANIFOLD_12    = 12;
const double ET_V_BASE           = 1.0 / 12.0;
const double ET_K_KOIDE          = 2.0 / 3.0;
const int    ET_A0_LOCAL_EM      = 137;
const int    ET_BIOLOGICAL_FLOOR = 420;
const int    ET_CORTICAL_FLOOR   = 27720;
