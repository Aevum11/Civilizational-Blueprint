# libet_med — Windows Wrapper

P/Invoke binding for `libet_med.dll` usable from any .NET language (C#, F#, VB.NET).

## Directory contents
| File | Purpose |
|------|---------|
| `LibEtMed.cs` | Complete P/Invoke binding for libet_med.dll. Includes managed facade (`EtMedLib` class) and all marshalled struct types. |
| `EtMedConsoleDemo.cs` | Console demo matching the C CLI output. |
| `EtMedConsoleDemo.csproj` | .NET SDK project file. |
| `README.md` | This file. |

## Build steps

### 1. Build the C core as a Windows DLL

Requires Visual Studio 2022 Build Tools (MSVC) or MinGW-w64.

```powershell
cd path\to\et_medical\libet_med
cmake -S . -B build_win -A x64 -DLIBET_MED_BUILD_SHARED=ON
cmake --build build_win --config Release
```

Output: `build_win\Release\libet_med.dll` (or `Debug\libet_med.dll`).

### 2. Build the .NET demo

```powershell
cd path\to\et_medical\wrappers\windows
dotnet build -c Release
```

### 3. Copy the DLL into place

```powershell
copy path\to\et_medical\libet_med\build_win\Release\libet_med.dll bin\Release\net8.0\
```

### 4. Run

```powershell
cd bin\Release\net8.0
.\EtMedConsoleDemo.exe
```

Expected output: multifold signature for a demo patient (HR=60 baseline) plus
findings for HR=120, RR=30, TEMP=38.8, GAIT=1.0.

## Integration notes

### Minimal API usage

```csharp
using EtMed;

var patient = PatientBaseline.Empty();
patient.HrRestBpm = 60.0;
patient.SexValue = Sex.Male;

var signature = EtMedLib.ComputeMultifoldSignature(patient);
Console.WriteLine($"Multifold scalar: {signature.Scalar:F4}");

var findings = EtMedLib.GenerateFindings(new[] {
    new Measurement { Name = "HR", CurrentValue = 120,
                      Units = "bpm", Tower = Tower.Cardiac }
}, patient);

foreach (var f in findings)
    Console.WriteLine($"{f.Name}: {f.State} {f.SeverityPct:F1}% ({f.SeverityText})");
```

### Error handling

All fallible methods throw `EtMedException` carrying an `EtError` code. Non-fatal
fallbacks are logged via the callback channel (see `et_set_log_callback` in
the C ABI) and increment `EtMedLib.FallbackCount()`.

### Thread safety

The C core is thread-unsafe for the log-callback / fallback-counter globals.
All other functions are thread-safe for independent data. Wrap calls in a
mutex if multiple threads share state.

### ABI match

This wrapper assumes:
- `sizeof(int) == 4`, `sizeof(double) == 8` on both sides (true for x64/x86/ARM64 on Windows).
- C11 default struct layout — no explicit packing.
- Cdecl calling convention (matches `LIBET_MED_API` + default cdecl).
