"""
et_bridge/et_monitor.py
ET32 Bridge — Process Monitor

Watches for configured 32-bit target processes using Windows API.
Derived from P ∘ D ∘ T = E.

The monitor implements the T-component of the bridge's PDT structure:
  P = the OS process table (substrate of all running processes)
  D = the configured target exe names (Descriptor set: which processes to bridge)
  T = this monitor (traverses P scanning for D-matches, triggering E on match)

When T finds a process P whose name matches a D in the config, it produces
the Exception state E = "process found, bridge engaged."

Poll interval = S seconds = 12 seconds (manifold symmetry governs scan frequency).
On match: calls registered on_process_found callbacks with (pid, exe_name, config).
"""

import os
import sys
import ctypes
import ctypes.wintypes
import struct
import time
import threading
from typing import Dict, List, Optional, Callable, Set, Tuple
from pathlib import Path

from .et_math import S, K, V_BASE, CONN_TIMEOUT_MS
from .et_config import ETBridgeConfig, TargetConfig
from .et_logger import ETLog

# Windows API constants
PROCESS_ALL_ACCESS      = 0x1F0FFF
PROCESS_QUERY_INFORMATION = 0x0400
PROCESS_VM_READ         = 0x0010
TH32CS_SNAPPROCESS      = 0x00000002
IMAGE_FILE_32BIT_MACHINE = 0x0100

# Windows structures
class PROCESSENTRY32(ctypes.Structure):
    _fields_ = [
        ("dwSize",              ctypes.wintypes.DWORD),
        ("cntUsage",            ctypes.wintypes.DWORD),
        ("th32ProcessID",       ctypes.wintypes.DWORD),
        ("th32DefaultHeapID",   ctypes.POINTER(ctypes.c_ulong)),
        ("th32ModuleID",        ctypes.wintypes.DWORD),
        ("cntThreads",          ctypes.wintypes.DWORD),
        ("th32ParentProcessID", ctypes.wintypes.DWORD),
        ("pcPriClassBase",      ctypes.c_long),
        ("dwFlags",             ctypes.wintypes.DWORD),
        ("szExeFile",           ctypes.c_char * 260),
    ]


class SYSTEM_INFO(ctypes.Structure):
    class _DUMMYUNIONNAME(ctypes.Union):
        class _DUMMYSTRUCTNAME(ctypes.Structure):
            _fields_ = [
                ("wProcessorArchitecture", ctypes.c_ushort),
                ("wReserved",              ctypes.c_ushort),
            ]
        _fields_ = [
            ("dwOemId",      ctypes.wintypes.DWORD),
            ("_s",           _DUMMYSTRUCTNAME),
        ]
    _anonymous_ = ("_u",)
    _fields_ = [
        ("_u",                     _DUMMYUNIONNAME),
        ("dwPageSize",             ctypes.wintypes.DWORD),
        ("lpMinimumApplicationAddress", ctypes.c_void_p),
        ("lpMaximumApplicationAddress", ctypes.c_void_p),
        ("dwActiveProcessorMask",  ctypes.POINTER(ctypes.c_ulong)),
        ("dwNumberOfProcessors",   ctypes.wintypes.DWORD),
        ("dwProcessorType",        ctypes.wintypes.DWORD),
        ("dwAllocationGranularity",ctypes.wintypes.DWORD),
        ("wProcessorLevel",        ctypes.c_ushort),
        ("wProcessorRevision",     ctypes.c_ushort),
    ]

PROCESSOR_ARCHITECTURE_INTEL  = 0   # x86 (32-bit)
PROCESSOR_ARCHITECTURE_AMD64   = 9   # x64 (64-bit)


def _is_32bit_process(pid: int) -> bool:
    """
    Determine if a process is 32-bit (WOW64 or native 32-bit OS).
    Uses IsWow64Process on 64-bit Windows.
    On 32-bit Windows, ALL processes are 32-bit.

    ET derivation: this is the Identification Principle applied to P_process:
      Identify P (is this a 32-bit substrate?).
    """
    kernel32 = ctypes.windll.kernel32

    # Check if we're on 64-bit Windows
    sys_info = SYSTEM_INFO()
    kernel32.GetNativeSystemInfo(ctypes.byref(sys_info))
    is_64bit_os = (sys_info._u._s.wProcessorArchitecture == PROCESSOR_ARCHITECTURE_AMD64)

    if not is_64bit_os:
        return True  # All processes are 32-bit on 32-bit OS

    try:
        h = kernel32.OpenProcess(PROCESS_QUERY_INFORMATION, False, pid)
        if not h:
            return False

        is_wow64 = ctypes.wintypes.BOOL(0)
        result = ctypes.windll.kernel32.IsWow64Process(h, ctypes.byref(is_wow64))
        kernel32.CloseHandle(h)

        if not result:
            return False
        return bool(is_wow64.value)

    except Exception:
        return False


def _snapshot_processes() -> List[Tuple[int, str]]:
    """
    Enumerate all running processes using CreateToolhelp32Snapshot.
    Returns list of (pid, exe_name_lower) tuples.
    """
    kernel32 = ctypes.windll.kernel32
    snapshot = kernel32.CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0)
    if snapshot == ctypes.wintypes.HANDLE(-1).value:
        return []

    results = []
    entry = PROCESSENTRY32()
    entry.dwSize = ctypes.sizeof(PROCESSENTRY32)

    try:
        if kernel32.Process32First(snapshot, ctypes.byref(entry)):
            while True:
                pid = entry.th32ProcessID
                exe = entry.szExeFile.decode("utf-8", errors="replace").lower()
                results.append((pid, exe))
                if not kernel32.Process32Next(snapshot, ctypes.byref(entry)):
                    break
    finally:
        kernel32.CloseHandle(snapshot)

    return results


class ProcessInfo:
    """Information about a detected 32-bit target process."""
    __slots__ = ("pid", "exe_name", "config", "detected_at", "is_32bit")

    def __init__(self, pid: int, exe_name: str, config: TargetConfig):
        self.pid         = pid
        self.exe_name    = exe_name
        self.config      = config
        self.detected_at = time.monotonic()
        self.is_32bit    = True


class ETProcessMonitor:
    """
    Process monitor: T-component that traverses the OS process table (P)
    looking for configured targets (D).

    When a match is found:
      1. Verifies the process is 32-bit
      2. Fires on_process_found callbacks
      3. Tracks the process until it exits

    Poll interval = S seconds (12s) for the main scan.
    On active target: rescans every S/12 = 1 second to detect exit promptly.
    """

    POLL_INTERVAL_S      : float = float(S)    # 12s normal scan
    ACTIVE_POLL_INTERVAL : float = 1.0          # 1s while managing a target

    def __init__(self, config: ETBridgeConfig):
        self._config  = config
        self._log     = ETLog("Monitor")
        self._lock    = threading.RLock()
        self._running = False
        self._thread  : Optional[threading.Thread] = None

        # Active bridges: {pid: ProcessInfo}
        self._active  : Dict[int, ProcessInfo] = {}
        # PIDs we've already processed (to avoid double-injection)
        self._seen    : Set[int] = set()

        # Callbacks
        self._on_found   : List[Callable[[ProcessInfo], None]] = []
        self._on_exit    : List[Callable[[ProcessInfo], None]] = []

    def on_process_found(self, callback: Callable[[ProcessInfo], None]):
        """Register callback invoked when a configured 32-bit process is found."""
        self._on_found.append(callback)

    def on_process_exit(self, callback: Callable[[ProcessInfo], None]):
        """Register callback invoked when a bridged process exits."""
        self._on_exit.append(callback)

    def start(self):
        """Start the monitor thread."""
        self._running = True
        self._thread = threading.Thread(
            target=self._monitor_loop,
            name="ET_ProcessMonitor",
            daemon=True
        )
        self._thread.start()
        self._log.mediation("Process monitor started")

    def stop(self):
        """Stop the monitor thread."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=self.POLL_INTERVAL_S + 1)
        self._log.info("Process monitor stopped")

    # ------------------------------------------------------------------
    # Main monitor loop
    # ------------------------------------------------------------------

    def _monitor_loop(self):
        while self._running:
            try:
                self._scan()
            except Exception as e:
                self._log.error(f"Monitor scan error: {e}", variance=K)

            # Adaptive poll rate: shorter when managing active targets
            with self._lock:
                has_active = bool(self._active)

            interval = self.ACTIVE_POLL_INTERVAL if has_active else self.POLL_INTERVAL_S
            time.sleep(interval)

    def _scan(self):
        """
        Single scan pass.
        PDT of scan:
          P = all running processes
          D = configured target exe names
          T = this scan iteration
        E = matches found
        """
        target_names = set(self._config.target_exe_names())
        if not target_names:
            return

        processes = _snapshot_processes()
        current_pids: Set[int] = set()

        for pid, exe_name in processes:
            current_pids.add(pid)
            if exe_name not in target_names:
                continue

            with self._lock:
                already_seen = pid in self._seen
                already_active = pid in self._active

            if already_seen or already_active:
                continue

            # New match — verify it's 32-bit
            if not _is_32bit_process(pid):
                self._log.debug(
                    f"Skipping {exe_name} (PID {pid}) — not 32-bit"
                )
                continue

            cfg = self._config.get_target(exe_name)
            if cfg is None or not cfg.enabled:
                continue

            info = ProcessInfo(pid, exe_name, cfg)

            with self._lock:
                self._seen.add(pid)
                self._active[pid] = info

            self._log.exception_state(
                f"Target found: {exe_name} (PID {pid}) — engaging bridge"
            )

            # Fire callbacks
            for cb in self._on_found:
                try:
                    cb(info)
                except Exception as e:
                    self._log.error(f"Callback error on found: {e}")

        # Check for exited processes
        with self._lock:
            exited_pids = [pid for pid in self._active if pid not in current_pids]

        for pid in exited_pids:
            with self._lock:
                info = self._active.pop(pid, None)

            if info:
                self._log.info(f"Target exited: {info.exe_name} (PID {pid})")
                for cb in self._on_exit:
                    try:
                        cb(info)
                    except Exception as e:
                        self._log.error(f"Callback error on exit: {e}")

    # ------------------------------------------------------------------
    # Manual trigger (for inject_on_startup mode)
    # ------------------------------------------------------------------

    def force_scan(self):
        """Run an immediate scan pass. Used at startup to catch already-running targets."""
        self._scan()

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    def active_targets(self) -> List[ProcessInfo]:
        with self._lock:
            return list(self._active.values())

    def is_active(self, pid: int) -> bool:
        with self._lock:
            return pid in self._active

    def status(self) -> Dict:
        with self._lock:
            active = [
                {"pid": i.pid, "exe": i.exe_name,
                 "age_s": round(time.monotonic() - i.detected_at, 1)}
                for i in self._active.values()
            ]
        return {
            "running": self._running,
            "active_count": len(active),
            "total_seen": len(self._seen),
            "active": active,
        }
