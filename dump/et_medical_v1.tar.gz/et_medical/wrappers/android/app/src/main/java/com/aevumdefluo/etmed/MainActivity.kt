/* ============================================================================
 * MainActivity.kt — minimal Android demo UI for libet_med
 * ----------------------------------------------------------------------------
 *  Displays:
 *   - Baseline inputs for HR/RR/temp/age/sex
 *   - A row of current-value inputs for HR/RR/Temp
 *   - "Compute" button runs computeMultifoldSignature + classifyMeasurement
 *   - Result pane shows the findings
 * ========================================================================= */
package com.aevumdefluo.etmed

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    EtMedScreen()
                }
            }
        }
    }
}

@Composable
fun EtMedScreen() {
    var hrRest  by remember { mutableStateOf("60") }
    var rrRest  by remember { mutableStateOf("12") }
    var temp    by remember { mutableStateOf("36.8") }
    var age     by remember { mutableStateOf("45") }
    var sex     by remember { mutableStateOf(Sex.Male) }

    var hr      by remember { mutableStateOf("120") }
    var rr      by remember { mutableStateOf("30") }
    var tempMeas by remember { mutableStateOf("38.8") }

    var output  by remember { mutableStateOf("(not computed yet)") }

    Column(
        modifier = Modifier.padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("libet_med Android demo",
            fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("ET-native projection of the human body onto the 12-fold lattice",
            fontSize = 12.sp)

        Divider()

        Text("Baseline", fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(hrRest, { hrRest = it }, label = { Text("HR rest bpm") },
                modifier = Modifier.weight(1f))
            OutlinedTextField(rrRest, { rrRest = it }, label = { Text("RR rest/min") },
                modifier = Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(temp, { temp = it }, label = { Text("Temp C") },
                modifier = Modifier.weight(1f))
            OutlinedTextField(age, { age = it }, label = { Text("Age yr") },
                modifier = Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Sex.values().forEach { s ->
                FilterChip(
                    selected = sex == s,
                    onClick = { sex = s },
                    label = { Text(s.name) }
                )
            }
        }

        Divider()
        Text("Current measurements", fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(hr, { hr = it }, label = { Text("HR bpm") },
                modifier = Modifier.weight(1f))
            OutlinedTextField(rr, { rr = it }, label = { Text("RR /min") },
                modifier = Modifier.weight(1f))
            OutlinedTextField(tempMeas, { tempMeas = it }, label = { Text("Temp C") },
                modifier = Modifier.weight(1f))
        }

        Button(
            onClick = {
                val baseline = PatientBaseline(
                    hrRestBpm    = hrRest.toDoubleOrNull() ?: Double.NaN,
                    rrRestPerMin = rrRest.toDoubleOrNull() ?: Double.NaN,
                    temperatureC = temp.toDoubleOrNull()   ?: Double.NaN,
                    ageYears     = age.toDoubleOrNull()    ?: Double.NaN,
                    sex          = sex.code
                )
                val sb = StringBuilder()
                try {
                    val sig = EtMed.computeMultifoldSignature(baseline)
                    sb.appendLine("Multifold signature:")
                    sb.appendLine("  scalar = %.4f".format(sig.scalar))
                    sb.appendLine("  normalized / reference = %.4f".format(sig.normalizedVsReference))
                    for (t in Tower.values()) {
                        val seconds = sig.r0Seconds[t.code]
                        val source  = if (sig.r0Present[t.code]) "patient" else "default"
                        sb.appendLine("  %-16s %14.3f s  (%s)".format(t.name, seconds, source))
                    }
                    sb.appendLine()
                    sb.appendLine("Findings:")

                    fun classify(name: String, v: String?, tower: Tower) {
                        val dv = v?.toDoubleOrNull() ?: return
                        val f = EtMed.classifyMeasurement(name, dv,
                                tower = tower, baseline = baseline)
                        sb.appendLine("  $name  @ ${tower.name}  r=? k=${f.projection.k} d=${f.projection.d}  eps=%.2f¢".format(f.projection.epsCents))
                        sb.appendLine("        state=${f.state}  severity=%.2f%%".format(f.severityPct))
                    }
                    classify("HR",   hr,       Tower.Cardiac)
                    classify("RR",   rr,       Tower.Respiratory)
                    classify("TEMP", tempMeas, Tower.Endocrine)

                    sb.appendLine()
                    sb.appendLine("Fallback paths during run: ${EtMed.fallbackCount()}")
                } catch (e: EtMedException) {
                    sb.append("Error: ${e.err} — ${e.message}")
                }
                output = sb.toString()
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Compute") }

        Divider()
        Text("Output", fontWeight = FontWeight.Bold)
        Text(output, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
    }
}
