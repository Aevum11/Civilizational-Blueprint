/*
 * ET Lossless Sensor Capture — Sensor Discovery
 * ================================================
 * Enumerates all available hardware sensors and configures
 * optimal access modes (direct channel > event queue).
 *
 * Author: Michael James Muller — Aevum Defluo (Exception Theory)
 * License: CC-BY-4.0
 */

package com.aevumdefluo.etsensor

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorManager

/**
 * Discovered sensor info — mirrors et_sensor_info_t from C.
 */
data class SensorInfo(
    val id: Int,
    val type: SensorType,
    val name: String,
    val vendor: String,
    val resolution: Float,
    val maxRange: Float,
    val minDelayUs: Int,
    val maxRateHz: Int,
    val fifoMax: Int,
    val axes: Int,
    val isBipolar: Boolean,
    val directChannelSupported: Boolean,
    val accessMode: String
)

/**
 * SensorDiscovery — enumerate all hardware sensors on the device.
 *
 * Only HARDWARE sensors are discovered. Virtual/composite sensors
 * (rotation vector, gravity, linear acceleration) are OS-computed
 * from hardware sensors and are SKIPPED. We record the raw hardware
 * data and derive composites in the lattice if needed.
 */
object SensorDiscovery {

    /* Android sensor types that are HARDWARE (not virtual/composite) */
    private val HARDWARE_TYPES = mapOf(
        Sensor.TYPE_ACCELEROMETER to SensorType.ACCEL,
        Sensor.TYPE_GYROSCOPE to SensorType.GYRO,
        Sensor.TYPE_MAGNETIC_FIELD to SensorType.MAG,
        Sensor.TYPE_PRESSURE to SensorType.BARO,
        Sensor.TYPE_LIGHT to SensorType.LIGHT,
        Sensor.TYPE_PROXIMITY to SensorType.PROXIMITY,
        Sensor.TYPE_AMBIENT_TEMPERATURE to SensorType.TEMP,
        Sensor.TYPE_RELATIVE_HUMIDITY to SensorType.HUMIDITY,
        Sensor.TYPE_HEART_RATE to SensorType.HEART_RATE,
        Sensor.TYPE_STEP_COUNTER to SensorType.STEP,
    )

    /* Vector sensors (3 axes) */
    private val VECTOR_TYPES = setOf(
        Sensor.TYPE_ACCELEROMETER,
        Sensor.TYPE_GYROSCOPE,
        Sensor.TYPE_MAGNETIC_FIELD,
    )

    /* Bipolar sensors (values can be negative) */
    private val BIPOLAR_TYPES = setOf(
        Sensor.TYPE_ACCELEROMETER,
        Sensor.TYPE_GYROSCOPE,
        Sensor.TYPE_MAGNETIC_FIELD,
    )

    /**
     * Discover all hardware sensors on this device.
     * Returns a list of SensorInfo sorted by type.
     */
    fun discover(context: Context): List<SensorInfo> {
        val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val allSensors = sensorManager.getSensorList(Sensor.TYPE_ALL)
        val results = mutableListOf<SensorInfo>()

        var id = 0
        for (sensor in allSensors) {
            val etType = HARDWARE_TYPES[sensor.type] ?: continue /* Skip non-hardware */

            val maxRateHz = if (sensor.minDelay > 0) 1_000_000 / sensor.minDelay else 200
            val axes = if (sensor.type in VECTOR_TYPES) 3 else 1
            val bipolar = sensor.type in BIPOLAR_TYPES

            /* Check direct channel support (API 26+) */
            val directSupported = try {
                sensor.highestDirectReportRateLevel >= android.hardware.SensorDirectChannel.RATE_FAST
            } catch (_: Exception) { false }

            val accessMode = if (directSupported) "direct_channel" else "event_queue"

            results.add(SensorInfo(
                id = id++,
                type = etType,
                name = sensor.name,
                vendor = sensor.vendor,
                resolution = sensor.resolution,
                maxRange = sensor.maximumRange,
                minDelayUs = sensor.minDelay,
                maxRateHz = maxRateHz,
                fifoMax = sensor.fifoMaxEventCount,
                axes = axes,
                isBipolar = bipolar,
                directChannelSupported = directSupported,
                accessMode = accessMode,
            ))
        }

        return results.sortedBy { it.type.code }
    }

    /**
     * Check audio input availability.
     */
    fun hasAudioInput(context: Context): Boolean {
        return context.packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_MICROPHONE)
    }

    /**
     * Check Camera2 RAW support.
     */
    fun hasCameraRaw(context: Context): Boolean {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as android.hardware.camera2.CameraManager
            cameraManager.cameraIdList.any { id ->
                val chars = cameraManager.getCameraCharacteristics(id)
                val caps = chars.get(android.hardware.camera2.CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)
                caps?.contains(android.hardware.camera2.CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_RAW) == true
            }
        } catch (_: Exception) { false }
    }

    /**
     * Check GPS availability.
     */
    fun hasGps(context: Context): Boolean {
        return context.packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_LOCATION_GPS)
    }

    /**
     * Generate a comprehensive hardware report string.
     */
    fun generateReport(context: Context): String {
        val sensors = discover(context)
        val sb = StringBuilder()

        sb.appendLine("╔══════════════════════════════════════════════════════════════╗")
        sb.appendLine("║   ET LOSSLESS SENSOR CAPTURE — HARDWARE DISCOVERY          ║")
        sb.appendLine("║   P∘D∘T = E — Aevum Defluo                                ║")
        sb.appendLine("╚══════════════════════════════════════════════════════════════╝")
        sb.appendLine()
        sb.appendLine("  Hardware sensors: ${sensors.size}")
        sb.appendLine("  Audio input: ${if (hasAudioInput(context)) "✓" else "✗"}")
        sb.appendLine("  Camera RAW: ${if (hasCameraRaw(context)) "✓" else "✗"}")
        sb.appendLine("  GPS: ${if (hasGps(context)) "✓" else "✗"}")
        sb.appendLine()

        for (s in sensors) {
            val direct = if (s.directChannelSupported) "✓ DIRECT" else "  event"
            sb.appendLine("  [${s.id}] ${s.name}")
            sb.appendLine("      Type: ${s.type.name} | Access: $direct")
            sb.appendLine("      Rate: ${s.maxRateHz} Hz | Axes: ${s.axes} | Range: ±${s.maxRange}")
            sb.appendLine("      R₀ = ${EtSensor.getDefaultR0(s.type.code)}")
            sb.appendLine()
        }

        sb.appendLine(EtSensor.getConstantsInfo())
        return sb.toString()
    }
}
