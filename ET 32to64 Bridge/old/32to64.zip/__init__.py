"""
et_bridge/__init__.py
ET32 Bridge — Package Initialisation

Derived from P ∘ D ∘ T = E.

This package implements the ET32 Bridge: a 64-bit broker process that extends
any configured 32-bit process to the full 64-bit address space and feature set.

Exports (the complete public surface of the bridge package):
  - ETBridgeAPI     — singleton entry point for the broker
  - ETAPIGateway    — high-level call surface (32-bit helper / test side)
  - ETIPCClient     — raw named-pipe client for 32-bit side
  - ETBridgeConfig  — configuration container
  - ETHost64        — 64-bit operation dispatcher
  - ETHandleTable   — 32↔64 address handle table
  - ETMetrics       — bridge performance metrics
  - ETPacket        — PDT packet structure
  - CmdFamily       — 12 command families (lattice positions d=1..12)
  - CmdCode         — all command codes within each family
  - S, K, V_BASE    — ET universal constants

ET Version: 1.0.0
PDT: P ∘ D ∘ T = E
"""

# ET constants — always available at package level
from .et_math import (
    S, K, V_BASE,
    DIGITAL_ACTION_QUANTUM, IPC_BUFFER_SIZE,
    PDT_HEADER_SIZE, CONN_TIMEOUT_MS, RETRY_COUNT,
    QUEUE_DEPTH, HANDLE_BASE, HANDLE_MAX, ADDR64_BASE,
    PIPE_NAME_TEMPLATE, SHMEM_NAME_TEMPLATE,
    CmdFamily, CmdCode,
    ETPacket, ETHandleMath, ETLatticeRouter, ETMetrics,
    pack_args, unpack_args,
)

# Handle table
from .et_handle import HandleTable, HandleEntry

# Configuration
from .et_config import ETBridgeConfig, TargetConfig

# Logging
from .et_logger import ETLog, ETLogFormatter

# Process monitoring
from .et_monitor import ETProcessMonitor

# IPC transport
from .et_ipc import ETIPCServer, ETIPCClient, pipe_name_for_pid

# 64-bit operation host
from .et_host64 import ETHost64

# API layer
from .et_api import ETBridgeAPI, ETAPIGateway, ETHookManager, ETMarshal

# Injection engine
from .et_injector import ETInjector

# Heaven's Gate
from .et_heaven import ETHeavenGate

__version__  = "1.0.0"
__author__   = "Michael James Muller"
__doctrine__ = "P ∘ D ∘ T = E"

__all__ = [
    # Constants
    "S", "K", "V_BASE",
    "DIGITAL_ACTION_QUANTUM", "IPC_BUFFER_SIZE",
    "PDT_HEADER_SIZE", "CONN_TIMEOUT_MS", "RETRY_COUNT",
    "QUEUE_DEPTH", "HANDLE_BASE", "HANDLE_MAX", "ADDR64_BASE",
    "PIPE_NAME_TEMPLATE", "SHMEM_NAME_TEMPLATE",
    # Math/Protocol
    "CmdFamily", "CmdCode",
    "ETPacket", "ETHandleMath", "ETLatticeRouter", "ETMetrics",
    "pack_args", "unpack_args",
    # Handle table
    "HandleTable", "HandleEntry",
    # Config
    "ETBridgeConfig", "TargetConfig",
    # Logging
    "ETLog", "ETLogFormatter",
    # Monitor
    "ETProcessMonitor",
    # IPC
    "ETIPCServer", "ETIPCClient", "pipe_name_for_pid",
    # Host
    "ETHost64",
    # API
    "ETBridgeAPI", "ETAPIGateway", "ETHookManager", "ETMarshal",
    # Injection
    "ETInjector",
    # Heaven's Gate
    "ETHeavenGate",
]
