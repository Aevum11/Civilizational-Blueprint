// ============================================================================
// LibEtMed.cs — .NET P/Invoke binding for libet_med
// ----------------------------------------------------------------------------
//  Identification: this is the Windows/UWP/.NET access layer to the C core.
//  All memory marshalling stays one-shot per call — the C core owns nothing
//  that survives the managed call, and the managed side copies into its own
//  types before any C pointer goes out of scope.
//
//  Subsumption: the same C ABI is used by JNI (Android), ctypes (Python),
//  and Emscripten (WebAssembly). This file is the .NET projection of that
//  common ABI — not a reimplementation.
//
//  Usage (minimal):
//      using EtMed;
//      var patient = new PatientBaseline {
//          HrRestBpm = 60, RrRestPerMin = 12, TemperatureC = 36.8,
//          AgeYears = 45, Sex = Sex.Male };
//      var signature = EtMed.ComputeMultifoldSignature(patient);
//      var findings = EtMed.GenerateFindings(new[] {
//          new Measurement { Name = "HR", CurrentValue = 120, Units = "bpm", Tower = Tower.Cardiac } },
//          patient);
//      foreach (var f in findings) Console.WriteLine($"{f.Name}: {f.State} sev={f.SeverityPct:F1}%");
//
//  Build (requires MSBuild or dotnet CLI):
//      dotnet build -c Release
//  Ensure libet_med.dll is on PATH or next to the managed assembly.
// ============================================================================
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Text;

namespace EtMed
{
    // ------------------------------------------------------------------------
    // Enums mirroring the C ABI exactly
    // ------------------------------------------------------------------------
    public enum EtError : int
    {
        Ok                         = 0,
        InvalidRatio               = 1,
        InvalidN                   = 2,
        InvalidArg                 = 3,
        OutOfMemory                = 4,
        UnknownTower               = 5,
        IncompleteBaseline         = 6,
        FallbackUsed               = 7,
        CascadeStabilityExceeded   = 8,
        OffLattice                 = 9,
        Numeric                    = 10,
        Last                       = 11
    }

    public enum Tower : int
    {
        Cardiac         = 0,
        Respiratory     = 1,
        Neural          = 2,
        Endocrine       = 3,
        Immune          = 4,
        Digestive       = 5,
        Renal           = 6,
        Musculoskeletal = 7,
        Reproductive    = 8,
        Developmental   = 9
    }

    public const int TowerCount = 10;

    public enum Sex : int
    {
        Female      = 0,
        Male        = 1,
        Unspecified = 2
    }

    public enum ManifoldState : int
    {
        Exception       = 0,
        Unsubstantiated = 1,
        Mediation       = 2,
        Incoherence     = 3
    }

    public enum IncoherenceLevel : int
    {
        None           = 0,
        L1Categorical  = 1,
        L2Binding      = 2,
        L3Cascade      = 3,
        L4Stability    = 4,
        L5Coherence    = 5
    }

    // ------------------------------------------------------------------------
    // Managed-side value types (structs match the C structs exactly — Explicit
    // layout is avoided so runtime can pack them the same way as the C side
    // under the same C11 layout rules. sizeof(double)=8 everywhere; ints are
    // 32-bit on all current Windows/Android/wasm32 ABIs.)
    // ------------------------------------------------------------------------
    [StructLayout(LayoutKind.Sequential)]
    public struct Projection
    {
        public double R;
        public double Log2R;
        public double ExactPos;
        public int    K;
        public int    G;
        public int    D;
        public double EpsCents;
        public int    N;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct Elegance
    {
        public double R;
        public int    P;
        public int    Q;
        public int    PplusQ;
        public int    D;
        public double EpsCents;
        public double SymmetryFactor;
        public double TightnessFactor;
        public double SimplicityFactor;
        public double EleganceValue;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct PatientBaseline
    {
        public double HrRestBpm;
        public double RrRestPerMin;
        public double TemperatureC;
        public double SbpRestMmHg;
        public double DbpRestMmHg;
        public double Spo2Pct;
        public double GaitCycleS;
        public double MenstrualCycleD;
        public double AgeYears;
        public Sex    SexValue;

        public static PatientBaseline Empty()
        {
            var b = new PatientBaseline();
            NativeMethods.et_patient_baseline_init(ref b);
            return b;
        }
    }

    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public struct MeasurementNative
    {
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 64)]
        public string Name;
        public double CurrentValue;
        public double BaselineValue;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 16)]
        public string Units;
        public Tower  Tower;
        public int    ResolutionOverride;
        public double TimestampS;
    }

    public class Measurement
    {
        public string Name          { get; set; } = "";
        public double CurrentValue  { get; set; } = double.NaN;
        public double BaselineValue { get; set; } = double.NaN;
        public string Units         { get; set; } = "";
        public Tower  Tower         { get; set; } = Tower.Cardiac;
        public int    ResolutionOverride { get; set; } = 0;
        public double TimestampS    { get; set; } = 0.0;

        internal MeasurementNative ToNative() => new MeasurementNative {
            Name               = Name ?? "",
            CurrentValue       = CurrentValue,
            BaselineValue      = BaselineValue,
            Units              = Units ?? "",
            Tower              = Tower,
            ResolutionOverride = ResolutionOverride,
            TimestampS         = TimestampS
        };
    }

    // Raw finding struct (pinned char arrays = 96 + 256 + 6*32 bytes of text)
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public struct FindingNative
    {
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 96)]  public string Name;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)] public string Description;
        public ManifoldState    State;
        public IncoherenceLevel IncoherenceLevel;
        public Tower            Tower;
        public int              LatticeResolution;
        public Projection       Projection;
        public double           SeverityScoreRaw;
        public double           SeverityScorePct;
        public int              UrgencyRank;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string Icd11Code;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string IcfCode;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string SnomedCode;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string Laterality;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string SeverityText;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string SpecificAnatomy;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string Histopathology;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 32)] public string TemporalPattern;
    }

    public class Finding
    {
        public string           Name              { get; set; } = "";
        public string           Description       { get; set; } = "";
        public ManifoldState    State             { get; set; }
        public IncoherenceLevel IncoherenceLevel  { get; set; }
        public Tower            Tower             { get; set; }
        public int              LatticeResolution { get; set; }
        public Projection       Projection        { get; set; }
        public double           SeverityRaw       { get; set; }
        public double           SeverityPct       { get; set; }
        public int              UrgencyRank       { get; set; }
        public string           Icd11Code         { get; set; } = "";
        public string           IcfCode           { get; set; } = "";
        public string           SnomedCode        { get; set; } = "";
        public string           Laterality        { get; set; } = "";
        public string           SeverityText      { get; set; } = "";
        public string           SpecificAnatomy   { get; set; } = "";
        public string           Histopathology    { get; set; } = "";
        public string           TemporalPattern   { get; set; } = "";

        internal static Finding FromNative(in FindingNative n) => new Finding {
            Name              = n.Name ?? "",
            Description       = n.Description ?? "",
            State             = n.State,
            IncoherenceLevel  = n.IncoherenceLevel,
            Tower             = n.Tower,
            LatticeResolution = n.LatticeResolution,
            Projection        = n.Projection,
            SeverityRaw       = n.SeverityScoreRaw,
            SeverityPct       = n.SeverityScorePct,
            UrgencyRank       = n.UrgencyRank,
            Icd11Code         = n.Icd11Code       ?? "",
            IcfCode           = n.IcfCode         ?? "",
            SnomedCode        = n.SnomedCode      ?? "",
            Laterality        = n.Laterality      ?? "",
            SeverityText      = n.SeverityText    ?? "",
            SpecificAnatomy   = n.SpecificAnatomy ?? "",
            Histopathology    = n.Histopathology  ?? "",
            TemporalPattern   = n.TemporalPattern ?? ""
        };
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct MultifoldSignatureNative
    {
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = TowerCount)]
        public double[] R0Seconds;
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = TowerCount)]
        public int[]    R0Present;
        // 45 pairs = TowerCount*(TowerCount-1)/2
        [MarshalAs(UnmanagedType.ByValArray, SizeConst = 45)]
        public Elegance[] Pairwise;
        public double MultifoldScalar;
        public double MultifoldLogScalar;
        public double MultifoldNormalized;
        public int    PairCountValid;
    }

    public class MultifoldSignature
    {
        public double[]   R0Seconds           { get; set; } = new double[TowerCount];
        public bool[]     R0Present           { get; set; } = new bool[TowerCount];
        public Elegance[] Pairwise            { get; set; } = new Elegance[45];
        public double     Scalar              { get; set; }
        public double     LogScalar           { get; set; }
        public double     NormalizedVsReference { get; set; }
        public int        PairCountValid      { get; set; }

        internal static MultifoldSignature FromNative(in MultifoldSignatureNative n)
        {
            var m = new MultifoldSignature {
                R0Seconds           = (double[])n.R0Seconds.Clone(),
                R0Present           = new bool[TowerCount],
                Pairwise            = (Elegance[])n.Pairwise.Clone(),
                Scalar              = n.MultifoldScalar,
                LogScalar           = n.MultifoldLogScalar,
                NormalizedVsReference = n.MultifoldNormalized,
                PairCountValid      = n.PairCountValid
            };
            for (int i = 0; i < TowerCount; ++i) m.R0Present[i] = n.R0Present[i] != 0;
            return m;
        }
    }

    // ------------------------------------------------------------------------
    // P/Invoke definitions
    // ------------------------------------------------------------------------
    internal static class NativeMethods
    {
        private const string Lib = "libet_med";
        private const CallingConvention CC = CallingConvention.Cdecl;

        // Constants (read-only globals) — we import as IntPtr then Marshal.Read*.
        // Simpler: expose via a wrapper. Instead we hardcode here from the
        // public header to avoid the IntPtr dance; these are ET primitives
        // and will never change.
        public const int    EtNPrimitives    = 3;
        public const int    EtSStates        = 4;
        public const int    EtNManifold12    = 12;
        public const double EtVBase          = 1.0 / 12.0;
        public const double EtKKoide         = 2.0 / 3.0;
        public const int    EtA0LocalEm      = 137;
        public const int    EtBiologicalFloor = 420;
        public const int    EtCorticalFloor  = 27720;

        [DllImport(Lib, CallingConvention = CC, CharSet = CharSet.Ansi)]
        public static extern IntPtr et_error_string(EtError err);

        [DllImport(Lib, CallingConvention = CC)]
        public static extern UIntPtr et_fallback_count();

        [DllImport(Lib, CallingConvention = CC)]
        public static extern void et_reset_fallback_count();

        [DllImport(Lib, CallingConvention = CC)]
        public static extern EtError et_project_real(double r, int N, ref Projection projOut);

        [DllImport(Lib, CallingConvention = CC)]
        public static extern EtError et_project_imag(double theta, int N, ref Projection projOut);

        [DllImport(Lib, CallingConvention = CC)]
        public static extern EtError et_project_multi(double r,
            [Out] Projection[] projOut, int maxLattices, out int countOut);

        [DllImport(Lib, CallingConvention = CC)]
        public static extern int et_lcm_tower([Out] int[] outRes, int maxCount);

        [DllImport(Lib, CallingConvention = CC)]
        public static extern EtError et_elegance_score(double r, int N, int maxDenom, ref Elegance outEleg);

        [DllImport(Lib, CallingConvention = CC)]
        public static extern double et_magical_impedance(int d, int S, int A0);

        [DllImport(Lib, CallingConvention = CC)]
        public static extern EtError et_best_rational(double r, int maxDenom, out int pOut, out int qOut);

        [DllImport(Lib, CallingConvention = CC)]
        public static extern int et_palindrome_d(int nMod12);

        [DllImport(Lib, CallingConvention = CC)]
        public static extern double et_shimmer(int n);

        [DllImport(Lib, CallingConvention = CC, CharSet = CharSet.Ansi)]
        public static extern IntPtr et_tower_name(Tower tower);

        [DllImport(Lib, CallingConvention = CC)]
        public static extern double et_tower_default_R0(Tower tower);

        [DllImport(Lib, CallingConvention = CC)]
        public static extern int et_tower_resolution(Tower tower);

        [DllImport(Lib, CallingConvention = CC)]
        public static extern double et_tower_reference_baseline_value(Tower tower);

        [DllImport(Lib, CallingConvention = CC)]
        public static extern void et_patient_baseline_init(ref PatientBaseline b);

        [DllImport(Lib, CallingConvention = CC)]
        public static extern EtError et_derive_personal_R0(ref PatientBaseline b,
            Tower tower, int fallbackAllowed, out double r0Out);

        [DllImport(Lib, CallingConvention = CC)]
        public static extern int et_pair_index(int i, int j);

        [DllImport(Lib, CallingConvention = CC)]
        public static extern EtError et_compute_multifold_signature(
            ref PatientBaseline b, int fallbackAllowed, ref MultifoldSignatureNative outSig);

        [DllImport(Lib, CallingConvention = CC, CharSet = CharSet.Ansi)]
        public static extern IntPtr et_manifold_state_name(ManifoldState s);

        [DllImport(Lib, CallingConvention = CC, CharSet = CharSet.Ansi)]
        public static extern IntPtr et_incoherence_level_name(IncoherenceLevel l);

        [DllImport(Lib, CallingConvention = CC)]
        public static extern void et_measurement_init(ref MeasurementNative m);

        [DllImport(Lib, CallingConvention = CC)]
        public static extern void et_finding_init(ref FindingNative f);

        [DllImport(Lib, CallingConvention = CC)]
        public static extern EtError et_classify_measurement(
            ref MeasurementNative m, ref PatientBaseline baseline,
            int fallbackAllowed, ref FindingNative outFinding);

        [DllImport(Lib, CallingConvention = CC)]
        public static extern EtError et_generate_findings(
            [In] MeasurementNative[] measurements, int measurementCount,
            ref PatientBaseline baseline, int fallbackAllowed,
            out IntPtr findingsOut, out int countOut);

        [DllImport(Lib, CallingConvention = CC)]
        public static extern void et_free_findings(IntPtr findings, int count);

        [DllImport(Lib, CallingConvention = CC)]
        public static extern double et_severity_score_raw(double absEpsCents, int d,
            double wNormSq, double wNormSqMax, int cascadeDepth, int nMax);

        [DllImport(Lib, CallingConvention = CC)]
        public static extern double et_severity_score_pct(double raw);

        [DllImport(Lib, CallingConvention = CC)]
        public static extern double et_severity_score_max_raw();

        [DllImport(Lib, CallingConvention = CC)]
        public static extern ManifoldState et_classify_state(double absEpsCents, int d, double tightness);

        [DllImport(Lib, CallingConvention = CC)]
        public static extern IncoherenceLevel et_classify_incoherence_level(
            ManifoldState state, double absEpsCents, int d, int cascadeDepth, double multifoldScalar);
    }

    // ------------------------------------------------------------------------
    // Public managed facade
    // ------------------------------------------------------------------------
    public static class EtMedLib
    {
        public static string ErrorString(EtError err)
            => Marshal.PtrToStringAnsi(NativeMethods.et_error_string(err)) ?? "";

        public static ulong FallbackCount()
            => NativeMethods.et_fallback_count().ToUInt64();

        public static void ResetFallbackCount()
            => NativeMethods.et_reset_fallback_count();

        public static Projection ProjectReal(double r, int n)
        {
            var p = new Projection();
            var e = NativeMethods.et_project_real(r, n, ref p);
            if (e != EtError.Ok) throw new EtMedException(e);
            return p;
        }

        public static Elegance EleganceScore(double r, int n, int maxDenom)
        {
            var el = new Elegance();
            var e = NativeMethods.et_elegance_score(r, n, maxDenom, ref el);
            if (e != EtError.Ok) throw new EtMedException(e);
            return el;
        }

        public static double MagicalImpedance(int d)
            => NativeMethods.et_magical_impedance(d, NativeMethods.EtSStates, NativeMethods.EtA0LocalEm);

        public static string TowerName(Tower t)
            => Marshal.PtrToStringAnsi(NativeMethods.et_tower_name(t)) ?? "";

        public static double TowerDefaultR0(Tower t)
            => NativeMethods.et_tower_default_R0(t);

        public static int TowerResolution(Tower t)
            => NativeMethods.et_tower_resolution(t);

        public static MultifoldSignature ComputeMultifoldSignature(PatientBaseline baseline, bool allowFallback = true)
        {
            var n = new MultifoldSignatureNative();
            var p = baseline;
            var err = NativeMethods.et_compute_multifold_signature(
                ref p, allowFallback ? 1 : 0, ref n);
            if (err != EtError.Ok) throw new EtMedException(err);
            return MultifoldSignature.FromNative(n);
        }

        public static List<Finding> GenerateFindings(IEnumerable<Measurement> measurements,
                                                     PatientBaseline baseline,
                                                     bool allowFallback = true)
        {
            var list = new List<Measurement>(measurements);
            var natArr = new MeasurementNative[list.Count];
            for (int i = 0; i < list.Count; ++i) natArr[i] = list[i].ToNative();

            var bl = baseline;
            IntPtr ptr = IntPtr.Zero;
            int count = 0;
            var err = NativeMethods.et_generate_findings(
                natArr, natArr.Length,
                ref bl, allowFallback ? 1 : 0,
                out ptr, out count);
            if (err != EtError.Ok)
            {
                if (ptr != IntPtr.Zero) NativeMethods.et_free_findings(ptr, count);
                throw new EtMedException(err);
            }

            var results = new List<Finding>(count);
            int sz = Marshal.SizeOf<FindingNative>();
            for (int i = 0; i < count; ++i)
            {
                var fn = Marshal.PtrToStructure<FindingNative>(ptr + i * sz);
                results.Add(Finding.FromNative(fn));
            }
            NativeMethods.et_free_findings(ptr, count);
            return results;
        }

        public static int PalindromeD(int nMod12) => NativeMethods.et_palindrome_d(nMod12);
        public static double Shimmer(int n)        => NativeMethods.et_shimmer(n);
        public static double SeverityScoreRaw(double absEps, int d, double wSq, double wSqMax,
                                              int cascade, int nMax)
            => NativeMethods.et_severity_score_raw(absEps, d, wSq, wSqMax, cascade, nMax);
        public static double SeverityScorePct(double raw) => NativeMethods.et_severity_score_pct(raw);
    }

    public class EtMedException : Exception
    {
        public EtError Code { get; }
        public EtMedException(EtError code)
            : base($"libet_med error {(int)code}: {EtMedLib.ErrorString(code)}")
        { Code = code; }
    }
}
