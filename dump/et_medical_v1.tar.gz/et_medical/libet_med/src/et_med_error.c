/* ============================================================================
 * et_med_error.c — Error model and fallback logging
 * ----------------------------------------------------------------------------
 *  Rule 33: every fallback path MUST be logged via the internal _et_error()
 *  channel. Silent fallbacks are a category-1 error (Identification failure:
 *  the system loses identity if it cannot account for its own state).
 *
 *  This file exposes:
 *    - the public et_error_string() / et_set_log_callback() / counters
 *    - the internal _et_error() macro+function used everywhere in the lib
 * ========================================================================= */
#include "libet_med.h"
#include "et_med_internal.h"

#include <stddef.h>
#include <string.h>

static et_log_fn g_log_fn        = NULL;
static void*     g_log_user_data = NULL;
static size_t    g_fallback_count = 0;

LIBET_MED_API const char* et_error_string(et_error_t err) {
    /* Subsumption: each error code IS a particular state in the Manifold State
     * lattice over the library's own internal D-structure. The string table
     * is one-to-one with the enum and is verified by ET_STATIC_ASSERT below. */
    switch (err) {
        case ET_OK:                              return "ok";
        case ET_ERR_INVALID_RATIO:               return "invalid ratio (r must be > 0 and finite)";
        case ET_ERR_INVALID_N:                   return "invalid lattice resolution N";
        case ET_ERR_INVALID_ARG:                 return "invalid argument (NULL or out-of-range)";
        case ET_ERR_OUT_OF_MEMORY:               return "out of memory";
        case ET_ERR_UNKNOWN_TOWER:               return "unknown tower id";
        case ET_ERR_INCOMPLETE_BASELINE:         return "incomplete patient baseline";
        case ET_ERR_FALLBACK_USED:               return "fallback path was used (informational)";
        case ET_ERR_CASCADE_STABILITY_EXCEEDED:  return "cascade stability ceiling exceeded";
        case ET_ERR_OFF_LATTICE:                 return "projection is off-lattice (annihilation boundary)";
        case ET_ERR_NUMERIC:                     return "numerical error (NaN or Inf produced)";
        case ET_ERR_LAST: /* fallthrough */
        default:                                 return "unknown error";
    }
}

LIBET_MED_API void et_set_log_callback(et_log_fn fn, void* user_data) {
    g_log_fn = fn;
    g_log_user_data = user_data;
}

LIBET_MED_API et_log_fn et_get_log_callback(void) {
    return g_log_fn;
}

LIBET_MED_API size_t et_fallback_count(void) {
    return g_fallback_count;
}

LIBET_MED_API void et_reset_fallback_count(void) {
    g_fallback_count = 0;
}

/* Internal entry point used by _et_error() macro in et_med_internal.h.
 * Always increments the counter; invokes user callback if set. Never aborts
 * (fatal=false everywhere in this library — fatal=true would be reserved for
 * Identification-Principle violations that cannot be recovered). */
void _et_error_impl(et_error_t err, const char* file, int line,
                    const char* func, const char* message) {
    g_fallback_count += 1;
    if (g_log_fn != NULL) {
        g_log_fn(err, file, line, func,
                 message != NULL ? message : "",
                 g_log_user_data);
    }
}
