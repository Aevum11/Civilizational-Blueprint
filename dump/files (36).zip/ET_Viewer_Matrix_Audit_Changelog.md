# ET Viewer Matrix — Stage 15 Audit Changelog

**Audit Date:** July 15, 2026  
**Source File:** `ET_Viewer_Matrix_14_Stage15__4_.html`  
**Methodology:** ET Three Tools (Identification Principle · Descriptor Gap Principle · Subsumption Law)  
**Auditor:** Claude (directed by Mike / Aevum Defluo)

---

## ET Three Tools Application

### Identification Principle — P-D-T Decomposition of the Audit

| Primitive | Identification |
|---|---|
| **P** | The ET Viewer Matrix HTML document — 21,220 lines, ~1 MB, containing CSS, HTML body, and 15,736 lines of JavaScript |
| **D** | Every rendering pipeline, CSS variable, HTML structure tag, JavaScript function, event handler, and data-processing algorithm within the document |
| **T** | The browser's HTML parser, CSS cascade, and JavaScript engine traversing the document to produce the rendered viewer |

### Descriptor Gap Principle — Applied to Every Issue

Each issue below is a **gap** — a missing or incorrect Descriptor — identified by testing the model (the viewer) against expected behavior and tracing the resulting error to its root cause.

### Subsumption Law — Completeness Criterion

The audit is complete when every feature of the document has been examined against the rendering pipeline without remainder. This audit covers: HTML tag structure, CSS variable coverage, JavaScript data correctness, memory management, performance characteristics, and documentation accuracy.

---

## Issues Found & Fixes Applied

### FIX #1 — Missing `</tbody>` in Formats Matrix Table (CRITICAL)

**Gap:** `D_gap_tbody_close` — the `<tbody>` tag at line 14833 was never closed.

**Root Cause:** The WELCOME_MD string literal contains a raw HTML `<table>` with 101 rows. The `<tbody>` at line 14833 had no matching `</tbody>` before the `</table>` at line 15575.

**Impact:** Without `</tbody>`, the browser's HTML parser auto-closes the element at unpredictable points during DOM construction. When `marked.parse()` processes the WELCOME_MD content, the malformed HTML causes the parser to corrupt the DOM tree — downstream content after the table (§3 Navigation, §4 Keyboard Shortcuts, §5 Features, etc.) is swallowed into the auto-closed table or rendered inside incorrect parent elements. This is the **primary root cause** of the "documents only render part of the document" symptom Mike reported.

**Fix:** Added `</tbody>` immediately before `</table>` at line 15575.

**Verification:** Tag balance check confirmed: `<tbody>` opens=1, `</tbody>` closes=1 (was 0). All 6 tag types now balanced.

---

### FIX #2 — `escHtml()` Does Not Escape Single Quotes (HIGH)

**Gap:** `D_gap_single_quote_escape` — the `escHtml()` utility escapes `&`, `<`, `>`, `"` but omits `'` (apostrophe/single quote).

**Root Cause:** All SQLite sidebar `onclick` handlers use single-quote JS string delimiters wrapping `escHtml()` output:
```js
onclick="App.sqliteBrowseTable('${escHtml(tabId)}','${escHtml(tableName)}',0)"
```

A table name containing an apostrophe (e.g., `user's_data`) produces:
```html
onclick="App.sqliteBrowseTable('t1','user's_data',0)"
```
The unescaped `'` terminates the JS string literal, causing a syntax error that silently breaks the click handler.

**Impact:** Any SQLite database with table/view/index names containing apostrophes has broken sidebar navigation — clicks do nothing. Affects 9 separate `onclick` handler sites across 3 functions.

**Fix:** Added `.replace(/'/g,'&#39;')` to `escHtml()`.

**Verification:** All 9 `onclick` sites now produce valid JS when table names contain single quotes.

---

### FIX #3 — Signed Integer Handling in `_StreamingSQLiteReader._parseRecord()` (HIGH)

**Gap:** `D_gap_signed_integer` — SQLite serial types 2–6 are signed twos-complement integers, but `_be()` reads unsigned values. Only serial type 1 (8-bit) had sign extension.

**Root Cause:** The `_be()` method reads big-endian bytes as an unsigned integer via `r = r * 256 + byte`. For serial types 2–6, negative values display as large positive numbers. Example: -1 stored as a 4-byte integer (serial type 4) = `0xFFFFFFFF` = 4294967295 displayed instead of -1.

**Impact:** Every negative value in 2-byte, 3-byte, 4-byte, 6-byte, and 8-byte integer columns displays incorrectly. This is a **data correctness** failure affecting any SQLite database with negative numbers.

**Fix:** Added proper twos-complement sign extension for serial types 2–6. For 8-byte integers (serial type 6), added split-half reading with `Number.isSafeInteger()` check — values exceeding `2^53` are pushed as strings to prevent silent precision loss.

**Verification:** Unit tests for all serial types confirm: -1, -128, -2147483648, 32767, and 2^53-1 all produce correct values.

---

### FIX #4 — `countRows()` Parses ALL Rows Just to Count Them (PERFORMANCE)

**Gap:** `D_gap_count_efficiency` — `countRows()` called `_scan()` with maxRows=10,000,000, fully parsing every row into objects, then returned `.length`.

**Root Cause:** The B-tree page header already contains the cell count at bytes `ho+3..ho+4`. For leaf pages, this IS the row count. For interior pages, summing child leaf counts gives the total. No payload parsing is needed.

**Impact:** Opening a 100k-row table allocates 100k parsed record objects, reads every B-tree page from disk, and can freeze the browser for seconds. For multi-million-row databases, the browser tab may crash from memory exhaustion.

**Fix:** Replaced with `_countScan()` — a lightweight B-tree traversal that reads only page headers (2 bytes per leaf page) without parsing any cell payload. Memory usage: O(tree depth) instead of O(row count).

**Verification:** Structural analysis confirms correct handling of page types 0x0D (leaf) and 0x05 (interior), including page 1's 100-byte header offset.

---

### FIX #5 — `scanTable()` Over-reads All Rows Before the Page Offset (PERFORMANCE)

**Gap:** `D_gap_scan_overread` — `scanTable(rootPage, limit, offset)` called `_scan(rootPage, rc, offset+limit, 0)` then sliced to `rc.rows.slice(offset, offset+limit)`.

**Root Cause:** For page 50 (offset=10,000, limit=200), this reads and fully parses ALL 10,200 rows then discards the first 10,000. Each subsequent page scans progressively more data.

**Impact:** Pagination becomes progressively slower with higher page numbers. At page 500 (offset=100,000), 100,200 rows are parsed and 100,000 discarded.

**Fix:** Pass `offset` directly to `_scan()` as the `skip` parameter. The `_scan` collector already has skip logic — it increments `rowCollector.skipped` without parsing payload for skipped rows. Only `limit` rows are materialized.

**Verification:** `_scan` skip logic confirmed: skipped rows increment counter without calling `_fullPayload` or `_parseRecord`.

---

### FIX #6 — Column Name Extraction Breaks on `DECIMAL(10,2)` (MEDIUM)

**Gap:** `D_gap_comma_in_typespec` — column name extraction from `CREATE TABLE` SQL used `m[1].split(',')`, which splits on ALL commas including those inside type specifications.

**Root Cause:** `DECIMAL(10,2)` splits into `"DECIMAL(10"` and `"2)"` — producing a phantom extra column and a corrupted column name.

**Impact:** Any table with column types containing commas (DECIMAL, NUMERIC, VARCHAR with multiple parameters) displays incorrect column headers in the streaming SQLite viewer. `PRIMARY KEY (col1, col2)` constraint clauses are also mishandled.

**Fix:** Replaced with a parenthesis-depth-aware comma splitter that only splits at depth 0. Constraint clauses (`PRIMARY KEY`, `FOREIGN KEY`, `UNIQUE`, `CHECK`, `CONSTRAINT`) are filtered out regardless of nesting.

**Verification:** Unit tests confirm correct parsing of `DECIMAL(10,2)`, `VARCHAR(50,100)`, `PRIMARY KEY (a, b)`, and `FOREIGN KEY (x) REFERENCES other(y)`.

---

### FIX #7 — Documentation Inaccuracy: "sql.js WASM" → Streaming Reader (LOW)

**Gap:** `D_gap_renderer_description` — the Formats Matrix table said "sql.js WASM binary reader" but the code uses `_StreamingSQLiteReader` — a zero-dependency, pure-JS B-tree page reader.

**Root Cause:** The WASM engine was replaced by the streaming reader in a prior iteration, but the documentation string was not updated.

**Fix:** Updated to "streaming B-tree page reader (zero WASM)".

---

### FIX #8 — `--pre-border-w` CSS Variable Missing from Light Mode (LOW)

**Gap:** `D_gap_pre_border_w_light` — defined in `:root` (dark mode, 2px) but not in `body.light-mode`.

**Root Cause:** The variable inherits from `:root` in light mode (same value), so the visual result is correct. However, the ET Descriptor Gap Principle requires every dark-mode descriptor to have an explicit light-mode counterpart — implicit inheritance is a gap.

**Fix:** Added `--pre-border-w: 2px;` to the `body.light-mode` block.

---

### FIX #9 — SQLite State Not Cleaned Up on Tab Close (MEMORY LEAK)

**Gap:** `D_gap_sqlite_close_leak` — `closeTab()` cleans up PDF state, Comic blob URLs, and EPUB blob URLs, but does NOT clean up `_sqliteState`.

**Root Cause:** The `_StreamingSQLiteReader` holds a reference to the `File` object. Without cleanup, closing a SQLite tab leaves the reader, the file reference, and the schema data in the `_sqliteState` Map indefinitely — a memory leak proportional to the schema size. The `reloadTab()` function correctly calls `_sqliteState.delete()`, but `closeTab()` omits it entirely.

**Impact:** Each opened-then-closed SQLite database leaks its state for the lifetime of the browser tab.

**Fix:** Added SQLite cleanup block in `closeTab()` that closes the WASM database (if present) and deletes the state map entry, with Telemetry trace logging.

---

### FIX #10 — SQLite Scroll Position Not Preserved on Tab Switch (UX)

**Gap:** `D_gap_sqlite_scroll_save` — `activateTab()`'s `_scrollEl()` resolver checks for `.epub-reader-pane`, `.subtab-pane.active`, and `[id^="pdfcontainer_"]`, but does NOT check for `.sqlite-data-pane`.

**Root Cause:** SQLite tabs scroll inside `.sqlite-data-pane` (overflow:auto). The outer `.sqlite-outer` has `overflow:hidden`, so the panel's own `scrollTop` is permanently 0. Without including `.sqlite-data-pane` in the resolver, switching away from a SQLite tab and back resets the scroll position to the top.

**Impact:** Browsing a large table, switching to another tab, and switching back loses the scroll position — user must manually scroll back to their previous location.

**Fix:** Added `.sqlite-data-pane` to the `_scrollEl()` chain in `activateTab()`, matching the existing handling in `reloadTab()`.

---

### FIX #11 — EPUB Prev/Next Navigation Breaks with Multiple EPUB Tabs (MULTI-TAB)

**Gap:** `D_gap_epub_global_nav` — EPUB chapter navigation used global `window._epubPrevChapter` and `window._epubNextChapter` functions that get overwritten when a second EPUB tab opens.

**Root Cause:** `createEPUBTab()` assigns `window._epubPrevChapter = function(tabId) { ... }` in a closure that captures the local `id` and `currentChapterIdx` variables. When a second EPUB opens, these global functions are overwritten with new closures that capture the *second* tab's `id`. The first tab's onclick handlers still call the global function with the old tabId, but the guard `if (tabId !== id) return` (where `id` is now the second tab's id) causes an immediate return — the first tab's Prev/Next buttons silently do nothing.

**Impact:** Opening 2+ EPUB files simultaneously breaks navigation on all but the most recently opened EPUB tab. Prev/Next buttons become dead — no error, no feedback, just silent failure.

**Fix:** Three-part fix:
1. Removed the global `window._epubPrevChapter` and `window._epubNextChapter` assignments entirely.
2. Store `currentChapterIdx` on the tab object as `tab._epubCurrentChapterIdx` (was only in closure scope).
3. Changed onclick handlers to use `tabById('${id}')._epubRenderChapter(...)` directly — the same pattern already used by the TOC item click handlers (which worked correctly).

**Verification:** Each tab's navigation is now fully independent — `tabById()` resolves the correct tab object regardless of how many EPUBs are open.

---

## Continued Audit — Subsystems Examined (No Issues Found)

The following subsystems were read in full, traced through their P-D-T pipelines, and verified against the Three Tools methodology. No actionable issues were found:

### PDF Renderer (lines 11766–12428)
- **Blob URL range loading** — no full-file ArrayBuffer allocation; any file size supported
- **IntersectionObserver lazy rendering** — root:null, proper unobserve/re-observe cycle
- **Offscreen canvas atomic swap** — eliminates flash-of-blank during re-render
- **Render task serialization** — prevents concurrent page.render() corruption
- **DPR-aware viewport** — separate renderViewport (scale×dpr) vs CSS viewport (scale)
- **Text layer coordinate transform** — Y-axis flip, rotation support, proper font sizing
- **State cleanup in closeTab** — observers disconnected, blob URL revoked

### DOCX/ODT Renderers (lines 9547–9815)
- **Streaming ZIP reader** — Central Directory only, entries fetched on demand
- **_buildLeanZip** — excludes media/embeddings to reduce memory for mammoth.js
- **XML sub-tab lazy highlighting** — HLJS applied on first open, not at load time
- **Metadata extraction** — core.xml parsing for DOCX, meta.xml for ODT

### DOC Binary Parser (lines 8710–9005)
- **CFB/OLE2 sector traversal** — DIFAT chain, FAT chain, mini-FAT chain all correct
- **FIB navigation** — variable-length sections (csw, cslw, cbRgFcLcb) properly walked
- **Clx piece table traversal** — ANSI vs Unicode pieces, compressed byte offset (fc>>1)
- **Summary Information stream** — OLE property set format parsing

### Spreadsheet Renderer (lines 9815–10146)
- **SheetJS integration** — three-CDN fallback chain
- **Merge cell handling** — coverSet for skipped cells, mergeMap for colspan/rowspan
- **Row/column caps** — 2000 rows × 500 columns with overflow notice
- **Formula mode toggle** — switches between formatted values and raw formulas
- **Sheet tab bar** — multi-sheet navigation with proper escaping

### CSV Renderer (lines 8279–8430)
- **RFC 4180 state machine parser** — correct double-quote escaping
- **Numeric column detection** — 80% threshold, right-alignment
- **5000-row cap** — documented, with overflow notice

### RTF Renderer (lines 7476–8268)
- **Full tokenizer** — group open/close, control words, hex escapes, text literals
- **Destination group skipping** — fonttbl, colortbl, stylesheet, pict, etc.
- **CP1252 supplement** — 0x80–0x9F mapped to correct Unicode codepoints
- **Formatting state stack** — bold, italic, underline, strikethrough with push/pop

### Plain Text Renderer (lines 7147–7406)
- **Code fence extraction BEFORE math protection** — prevents $-sign corruption in code
- **ASCII art detection** — box-drawing chars, separator lines, pipe tables
- **Block continuation heuristics** — indented content bridging, single-blank bridging
- **Header detection** — # H1, ## H2, ### H3 with visual styling
- **Inline formatting** — bold, italic, inline code, horizontal rules

### CBZ/CBR Comic Viewers (lines 10888–11410)
- **CBZ streaming** — _StreamingZipReader, lazy IntersectionObserver per page
- **CBR dual-path** — ZIP-based CBRs use streaming reader; genuine RAR uses libarchive WASM
- **Natural sort** — localeCompare({numeric:true}) for correct page ordering
- **Blob URL revocation** — cleanup on tab close prevents memory leaks

### JSX/TSX Renderer (lines 12433–13218)
- **Component/hook/export detection** — regex-based descriptor lattice analysis
- **Import map** — named/default imports parsed from source
- **Live render iframe** — Babel transpilation in sandboxed iframe
- **Structure panel** — collapsible grid of sections

### Search Infrastructure (lines 14477–14730)
- **Per-tab-type target resolution** — PDF, spreadsheet, EPUB, MD each has correct root
- **Hit rail** — proportional tick marks on scroll track
- **mark.js exclusions** — MathJax elements excluded from marking

### Print Pipeline (lines 17140–17600)
- **Deferred visual system** — wide elements moved to landscape pages
- **Flow table detection** — tables paginate across pages without zoom shrinkage
- **Column protection** — short-content columns get nowrap to prevent crushing
- **Atomic cleanup** — all DOM mutations reversed in correct order

### Offline Mode (lines 18255–19700+)
- **Service worker-free** — downloads all CDN resources into blob URLs
- **Single-file generation** — produces self-contained HTML with embedded libraries
- **Connectivity badge** — status bar indicator for online/offline/cached state

### HLJS Grammar Coverage
- **47 unique grammars** available: 22 from common bundle, 19 from CDN, 6 inline-registered
- **100 file extensions** in FILE_TYPE_MAP — all have corresponding LANG_BADGE_MAP entries
- **All code-type extensions** have HLJS_LANG_MAP routing to an available grammar

### CSS Variable Coverage
- **All 26 CSS custom properties** defined in `:root` now have explicit `body.light-mode` counterparts (after FIX #8)
- **No orphaned variables** — every `var(--name)` reference resolves to a defined property

---

## Known Limitations Documented (Not Fixed — By Design)

### WITHOUT ROWID Tables

The `_StreamingSQLiteReader._scan()` handles table B-tree pages (types 0x0D leaf, 0x05 interior) but not index B-tree pages (types 0x0A leaf, 0x02 interior). WITHOUT ROWID tables use index B-trees, so they silently return 0 rows. This is a fundamental limitation of the streaming reader's current scope.

### View Column Names

Views have `CREATE VIEW ... AS SELECT ...` SQL which does not match the `\((.+)\)/s` column extraction regex. The fallback produces generic names (`col0`, `col1`, ...). This is a known UX limitation of the streaming reader vs. the sql.js WASM engine (which could execute `PRAGMA table_info(view_name)`).

### Large Integer Precision

JavaScript Numbers can only exactly represent integers up to 2^53. SQLite 8-byte integers can range to ±2^63. The fix (FIX #3) pushes values outside the safe range as strings, which prevents silent precision loss but means they can't be used in arithmetic on the client side.

---

## Summary

| # | Severity | Category | Description |
|---|----------|----------|-------------|
| 1 | **CRITICAL** | HTML Structure | Missing `</tbody>` — root cause of partial document rendering |
| 2 | **HIGH** | Security/UX | `escHtml()` missing single-quote escape — breaks SQLite navigation |
| 3 | **HIGH** | Data Correctness | Signed integers display as large positive numbers |
| 4 | **PERFORMANCE** | Efficiency | `countRows()` parses all rows — O(N) → O(tree depth) |
| 5 | **PERFORMANCE** | Efficiency | `scanTable()` over-reads all preceding rows |
| 6 | **MEDIUM** | Data Correctness | Column parser breaks on `DECIMAL(10,2)` |
| 7 | **LOW** | Documentation | "sql.js WASM" label outdated |
| 8 | **LOW** | CSS Completeness | `--pre-border-w` missing from light mode |
| 9 | **MEMORY** | Leak | SQLite state not cleaned up on tab close |
| 10 | **UX** | Scroll | SQLite scroll position lost on tab switch |
| 11 | **MULTI-TAB** | EPUB Navigation | Prev/Next buttons break with 2+ EPUB tabs open |

**Total issues found:** 11  
**Total issues fixed:** 11  
**Subsystems fully audited:** 18 (PDF, DOCX, ODT, DOC, XLSX/XLS/ODS, CSV, RTF, TXT, Code, JSX/TSX, SQLite, CBZ, CBR, EPUB, Search, Print, Offline, HLJS Grammars)  
**Zero regressions:** All existing functionality preserved (Rule 2, Rule 24)

---

*"For every exception there is an exception, except the exception."*  
*P ∘ D ∘ T = E*
