"""
Deep investigation part 2 — isotope chains, pairing, mass defect, shell effects.
"""
import sys
sys.path.insert(0, '/home/claude')
import mpmath
mpmath.mp.dps = 130
from collections import defaultdict

from sempaevum_atomic_viewer import (
    build_atomic_particles, compute_particle_projections,
    sempaevum_project_mp, N, et_gcd, MU_OVER_ME_STR
)

print("Loading and projecting...")
particles = build_atomic_particles(measured_only=True)
results = compute_particle_projections(particles)
print(f"Projected {len(results)} isotopes\n")

# Build lookups
by_ZA = {}
by_Z = defaultdict(list)
by_A = defaultdict(list)
for r in results:
    Z, A_val = r.get("Z", 0), r.get("A", 0)
    by_ZA[(Z, A_val)] = r
    by_Z[Z].append(r)
    by_A[A_val].append(r)

# ================================================================
print("=" * 80)
print("1. EVEN-EVEN vs ODD-ODD vs MIXED — Pairing on the lattice")
print("   Does nuclear pairing (the strongest short-range nuclear effect)")
print("   manifest in lattice statistics?")
print("=" * 80)

categories = {"EE": [], "EO": [], "OE": [], "OO": []}
for r in results:
    Z, A_val = r.get("Z", 0), r.get("A", 0)
    N_val = A_val - Z
    key = ("E" if Z % 2 == 0 else "O") + ("E" if N_val % 2 == 0 else "O")
    categories[key].append(r)

print(f"\n  {'Type':>4s} | {'Count':>6s} | {'Avg |ε|':>10s} | {'Median |ε|':>10s} | {'Nat/Total':>10s} | d_r=12 %")
print(f"  {'-'*4}-+-{'-'*6}-+-{'-'*10}-+-{'-'*10}-+-{'-'*10}-+-{'-'*8}")
for key in ["EE", "EO", "OE", "OO"]:
    items = categories[key]
    eps_list = sorted([abs(r["eps_mp_12"]) for r in items])
    avg_eps = sum(eps_list) / len(eps_list) if eps_list else mpmath.mpf(0)
    med_eps = eps_list[len(eps_list)//2] if eps_list else mpmath.mpf(0)
    nat = sum(1 for r in items if r.get("is_naturally_occurring"))
    d12_pct = 100 * sum(1 for r in items if r["d_r_12"] == 12) / len(items) if items else 0
    label = {"EE":"Even-Even","EO":"Even Z Odd N","OE":"Odd Z Even N","OO":"Odd-Odd"}[key]
    print(f"  {label:>14s} | {len(items):>6d} | {mpmath.nstr(avg_eps,6):>10s} | {mpmath.nstr(med_eps,6):>10s} | {nat:>4d}/{len(items):<5d} | {d12_pct:>5.1f}%")

# ================================================================
print("\n" + "=" * 80)
print("2. ISOTOPE CHAINS — How does adding a neutron change the lattice?")
print("   Δk per neutron for selected elements")
print("=" * 80)

for Z_target, name in [(6,"Carbon"), (26,"Iron"), (50,"Tin"), (82,"Lead")]:
    chain = sorted(by_Z[Z_target], key=lambda r: r.get("A", 0))
    if len(chain) < 3:
        continue
    print(f"\n  {name} (Z={Z_target}) — {len(chain)} isotopes:")
    prev_k = None
    prev_A = None
    for r in chain:
        A_val = r.get("A", 0)
        k = r["k_r_12"]
        d = r["d_r_12"]
        eps = r["eps_mp_12"]
        nat = "★" if r.get("is_naturally_occurring") else " "
        dk = f"Δk={k - prev_k:+d}" if prev_k is not None else "      "
        # Check for magic N
        N_val = A_val - Z_target
        magic = " ◆" if N_val in {2,8,20,28,50,82,126} else "  "
        print(f"    A={A_val:>3d} (N={N_val:>3d}){magic} k={k:>3d} d_r={d:>2d} ε={mpmath.nstr(eps,6):>10s}¢ {dk} {nat}")
        prev_k = k
        prev_A = A_val

# ================================================================
print("\n" + "=" * 80)
print("3. ISOBAR ANALYSIS — Within a mass number, ε orders by stability")
print("   Testing: does the most stable isobar have the smallest |ε|?")
print("=" * 80)

# For each mass number with 5+ isotopes, find the most stable (highest BE/A)
# and check if it also has the smallest |ε|
isobar_stability_match = 0
isobar_total_tested = 0

for A_val in sorted(by_A.keys()):
    group = by_A[A_val]
    if len(group) < 5:
        continue
    
    # Parse BE/A as mpmath for comparison
    be_data = []
    for r in group:
        be_str = r.get("binding_energy_per_A_keV", "0")
        if isinstance(be_str, str) and be_str.replace('.','').replace('-','').isdigit():
            be = mpmath.mpf(be_str)
            be_data.append((r, be, abs(r["eps_mp_12"])))
    
    if len(be_data) < 5:
        continue
    
    # Sort by BE/A descending (most stable first)
    be_sorted = sorted(be_data, key=lambda x: -x[1])
    # Sort by |ε| ascending (most lattice-exact first)
    eps_sorted = sorted(be_data, key=lambda x: x[2])
    
    most_stable = be_sorted[0][0]
    most_exact = eps_sorted[0][0]
    
    isobar_total_tested += 1
    if most_stable["symbol"] == most_exact["symbol"]:
        isobar_stability_match += 1

# Print results for specific mass numbers
print(f"\n  Across {isobar_total_tested} isobars (A with 5+ isotopes):")
print(f"  Most stable = most lattice-exact: {isobar_stability_match}/{isobar_total_tested} "
      f"({100*isobar_stability_match/isobar_total_tested:.1f}%)")
print(f"  Random expectation: ~{100/10:.0f}% (1 in ~10 isotopes per mass number)")

# Show detailed examples
for A_show in [56, 100, 150, 192, 208]:
    group = by_A.get(A_show, [])
    if not group:
        continue
    
    be_data = []
    for r in group:
        be_str = r.get("binding_energy_per_A_keV", "0")
        if isinstance(be_str, str) and be_str.replace('.','').replace('-','').isdigit():
            be = mpmath.mpf(be_str)
            be_data.append((r, be))
    
    if not be_data:
        continue
    
    be_sorted = sorted(be_data, key=lambda x: -x[1])
    print(f"\n  A={A_show} ({len(be_sorted)} isotopes):")
    for r, be in be_sorted[:5]:
        nat = "★" if r.get("is_naturally_occurring") else " "
        print(f"    {r['symbol']:>8s} {nat} BE/A={mpmath.nstr(be,8)} keV  "
              f"|ε|={mpmath.nstr(abs(r['eps_mp_12']),8):>12s}¢  d_r={r['d_r_12']}")

# ================================================================
print("\n" + "=" * 80)
print("4. SHELL CLOSURE JUMPS — Does |ε| change abruptly at magic N?")
print("   Looking at Sn (Z=50) chain — the element with the most stable isotopes")
print("=" * 80)

sn_chain = sorted(by_Z.get(50, []), key=lambda r: r.get("A", 0))
if sn_chain:
    print(f"\n  Tin (Z=50): {len(sn_chain)} isotopes, magic N = 50, 82")
    for r in sn_chain:
        A_val = r.get("A", 0)
        N_val = A_val - 50
        k = r["k_r_12"]
        d = r["d_r_12"]
        eps = abs(r["eps_mp_12"])
        nat = "★" if r.get("is_naturally_occurring") else " "
        magic = " ◆MAGIC" if N_val in {50, 82} else ""
        be_str = r.get("binding_energy_per_A_keV", "0")
        be = mpmath.nstr(mpmath.mpf(be_str), 7) if be_str != "0" else "?"
        print(f"    A={A_val:>3d} N={N_val:>3d}{magic:>8s} k={k:>3d} d_r={d:>2d} "
              f"|ε|={mpmath.nstr(eps,6):>10s}¢ BE/A={be} {nat}")

# ================================================================
print("\n" + "=" * 80)
print("5. MASS DEFECT PROJECTED — The mass defect Δm = Z·m_p + N·m_n - M")
print("   as a ratio, projected onto the lattice")
print("=" * 80)

m_p_str = "1.007276466621"  # proton mass in u
m_n_str = "1.008664915600"  # neutron mass in u

print("\n  Most tightly bound (largest mass defect fraction Δm/M):")
defect_data = []
for r in results:
    Z = r.get("Z", 0)
    A_val = r.get("A", 0)
    N_val = A_val - Z
    mass_str = r.get("Ar_str", r.get("mass_str", ""))
    if not mass_str or Z == 0:
        continue
    
    M = mpmath.mpf(mass_str)
    constituent = Z * mpmath.mpf(m_p_str) + N_val * mpmath.mpf(m_n_str)
    defect = constituent - M
    defect_fraction = defect / M
    
    # Project the defect fraction itself
    if defect_fraction > 0:
        proj = sempaevum_project_mp(mpmath.nstr(defect_fraction, 30), N)
        defect_data.append((r, defect_fraction, proj))

# Sort by defect fraction descending (most bound)
defect_data.sort(key=lambda x: -x[1])

print(f"  {'Isotope':>10s} | {'Δm/M':>14s} | {'k_defect':>8s} | {'d_defect':>8s} | {'ε_defect':>10s}")
for r, frac, proj in defect_data[:15]:
    nat = "★" if r.get("is_naturally_occurring") else " "
    print(f"  {r['symbol']:>10s} {nat}| {mpmath.nstr(frac, 10):>14s} | {proj[0]:>8d} | {proj[1]:>8d} | {mpmath.nstr(proj[2], 6):>10s}¢")

# ================================================================
print("\n" + "=" * 80)
print("6. ADJACENT ISOBARS — The β-decay chain on the lattice")
print("   When A=100 nucleus β-decays, how does it move on the lattice?")
print("=" * 80)

for A_show in [100, 131, 192]:
    group = sorted(by_A.get(A_show, []), key=lambda r: r.get("Z", 0))
    if len(group) < 4:
        continue
    print(f"\n  A={A_show} β-decay chain (Z increasing = more proton-rich):")
    for r in group:
        Z = r.get("Z", 0)
        N_val = A_show - Z
        eps = r["eps_mp_12"]
        be_str = r.get("binding_energy_per_A_keV", "0")
        nat = "★" if r.get("is_naturally_occurring") else " "
        magic_z = " ◆Z" if Z in {2,8,20,28,50,82} else "   "
        magic_n = " ◆N" if N_val in {2,8,20,28,50,82,126} else "   "
        print(f"    {r['symbol']:>8s} (Z={Z:>3d},N={N_val:>3d}){magic_z}{magic_n} {nat} "
              f"k={r['k_r_12']:>3d} d_r={r['d_r_12']:>2d} ε={mpmath.nstr(eps,8):>12s}¢")

# ================================================================
print("\n" + "=" * 80)
print("7. Δk PER NEUTRON — Is there a characteristic lattice step?")
print("   For each element, compute the average Δk when adding one neutron")
print("=" * 80)

dk_by_Z = {}
for Z_val in sorted(by_Z.keys()):
    if Z_val == 0:
        continue
    chain = sorted(by_Z[Z_val], key=lambda r: r.get("A", 0))
    if len(chain) < 3:
        continue
    dks = []
    for i in range(1, len(chain)):
        A_prev = chain[i-1].get("A", 0)
        A_curr = chain[i].get("A", 0)
        if A_curr - A_prev == 1:  # Adjacent isotopes only
            dk = chain[i]["k_r_12"] - chain[i-1]["k_r_12"]
            dks.append(dk)
    if dks:
        avg_dk = sum(dks) / len(dks)
        dk_by_Z[Z_val] = (avg_dk, len(dks), chain[0].get("symbol","?").split("-")[0])

print(f"\n  Average Δk per neutron addition (adjacent isotopes only):")
print(f"  {'Z':>3s} {'El':>3s} | {'Avg Δk':>8s} | {'Pairs':>5s} | Notes")
for Z_val in sorted(dk_by_Z.keys()):
    avg, count, sym = dk_by_Z[Z_val]
    # For heavy elements, each neutron adds ~1u ≈ 1/A fraction of mass
    # Δk ≈ 12 × log₂(1 + 1/A) ≈ 12/(A × ln2) ≈ 17.3/A
    A_typical = Z_val * 2.5  # rough estimate
    expected_dk = 17.3 / A_typical if A_typical > 0 else 0
    print(f"  {Z_val:>3d} {sym:>3s} | {avg:>8.4f} | {count:>5d} | expected≈{expected_dk:.3f}")
    if Z_val > 30 and Z_val % 20 != 0 and Z_val != 50 and Z_val != 82:
        continue  # Skip for brevity, show only selected

print("\n" + "=" * 80)
print("DEEP INVESTIGATION COMPLETE")
print("=" * 80)
