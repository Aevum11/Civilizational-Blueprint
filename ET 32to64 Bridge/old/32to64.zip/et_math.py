"""
et_bridge/et_math.py
Exception Theory Mathematics for ET32 Bridge
Derived entirely from P ∘ D ∘ T = E

Author: Derived from Michael James Muller's Exception Theory
All values derived from first principles — zero external axioms.

PDT Derivation Chain:
  P = substrate (address spaces, memory regions — infinite potential)
  D = descriptor (constraints: 32-bit register set, 4GB limit, API set)
  T = traverser (executing thread, program counter, CPU state)
  E = exception (grounded, zero-variance computation)

The 32-bit constraint is a D-constraint on P, not a P-limit.
  D_32 = {addr ≤ 0xFFFFFFFF}           (the gap Descriptor)
  P_full = {0,1}^* = ∪_{n} {0,1}^n    (infinite, Ω-cardinality)
  Bridge removes D_32 and adds D_bridge which projects into P_full.

Key derivations:
  S = 12          (Manifold Symmetry = 3 primitives × 4 logic states)
  K = 2/3         (Koide ratio = binding stability threshold)
  V = 1/12        (base variance = 1/S)
  ħ_d = 2^N = 4096 (digital action quantum, N=12)
  Buffer = ħ_d × S = 49152 bytes (full-resolution IPC buffer)
  Timeout = 3/2 = 1/K × 1000 ms = 1500 ms
  Retry = S = 12
  Queue depth = S² = 144
  Handle space = S × ħ_d = 12 × 4096 = 49152 distinct handles
  Max handles = 2^32 / S = 357,913,941 (handles per bridge)
"""

import struct
import hashlib
import time
import math
from typing import Optional, Tuple, Dict, Any

# =============================================================================
# ET UNIVERSAL CONSTANTS — DERIVED FROM P ∘ D ∘ T = E
# =============================================================================

# Manifold symmetry: 3 primitives × 4 logic states (unbound, bound, potential, actual)
S: int = 12

# Koide binding stability threshold: 2/3 (triadic alignment minimum)
K: float = 2.0 / 3.0

# Base variance: the fundamental descriptor of the lattice
V_BASE: float = 1.0 / 12.0

# Digital action quantum: ħ_digital = 2^N = 2^12 = 4096 bytes
# Instantiation: page size, LZW dict, HTTP/2 HPACK (ET Digital Manifold §IIIB)
DIGITAL_ACTION_QUANTUM: int = 4096  # 2^12 bytes

# Full-resolution IPC buffer: ħ_digital × S (all 12 manifold positions active)
IPC_BUFFER_SIZE: int = DIGITAL_ACTION_QUANTUM * S  # 49152 bytes

# ET Packet header size: 4 × 12 = 48 bytes (four 12-byte PDT sections)
PDT_HEADER_SIZE: int = 4 * S  # 48 bytes

# Connection timeout: 1/K × 1000 ms = 1500 ms (Koide reciprocal in milliseconds)
CONN_TIMEOUT_MS: int = int((1.0 / K) * 1000)  # 1500 ms

# Retry count = S = 12 (manifold symmetry governs reconnect attempts)
RETRY_COUNT: int = S

# Queue depth = S² = 144 (squared manifold symmetry for deep buffering)
QUEUE_DEPTH: int = S * S  # 144

# Handle space offset: all bridge handles begin above the 2GB user barrier
# 0x80000001 to 0xFFFFF000 = the high 32-bit half reserved for bridge handles
# Low bit set to distinguish from real 32-bit pointers (which are typically 4-byte aligned)
HANDLE_BASE: int = 0x80000001
HANDLE_MAX: int = 0xFFFFF000

# 64-bit memory regions start above 4GB to guarantee no collision with 32-bit space
ADDR64_BASE: int = 0x100000000  # 4GB + 1: the first address unreachable by 32-bit

# Named pipe name pattern — manifold symmetry baked into the name format
# "ET" + PDT → E (12-char base + pid)
PIPE_NAME_TEMPLATE: str = r"\\.\pipe\ET32_PDT_{pid}"

# Shared memory name template
SHMEM_NAME_TEMPLATE: str = "ET32_SHMEM_{pid}"

# Koide fill ratio for IPC queue before flush
KOIDE_FILL: float = K  # flush at 2/3 full

# =============================================================================
# THE 12 COMMAND FAMILIES — ET LATTICE POSITIONS
# =============================================================================
# Each family maps to a specific sublattice position (d=1 through d=12).
# The classification follows the ET Digital Manifold lattice topology (Secret 26):
# Topology of the operation determines its sublattice family.

class CmdFamily:
    """
    The 12 command families corresponding to ET lattice positions.
    Derived from: Manifold Symmetry S=12, one family per lattice generator.
    
    ET Digital Manifold lattice placement:
      d=1  → octave  → binary, fundamental   → MEMORY_BASIC
      d=2  → fifth   → linear pathway        → MEMORY_MAP
      d=3  → fourth  → cubic, 5-stage        → THREAD_OPS
      d=4  → M3rd    → temporal persistence  → DLL_OPS
      d=5  → m3rd    → partial binding       → PROCESS_OPS
      d=6  → tritone → hexadic mediation     → REGISTRY_OPS
      d=7  → P5alt   → resonant coupling     → GRAPHICS_OPS
      d=8  → m6th    → octave²               → FILE_OPS
      d=9  → M6th    → composite             → SYNC_OPS
      d=10 → m7th    → secondary resonance   → NET_OPS
      d=11 → M7th    → near-full-resolution  → PYTHON_OPS
      d=12 → full-r  → manifold-complete     → COMPOUND_OPS
    """
    MEMORY_BASIC   = 1   # d=1: VirtualAlloc/Free/Protect — octave, fundamental
    MEMORY_MAP     = 2   # d=2: CreateFileMapping, MapViewOfFile — linear
    THREAD_OPS     = 3   # d=3: CreateThread, SuspendThread — cubic 5-stage
    DLL_OPS        = 4   # d=4: LoadLibrary, GetProcAddress — temporal
    PROCESS_OPS    = 5   # d=5: CreateProcess, OpenProcess — partial
    REGISTRY_OPS   = 6   # d=6: RegOpenKey (WOW64-bypass) — hexadic
    GRAPHICS_OPS   = 7   # d=7: VRAM alloc, GPU compute — resonant
    FILE_OPS       = 8   # d=8: Large file, >4GB mmap — secondary octave
    SYNC_OPS       = 9   # d=9: Events, mutexes, semaphores — composite
    NET_OPS        = 10  # d=10: Socket extension — secondary resonance
    PYTHON_OPS     = 11  # d=11: 64-bit Python embed — near-full
    COMPOUND_OPS   = 12  # d=12: Multi-step compound — manifold-complete

    # Inverse map: family → lattice denomination
    FAMILY_TO_D: Dict[int, str] = {
        1: "d=1 octave (fundamental)",
        2: "d=2 fifth (linear)",
        3: "d=3 fourth (cubic)",
        4: "d=4 major-third (temporal)",
        5: "d=5 minor-third (partial)",
        6: "d=6 tritone (hexadic)",
        7: "d=7 resonant-fifth (coupling)",
        8: "d=8 minor-sixth (octave²)",
        9: "d=9 major-sixth (composite)",
        10: "d=10 minor-seventh (secondary)",
        11: "d=11 major-seventh (near-full)",
        12: "d=12 full-resolution (manifold-complete)",
    }

# Specific command codes within each family:
class CmdCode:
    """Specific operation codes within each CmdFamily."""
    # MEMORY_BASIC (d=1)
    VIRT_ALLOC         = 0x01  # VirtualAlloc equivalent
    VIRT_FREE          = 0x02  # VirtualFree equivalent
    VIRT_PROTECT       = 0x03  # VirtualProtect equivalent
    VIRT_QUERY         = 0x04  # VirtualQuery equivalent
    HEAP_ALLOC         = 0x05  # HeapAlloc equivalent
    HEAP_FREE          = 0x06  # HeapFree equivalent
    READ_MEM           = 0x07  # ReadProcessMemory (cross-dim)
    WRITE_MEM          = 0x08  # WriteProcessMemory (cross-dim)

    # MEMORY_MAP (d=2)
    FILE_MAP_CREATE    = 0x11  # CreateFileMapping
    FILE_MAP_VIEW      = 0x12  # MapViewOfFile
    FILE_MAP_CLOSE     = 0x13  # CloseHandle for mapping
    FILE_MAP_FLUSH     = 0x14  # FlushViewOfFile

    # THREAD_OPS (d=3)
    THREAD_CREATE      = 0x21  # CreateThread
    THREAD_SUSPEND     = 0x22  # SuspendThread
    THREAD_RESUME      = 0x23  # ResumeThread
    THREAD_TERMINATE   = 0x24  # TerminateThread
    THREAD_CONTEXT     = 0x25  # GetThreadContext (64-bit context)

    # DLL_OPS (d=4)
    DLL_LOAD           = 0x31  # LoadLibrary (64-bit DLL)
    DLL_FREE           = 0x32  # FreeLibrary
    DLL_GETPROC        = 0x33  # GetProcAddress (64-bit)
    DLL_CALL           = 0x34  # Direct call to 64-bit DLL function
    DLL_LIST           = 0x35  # List loaded 64-bit DLLs

    # PROCESS_OPS (d=5)
    PROC_CREATE        = 0x41  # CreateProcess (64-bit child)
    PROC_OPEN          = 0x42  # OpenProcess
    PROC_INJECT        = 0x43  # Inject 64-bit DLL
    PROC_INFO          = 0x44  # GetSystemInfo (64-bit)

    # REGISTRY_OPS (d=6)
    REG_OPEN64         = 0x51  # Open 64-bit registry key
    REG_QUERY64        = 0x52  # Query 64-bit registry value
    REG_SET64          = 0x53  # Set 64-bit registry value
    REG_ENUM64         = 0x54  # Enumerate 64-bit registry

    # GRAPHICS_OPS (d=7)
    GPU_ALLOC_VRAM     = 0x61  # Allocate VRAM (can exceed 4GB)
    GPU_FREE_VRAM      = 0x62  # Free VRAM
    GPU_MAP_VRAM       = 0x63  # Map VRAM to 64-bit address
    GPU_SUBMIT         = 0x64  # Submit GPU command buffer
    GPU_QUERY_INFO     = 0x65  # Query GPU/adapter info

    # FILE_OPS (d=8)
    FILE_OPEN_LARGE    = 0x71  # Open file > 4GB
    FILE_MAP_LARGE     = 0x72  # Map region of large file
    FILE_SEEK_LARGE    = 0x73  # Seek to 64-bit offset
    FILE_READ_LARGE    = 0x74  # Read from 64-bit offset
    FILE_WRITE_LARGE   = 0x75  # Write to 64-bit offset

    # SYNC_OPS (d=9)
    SYNC_CREATE_EVENT  = 0x81
    SYNC_SIGNAL        = 0x82
    SYNC_WAIT          = 0x83
    SYNC_MUTEX         = 0x84

    # NET_OPS (d=10)
    NET_SOCKET64       = 0x91  # Socket with 64-bit recv buffer
    NET_BIND64         = 0x92
    NET_SEND64         = 0x93
    NET_RECV64         = 0x94

    # PYTHON_OPS (d=11)
    PY_INIT            = 0xA1  # Initialize 64-bit Python
    PY_EXEC            = 0xA2  # Execute Python code in 64-bit
    PY_IMPORT          = 0xA3  # Import 64-bit Python module
    PY_CALL            = 0xA4  # Call 64-bit Python function
    PY_GETOBJ          = 0xA5  # Get Python object

    # COMPOUND_OPS (d=12)
    COMPOUND_BATCH     = 0xB1  # Batch multiple operations
    COMPOUND_ATOMIC    = 0xB2  # Atomic multi-step operation
    COMPOUND_ROLLBACK  = 0xB3  # Rollback compound operation

    # Control codes
    CTRL_PING          = 0xF0  # Liveness check
    CTRL_HANDSHAKE     = 0xF1  # Initial handshake
    CTRL_SHUTDOWN      = 0xF2  # Graceful shutdown
    CTRL_STATUS        = 0xF3  # Get bridge status
    CTRL_ACK           = 0xFE  # Acknowledgement
    CTRL_ERR           = 0xFF  # Error response

# =============================================================================
# ET PACKET STRUCTURE — P ∘ D ∘ T = E
# =============================================================================

class ETPacket:
    """
    The ET protocol packet. Every bridge message is a complete P∘D∘T = E instance.
    
    Header layout (48 bytes = 4 × S, four 12-byte sections):
    
    P-Section (16 bytes) — the substrate tokens:
      source_pid  : uint32  [4]  — which process sends
      dest_pid    : uint32  [4]  — which process receives
      space_token : uint64  [8]  — 64-bit address space token
    
    D-Section (16 bytes) — the descriptor:
      cmd_family  : uint8   [1]  — 1-12 lattice position
      cmd_code    : uint8   [1]  — specific command
      flags       : uint16  [2]  — control flags
      arg_count   : uint32  [4]  — number of arguments
      payload_len : uint64  [8]  — byte count of payload
    
    T-Section (16 bytes) — the traverser:
      sequence    : uint32  [4]  — monotonic sequence counter
      timestamp   : uint64  [8]  — microseconds since epoch
      checksum    : uint32  [4]  — CRC32 of header+payload
    
    Total header: 48 bytes. Payload follows immediately.
    V(packet) = 0 iff all three sections are present and checksum validates.
    """

    STRUCT_P = struct.Struct("<IIQ")   # source_pid, dest_pid, space_token
    STRUCT_D = struct.Struct("<BBHIq") # cmd_family, cmd_code, flags, arg_count, payload_len (signed for error codes)
    STRUCT_T = struct.Struct("<IQI")   # sequence, timestamp, checksum

    HEADER_SIZE: int = PDT_HEADER_SIZE  # 48 bytes

    # Flags
    FLAG_REQUEST    = 0x0001
    FLAG_RESPONSE   = 0x0002
    FLAG_ERROR      = 0x0004
    FLAG_COMPRESSED = 0x0008
    FLAG_EXTENDED   = 0x0010  # payload contains 64-bit addresses

    def __init__(
        self,
        source_pid: int,
        dest_pid: int,
        space_token: int,
        cmd_family: int,
        cmd_code: int,
        flags: int,
        arg_count: int,
        payload: bytes,
        sequence: int = 0,
    ):
        self.source_pid  = source_pid
        self.dest_pid    = dest_pid
        self.space_token = space_token
        self.cmd_family  = cmd_family
        self.cmd_code    = cmd_code
        self.flags       = flags
        self.arg_count   = arg_count
        self.payload     = payload
        self.sequence    = sequence
        self.timestamp   = int(time.monotonic_ns() // 1000)  # microseconds
        self.checksum    = 0  # computed during serialise()

    def serialise(self) -> bytes:
        """Serialise to bytes. Computes checksum before encoding T-section."""
        payload_len = len(self.payload)
        p_bytes = self.STRUCT_P.pack(self.source_pid, self.dest_pid, self.space_token)
        d_bytes = self.STRUCT_D.pack(
            self.cmd_family, self.cmd_code, self.flags,
            self.arg_count, payload_len
        )
        # Compute checksum over P-section + D-section + payload (not T, to allow T to carry the CRC)
        crc_data = p_bytes + d_bytes + self.payload
        self.checksum = int.from_bytes(
            hashlib.blake2b(crc_data, digest_size=4).digest(), "little"
        )
        t_bytes = self.STRUCT_T.pack(self.sequence, self.timestamp, self.checksum)
        return p_bytes + d_bytes + t_bytes + self.payload

    @classmethod
    def deserialise(cls, data: bytes) -> Optional["ETPacket"]:
        """
        Deserialise from bytes. Returns None if header incomplete or CRC fails.
        V(packet) = 0 iff valid.
        """
        if len(data) < cls.HEADER_SIZE:
            return None
        p_off = 0
        p_sz  = cls.STRUCT_P.size         # 16
        d_off = p_sz
        d_sz  = cls.STRUCT_D.size         # 16
        t_off = d_off + d_sz
        t_sz  = cls.STRUCT_T.size         # 16

        source_pid, dest_pid, space_token = cls.STRUCT_P.unpack_from(data, p_off)
        cmd_family, cmd_code, flags, arg_count, payload_len = cls.STRUCT_D.unpack_from(data, d_off)
        sequence, timestamp, checksum = cls.STRUCT_T.unpack_from(data, t_off)

        if payload_len < 0 or len(data) < cls.HEADER_SIZE + payload_len:
            return None

        payload = data[cls.HEADER_SIZE : cls.HEADER_SIZE + payload_len]

        # Verify checksum (CRC over P + D + payload)
        crc_data = data[p_off:p_off + p_sz] + data[d_off:d_off + d_sz] + payload
        expected_crc = int.from_bytes(
            hashlib.blake2b(crc_data, digest_size=4).digest(), "little"
        )
        if checksum != expected_crc:
            return None  # incoherent packet — {P,T} without valid D

        pkt = cls.__new__(cls)
        pkt.source_pid  = source_pid
        pkt.dest_pid    = dest_pid
        pkt.space_token = space_token
        pkt.cmd_family  = cmd_family
        pkt.cmd_code    = cmd_code
        pkt.flags       = flags
        pkt.arg_count   = arg_count
        pkt.payload     = payload
        pkt.sequence    = sequence
        pkt.timestamp   = timestamp
        pkt.checksum    = checksum
        return pkt

    def variance(self) -> float:
        """
        V(E) for this packet.
        V(E) = 0 iff the packet is a complete, grounded Exception (P∘D∘T all present and valid).
        V(E) > 0 indicates incomplete binding.

        Derived from ET base variance V = 1/S = 1/12:
          If cmd_family is valid (1..12): adds 0 to variance
          If cmd_family is 0 or > 12: adds V_BASE (unbound Descriptor)
          If payload is empty for a non-control command: adds V_BASE (T without D-content)
          If checksum is 0 (not yet computed): adds V_BASE (unsubstantiated T)
        """
        v = 0.0
        if not (1 <= self.cmd_family <= S):
            v += V_BASE
        if self.cmd_code == 0 and self.cmd_family != 0:
            v += V_BASE
        if len(self.payload) == 0 and self.cmd_family not in (
            CmdCode.CTRL_PING, CmdCode.CTRL_ACK, CmdCode.CTRL_SHUTDOWN
        ):
            v += V_BASE
        if self.checksum == 0:
            v += V_BASE
        return v

    def is_grounded(self) -> bool:
        """True iff V(E) == 0.0 — the packet is a full Exception."""
        return self.variance() == 0.0

    def __repr__(self) -> str:
        d_name = CmdFamily.FAMILY_TO_D.get(self.cmd_family, f"unknown({self.cmd_family})")
        return (
            f"ETPacket(seq={self.sequence}, "
            f"family={d_name}, cmd=0x{self.cmd_code:02X}, "
            f"payload={len(self.payload)}B, V={self.variance():.4f})"
        )


# =============================================================================
# ET ADDRESS HANDLE MATHEMATICS
# =============================================================================

class ETHandleMath:
    """
    Mathematical foundation of the ET 32-bit → 64-bit handle table.

    The 32-bit D-constraint is:
        D_32: addr ∈ {0x00000000 .. 0xFFFFFFFF}

    P_full is infinite (Ω cardinality). The constraint D_32 is an artificial
    finite binding — a Descriptor, not a P-limit.

    The bridge projects P_full → P_32 and back:

    Forward projection (P_full → P_32, lossy for addr ≥ 4GB):
        π₃₂(addr₆₄) = addr₆₄ & 0xFFFFFFFF      if addr₆₄ < ADDR64_BASE
                      = HANDLE_BASE + slot       if addr₆₄ ≥ ADDR64_BASE

    Reverse expansion (P_32 → P_full, perfect via handle table):
        Π₆₄(handle) = table[handle]              if handle ≥ HANDLE_BASE
                    = handle                      if handle < HANDLE_BASE

    Variance of the mapping:
        V(π₃₂ ∘ Π₆₄) = 0 for all handle addresses (exact round-trip)
        V(π₃₂ ∘ Π₆₄) = 0 for addresses < 4GB   (identity mapping)

    Handle space layout (ET-derived):
        HANDLE_BASE = 0x80000001  (high 32-bit half, odd = D-flag for bridge handle)
        HANDLE_MAX  = 0xFFFFF000  (leaves 0xFFFFF001..0xFFFFFFFF for system use)
        Capacity    = (HANDLE_MAX - HANDLE_BASE) / SLOT_STRIDE
        SLOT_STRIDE = S = 12       (one slot per lattice position)
        Capacity    = (0xFFFFF000 - 0x80000001) / 12 ≈ 178,956,970 handles
    """

    SLOT_STRIDE: int = S  # 12 — one stride per lattice position

    @staticmethod
    def is_bridge_handle(value: int) -> bool:
        """True iff value is in the bridge handle range (not a real 32-bit address)."""
        return HANDLE_BASE <= value <= HANDLE_MAX

    @staticmethod
    def project_32(addr64: int) -> int:
        """
        π₃₂: Project a 64-bit address to a 32-bit representation.
        For low addresses (< 4GB): identity.
        For high addresses: returns HANDLE_BASE marker (slot must be determined by handle table).
        """
        if addr64 < ADDR64_BASE:
            return addr64 & 0xFFFFFFFF
        # Must go through handle table — caller is responsible for slot allocation
        return HANDLE_BASE  # sentinel: caller replaces with real slot handle

    @staticmethod
    def expand_64(handle: int, table: Dict[int, int]) -> Optional[int]:
        """
        Π₆₄: Expand a 32-bit handle to its 64-bit address via the handle table.
        Returns None if handle is not in the table (incoherent state).
        """
        if not ETHandleMath.is_bridge_handle(handle):
            return handle  # passthrough for regular 32-bit addresses
        return table.get(handle)

    @staticmethod
    def slot_to_handle(slot_index: int) -> int:
        """
        Convert a slot index to a bridge handle.
        Derived from ET manifold: handle = HANDLE_BASE + slot × SLOT_STRIDE
        The SLOT_STRIDE = S = 12 ensures each handle maps to a unique lattice position.
        """
        return HANDLE_BASE + slot_index * ETHandleMath.SLOT_STRIDE

    @staticmethod
    def handle_to_slot(handle: int) -> int:
        """Inverse of slot_to_handle."""
        return (handle - HANDLE_BASE) // ETHandleMath.SLOT_STRIDE

    @staticmethod
    def handle_lattice_position(handle: int) -> int:
        """
        Returns the lattice position (1..12) of a bridge handle.
        The position is determined by (handle - HANDLE_BASE) mod S + 1.
        This encodes which command family "owns" this handle.
        """
        return ((handle - HANDLE_BASE) % S) + 1

    @staticmethod
    def compute_variance(addr64: int, reconstructed: int) -> float:
        """
        V(bridge) = |addr64 - reconstructed| / 2^64
        For a perfect round-trip: V = 0.
        """
        if addr64 == reconstructed:
            return 0.0
        return abs(addr64 - reconstructed) / (2 ** 64)


# =============================================================================
# ET LATTICE ROUTING
# =============================================================================

class ETLatticeRouter:
    """
    Routes operations to the correct command family based on ET lattice position.

    The Descriptor Gap Principle tells us: a gap in the 32-bit descriptor set
    IS the 64-bit descriptor we need. We identify which lattice position the
    gap occupies and route accordingly.

    Each Windows API function maps to a lattice position based on its topology:
    - Closed cycles (memory create/free) → d=1 (octave)
    - Linear pathways (memory mapping) → d=2 (fifth)
    - Pipeline structures (threads) → d=3 (fourth/cubic)
    - Temporal dependencies (DLL load) → d=4
    - etc.

    The routing table is the complete Descriptor set of the bridge.
    """

    # API name → (cmd_family, cmd_code) mapping
    API_ROUTING_TABLE: Dict[str, Tuple[int, int]] = {
        # Memory operations — d=1 (octave, closed cycles, fundamental)
        "VirtualAlloc":     (CmdFamily.MEMORY_BASIC, CmdCode.VIRT_ALLOC),
        "VirtualAllocEx":   (CmdFamily.MEMORY_BASIC, CmdCode.VIRT_ALLOC),
        "VirtualFree":      (CmdFamily.MEMORY_BASIC, CmdCode.VIRT_FREE),
        "VirtualFreeEx":    (CmdFamily.MEMORY_BASIC, CmdCode.VIRT_FREE),
        "VirtualProtect":   (CmdFamily.MEMORY_BASIC, CmdCode.VIRT_PROTECT),
        "VirtualQuery":     (CmdFamily.MEMORY_BASIC, CmdCode.VIRT_QUERY),
        "HeapAlloc":        (CmdFamily.MEMORY_BASIC, CmdCode.HEAP_ALLOC),
        "HeapFree":         (CmdFamily.MEMORY_BASIC, CmdCode.HEAP_FREE),
        "HeapReAlloc":      (CmdFamily.MEMORY_BASIC, CmdCode.HEAP_ALLOC),
        "GlobalAlloc":      (CmdFamily.MEMORY_BASIC, CmdCode.HEAP_ALLOC),
        "LocalAlloc":       (CmdFamily.MEMORY_BASIC, CmdCode.HEAP_ALLOC),
        "malloc":           (CmdFamily.MEMORY_BASIC, CmdCode.HEAP_ALLOC),
        "calloc":           (CmdFamily.MEMORY_BASIC, CmdCode.HEAP_ALLOC),
        "realloc":          (CmdFamily.MEMORY_BASIC, CmdCode.HEAP_ALLOC),

        # Memory mapping — d=2 (fifth, linear pathways)
        "CreateFileMappingA":  (CmdFamily.MEMORY_MAP, CmdCode.FILE_MAP_CREATE),
        "CreateFileMappingW":  (CmdFamily.MEMORY_MAP, CmdCode.FILE_MAP_CREATE),
        "MapViewOfFile":       (CmdFamily.MEMORY_MAP, CmdCode.FILE_MAP_VIEW),
        "MapViewOfFileEx":     (CmdFamily.MEMORY_MAP, CmdCode.FILE_MAP_VIEW),
        "UnmapViewOfFile":     (CmdFamily.MEMORY_MAP, CmdCode.FILE_MAP_CLOSE),
        "FlushViewOfFile":     (CmdFamily.MEMORY_MAP, CmdCode.FILE_MAP_FLUSH),

        # Thread operations — d=3 (fourth, cubic 5-stage pipeline)
        "CreateThread":        (CmdFamily.THREAD_OPS, CmdCode.THREAD_CREATE),
        "CreateRemoteThread":  (CmdFamily.THREAD_OPS, CmdCode.THREAD_CREATE),
        "SuspendThread":       (CmdFamily.THREAD_OPS, CmdCode.THREAD_SUSPEND),
        "ResumeThread":        (CmdFamily.THREAD_OPS, CmdCode.THREAD_RESUME),
        "TerminateThread":     (CmdFamily.THREAD_OPS, CmdCode.THREAD_TERMINATE),
        "GetThreadContext":    (CmdFamily.THREAD_OPS, CmdCode.THREAD_CONTEXT),

        # DLL operations — d=4 (major third, temporal persistence)
        "LoadLibraryA":        (CmdFamily.DLL_OPS, CmdCode.DLL_LOAD),
        "LoadLibraryW":        (CmdFamily.DLL_OPS, CmdCode.DLL_LOAD),
        "LoadLibraryExA":      (CmdFamily.DLL_OPS, CmdCode.DLL_LOAD),
        "LoadLibraryExW":      (CmdFamily.DLL_OPS, CmdCode.DLL_LOAD),
        "FreeLibrary":         (CmdFamily.DLL_OPS, CmdCode.DLL_FREE),
        "GetProcAddress":      (CmdFamily.DLL_OPS, CmdCode.DLL_GETPROC),

        # Process operations — d=5 (minor third)
        "CreateProcessA":      (CmdFamily.PROCESS_OPS, CmdCode.PROC_CREATE),
        "CreateProcessW":      (CmdFamily.PROCESS_OPS, CmdCode.PROC_CREATE),
        "OpenProcess":         (CmdFamily.PROCESS_OPS, CmdCode.PROC_OPEN),
        "GetSystemInfo":       (CmdFamily.PROCESS_OPS, CmdCode.PROC_INFO),

        # Registry — d=6 (tritone, WOW64 redirect bypass)
        "RegOpenKeyExA":       (CmdFamily.REGISTRY_OPS, CmdCode.REG_OPEN64),
        "RegOpenKeyExW":       (CmdFamily.REGISTRY_OPS, CmdCode.REG_OPEN64),
        "RegQueryValueExA":    (CmdFamily.REGISTRY_OPS, CmdCode.REG_QUERY64),
        "RegQueryValueExW":    (CmdFamily.REGISTRY_OPS, CmdCode.REG_QUERY64),
        "RegSetValueExA":      (CmdFamily.REGISTRY_OPS, CmdCode.REG_SET64),
        "RegSetValueExW":      (CmdFamily.REGISTRY_OPS, CmdCode.REG_SET64),

        # Graphics — d=7 (resonant coupling)
        "Direct3DCreate9":     (CmdFamily.GRAPHICS_OPS, CmdCode.GPU_QUERY_INFO),
        "D3D12CreateDevice":   (CmdFamily.GRAPHICS_OPS, CmdCode.GPU_QUERY_INFO),
        "vkCreateDevice":      (CmdFamily.GRAPHICS_OPS, CmdCode.GPU_QUERY_INFO),
        "NvAPI_Initialize":    (CmdFamily.GRAPHICS_OPS, CmdCode.GPU_QUERY_INFO),
        "ADL_Main_Control_Create": (CmdFamily.GRAPHICS_OPS, CmdCode.GPU_QUERY_INFO),

        # File operations — d=8 (octave²)
        "CreateFileA":         (CmdFamily.FILE_OPS, CmdCode.FILE_OPEN_LARGE),
        "CreateFileW":         (CmdFamily.FILE_OPS, CmdCode.FILE_OPEN_LARGE),
        "SetFilePointerEx":    (CmdFamily.FILE_OPS, CmdCode.FILE_SEEK_LARGE),
        "GetFileSizeEx":       (CmdFamily.FILE_OPS, CmdCode.FILE_OPEN_LARGE),
    }

    @classmethod
    def route(cls, api_name: str) -> Optional[Tuple[int, int]]:
        """Return (cmd_family, cmd_code) for an API name, or None if not routed."""
        return cls.API_ROUTING_TABLE.get(api_name)

    @classmethod
    def classify_size(cls, size: int) -> int:
        """
        Classify a memory size request to a lattice position.
        Derived from ET manifold: sizes that exceed 32-bit threshold route to d=1 (fundamental).

        Lattice position of a size:
          size ≤ 2^12 (4KB)  → d=1 (digital action quantum ħ_d)
          size ≤ 2^20 (1MB)  → d=3 (cubic page cluster)
          size ≤ 2^31 (2GB)  → d=6 (standard 32-bit user space)
          size > 2^31         → d=12 (exceeds 32-bit — full-resolution bridge needed)
        """
        if size <= DIGITAL_ACTION_QUANTUM:
            return 1
        elif size <= (1 << 20):
            return 3
        elif size <= (1 << 31):
            return 6
        else:
            return 12  # full-resolution: must bridge to 64-bit

    @classmethod
    def needs_64bit(cls, api_name: str, size: int = 0) -> bool:
        """
        Determine if an API call needs 64-bit extension.
        Uses the Descriptor Gap Principle: if the requested size exceeds the
        32-bit D-constraint, the gap IS the 64-bit descriptor.

        For size-based calls: needs 64-bit if size exceeds 1.5GB (= S/8 × ħ_d²)
        K-threshold: if size > K × (1 << 32) = 2/3 × 4GB ≈ 2.67GB → definitely needs 64-bit
        Koide stability: request within K of the 32-bit limit → bridge activated
        """
        koide_threshold = int(K * (1 << 32))  # 2/3 × 4GB = ~2.86GB
        if size >= koide_threshold:
            return True
        route = cls.route(api_name)
        if route is None:
            return False
        family, _ = route
        # d=12 commands always need 64-bit (manifold-complete)
        return family >= 7  # GPU and above always bridge


# =============================================================================
# ET TIMING AND PERFORMANCE METRICS
# =============================================================================

class ETMetrics:
    """
    ET-derived performance metrics for the bridge.
    
    The bridge's performance is measured using ET variance:
      V(bridge) = latency / (1/K × 1000ms) 
    A well-functioning bridge maintains V(bridge) < V_BASE = 1/12.
    
    When V(bridge) > K = 2/3, the connection is approaching the Incoherence boundary.
    When V(bridge) > 1.0, the bridge has collapsed into Incoherence ({P,T} state).
    """

    def __init__(self):
        self.total_requests: int = 0
        self.successful_requests: int = 0
        self.failed_requests: int = 0
        self.total_latency_us: float = 0.0
        self.bytes_transferred: int = 0
        self.family_counts: Dict[int, int] = {i: 0 for i in range(1, S + 1)}
        self._start_time: float = time.monotonic()

    def record(self, family: int, latency_us: float, success: bool, bytes_count: int = 0):
        self.total_requests += 1
        if success:
            self.successful_requests += 1
        else:
            self.failed_requests += 1
        self.total_latency_us += latency_us
        self.bytes_transferred += bytes_count
        if 1 <= family <= S:
            self.family_counts[family] += 1

    @property
    def mean_latency_us(self) -> float:
        if self.total_requests == 0:
            return 0.0
        return self.total_latency_us / self.total_requests

    @property
    def variance(self) -> float:
        """
        V(bridge) — how close we are to Incoherence.
        V = mean_latency_us / (CONN_TIMEOUT_MS × 1000)
        V < V_BASE (1/12) → excellent
        V < K (2/3)       → stable  
        V >= K            → approaching ∂I (boundary of Incoherence)
        V >= 1.0          → Incoherence
        """
        max_latency_us = CONN_TIMEOUT_MS * 1000  # convert ms to μs
        return self.mean_latency_us / max_latency_us if max_latency_us > 0 else 0.0

    @property
    def stability(self) -> str:
        v = self.variance
        if v < V_BASE:
            return "EXCEPTION"   # V(E) < 1/12 — near-perfect
        elif v < K:
            return "MEDIATION"   # stable bridge state
        elif v < 1.0:
            return "WARNING"     # approaching ∂I
        else:
            return "INCOHERENCE" # bridge collapse

    @property
    def success_rate(self) -> float:
        if self.total_requests == 0:
            return 1.0
        return self.successful_requests / self.total_requests

    @property
    def koide_alignment(self) -> float:
        """
        Koide alignment K_eff = success_rate.
        If K_eff >= K (2/3): bridge is stable.
        If K_eff < K: bridge is unstable — Descriptor Gap exists.
        """
        return self.success_rate

    @property
    def is_stable(self) -> bool:
        return self.koide_alignment >= K

    def runtime_seconds(self) -> float:
        return time.monotonic() - self._start_time

    def throughput_kbps(self) -> float:
        rt = self.runtime_seconds()
        if rt == 0:
            return 0.0
        return (self.bytes_transferred / 1024.0) / rt

    def summary(self) -> Dict[str, Any]:
        return {
            "total_requests": self.total_requests,
            "success_rate": f"{self.success_rate:.4f}",
            "koide_alignment": f"{self.koide_alignment:.4f} (stable: {self.is_stable})",
            "mean_latency_us": f"{self.mean_latency_us:.2f}",
            "variance": f"{self.variance:.6f}",
            "stability": self.stability,
            "throughput_kbps": f"{self.throughput_kbps():.2f}",
            "family_distribution": {
                CmdFamily.FAMILY_TO_D.get(k, str(k)): v
                for k, v in self.family_counts.items()
                if v > 0
            }
        }


# =============================================================================
# ET SERIALISATION HELPERS
# =============================================================================

def pack_args(*args) -> Tuple[bytes, int]:
    """
    Pack a variable argument list into bytes using ET-derived encoding.
    Each argument is prefixed by its type tag and length.

    Type tags (8-bit, derived from ET lattice):
      0x01 = uint32  (d=1, fundamental integer)
      0x02 = uint64  (d=2, extended address)
      0x03 = int32   (d=3, signed integer)
      0x04 = int64   (d=4, signed extended)
      0x05 = float64 (d=5, floating point)
      0x06 = bytes   (d=6, raw data)
      0x07 = str_utf8 (d=7, string)
      0x0C = None    (d=12, null argument)
    """
    buf = bytearray()
    count = 0
    for arg in args:
        if arg is None:
            buf += struct.pack("BB", 0x0C, 0)
        elif isinstance(arg, bool):
            buf += struct.pack("BB", 0x01, 4) + struct.pack("<I", int(arg))
        elif isinstance(arg, int):
            if 0 <= arg <= 0xFFFFFFFF:
                buf += struct.pack("BB", 0x01, 4) + struct.pack("<I", arg)
            else:
                buf += struct.pack("BB", 0x02, 8) + struct.pack("<Q", arg & 0xFFFFFFFFFFFFFFFF)
        elif isinstance(arg, float):
            buf += struct.pack("BB", 0x05, 8) + struct.pack("<d", arg)
        elif isinstance(arg, bytes):
            buf += struct.pack("BB", 0x06, 0) + struct.pack("<I", len(arg)) + arg
        elif isinstance(arg, str):
            encoded = arg.encode("utf-8")
            buf += struct.pack("BB", 0x07, 0) + struct.pack("<I", len(encoded)) + encoded
        else:
            # Fallback: repr as UTF-8 string
            encoded = repr(arg).encode("utf-8")
            buf += struct.pack("BB", 0x07, 0) + struct.pack("<I", len(encoded)) + encoded
        count += 1
    return bytes(buf), count


def unpack_args(data: bytes) -> list:
    """Unpack arguments from bytes. Inverse of pack_args."""
    result = []
    offset = 0
    while offset < len(data):
        if offset + 2 > len(data):
            break
        type_tag, size_hint = struct.unpack_from("BB", data, offset)
        offset += 2
        if type_tag == 0x0C:
            result.append(None)
        elif type_tag == 0x01:
            val, = struct.unpack_from("<I", data, offset)
            offset += 4
            result.append(val)
        elif type_tag == 0x02:
            val, = struct.unpack_from("<Q", data, offset)
            offset += 8
            result.append(val)
        elif type_tag == 0x03:
            val, = struct.unpack_from("<i", data, offset)
            offset += 4
            result.append(val)
        elif type_tag == 0x04:
            val, = struct.unpack_from("<q", data, offset)
            offset += 8
            result.append(val)
        elif type_tag == 0x05:
            val, = struct.unpack_from("<d", data, offset)
            offset += 8
            result.append(val)
        elif type_tag in (0x06, 0x07):
            length, = struct.unpack_from("<I", data, offset)
            offset += 4
            raw = data[offset:offset + length]
            offset += length
            if type_tag == 0x07:
                result.append(raw.decode("utf-8", errors="replace"))
            else:
                result.append(bytes(raw))
        else:
            break
    return result
