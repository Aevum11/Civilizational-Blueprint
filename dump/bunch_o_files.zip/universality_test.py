"""
ULTRATHINK verification for Mike's universality claim:
Can EML + lattice + LCM tower + limits cover "all of mathematics"?

Tests:
1. Non-elementary function (erf) via Taylor limit — does the lattice classify it?
2. The three Sheffer variants' operational sublattice character — do they
   inhabit different ET sublattice families at the operator level?
3. Does K(r) (EML complexity) correlate with first-native-LCM(r) (resolution)?
4. The Gödel edge — what the combined system honestly cannot do.
"""
import math, cmath
from math import gcd, log2, factorial

N = 12

def project(r, Nl=N):
    """Standard ET lattice projection."""
    if r <= 0: return None
    ex = Nl * log2(r)
    k = round(ex)
    g = gcd(abs(k), Nl) if k != 0 else Nl
    d = Nl // g
    eps = (ex - k) * (1200.0 / Nl)
    return dict(k=k, d=d, eps=eps, exact=ex)

# ============================================================
# TEST 1: Non-elementary function via elementary limit
# ============================================================
# erf(x) = (2/√π) · ∫₀ˣ e^(-t²) dt
#       = (2/√π) · Σ (-1)ⁿ · x^(2n+1) / (n! · (2n+1))
# Each partial sum S_N(x) is elementary (finite EML-expressible).
# The limit erf(x) is NOT elementary (Liouville).
# Can the lattice still classify erf(1)?

def erf_partial(x, N):
    """N-th partial sum of erf Taylor series — finite, EML-expressible."""
    c = 2.0 / math.sqrt(math.pi)
    s = 0.0
    for n in range(N + 1):
        s += (-1)**n * x**(2*n+1) / (factorial(n) * (2*n+1))
    return c * s

print("=" * 76)
print("TEST 1: erf(1) via increasing Taylor partial sums — lattice tracking")
print("=" * 76)
print(f"True erf(1) ≈ {math.erf(1):.15f}  (NOT elementary — beyond EML's finite scope)")
print()
print(f"{'N (partial)':>12}  {'S_N(1)':>18}  {'(k, d, ε¢)':>22}  {'|S_N − erf(1)|':>16}")
print("-" * 76)
for N_terms in [0, 1, 2, 3, 5, 10, 20, 50, 100]:
    s = erf_partial(1.0, N_terms)
    if s > 0:
        p = project(s)
        err = abs(s - math.erf(1))
        print(f"{N_terms:>12}  {s:>18.15f}  ({p['k']:>+3}, {p['d']:>2}, {p['eps']:>+7.3f})  {err:>16.3e}")
# Final: converged projection
p_true = project(math.erf(1))
print(f"{'limit':>12}  {math.erf(1):>18.15f}  ({p_true['k']:>+3}, {p_true['d']:>2}, {p_true['eps']:>+7.3f})  (true)")

print()
print("→ Conclusion: each finite EML-expressible partial sum projects onto the")
print("  lattice. The projections CONVERGE to the non-elementary limit's")
print("  projection. This is the Asymptotic Precision Principle in action")
print("  (Three Tools §8.3) — non-elementary functions are reached AS LIMITS")
print("  of EML projections, not as finite EML trees.")

# ============================================================
# TEST 2: The three Sheffer variants — sublattice fingerprint
# ============================================================
# EML:    exp(x) − ln(y)   [subtraction]        constant = 1
# EDL:    exp(x) / ln(y)   [division]           constant = e
# -EML:   ln(x) − exp(y)   [reversed sub]       constant = -∞
#
# Claim: each operator's STRUCTURAL SIGNATURE on the lattice matches a different
# ET sublattice family. Compute the signature as the characteristic ratio the
# operator produces at a symmetric input.

print()
print("=" * 76)
print("TEST 2: The three Sheffer variants — lattice-native operator fingerprint")
print("=" * 76)

# Standard probe: apply each operator with both inputs equal to some x > 1,
# then observe the sublattice family of the result.
# This is analogous to how paper (§5) uses f(x,x) = const to probe operator
# structure. We use x = 2 as a neutral probe (not e, not 1, not special to any).

x = 2.0
eml_val = math.exp(x) - math.log(x)          # EML at x,x
edl_val = math.exp(x) / math.log(x)          # EDL at x,x
rev_val = math.log(x) - math.exp(x)          # -EML at x,x (reversed)

print(f"Probe: x = y = {x}")
print()
for name, operator_form, constant, value in [
    ("EML", "exp(x) − ln(y)", "1 (D-identity)", eml_val),
    ("EDL", "exp(x) / ln(y)", "e (T-fixed)",    edl_val),
    ("-EML", "ln(x) − exp(y)", "-∞ (P-edge)",   rev_val),
]:
    if value > 0:
        p = project(value)
        print(f"{name:<6} {operator_form:<18} constant={constant:<16}")
        print(f"       probe_value = {value:>18.10f}   (k={p['k']:>+3}, d={p['d']:>2}, ε={p['eps']:>+7.2f}¢)")
    else:
        p_abs = project(abs(value))
        print(f"{name:<6} {operator_form:<18} constant={constant:<16}")
        print(f"       probe_value = {value:>18.10f}  (negative — |value|: k={p_abs['k']:>+3}, d={p_abs['d']:>2}, ε={p_abs['eps']:>+7.2f}¢)")
    print()

# ============================================================
# TEST 3: Sublattice character of the operator-structural choices
# ============================================================
# Structural level: what's the sublattice of the basic operation used?
# Subtraction: algebraically, the tritone / half-period involution (a-b, b-a differ by sign)
# Division: algebraically, the octave-class (a/b, b/a are reciprocal — d=1 identity class)
# Paper's Table 4 gives direct-search K values: subtraction K=11, division K=17.
print("=" * 76)
print("TEST 3: Sublattice fingerprint of basic ARITHMETIC operations (paper Table 4 K)")
print("=" * 76)
print(f"{'operation':<24}  {'K_direct':>8}  {'K projected (k, d, ε¢)':>32}  {'family reading'}")
print("-" * 92)
ops = [
    ("subtraction (x-y)",    11,  "tritone pivot / CPT-reflect"),
    ("addition (x+y)",       19,  "T-axis weak-class (quartic)"),
    ("multiplication (x×y)", 17,  "full-resolution EM"),
    ("division (x/y)",       17,  "full-resolution EM"),
    ("negation (-x)",        15,  "full-resolution EM"),
    ("reciprocal (1/x)",     15,  "full-resolution EM"),
    ("squaring (x²)",        17,  "full-resolution EM"),
]
for op, K, rdg in ops:
    p = project(K)
    print(f"{op:<24}  {K:>8}  ({p['k']:>+3}, {p['d']:>2}, {p['eps']:>+7.2f})  {rdg}")

# ============================================================
# TEST 4: K vs first-native-LCM correlation (Investigation §8.2 conjecture)
# ============================================================
# For each elementary constant, if we have its direct-search K (from paper
# Table 4) and its first-native-LCM level, does a correlation appear?
print()
print("=" * 76)
print("TEST 4: K (EML complexity) vs first-native LCM — empirical pattern")
print("=" * 76)

# A constant c requires its simplest-form denominator d to be native at some LCM.
# For integers: d=1 → 12ET native
# For rational p/q: depends on prime factorization of q
# For transcendentals: require higher resolution

LCM_landmarks = [(12, "12ET"), (24, "24ET"), (36, "36ET"), (60, "60ET"),
                  (84, "84ET"), (132, "132ET"), (420, "420ET"), (2520, "2520ET"),
                  (27720, "27720ET")]

def first_native(val, max_lcm=27720, tol_cents=1.0):
    """Find smallest LCM-tower resolution at which val projects within tol_cents."""
    for Nl, label in LCM_landmarks:
        p = project(val, Nl)
        if abs(p['eps']) < tol_cents:
            return Nl, label, p
    return None, None, None

print(f"\n{'constant':<14}  {'value':>18}  {'K direct':>8}  {'first-native LCM':>20}  {'struct family'}")
print("-" * 92)
catalog = [
    ("1",         1.0,                1),
    ("e",         math.e,             3),
    ("2",         2.0,                19),
    ("-1",        1.0,                17),  # |·|=1; paper has -1 at K=17
    ("1/2",       0.5,                29),
    ("-1/2",      0.5,                31),
    ("2/3",       2.0/3.0,            39),
    ("-2/3",      2.0/3.0,            45),
    ("√2",        math.sqrt(2),       None),  # > 47 (paper says >47)
    ("i (|i|=1)", 1.0,                None),  # |i|=1
    ("π",         math.pi,            None),  # > 53
]
for name, val, K in catalog:
    Nl, label, p = first_native(val)
    K_str = f"{K}" if K else ">47"
    native_str = label if label else "unresolved"
    if p:
        print(f"{name:<14}  {val:>18.10f}  {K_str:>8}  {native_str:>20}  k={p['k']}, d={p['d']}")
    else:
        print(f"{name:<14}  {val:>18.10f}  {K_str:>8}  {native_str:>20}  (needs refinement)")

print()
print("→ Observation: the paper's K values cluster with the first-native-LCM level")
print("  loosely but not tightly.  The K=17 cluster (|−1|, ×, /, x², ε_EM-class) all")
print("  sit at 12ET full-resolution d=12.  The K=19 cluster (+, x+1, 2x, 2) sits")
print("  at d=4 weak.  The K=11 cluster (−, x−1) sits at d=2 tritone pivot.")
print("  There IS structure — but it's the operator's OWN sublattice signature,")
print("  not just K ∝ log(LCM). The mapping is richer than a single correlation.")

# ============================================================
# TEST 5: The Gödel edge — what EML+lattice+LCM tower CANNOT do
# ============================================================
print()
print("=" * 76)
print("TEST 5: Honest limits — the Gödel/computability edge")
print("=" * 76)
print("""
  The combined EML + lattice + LCM tower + limits + active-system framework
  covers EVERYTHING that is:

    (a) a positive real ratio on the multiplicative manifold (R+, ×)
    (b) computable to arbitrary precision by a finite algorithm
    (c) at any finite lattice resolution

  It does NOT cover:

    (i)  Non-computable reals (Chaitin's Ω, most reals are in this class)
         — no finite process produces them; EML or anything else is blind
    (ii) Gödel-undecidable propositions (e.g., Con(ZFC) inside ZFC)
         — Three Tools §4.8: P's Ω cardinality exceeds any finite D-set;
           this is a structural feature of ET, not a defect of the pipeline
    (iii) Formal-systems questions of its own consistency
          — any sufficiently strong system has this limit; ET acknowledges
            it as the Descriptor Gap at the meta-level

  These limits are STRUCTURAL — they apply to any finite mathematical system.
  They are not specific failures of the EML+lattice pipeline; they are
  built into the nature of finite D-descriptions of infinite P-substrates.
""")

