/*
 * ET Lossless Sensor Capture — Main Activity
 * =============================================
 * Jetpack Compose UI: sensor discovery, recording, live lattice view.
 *
 * Author: Michael James Muller — Aevum Defluo (Exception Theory)
 * License: CC-BY-4.0
 */

package com.aevumdefluo.etsensor

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.io.File

class MainActivity : ComponentActivity() {

    private val requiredPermissions = arrayOf(
        Manifest.permission.RECORD_AUDIO,
        Manifest.permission.CAMERA,
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.BODY_SENSORS,
        Manifest.permission.HIGH_SAMPLING_RATE_SENSORS,
    )

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { /* Permissions granted or denied — UI recomposes automatically */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        /* Request all sensor permissions */
        val needed = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isNotEmpty()) {
            permissionLauncher.launch(needed.toTypedArray())
        }

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Color(0xFF00FFAA),
                    onPrimary = Color.Black,
                    surface = Color(0xFF0A0A0A),
                    onSurface = Color(0xFFCCCCCC),
                    background = Color(0xFF0A0A0A),
                    onBackground = Color(0xFFCCCCCC),
                )
            ) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    EtSensorApp()
                }
            }
        }
    }

    @Composable
    fun EtSensorApp() {
        var discoveredSensors by remember { mutableStateOf<List<SensorInfo>>(emptyList()) }
        var hardwareReport by remember { mutableStateOf("") }
        var isRecording by remember { mutableStateOf(false) }
        var recordingSession by remember { mutableStateOf<RecordingSession?>(null) }
        var statusText by remember { mutableStateOf("Ready") }
        var liveProjections by remember { mutableStateOf("") }
        var etConstants by remember { mutableStateOf("") }

        /* Load constants on first composition */
        LaunchedEffect(Unit) {
            etConstants = try { EtSensor.getConstantsInfo() } catch (_: Exception) { "Native library not loaded" }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
        ) {
            /* ── Header ── */
            Text(
                "ET LOSSLESS SENSOR CAPTURE",
                fontSize = 18.sp, fontWeight = FontWeight.Bold,
                color = Color(0xFF00FFAA)
            )
            Text(
                "P∘D∘T = E — Aevum Defluo",
                fontSize = 12.sp, color = Color(0xFF888888)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                etConstants,
                fontSize = 10.sp, fontFamily = FontFamily.Monospace,
                color = Color(0xFF666666)
            )

            Divider(modifier = Modifier.padding(vertical = 8.dp), color = Color(0xFF333333))

            /* ── Discover Sensors Button ── */
            Button(
                onClick = {
                    statusText = "Discovering hardware sensors..."
                    discoveredSensors = SensorDiscovery.discover(this@MainActivity)
                    hardwareReport = SensorDiscovery.generateReport(this@MainActivity)
                    statusText = "Found ${discoveredSensors.size} hardware sensors"
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1A3A2A))
            ) { Text("Discover Hardware Sensors", color = Color(0xFF00FFAA)) }

            /* ── Sensor List ── */
            if (discoveredSensors.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text("Hardware Sensors:", fontWeight = FontWeight.Bold, fontSize = 14.sp)

                for (sensor in discoveredSensors) {
                    val direct = if (sensor.directChannelSupported) "✓ DIRECT" else "event"
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 2.dp)
                            .background(Color(0xFF111111))
                            .padding(8.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "[${sensor.id}] ${sensor.name}",
                                fontSize = 12.sp, fontFamily = FontFamily.Monospace
                            )
                            Text(
                                "${sensor.type.name} | $direct | ${sensor.maxRateHz} Hz | ${sensor.axes}-axis",
                                fontSize = 10.sp, color = Color(0xFF888888),
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }

            Divider(modifier = Modifier.padding(vertical = 8.dp), color = Color(0xFF333333))

            /* ── Recording Controls ── */
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        if (!isRecording && discoveredSensors.isNotEmpty()) {
                            val outputDir = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS)
                                ?: filesDir
                            val session = RecordingSession(
                                this@MainActivity, discoveredSensors, outputDir
                            )
                            if (session.start()) {
                                recordingSession = session
                                isRecording = true
                                statusText = "● RECORDING — all sensors active"
                            } else {
                                statusText = "Failed to start recording"
                            }
                        }
                    },
                    enabled = !isRecording && discoveredSensors.isNotEmpty(),
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2A1A1A))
                ) { Text(if (isRecording) "● Recording..." else "Start Recording", color = Color(0xFFFF4444)) }

                Button(
                    onClick = {
                        if (isRecording) {
                            recordingSession?.stop()
                            val session = recordingSession
                            isRecording = false
                            statusText = if (session != null) {
                                "■ Stopped — ${session.totalSamples} samples, " +
                                "${session.durationMs}ms → ${session.outputPath}"
                            } else { "Stopped" }
                            recordingSession = null
                        }
                    },
                    enabled = isRecording,
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1A1A2A))
                ) { Text("Stop", color = Color(0xFF4444FF)) }
            }

            /* ── Live Projection Test ── */
            Divider(modifier = Modifier.padding(vertical = 8.dp), color = Color(0xFF333333))
            Text("Bijection Verification:", fontWeight = FontWeight.Bold, fontSize = 14.sp)

            Button(
                onClick = {
                    val sb = StringBuilder()
                    /* Verify round-trip for key values */
                    val testValues = listOf(
                        "3.14159265358979323846" to "π",
                        "2.71828182845904523536" to "e",
                        "1.61803398874989484820" to "φ",
                        "0.66666666666666666667" to "K=2/3",
                        "137.036" to "α⁻¹",
                        "1836.15267" to "μ (proton/electron)",
                    )
                    for ((value, name) in testValues) {
                        val exact = EtSensor.verifyRoundtrip(value, 12)
                        sb.appendLine("  $name: ${if (exact) "✓ EXACT" else "✗ FAIL"}")
                    }
                    liveProjections = sb.toString()
                    statusText = "Bijection verification complete"
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1A2A3A))
            ) { Text("Verify Lossless Round-Trip", color = Color(0xFF44AAFF)) }

            if (liveProjections.isNotEmpty()) {
                Text(
                    liveProjections,
                    fontSize = 11.sp, fontFamily = FontFamily.Monospace,
                    color = Color(0xFF00FFAA),
                    modifier = Modifier.padding(8.dp)
                )
            }

            /* ── Status ── */
            Divider(modifier = Modifier.padding(vertical = 8.dp), color = Color(0xFF333333))
            Text(
                statusText,
                fontSize = 12.sp, fontFamily = FontFamily.Monospace,
                color = Color(0xFFFFAA00)
            )

            /* ── Full Hardware Report ── */
            if (hardwareReport.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    hardwareReport,
                    fontSize = 9.sp, fontFamily = FontFamily.Monospace,
                    color = Color(0xFF666666),
                    modifier = Modifier.padding(8.dp)
                )
            }
        }
    }
}
