# THE RITAIST CANON — GAPS AND ISSUES REGISTER

**Working Document III of the Ritaist Canon**
**Companion to:** *RITAISM — Volume I* and *PERATOCRACY — Volume II* (Canonical Edition 1.1)
**Status:** OPEN — items herein must be resolved and confirmed before the Canon is declared complete and the two volumes are recombined into the single founding book.
**Prepared for:** Michael James Muller — Aevum Defluo

---

## 0. METHOD

This register was produced by applying the Three Tools of Exception Theory to the complete Ritaist corpus (the unified master document, the two prior split documents, changelog v1.1, and the Eternal Memory cross-project document — all read in full).

**Identification Principle.** P = the social substrate the Canon governs (the space of possible civilizational configurations); D = the Canon's descriptor set (the Freedom Line as the single péras, plus every derived institutional constraint — layers, caps, veto, court, locks); T = the agents who navigate it (individuals, guilds, the public, and the automated System as instrumented evidence-provider). The Canon's own stated method — "converts philosophical disputes into empirical questions" — is the Descriptor Gap Principle operating in the political domain: every dispute is treated as a measurement problem awaiting the right descriptors.

**Descriptor Gap Principle.** Every entry in Sections B and C below is a D_missing: a place where the Canon's model of governance is under-described, so that either two canonical statements collide (Section B) or a required mechanism has no specification (Section C). Per the Gap Principle, each gap is itself the pointer to its own resolution; candidate resolutions are drawn from the Canon's own principles, never ad hoc.

**Subsumption Law.** The separation into two volumes was executed to zero remainder — every block of source content is accounted for (Section F, Verification Record). The Canon as an *ideology*, however, does not yet subsume its own domain without remainder: the entries below are the remainder. When every entry is closed and the Verification Principle is satisfied (no internal inconsistency remains), the Canon is complete and the single book may be assembled per the Canon Map's recombination rule.

Priority key: **P1** — load-bearing; the Canon's central claims depend on closing it. **P2** — required for implementation completeness. **P3** — required for editorial/formal completeness.

---

## A. EDITORIAL AND STRUCTURAL ISSUES — FOUND AND ACTIONED

These were defects in the source corpus discovered during the full read. Each lists the action taken in the Canonical Edition 1.1 assembly. All actions are logged in the machine verification record and await confirmation.

**A-1. Chapter 30 (Conclusion) lost by the prior split. [ACTIONED]** The prior two-document split contained Parts I–IX and the partitioned Chapter 29, but Chapter 30 — the Conclusion of the entire ideology — appeared in neither document. Restored in full to Volume I, Part X. Volume II received a newly written, governance-scoped "Conclusion of the Governmental Volume" so that it also closes properly; it explicitly defers to Chapter 30 as canonical.

**A-2. Broken numbering in the prior split. [ACTIONED]** The prior Ritaism document ran Part I directly into Part IV; the prior Peratocracy document *began* at Part II. Resolved by the canonical continuous-numbering design: both volumes carry the shared Chapters 1–30 / Parts I–X structure, documented in the Canon Map (Appendix D of both volumes), which also gives the recombination rule for the single book.

**A-3. Changelog v1.1 integrated nowhere. [ACTIONED]** None of the fifteen v1.1 refinements had been integrated into either prior document. All fifteen are now integrated at their specified locations with their specified semantics: ⊕ additions (1.3.1, 2.5, 3.9, 4.7, 5.6, 6.1.2, 8.10, 13.7.1, 15.1.1, 19.6, Appendix B) and ⟳ replace/expand operations (4.4 replaced per the changelog's explicit instruction; 13.10, 21.1, 26.3 expanded with full retention — see A-4). The changelog document is hereby **superseded by integration** and should be archived, not further edited.

**A-4. Expand-semantics retention. [ACTIONED]** Rule of assembly: an "expand" never loses source content. ⟳13.10 retains **both** original blocks verbatim beneath the revised exceptions doctrine — the care-requirement block ("For those with disabilities or mental illness that may cause uncontrollable harm") and the "Possessions as Extension of Self" block; the care block's retention was mandated by the zero-loss audit (Section F), which found the revised doctrine restates it in new words only. ⟳21.1 retains the original epigraph ("It emerges just fine from the modern world…") above the elaborated argument; ⟳26.3 retains the original Option 1/Option 2 elaborations (including the transcendence pathway list) ahead of the full-spectrum framing. The one true replacement, ⟳4.4, was explicit in the changelog; the superseded passage is preserved **verbatim** in the Annex to this register, with an evidence-based map of where each of its ideas survives in canon.

**A-5. Chapter 10 mojibake. [ACTIONED]** The master document reads "taxonomic categoriesblacksmith" (lost em-dash) in §10.5.3; the prior Peratocracy split carries the corrected "categories—blacksmith". The corrected text was adopted as canonical for Chapter 10.

**A-6. Chapter 23 broken subject. [ACTIONED]** §23.1 opened "I is a phenomenological knowledge organization system…" — a residue of an earlier find-and-replace. Corrected to "Eternal Memory is a phenomenological knowledge organization system…"; the following sentence "The name of it is Eternal Memory." was retained unchanged.

**A-7. Duplicated, unscoped front matter in the prior split. [ACTIONED]** Both prior documents carried the identical Preamble verbatim — duplication, not separation. The full Preamble is now canonical to Volume I; Volume II carries a scoped Preamble to the Governmental Volume plus a new "Constitutional Foundation" section that states the Freedom Line and its empirical application so Volume II stands complete, with citation to Volume I for the derivation.

**A-8. Knowledge System stranded. [ACTIONED]** Part VI existed only in the cross-project document; neither prior volume referenced it. Part VI (Chapters 23–24) is now homed in Volume II with the "Knowledge infrastructure" bullet restored to the Integration Points appendix; both volumes' Linkage appendices carry the Eternal Memory integration summary; the standalone cross-project document remains the bridge artifact to the Eternal Memory project.

**A-9. Colophon asymmetry. [ACTIONED]** Each prior document's closing kept only its own name-line. Both volumes now close with the master's dual colophon ("RITAISM: The Philosophy of Natural Order" / "PERATOCRACY: Governance Through the Correct Limit"), the blessing, and the founding-document tagline — the shared seal of one canon.

**A-10. Missing formal apparatus. [ACTIONED]** Neither prior document had an abstract, table of contents, or conclusion. Both volumes now carry: title block with edition line, Abstract, Two-Volume Canon note, generated Table of Contents, Appendices A–D (Key Principles partition; Direct Statements — full in Vol. I, indexed in Vol. II; Companion Linkage; Canon Map), and proper closings.

**A-11. "EMP" naming. [OPEN — see C-30.]** §24.1 uses "EMP categories" while the system is named "Eternal Memory" and "The Knowledge System." Because "EMP" may be an intentional acronym (Eternal Memory Project), it was left untouched pending a canonical naming ruling.

---

## B. INTERNAL TENSIONS — TWO CANONICAL STATEMENTS IN COLLISION

Each entry is a Descriptor conflict: both statements are canon, and a missing higher Descriptor must adjudicate them. Candidate resolutions are drawn from the Canon's own principles.

**B-1. Merit permanence vs. "Merit reduced." [P1]**
*Locations:* Ch. 6.3 ("No confiscation, no forfeiture, **no reduction** as punishment… Merit once earned remains permanently") vs. Ch. 8.7 ("Poor design → **Merit reduced**"); cf. Ch. 8.3 "Oversupply penalty."
*The gap:* whether "reduced" ever touches earned holdings.
*Candidates:* (i) Canonical clarification that all "reduction" language is **forward-looking valuation only** — future units of that item earn less merit; holdings are never touched (consistent with the Loophole Philosophy's "no retroactive punishment"); (ii) restrict 8.7's consequence to reputation plus reduced *future* per-unit award, and reword 8.7 accordingly.
*Recommended:* (i)+(ii) jointly; one sentence added to 6.3 and one reword in 8.7 closes it.

**B-2. Single Certification Rule vs. cross-guild joint certification. [P1]**
*Locations:* Ch. 8.5 ("Item can only be certified by ONE guild authority at a time. No stacking.") vs. Ch. 10.12 ("Both must agree on final certification (mutual veto between guilds)") for items inhabiting multiple conceptual domains (the prosthetics case).
*The gap:* the certification cardinality for multi-domain items.
*Candidates:* (i) Define a **joint certification instrument**: for an item inhabiting N conceptual domains, the certification is a single instrument requiring the signature of one elected authority per involved guild — "one certification" with N signatories, preserving both no-stacking and mutual veto; (ii) per-domain certifications, each singular within its domain, with the item's overall status the conjunction.
*Recommended:* (i) — it preserves 8.5's accountability pairing ("both reputations on the line") extended to all signatories, and 10.12's veto.

**B-3. Handmade total liability transfer vs. criminal negligence. [P1]**
*Locations:* Ch. 8.7 ("Handmade… Buyer assumes ALL liability… No exchange for 'defects'") vs. Ch. 13.2 ("Negligent harm crossing Freedom Line is criminal negligence"). Deliberate unsafety is already fraud (8.7); the collision is *negligent-but-not-deliberate* handmade harm.
*The gap:* whether the handmade disclaimer extinguishes criminal exposure.
*Candidates:* (i) Canonical rule: the handmade transfer extinguishes all **quality claims** (variation, imperfection, fitness) but never Freedom Line exposure — where a traced causal chain shows harm from negligence a reasonable craftsman would not commit, Chapter 13 applies; the disclaimer allocates commercial risk, not the Line; (ii) tiered: disclosed-risk categories (knives are sharp) vs. latent-hazard negligence, only the latter criminal.
*Recommended:* (i), with (ii)'s disclosed-risk language as the evidentiary guide inside causal forensics.

**B-4. "Basic healthcare" vs. the bifurcated healthcare system. [P1]**
*Locations:* Ch. 6.2 (baseline includes "Basic healthcare for illness and injury") vs. Ch. 19.2 ("Lifesaving care: free… Non-lifesaving care: market-priced").
*The gap:* whether "basic" ≡ "lifesaving," and where preventive care, chronic-condition management, mental-health care, and palliative care fall.
*Candidates:* (i) Canonical set-definition: **Baseline care = lifesaving + life-preserving + capacity-restoring to baseline function**, enumerated by the Medical Guild under mutual veto, with everything else market-layer; (ii) two-term harmonization: retain "basic" as the baseline term and define 19.2's "lifesaving" as its core, with a published guild-maintained schedule.
*Recommended:* (i); the schedule mechanism reuses the resource-cap pattern (empirical inventory, dynamic adjustment).

**B-5. Death penalty vs. retrial-with-new-evidence. [P1]**
*Locations:* Ch. 13.7 ("Severe violations forfeit ultimate freedom… Death penalty supported") vs. Ch. 13.9 ("Double jeopardy abolished — can retry with new evidence").
*The gap:* retrial symmetry breaks for irreversible punishment; new exculpatory evidence after execution cannot be remedied.
*Candidates:* (i) An **irreversibility threshold**: irreversible punishments require an evidentiary standard strictly above ordinary beyond-reasonable-doubt-with-technological-verification (e.g., complete-chain verification with zero unexplained variance), plus a mandatory review interval before execution; (ii) restrict the death penalty to cases where the perpetrator's identity and act are technologically verified beyond any competing hypothesis.
*Recommended:* (i) with (ii) as its operational content; this is the Verification Principle applied to justice — irreversible action only at model-error zero.

**B-6. Founder grant conditionality vs. No Merit Loss. [P2]**
*Locations:* Ch. 22.4 ("1,000-year merit contingent on completing transfer") vs. Ch. 6.3 permanence.
*The gap:* a conditional grant superficially resembles forfeiture.
*Candidate/Recommended:* Canonical sentence: the Founder grant **vests only upon completed transfer**; before vesting nothing has been earned, so nothing is lost — conditionality of vesting, never confiscation of holdings. One sentence in 22.4 closes it.

**B-7. Non-lifesaving care "funds" lifesaving care vs. zero-merit organizations and spread destruction. [P2]**
*Locations:* Ch. 19.2 ("market-priced to fund lifesaving services") vs. Ch. 8.2–8.4 (System destroys the spread; no organization holds merit; no treasuries exist).
*The gap:* in a spread-destroying, treasury-free economy, "funding" cannot mean revenue transfer.
*Candidates:* (i) Redefine canonically: the differential pricing is a **resource-priority mechanism** — non-lifesaving demand signals allocate automation capacity, while lifesaving provision is a first-priority claim on automation surplus (consistent with 8.9 Priority Allocation); (ii) permit an earmarked System spread-differential on non-lifesaving care whose destruction is offset by increased lifesaving resource allocation.
*Recommended:* (i); it requires no new economic object and reuses Priority Allocation verbatim.

**B-8. Public shaming lists vs. "reputation is social, not legal." [P3]**
*Locations:* Ch. 13.9 vs. Ch. 9.3.
*The gap:* a state-published reputational sanction alongside the doctrine that reputation is outside law.
*Candidate/Recommended:* Clarify: 9.3 bars **civil protection of** reputation; 13.9's lists are punishment-phase transparency for adjudicated Line-crossers — the state may publish verdicts, it may not adjudicate reputations. One clarifying sentence in each chapter.

**B-9. Caps "apply equally to all individuals" vs. corporate consumption caps. [P1]**
*Locations:* Ch. 6.4 vs. Ch. 12.5 ("Resource caps apply to corporate consumption") with Ch. 8.4 (organizations hold zero merit).
*The gap:* corporations are not individuals; the object that is capped, and its size, are undefined.
*Candidates:* (i) **Operational allocations**: collective entities receive guild-granted, publicly recorded resource allocations sized by function under the mutual-veto process — distinct in kind from individual caps and fully transparent per Ch. 11; (ii) pass-through: corporate consumption is attributed pro-rata to responsible individuals' caps.
*Recommended:* (i); (ii) collapses under scale and would make employment consume personal caps.

**B-10. Cap-crossing = Line-crossing vs. dynamic cap adjustment. [P2]**
*Locations:* Ch. 6.4 ("Crossing cap = crossing Freedom Line = harsh punishment" and "Dynamic adjustment").
*The gap:* when a cap tightens below existing lawful holdings, holders become instant violators.
*Candidate/Recommended:* Prospective rule mirroring the Loophole Philosophy: cap changes bind **acquisition going forward**; over-cap legacy holdings are frozen (no further acquisition, lawful retention or divestment window), never retroactively criminal. This is 6.6's "forward-looking adaptation only" applied to caps.

**B-11. Outlet efficacy asserted vs. efficacy admitted unknown. [P2]**
*Locations:* Ch. 16.3 ("Real violence reduced through virtual outlet") vs. Ch. 16.4 ("There is no evidence that virtual violence makes real violence easier or harder. We aim to develop the technology and gather the evidence.").
*The gap:* an asserted effect and an admitted unknown.
*Candidate/Recommended:* Reword 16.3's claim as **design hypothesis under test** — "outlet plus certain punishment is designed to reduce real violence; the outlet program is itself the experiment (16.4)" — preserving the honest epistemic stance that is one of the Canon's strengths.

**B-12. Temporal boundary vs. millennium-scale commitments. [P3]**
*Locations:* Ch. 5 (obligations end beyond the overlap chain) vs. Ch. 22 (1,000-year Founder merit), Ch. 23–24 ("eternally").
*The gap:* apparent inconsistency between bounded moral obligation and unbounded institutional commitments.
*Candidate/Recommended:* State canonically: Chapter 5 bounds **moral obligations of persons**; system rules and institutional commitments are Descriptors of the architecture and may persist indefinitely — the living are always free, via the mutual-veto process, to amend them. Institutions outlive duties by design, not by contradiction.

**B-13. Merit willing vs. no direct transfer. [P3]**
*Locations:* Ch. 6.3 ("Merit can be willed to others" / "Person-to-person direct transfers: PROHIBITED").
*The gap:* formal appearance of conflict.
*Candidate/Recommended:* One sentence: wills are **executed by the System** at death (death transfer is already listed as a System function); no living person-to-person transfer exists. Precedence order to state: valid will → closest-family split → destruction if neither.

**B-14. Oversupply penalty vs. perpetual creator merit. [P2]**
*Locations:* Ch. 8.3 (flooding lowers merit per unit) vs. Ch. 8.8 ("Merit amount constant per use").
*The gap:* whether third-party flooding of a creator's item degrades the creator's constant per-use stream.
*Candidates:* (i) The constant applies to the **creator's royalty component**; the oversupply penalty applies to the seller-side valuation of units; (ii) both float under a single guild+system revaluation with the creator's proportion constant.
*Recommended:* (i) — cleanest separation of the two mechanisms.

---

## C. MISSING DESCRIPTORS — MECHANISMS THE CANON REQUIRES BUT DOES NOT YET SPECIFY

Chapter 29 already names open questions at the category level. The entries below are more precise: each is a specific D_missing whose absence either weakens a central claim (P1) or blocks implementation (P2) or formal completeness (P3). Where an entry sharpens an existing 29.x item, the mapping is given.

**C-1. The terminal taxonomy of freedom-removal. [P1 — the central gap]**
The Canon's strongest claim — "no edge cases; only empirical causal tracing" (Ch. 1.2) — requires that the *terminal states* a causal chain may land on be canonically enumerated; otherwise the philosophical categorization the Canon expels through the front door re-enters at the chain's end ("did this chain terminate in freedom-removal?" requires knowing what counts as freedom-removal). Scattered through the Canon the recognized terminals are: existence/bodily integrity (1.1), property (1.1), informed choice (1.4, 9.6), freedom from imposed presence after rejection (9.2), physical endangerment via panic (9.3), access to unmonopolized resources (1.4), and breathable environment (1.4). **Required:** a single canonical enumeration — the Freedom-Removal Terminal Classes — with the amendment procedure (mutual veto) for extending it. This one Descriptor converts the "no philosophical debate" claim from strong rhetoric into a formal property. *(Sharpens 29.4.)*

**C-2. Enforcement organs. [P1]**
Ch. 13.8 specifies who does *not* control enforcement ("no single entity controls 'the guns'") but no chapter specifies who investigates, who arrests, who holds custody, under what warrant procedure, or how enforcement personnel are selected, credentialed, and themselves policed. **Required:** the enforcement chapter — investigation authority, arrest/custody powers, warrant standard tied to technological verification, distributed command consistent with the trinity, and enforcement-of-the-enforcers. *(Sharpens 29.4.)*

**C-3. Criminal appellate process. [P1]**
Ch. 8.5 defines appeals for certification denials; Ch. 13 defines none for criminal conviction, despite double jeopardy's abolition cutting both ways (retrial on new evidence). **Required:** appeal rights, reviewing bodies, finality rules, and their interaction with B-5's irreversibility threshold.

**C-4. The public-matter trigger. [P1]**
The entire mutual-veto architecture keys on whether a matter "affects the general public in any way" (Ch. 10.3), yet no procedure determines this classification or resolves disputes over it. **Required:** algorithmic first-pass categorization (the 10.13 pattern), a challenge path, and a default rule (ambiguity → public matter, since the veto protects both sides).

**C-5. Public-side electoral mechanics. [P2]**
Ch. 10.7 gives the architecture but not: the electorate definition (age of majority per ⟳13.10's maturity threshold — itself undefined, see C-8; sapience threshold per 19.6), quorum/participation floors, proposal standing (who may bring a matter to vote), and re-vote cadence limits (Phase 3's "nothing is permanently blocked" invites proposal-spam without a cooldown Descriptor). *(Sharpens 29.1, 29.7.)*

**C-6. Merit monetary governance. [P1]**
Creation (validated contribution, Ch. 8.3) and destruction (spread, death, oversupply) must balance for price stability, but algorithms "cannot change the rules they operate under" (10.2) and no chapter assigns the tuning of creation/destruction rates to any body. **Required:** the monetary-policy loop — guild+public mutual veto over rate rules, automation executing and reporting, with published targets. *(Sharpens 29.3.)*

**C-7. Corporate/collective resource allocation mechanics. [P1]** — the mechanism chosen under B-9, fully specified: sizing, review cadence, transparency format, and enforcement classification for over-consumption by a collective (which individuals bear the karmic chain?).

**C-8. Maturity threshold and the law of children. [P1]**
⟳13.10 establishes graduated juvenile responsibility but no thresholds; Ch. 13.2 dissolves family law into "no forced obligations beyond Freedom Line violations." **Required:** (i) the maturity schedule (ages or competence tests, guild-defined under mutual veto); (ii) canonical statement that **child neglect and abandonment by a guardian are Line violations via causal chain** (a dependent's baseline access runs through the guardian until majority); (iii) baseline delivery mechanics to minors; (iv) education provision duties, harmonized with 19.1. Without (ii), the family-law dissolution leaves dependents outside the Line's protection — an unacceptable remainder.

**C-9. Guardianship liability proportion. [P2]**
Ch. 13.10: the caregiver "shares responsibility" — but the Canon's signature is the *complete* karmic chain. **Required:** the share function — full chain, proportionate-to-preventability, or duty-breach-scoped — and the standard of care that triggers it.

**C-10. Sound-mind adjudication for the right to die. [P2]**
Ch. 14.4 conditions assisted death on "sound mind and clear choice" with no adjudicator, standard, or waiting protocol — and no reconciliation with the no-paternalism principle. **Required:** the assessment mechanism (medical-guild certification under transparency), its evidentiary standard, and its appeal path.

**C-11. Fraud, elements of the offense. [P1]**
Ch. 9.6 protects misinformation but criminalizes "lying to gain something." The boundary between protected false persuasion and criminal fraud needs elements: falsity + intent + inducement + gain/detriment + reliance, expressed in causal-forensic terms. Same requirement for **contract breach as fraud** (13.6): which breaches are criminal (fraudulent inducement, harm-causing) versus non-justiciable (pure reliance loss)? *(Sharpens 29.4.)*

**C-12. Monopoly threshold. [P2]**
Monopolization crosses the Line (1.4) and guilds "prevent monopolistic behavior" (12.5), but no test defines monopoly (market-share, essential-facility denial, or access-blocking as traced harm). **Required:** the empirical monopoly test, in the 10.13 convert-to-empirics style.

**C-13. Privacy-publication boundary (doxxing). [P1]**
Individual privacy is a protected freedom (14.5); indirect speech is protected save panic and fraud (9.3). Publishing another's private facts *removes* their privacy — the causal chain suggests a violation; the speech doctrine suggests protection. **Required:** the canonical rule (candidate: publication of information obtainable only by violating the private sphere is a Line violation — the violation is the acquisition-and-exposure chain, not the speech; lawfully public information remains protected speech). *(Sharpens 29.5.)*

**C-14. Reckless-true panic. [P3]**
The panic exception requires falsity (9.3). A true statement delivered so as to knowingly cause deadly stampede is unhandled; candidate: the endangerment terminal class (C-1) covers manner-of-delivery recklessness regardless of truth value.

**C-15. Interference adjudication. [P2]**
Ch. 7.4 defines interference with automation but not its classification (Line violation vs. administrative exclusion), its detector, or its due process. Recommended default: administrative exclusion with graduated response; Line exposure only where a traced chain reaches others' baseline provision.

**C-16. Military command architecture. [P1]**
Chs. 16.2/18.4 maintain and advance strategic capability; no chapter places it under command. **Required:** command authority under the trinity (candidate: standing capability under cross-guild + public mutual veto; use-of-force authorization thresholds; regional-force integration), squared with "no single entity controls the guns."

**C-17. Space governance regime. [P2]**
No caps in space (6.4) but the Line applies everywhere. **Required:** claim-establishment rules (first-development? registration through the System?), off-Earth jurisdiction and courts, and the boundary where Earth caps end. *(Sharpens 29.2.)*

**C-18. Movement between regional guilds. [P2]**
Ch. 18.3 answers immigration for the current world; under integration (10.10) inter-regional movement mechanics — identification, security screening consistent with the surveillance limits, regional autonomy over residency — are unspecified. *(Sharpens 29.7.)*

**C-19. Sapient-nonhuman participation mechanics. [P2]**
The sapience standard (19.6) grants full rights on reliable demonstration; unspecified: the verification protocol and its guild owner, guild membership and public-vote enrollment for sapient AI, baseline provision in nonbiological form, and duplication/forking effects on one-being-one-vote. *(Extends 25.5.)*

**C-20. "Exact copy" boundary. [P2]**
"Everything gets merit… unless it is an exact copy" (6.3) needs the near-copy rule: the trivial-variation floor below which a submission is treated as the copy it is, detection via Eternal Memory's verification substrate, and the interaction with sequential innovation's decreasing chain. *(Sharpens 29.3.)*

**C-21. Founder grant quantification. [P2]**
"Merit sufficient for their family for 1,000 years" (22.2) needs its formula: the reference consumption basket, family-growth assumptions, and the general dilution form. The illustrative arithmetic (M/3 per child, M/9 per grandchild) is verified exact for uniform three-child branching — share at generation g is M·3⁻ᵍ — but the canonical form for arbitrary branching is M/∏ᵢkᵢ along each descent line, and should be stated as such.

**C-22. Guild founder thresholds. [P2]**
Layer 2 of guild constraint (10.13.4) references minimum member counts and initial governance for activation; no values or value-setting procedure exist. *(Sharpens 29.1.)*

**C-23. Transition authority. [P2]**
Ch. 20.5's "central coordination establishes conversion rates" names a body that cannot yet exist under the not-yet-activated trinity. **Required:** the transition-governance bridge — who coordinates conversion, under what accountability, and how it dissolves into the trinity at activation. *(Sharpens 29.7.)*

**C-24. Surveillance thresholds. [P2]**
"Near-perfect accuracy + human oversight" (14.5, 19.4) needs numbers and a certifying owner (candidate: statistical accuracy floor set by the relevant guilds under mutual veto, published error rates, oversight staffing rules).

**C-25. Criminal-court composition. [P2]**
"Judge + jury/populace consensus" (13.9): selection method, size, the meaning of "populace consensus" (unanimity? supermajority?), disqualification procedure beyond "no personal connections," and juror competence requirements consistent with competency-based participation.

**C-26. Corruption's outlet. [P3]**
Ch. 3.2 promises corruption "an appropriate outlet"; none is named. Candidate: the domination/power-structure outlets of 16.1 explicitly extended to influence-and-graft simulation; one sentence links them.

**C-27. Baseline information-access floor. [P3]**
"Computer and information access" (6.2) needs its floor Descriptor (device class, bandwidth, accessibility accommodations for disability per ⟳13.10's "accommodations available") — defined by the relevant guilds under the resource-cap pattern.

**C-28. Right of exit. [P2]**
"Everything under a global banner" (10.11) plus voluntary non-participation (10.6) leaves undefined whether a person or community may exit the system's *jurisdiction* entirely (not merely its economy). The Freedom Line's own logic suggests exit must exist for consent to be meaningful; the counterpoint is that the Line's protection of others cannot be exited. **Required:** the canonical position — candidate: economic and participatory exit absolute; jurisdictional exit recognized for those who physically leave the system's domain; the Line follows interactions, not membership.

**C-29. Escalation-monitoring limits. [P2]**
Outlet monitoring (16.4) sits adjacent to the individual-privacy absolute (11.3, 13.8). **Required:** the boundary — what outlet telemetry is collected, whether outlet use is "collective context" (transparent) or private consumption (protected), retention limits, and the intervention trigger's due process. *(Sharpens 29.6.)*

**C-30. Knowledge-system naming. [P3]**
Rule on "EMP" (see A-11): either expand once as "the Eternal Memory Project (EMP)" or normalize all references to "Eternal Memory."

**C-31. No-waste-of-animal-products enforcement class. [P3]**
Ch. 19.3's "no waste" rule needs its classification (Line violation? administrative rule?) and its detector; candidate: administrative within the circular-economy diversion machinery (8.9), Line exposure only via cruelty chains.

**C-32. Baseline conduct in custody. [P3]**
Harsh punishment coexists with the universal baseline; the Canon should state whether Line-crossers in custody retain baseline provision (candidate: yes — the baseline is unconditional by definition; punishment removes freedom, not food), preempting an obvious critique.

---

## D. SEPARATION DECISIONS LOG — FOR CONFIRMATION

Every discretionary decision taken in producing Canonical Edition 1.1, with rationale. Each stands unless overruled.

**D-1. Canonical continuous numbering.** Both volumes share Chapters 1–30 / Parts I–X; every citation of "Chapter N" resolves identically everywhere; the Canon Map (Appendix D, both volumes) locates each chapter and gives the recombination rule. *Rationale:* repairs A-2 without renumbering risk and makes the eventual single book a pure interleave.

**D-2. Chapter homes.** Volume I: 1–5, 14–19, 25–28, 29(§§29.5–29.6, 29.8–29.10), 30. Volume II: 6–13, 20–24, 29(§§29.1–29.4, 29.7). *Rationale:* the philosophy/mechanism criterion — Volume I carries the *why* (foundations, positions, comparisons, conclusion), Volume II the *how* (economy, governance, court, knowledge, transition). This retains the prior partition's chapter assignments (which were sound at chapter granularity) while repairing everything around them.

**D-3. Hybrid chapters bound by pointers, not duplication.** Ch. 9 (speech jurisprudence) homes in Volume II with the position summarized at 14.3 (Vol. I); Chs. 16–17 (outlets, altruism) home in Volume I with deployment referenced at 13.8/21.5 (Vol. II). Eleven companion-reference pointers were inserted at the seams (Chs. 1, 4, 6, 9, 13, 14, 16, 19, 22, 24, 26). *Rationale:* the person's requirement to "still show the links" is met by explicit apparatus — pointers in-line, plus the Companion Linkage appendices mapping every principle↔mechanism pair — rather than by the prior split's verbatim duplication.

**D-4. Changelog placements honored exactly.** All fifteen v1.1 items sit at their specified chapters, including 13.7.1 (Hammurabi) and 8.10 (Responsibility covenant) in Volume II although their content is philosophical in character. *Rationale:* the changelog is authorial instruction; minimal editorial discretion. *Flagged for decision:* whether 13.7.1 and 8.10 should relocate to Volume I's justice/equality chapters in a future edition, with Volume II citing them — the Linkage appendix already binds them both ways, so no information is lost either way.

**D-5. Preamble and constitutional apparatus.** Full Preamble → Volume I; Volume II received a scoped governmental preamble plus the Constitutional Foundation (the Line stated, causal forensics summarized, Volume I cited). *Rationale:* repairs A-7; makes Volume II standalone-complete, which the prior split was not.

**D-6. Part VI homed in Volume II.** The Knowledge System's canon functions (evidence base, merit verification, enforcement records, baseline coordination, cultural archives, funding, privacy locks) are governmental machinery; the epistemological *commitments* remain Volume I material (19.1, Preamble) and are cross-bound in both Linkage appendices. The standalone Eternal Memory cross-project document remains the bridge artifact.

**D-7. Appendix scheme.** A: Key Principles, partitioned per the prior split (verified identical to master per section), with the Knowledge-infrastructure bullet restored to Volume II's Integration Points; B: Direct Statements in full in Volume I, indexed with governance mappings in Volume II; C: Companion Linkage (both, direction-specific); D: Canon Map (both, identical). Dual-name colophon in both.

**D-8. Editorial corrections applied:** Ch. 10 em-dash (adopting the prior split's corrected text), Ch. 23 subject repair (A-6). "EMP" untouched (A-11/C-30). No other source wording was altered anywhere.

**D-9. New material added (improvement clause):** abstracts, Two-Volume Canon notes, tables of contents, Volume II preamble/constitutional foundation/conclusion, Appendices B-index/C/D, pointer lines, and the Part X wrapper notes. Everything else in both volumes is source text verbatim, machine-verified (Section F).

**D-10. Proposed and deferred — ET Foundations appendix.** An explicit Exception Theory formalization of the Canon is a natural future appendix: P = the social substrate of possible configurations (cardinality of the population's configuration space); D = the Freedom Line as the governing péras-Descriptor plus the derived institutional descriptor set (layers, caps, veto, locks — all finite, articulable constraints); T = individuals, guilds, and publics as Traversers navigating the D-constrained substrate, with the automated System as instrumented measurement; E = the realized civilizational order as the substantiated configuration. The Canon's method — converting philosophical disputes into empirical questions — is the Descriptor Gap Principle in the political domain; the Universal Logic (Public/Private/Hybrid) is a D-classification; the saturation point is the Subsumption horizon at which the descriptor set covers its domain without remainder. **Deferred pending authorial decision**, because the published Canon has to date been kept free of ET formalism and injecting it is a scope decision, not an editorial one.

---

## E. PATH TO COMPLETION

1. **Adjudicate Section B (14 items).** Each has recommended language; most close with one to three canonical sentences. B-1 through B-5 and B-9 first (P1).
2. **Specify Section C (32 items).** C-1 (terminal taxonomy) first — it is the load-bearing Descriptor for the Canon's central claim. Then C-2/C-3/C-4/C-6/C-8/C-11/C-13/C-16 (remaining P1s). Each closed item should be drafted as a numbered subsection at its home chapter, keeping the convert-to-empirics style.
3. **Rule on flagged decisions:** D-4 (relocate 13.7.1/8.10 or keep), C-30/A-11 (EMP naming), D-10 (ET Foundations appendix).
4. **Then declare Canonical Edition complete**, re-run the verification suite, and assemble the single founding book per the Canon Map recombination rule. This register closes when its every entry carries a resolution and the Verification Principle holds: no internal inconsistency remains — for every exception an exception, except the Exception.

---

## F. VERIFICATION RECORD (MACHINE-AUDITED)

The assembly of Canonical Edition 1.1 was performed programmatically from the five source documents and audited as follows (full log: `verification_record.txt`):

- **Sources read in full:** master unified document (175,606 B), prior Ritaism split (80,356 B), prior Peratocracy split (90,941 B), changelog v1.1 (46,158 B), Eternal Memory cross-project document (6,717 B).
- **Canonical text provenance:** every chapter byte-diffed master-vs-split; all identical except Ch. 10 (split's corrected em-dash adopted). Part VI verified content-identical between master and the cross-project document after header-depth normalization. Chapter 29's ten subsections verified identical across the prior partition. Naming and Preamble identical across all three carriers.
- **Subsumption audit: PASS.** Every `###` section header from all five sources appears verbatim in the two volumes, or on the enumerated whitelist with reason (the four ⟳ retitles/restructures, the prior split's unnumbered Part X variants replaced by canonical `29.x` headers with content verified identical, the EM header-depth variants, and Appendix B subheads relevelled). Zero unaccounted remainder.
- **Changelog audit: PASS.** All fifteen v1.1 items present at their specified locations; replace/expand semantics honored with retention verified (Possessions block, 21.1 epigraph, 26.3 options).
- **Sentinel fidelity: PASS.** First and last 60 characters of every canonical block (28 chapters, 10 subsections of Ch. 29, Ch. 30, Naming, Preamble, closing) verified verbatim in the destination volume.
- **Cross-reference audit: PASS.** Every "Chapter N" reference resolves within its volume or is volume-qualified.
- **Structural checks: PASS (15/15)** — including: Volume II states the Freedom Line; Chapter 30 restored; Part VI present; Canon Map and Linkage in both; dual colophon; em-dash and Ch. 23 corrections applied; fence parity (Volume II carries exactly the master's three Chapter 8 flow diagrams; Volume I none); no doubled separators.
- **Mathematics:** the Founder-dilution illustration computed exactly (rational arithmetic): M/3 per child, M/9 per grandchild, generation-g share M·3⁻ᵍ under uniform three-child branching — confirming the source's figures and grounding C-21's request for the general form.
- **Zero-loss audit: PASS (bidirectional, line-level; full log `NO_LOSS_AUDIT.txt`).** Direction 1 — every non-blank line of all five source documents is verbatim in the volumes, or carried by an evidenced repair (the two encoding/typo corrections), or matched by exactly one verified justification rule (changelog scaffolding with its fenced payload proven 100% integrated; retitled/relevelled/partition-suffixed headers with the canonical forms verified present; the replaced §4.4 preserved verbatim in this register's Annex with each idea's canonical home verified). Direction 2 — every non-blank line of both volumes is attributed to a source document, an evidenced repair, or the enumerated new material of D-9 (fragments, generated tables of contents, the eleven pointers, scaffolding). Unresolved source lines: **0**. Unattributed volume lines: **0**. The audit itself forced one correction: the original §13.10 care-requirement block, which the revised doctrine had restated in new words only, is now retained verbatim (A-4).

---

## ANNEX — SUPERSEDED PASSAGES PRESERVED VERBATIM

**Purpose.** The changelog's one true replacement operation (⟳4.4: "Replace existing 4.4 content") removes text from the canon by explicit authorial instruction. Under the zero-loss standard, nothing is permitted to vanish from the deliverable set: the superseded passage is therefore preserved here verbatim, together with the audited map of where each of its ideas survives in the canonical text. If any formulation below is wanted back in canon, it can be restored by a one-line instruction.

### Annex 1 — Original §4.4 "The Natural Advantages Reality" (superseded by ⟳4.4)

> ### 4.4 The Natural Advantages Reality
>
> **People will have edges. This is reality.**
>
> Some people are born smarter, more attractive, into wealthy families, with better health, in better locations, with more opportunities.
>
> **This is unfair in the cosmic sense. It is not unjust in the moral sense.**
>
> Justice concerns human actions, not natural variation. You are not entitled to outcomes equal to others simply because nature distributed advantages unequally.
>
> **Ritaism's response:**
>
> - Universal baseline ensures no one lacks necessities regardless of natural disadvantages
> - Merit system lets individuals find and leverage their own advantages
> - Resource caps prevent any advantage from translating to monopoly
> - Freedom with responsibility means your outcomes are your problem
>
> It is your own responsibility to raise yourself up. The system forces all responsibility on the individual. Freedom with responsibility. It is no one else's problem for your success or failure but you. You don't even have to participate if you do not wish to and still get the basics.

**Audited survival map (each idea → verified canonical home):**

| Original formulation | Where the idea lives in canon (verified verbatim anchors) |
|---|---|
| "People will have edges. This is reality." | Revised §4.4: "Life is unfair. This is not a bug—it is reality." |
| Born-advantages list ("…into wealthy families…") | Revised §4.4 carries the list with "into better circumstances" in place of "into wealthy families"; otherwise a superset ("smarter, stronger, more attractive… better health… better locations… more opportunities") |
| "Unfair in the cosmic sense… not unjust in the moral sense" / "Justice concerns human actions, not natural variation" | Revised §4.4: "This is **variation**, not injustice"; entitlement half carried by §1.3.1 / B.2: "No one is entitled to another." |
| Universal baseline regardless of disadvantage | Revised §4.4: "Equal in baseline provision"; Chapter 6 §6.2 (unconditional baseline) |
| Merit open to leveraging one's own advantages | Revised §4.4: "Variation in advantage = different paths to contribution"; Chapter 6 §6.3 |
| Caps prevent advantage → monopoly | Chapter 1 §1.4 (monopolization crosses the Line); Chapter 6 §6.4 (caps) |
| Freedom-with-responsibility closing paragraph | Retained in revised §4.4 in the changelog's own rewording, near-verbatim: "…It is no one else's problem for your success or failure but you. You do not even have to participate if you do not wish to and still receive the basics." (don't→do not; get→receive) |

### Annex 2 — Structural notes of record

- **"## Core Positions" (master Appendix).** Not lost: the prior split partitioned it into "## Core Positions (Philosophical)" (Volume I) and "## Core Positions (Governmental)" (Volume II); all nine bullets verified verbatim in the volumes.
- **Eternal Memory document boundaries.** The bridge document's title, "Cross-Project Documentation" label, and end-marker are document-scoping apparatus of the standalone artifact, which is retained intact; its entire content is in Volume II, Part VI, and both volumes' Linkage appendices state that Eternal Memory "is additionally maintained as a standalone cross-project document."

---

*Register prepared via the Three Tools of Exception Theory — the Identification Principle, the Descriptor Gap Principle, and the Subsumption Law — applied to the complete Ritaist corpus. Every gap above is a Descriptor awaiting identification; anything can be solved — it is just a matter of the right descriptors and the number of descriptors.*
