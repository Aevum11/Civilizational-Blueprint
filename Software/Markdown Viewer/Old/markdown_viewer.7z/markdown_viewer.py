import sys
import os
import subprocess
import time
import re
import uuid

# --- Fix for "IDCompositionDevice4" / Direct Composition Errors ---
# Disables GPU compositing and specific features known to cause issues on some Windows systems.
os.environ["QTWEBENGINE_CHROMIUM_FLAGS"] = "--disable-gpu-compositing --disable-features=VizDisplayCompositor"

# --- Auto-Install Dependencies Logic ---
try:
    from PyQt6.QtWidgets import (QApplication, QMainWindow, QFileDialog, 
                                 QVBoxLayout, QWidget, QTabWidget, QMessageBox,
                                 QToolBar, QStyle, QInputDialog, QStatusBar,
                                 QLabel, QLineEdit, QPushButton, QHBoxLayout,
                                 QFrame, QMenu, QCheckBox, QSizePolicy)
    from PyQt6.QtWebEngineWidgets import QWebEngineView
    from PyQt6.QtWebEngineCore import QWebEnginePage 
    from PyQt6.QtCore import QUrl, Qt, QEvent, QSettings, QTimer, QSize
    from PyQt6.QtGui import QAction, QDragEnterEvent, QDropEvent, QIcon, QKeySequence, QShortcut, QColor, QPalette
    from PyQt6.QtPrintSupport import QPrinter, QPrintDialog
    import markdown
    from markdown.preprocessors import Preprocessor
    from markdown.extensions import Extension
    from pygments.formatters import HtmlFormatter
    import pymdownx 
except ImportError:
    import tkinter as tk
    from tkinter import messagebox
    
    root = tk.Tk()
    root.title("Setup")
    width, height = 400, 120
    x = (root.winfo_screenwidth() // 2) - (width // 2)
    y = (root.winfo_screenheight() // 2) - (height // 2)
    root.geometry(f"{width}x{height}+{x}+{y}")
    
    tk.Label(root, text="First Run: Installing dependencies...", font=("Segoe UI", 10, "bold")).pack(pady=(20, 5))
    tk.Label(root, text="(PyQt6, Markdown, Pygments, Pymdown-Extensions)\nThis may take a minute...", font=("Segoe UI", 8)).pack(pady=5)
    root.update()

    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "PyQt6", "PyQt6-WebEngine", "markdown", "pygments", "pymdown-extensions"])
        root.destroy()
        os.execv(sys.executable, [sys.executable] + sys.argv)
    except Exception as e:
        messagebox.showerror("Installation Failed", f"Error: {e}")
        sys.exit(1)

# --- Configuration & Styling ---
BASE_CSS = """
<style>
    :root {
        --bg-color: #ffffff;
        --text-color: #24292f;
        --link-color: #0969da;
        --code-bg: #f6f8fa;
        --code-text: #24292f;
        --border-color: #d0d7de;
        --quote-color: #57606a;
        --quote-border: #d0d7de;
        --table-header-bg: #f6f8fa;
        --table-row-even: #ffffff;
        --table-row-hover: #f6f8fa;
        --pre-border-width: 2px;
    }

    body.dark-mode {
        --bg-color: #0d1117;
        --text-color: #e6edf3;
        --link-color: #79c0ff;
        --code-bg: #161b22;
        --code-text: #e6edf3;
        --border-color: #30363d;
        --quote-color: #8b949e;
        --quote-border: #30363d;
        --table-header-bg: #161b22;
        --table-row-even: #0d1117;
        --table-row-hover: #161b22;
    }

    body {
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Noto Sans", Helvetica, Arial, sans-serif;
        line-height: 1.6;
        color: var(--text-color);
        background-color: var(--bg-color);
        margin: 0;
        padding: 32px;
        max-width: 900px;
        margin-left: auto;
        margin-right: auto;
        transition: background-color 0.3s, color 0.3s;
    }

    /* Headers */
    h1, h2, h3, h4, h5, h6 { margin-top: 24px; margin-bottom: 16px; font-weight: 600; line-height: 1.25; color: var(--text-color); }
    h1 { font-size: 2em; padding-bottom: 0.3em; border-bottom: 1px solid var(--border-color); }
    h2 { font-size: 1.5em; padding-bottom: 0.3em; border-bottom: 1px solid var(--border-color); }

    /* Links */
    a { color: var(--link-color); text-decoration: none; }
    a:hover { text-decoration: underline; }

    /* Quotes */
    blockquote { margin: 0 0 16px; padding: 0 1em; color: var(--quote-color); border-left: 0.25em solid var(--quote-border); }

    /* Code Blocks */
    pre { background-color: var(--code-bg); border-radius: 6px; padding: 16px; overflow: auto; line-height: 1.45; border: var(--pre-border-width) solid var(--border-color); }
    
    /* Inline Code */
    code { font-family: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace; padding: 0.2em 0.4em; margin: 0; font-size: 85%; background-color: var(--code-bg); color: var(--code-text); border-radius: 6px; }
    pre code { padding: 0; background-color: transparent; font-size: 100%; color: inherit; }
    
    /* Remove Red Boxes from Pygments Errors */
    .codehilite .err, .err, span.err { border: none !important; background-color: transparent !important; color: inherit !important; outline: none !important; }

    /* Dark Mode Syntax Highlighting */
    body.dark-mode .codehilite { filter: brightness(1.3) contrast(1.1); }
    body.dark-mode .codehilite .nc, body.dark-mode .codehilite .nf, body.dark-mode .codehilite .ne { color: #d2a8ff !important; }
    body.dark-mode .codehilite .k, body.dark-mode .codehilite .kn, body.dark-mode .codehilite .kp { color: #ff7b72 !important; }
    body.dark-mode .codehilite .s2, body.dark-mode .codehilite .s1 { color: #a5d6ff !important; }

    /* Tables */
    table { border-spacing: 0; border-collapse: collapse; display: block; width: max-content; max-width: 100%; overflow: auto; margin-bottom: 16px; }
    tr { background-color: var(--table-row-even); border-top: 1px solid var(--border-color); }
    tr:nth-child(2n) { background-color: var(--table-header-bg); }
    tr:hover { background-color: var(--table-row-hover); }
    th, td { padding: 6px 13px; border: 1px solid var(--border-color); }
    th { font-weight: 600; background-color: var(--table-header-bg); }

    img { max-width: 100%; box-sizing: content-box; background-color: var(--bg-color); }
    hr { height: 0.25em; padding: 0; margin: 24px 0; background-color: var(--border-color); border: 0; }
    ::-webkit-scrollbar { width: 12px; height: 12px; }
    ::-webkit-scrollbar-thumb { background-color: var(--border-color); border-radius: 6px; border: 3px solid var(--bg-color); }
    ::-webkit-scrollbar-track { background-color: var(--bg-color); }
    .arithmatex { display: inline-block; }
    
    /* Task Lists */
    .task-list-item { list-style-type: none; }
    .task-list-item-checkbox { margin: 0 0.2em 0.25em -1.6em; vertical-align: middle; }
    
    /* MathJax Display */
    .MathJax_Display, .MJXc-display { margin: 1em 0 !important; overflow-x: auto; overflow-y: hidden; }
</style>
"""

class RobustMathPreprocessor(Preprocessor):
    """
    Edge-Case Killer for Math:
    1. Handles non-breaking spaces (\xa0) which break block detection.
    2. Rescues indented '$$' blocks from being treated as code.
    3. Ensures blank lines exist around blocks for strict markdown parsers.
    """
    def run(self, lines):
        new_lines = []
        in_block_math = False
        
        for i, line in enumerate(lines):
            # FIX 1: Normalize invisible characters.
            # \xa0 (NBSP) looks like a space but acts like text, causing "blank" lines 
            # to be read as content, which merges paragraphs and breaks math blocks.
            clean_line = line.replace('\xa0', ' ')
            stripped = clean_line.strip()
            
            # FIX 2: Detect Block Math Delimiters ($$)
            # We look for lines that are exactly '$$' or start/end with '$$'
            
            # CASE A: Multi-line block start/end: strictly '$$'
            if stripped == '$$':
                if not in_block_math:
                    # Opening a block.
                    # CRITICAL: Ensure preceding line is blank for block detection.
                    if new_lines and new_lines[-1].strip() != '':
                        new_lines.append('')
                    new_lines.append('$$')
                    in_block_math = True
                else:
                    # Closing a block.
                    new_lines.append('$$')
                    # CRITICAL: Ensure following line is blank.
                    new_lines.append('') 
                    in_block_math = False
                continue
            
            # CASE B: Single-line block: $$math content$$
            if not in_block_math and stripped.startswith('$$') and stripped.endswith('$$') and len(stripped) > 4:
                if new_lines and new_lines[-1].strip() != '':
                    new_lines.append('')
                # We strip indentation to prevent code-block rendering
                new_lines.append(stripped)
                new_lines.append('')
                continue
            
            # CASE C: Inside a multi-line block
            if in_block_math:
                # We strip indentation inside the block so it aligns with the '$$'
                # and doesn't trigger code formatting inside the math environment.
                new_lines.append(stripped)
                continue

            # CASE D: Standard Content
            # We preserve the original line (with cleaned NBSP)
            new_lines.append(clean_line)
            
        return new_lines

class RobustMathExtension(Extension):
    def extendMarkdown(self, md):
        # Register with very high priority (180) to run before standard block parsers
        md.preprocessors.register(RobustMathPreprocessor(md), 'robust_math_fix', 180)

class DropFriendlyWebView(QWebEngineView):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(False)
        self.file_path = None 
        self.last_mtime = 0
        self.is_dirty = False 

class MarkdownViewer(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Markdown Viewer Pro")
        self.resize(1100, 800)
        
        # --- Settings Persistence ---
        self.settings = QSettings("Gemini", "MarkdownViewerPro")
        if self.settings.value("geometry"):
            self.restoreGeometry(self.settings.value("geometry"))

        self.is_dark_mode = self.settings.value("dark_mode", True, type=bool)
        self.default_zoom = self.settings.value("default_zoom", 1.0, type=float)
        self.recent_files = self.settings.value("recent_files", [], type=str)

        # --- Enable Drag and Drop ---
        self.setAcceptDrops(True)

        # --- Setup UI ---
        self.setup_ui()

        # --- Auto-Reload Timer ---
        self.auto_reload_enabled = False
        self.reload_timer = QTimer(self)
        self.reload_timer.timeout.connect(self.check_for_file_changes)
        
        # --- CLI Support ---
        if len(sys.argv) > 1:
            opened_any = False
            for arg in sys.argv[1:]:
                if os.path.isfile(arg):
                    self.load_file_from_path(arg)
                    opened_any = True
            if not opened_any:
                self.load_markdown(self.get_welcome_markdown(), title="Documentation")
        else:
            self.load_markdown(self.get_welcome_markdown(), title="Documentation")

    def setup_ui(self):
        # Central Widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Tabs
        self.tabs = QTabWidget()
        self.tabs.setTabsClosable(True)
        self.tabs.tabCloseRequested.connect(self.close_tab)
        self.tabs.setDocumentMode(True)
        self.tabs.currentChanged.connect(self.on_tab_changed)
        layout.addWidget(self.tabs)

        # Status Bar
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        self.path_label = QLabel("Welcome")
        self.zoom_label = QLabel("Zoom: 100%")
        self.status_bar.addPermanentWidget(self.path_label, stretch=1)
        self.status_bar.addPermanentWidget(self.zoom_label)

        # Actions & Toolbar
        self.create_actions()
        self.create_toolbar()
        self.create_menu()

    def create_actions(self):
        style = self.style()
        
        self.open_act = QAction(style.standardIcon(QStyle.StandardPixmap.SP_DirOpenIcon), "&Open", self)
        self.open_act.setShortcut("Ctrl+O")
        self.open_act.triggered.connect(self.open_file_dialog)

        self.reload_act = QAction(style.standardIcon(QStyle.StandardPixmap.SP_BrowserReload), "&Reload", self)
        self.reload_act.setShortcut("F5")
        self.reload_act.triggered.connect(self.reload_current_tab)

        self.find_focus_act = QAction("Find", self)
        self.find_focus_act.setShortcut("Ctrl+F")
        self.find_focus_act.triggered.connect(self.focus_search)
        
        self.find_next_act = QAction("Find Next", self)
        self.find_next_act.setShortcut("F3")
        self.find_next_act.triggered.connect(self.find_next)
        
        self.find_prev_act = QAction("Find Previous", self)
        self.find_prev_act.setShortcut("Shift+F3")
        self.find_prev_act.triggered.connect(self.find_prev)

        icon = QIcon.fromTheme("document-print")
        if icon.isNull():
            icon = style.standardIcon(QStyle.StandardPixmap.SP_ComputerIcon) # Fallback
            if hasattr(QStyle.StandardPixmap, "SP_Printer"):
                icon = style.standardIcon(QStyle.StandardPixmap.SP_Printer)
                
        self.print_act = QAction(icon, "Print...", self)
        self.print_act.setShortcut("Ctrl+P")
        self.print_act.triggered.connect(self.print_current_page)
        
        self.export_pdf_act = QAction("Export to PDF...", self)
        self.export_pdf_act.triggered.connect(self.export_to_pdf)

        self.zoom_in_act = QAction("Zoom In", self)
        self.zoom_in_act.setShortcut("Ctrl++")
        self.zoom_in_act.triggered.connect(lambda: self.adjust_zoom(0.1))

        self.zoom_out_act = QAction("Zoom Out", self)
        self.zoom_out_act.setShortcut("Ctrl+-")
        self.zoom_out_act.triggered.connect(lambda: self.adjust_zoom(-0.1))
        
        self.zoom_reset_act = QAction("Reset Zoom", self)
        self.zoom_reset_act.setShortcut("Ctrl+0")
        self.zoom_reset_act.triggered.connect(lambda: self.adjust_zoom(0, reset=True))

        self.dark_mode_act = QAction("Dark Mode", self, checkable=True)
        self.dark_mode_act.setShortcut("Ctrl+D")
        self.dark_mode_act.setChecked(self.is_dark_mode)
        self.dark_mode_act.triggered.connect(self.toggle_dark_mode)
        
        self.auto_reload_act = QAction("Auto-Reload", self, checkable=True)
        self.auto_reload_act.triggered.connect(self.toggle_auto_reload)

        self.close_tab_act = QAction("Close Tab", self)
        self.close_tab_act.setShortcut("Ctrl+W")
        self.close_tab_act.triggered.connect(self.close_current_tab)

        self.exit_act = QAction("Exit", self)
        self.exit_act.setShortcut("Ctrl+Q")
        self.exit_act.triggered.connect(self.close)
        
        self.about_act = QAction("About", self)
        self.about_act.triggered.connect(self.show_about)
        
        # Search Actions (for the toolbar buttons)
        self.search_case_act = QAction("Aa", self, checkable=True)
        self.search_case_act.setToolTip("Case Sensitive")

    def create_toolbar(self):
        toolbar = QToolBar("Main Toolbar")
        toolbar.setMovable(False)
        toolbar.setIconSize(QSize(24, 24))
        self.addToolBar(toolbar)

        toolbar.addAction(self.open_act)
        toolbar.addAction(self.reload_act)
        toolbar.addSeparator()
        toolbar.addAction(self.print_act)
        toolbar.addSeparator()
        toolbar.addAction(self.zoom_in_act)
        toolbar.addAction(self.zoom_out_act)
        toolbar.addSeparator()
        toolbar.addAction(self.dark_mode_act)
        toolbar.addSeparator()
        
        # Spacer to push search to the right
        spacer = QWidget()
        spacer.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        toolbar.addWidget(spacer)
        
        # Search Widgets in Toolbar
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Find...")
        self.search_input.setMaximumWidth(200)
        self.search_input.setClearButtonEnabled(True)
        self.search_input.returnPressed.connect(self.find_next)
        self.search_input.textChanged.connect(self.on_search_text_changed)
        toolbar.addWidget(self.search_input)
        
        toolbar.addAction(self.search_case_act)
        
        act_prev = QAction("<", self)
        act_prev.setToolTip("Previous Match")
        act_prev.triggered.connect(self.find_prev)
        toolbar.addAction(act_prev)
        
        act_next = QAction(">", self)
        act_next.setToolTip("Next Match")
        act_next.triggered.connect(self.find_next)
        toolbar.addAction(act_next)

    def create_menu(self):
        menubar = self.menuBar()
        
        file_menu = menubar.addMenu("&File")
        file_menu.addAction(self.open_act)
        
        self.recent_menu = file_menu.addMenu("Open &Recent")
        self.update_recent_menu()
        
        file_menu.addAction(self.reload_act)
        file_menu.addAction(self.print_act)
        file_menu.addAction(self.export_pdf_act)
        file_menu.addAction(self.close_tab_act)
        file_menu.addSeparator()
        file_menu.addAction(self.exit_act)

        view_menu = menubar.addMenu("&View")
        view_menu.addAction(self.dark_mode_act)
        view_menu.addAction(self.auto_reload_act)
        view_menu.addSeparator()
        view_menu.addAction(self.zoom_in_act)
        view_menu.addAction(self.zoom_out_act)
        view_menu.addAction(self.zoom_reset_act)
        
        edit_menu = menubar.addMenu("&Edit")
        edit_menu.addAction(self.find_focus_act)
        edit_menu.addAction(self.find_next_act)
        edit_menu.addAction(self.find_prev_act)
        
        help_menu = menubar.addMenu("&Help")
        help_menu.addAction(self.about_act)

    # --- Search Logic ---
    def focus_search(self):
        self.search_input.setFocus()
        self.search_input.selectAll()
        
    def get_find_flags(self):
        flags = QWebEnginePage.FindFlag(0)
        if self.search_case_act.isChecked():
            flags |= QWebEnginePage.FindFlag.FindCaseSensitively
        return flags
        
    def find_next(self):
        view = self.tabs.currentWidget()
        text = self.search_input.text()
        if isinstance(view, QWebEngineView) and text:
            view.findText(text, self.get_find_flags())
            
    def find_prev(self):
        view = self.tabs.currentWidget()
        text = self.search_input.text()
        if isinstance(view, QWebEngineView) and text:
            flags = self.get_find_flags() | QWebEnginePage.FindFlag.FindBackward
            view.findText(text, flags)

    def on_search_text_changed(self, text):
        if not text:
            view = self.tabs.currentWidget()
            if isinstance(view, QWebEngineView):
                view.findText("")

    # --- Recent Files ---
    def add_recent_file(self, file_path):
        if file_path in self.recent_files:
            self.recent_files.remove(file_path)
        self.recent_files.insert(0, file_path)
        self.recent_files = self.recent_files[:10]
        self.settings.setValue("recent_files", self.recent_files)
        self.update_recent_menu()

    def update_recent_menu(self):
        self.recent_menu.clear()
        if not self.recent_files:
            self.recent_menu.addAction("No recent files").setEnabled(False)
            return
            
        for path in self.recent_files:
            action = QAction(os.path.basename(path), self)
            action.setStatusTip(path)
            action.triggered.connect(lambda checked, p=path: self.load_file_from_path(p))
            self.recent_menu.addAction(action)
        
        self.recent_menu.addSeparator()
        clear_act = QAction("Clear Recent", self)
        clear_act.triggered.connect(self.clear_recent)
        self.recent_menu.addAction(clear_act)

    def clear_recent(self):
        self.recent_files = []
        self.settings.setValue("recent_files", [])
        self.update_recent_menu()

    # --- Event Handlers ---
    def closeEvent(self, event):
        self.settings.setValue("geometry", self.saveGeometry())
        self.settings.setValue("dark_mode", self.is_dark_mode)
        super().closeEvent(event)

    def on_tab_changed(self, index):
        view = self.tabs.widget(index)
        if isinstance(view, DropFriendlyWebView):
            filename = os.path.basename(view.file_path) if view.file_path else "Welcome"
            self.setWindowTitle(f"{filename} - Markdown Viewer Pro")
            self.path_label.setText(view.file_path if view.file_path else "Welcome")
            self.zoom_label.setText(f"Zoom: {int(view.zoomFactor() * 100)}%")
            if view.is_dirty:
                self.reload_specific_tab(view, quiet=True)
                view.is_dirty = False
                self.tabs.setTabText(index, filename)

    def dragEnterEvent(self, event: QDragEnterEvent):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            event.ignore()

    def dropEvent(self, event: QDropEvent):
        files = [u.toLocalFile() for u in event.mimeData().urls()]
        first_new_tab_index = None
        for file_path in files:
            if os.path.isfile(file_path):
                self.load_file_from_path(file_path)
                if first_new_tab_index is None:
                    first_new_tab_index = self.tabs.count() - 1
        if first_new_tab_index is not None:
             self.tabs.setCurrentIndex(first_new_tab_index)

    # --- Core Logic ---
    def open_file_dialog(self):
        file_name, _ = QFileDialog.getOpenFileName(
            self, "Open Markdown File", "", "Markdown Files (*.md);;Text Files (*.txt);;All Files (*)"
        )
        if file_name:
            self.load_file_from_path(file_name)

    def load_file_from_path(self, file_path):
        try:
            # Use utf-8-sig to handle optional BOM which can break parsing
            with open(file_path, 'r', encoding='utf-8-sig') as f:
                content = f.read()
            self.add_recent_file(file_path)
            self.load_markdown(content, base_path=os.path.dirname(file_path), title=os.path.basename(file_path), file_path=file_path)
        except Exception as e:
            QMessageBox.critical(self, "Error Loading File", f"Could not load file:\n{file_path}\n\nError:\n{e}")

    def reload_current_tab(self, quiet=False):
        view = self.tabs.currentWidget()
        self.reload_specific_tab(view, quiet)

    def reload_specific_tab(self, view, quiet=False):
        if isinstance(view, DropFriendlyWebView) and view.file_path:
            def on_scroll_captured(scroll_pos):
                if scroll_pos is None: scroll_pos = 0
                self._perform_reload(view, quiet, scroll_pos)
            view.page().runJavaScript("window.scrollY", on_scroll_captured)

    def _perform_reload(self, view, quiet, scroll_pos):
        try:
            with open(view.file_path, 'r', encoding='utf-8-sig') as f:
                content = f.read()
            
            self.load_markdown(content, 
                               base_path=os.path.dirname(view.file_path), 
                               title=os.path.basename(view.file_path), 
                               file_path=view.file_path,
                               view=view)
            
            def restore():
                view.page().runJavaScript(f"window.scrollTo(0, {scroll_pos});")
            QTimer.singleShot(50, restore)

            if os.path.exists(view.file_path):
                view.last_mtime = os.path.getmtime(view.file_path)

            if not quiet and view == self.tabs.currentWidget():
                self.status_bar.showMessage("Reloaded", 2000)
        except Exception as e:
            if not quiet:
                QMessageBox.critical(self, "Reload Failed", str(e))

    def close_tab(self, index):
        if self.tabs.count() <= 1:
            self.load_markdown(self.get_welcome_markdown(), title="Documentation")
            self.tabs.removeTab(index) 
        else:
            self.tabs.removeTab(index)

    def close_current_tab(self):
        self.close_tab(self.tabs.currentIndex())

    def adjust_zoom(self, delta, reset=False):
        view = self.tabs.currentWidget()
        if view:
            if reset:
                view.setZoomFactor(1.0)
            else:
                view.setZoomFactor(view.zoomFactor() + delta)
            self.zoom_label.setText(f"Zoom: {int(view.zoomFactor() * 100)}%")
            self.default_zoom = view.zoomFactor()
            self.settings.setValue("default_zoom", self.default_zoom)

    def print_current_page(self):
        view = self.tabs.currentWidget()
        if not view: return
        printer = QPrinter(QPrinter.PrinterMode.HighResolution)
        dialog = QPrintDialog(printer, self)
        if dialog.exec() == QPrintDialog.DialogCode.Accepted:
            view.page().print(printer, lambda success: None)

    def export_to_pdf(self):
        view = self.tabs.currentWidget()
        if not view: return
        file_name, _ = QFileDialog.getSaveFileName(self, "Export to PDF", "", "PDF Files (*.pdf)")
        if file_name:
            try: view.page().pdfPrintingFinished.disconnect()
            except: pass
            view.page().pdfPrintingFinished.connect(lambda path, success: self.on_pdf_finished(path, success))
            view.page().printToPdf(file_name)

    def on_pdf_finished(self, path, success):
        if success:
            self.status_bar.showMessage(f"Exported to {os.path.basename(path)}", 3000)
        else:
            QMessageBox.warning(self, "Export Failed", "Could not save PDF file.")

    def toggle_auto_reload(self):
        self.auto_reload_enabled = self.auto_reload_act.isChecked()
        if self.auto_reload_enabled:
            self.reload_timer.start(2000)
            self.status_bar.showMessage("Auto-Reload Enabled", 2000)
        else:
            self.reload_timer.stop()
            self.status_bar.showMessage("Auto-Reload Disabled", 2000)

    def check_for_file_changes(self):
        current_view = self.tabs.currentWidget()
        for i in range(self.tabs.count()):
            view = self.tabs.widget(i)
            if isinstance(view, DropFriendlyWebView) and view.file_path:
                try:
                    mtime = os.path.getmtime(view.file_path)
                    if mtime > view.last_mtime:
                        view.last_mtime = mtime
                        if view == current_view:
                            self.reload_specific_tab(view, quiet=False)
                            self.status_bar.showMessage(f"Auto-Reloaded: {os.path.basename(view.file_path)}", 2000)
                        else:
                            view.is_dirty = True
                            title = os.path.basename(view.file_path)
                            self.tabs.setTabText(i, title + " *")
                except OSError:
                    pass
    
    def show_about(self):
        QMessageBox.about(self, "About Markdown Viewer Pro", 
                          "<h3>Markdown Viewer Pro v7.4</h3>"
                          "<p>A lightweight, professional Markdown viewer built with PyQt6.</p>"
                          "<ul>"
                          "<li><b>Features:</b> Tabs, Dark Mode, MathJax, Auto-Reload, PDF Export</li>"
                          "<li><b>Robustness:</b> Fixes non-breaking spaces and indented math blocks automatically.</li>"
                          "<li><b>Author:</b> Gemini</li>"
                          "</ul>")

    # --- Rendering Logic ---
    def load_markdown(self, markdown_text, base_path=None, title="Untitled", file_path=None, view=None):
        try:
            # Configure Extensions based on file type
            extensions = [
                RobustMathExtension(), # CRITICAL: Fixes indentation/whitespace issues before parsing
                'pymdownx.superfences',
                'pymdownx.highlight',
                'pymdownx.tasklist',
                'pymdownx.arithmatex', # Standard math extension for rendering
                'tables',
                'sane_lists'
            ]
            
            # Enable nl2br ONLY for .txt files to preserve line breaks, BUT be careful with math.
            # RobustMathPreprocessor should handle blocks so nl2br doesn't break them.
            if file_path and file_path.lower().endswith('.txt'):
                extensions.append('nl2br')

            extension_configs = {
                'pymdownx.superfences': {'disable_indented_code_blocks': False},
                'pymdownx.highlight': {
                    'use_pygments': True,
                    'guess_lang': True,
                    'css_class': 'codehilite'
                },
                'pymdownx.arithmatex': {
                    'generic': True,
                    'smart_dollar': True
                }
            }

            # Convert to HTML
            html_content = markdown.markdown(markdown_text, extensions=extensions, extension_configs=extension_configs)
            
        except Exception as e:
            html_content = f"<h3>Error parsing markdown</h3><pre>{e}</pre>"

        formatter = HtmlFormatter(style='friendly') 
        pygments_css = formatter.get_style_defs('.codehilite')
        
        base_tag = f'<base href="file:///{base_path.replace(os.sep, "/")}/">' if base_path else ""
        body_class = "dark-mode" if self.is_dark_mode else ""
        
        full_html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            {base_tag}
            {BASE_CSS}
            <style>
                {pygments_css}
                .codehilite {{ background: transparent !important; }}
                .codehilite pre {{ background: transparent !important; }}
                .math-block {{ margin: 1em 0; text-align: center; }} 
            </style>
            <script>
            window.MathJax = {{
              tex: {{
                inlineMath: [['$', '$'], ['\\\\(', '\\\\)']],
                displayMath: [['$$', '$$'], ['\\\\[', '\\\\]']],
                processEscapes: true,
                processEnvironments: true
              }},
              options: {{
                ignoreHtmlClass: 'tex2jax_ignore',
                processHtmlClass: 'tex2jax_process'
              }},
              loader: {{ load: ['[tex]/ams'], version: '3' }}
            }};
            </script>
            <script id="MathJax-script" async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>
        </head>
        <body class="{body_class}">
            {html_content}
        </body>
        </html>
        """

        if view is None:
            view = DropFriendlyWebView()
            view.setContextMenuPolicy(Qt.ContextMenuPolicy.NoContextMenu)
            view.setZoomFactor(self.default_zoom)
            index = self.tabs.addTab(view, title)
            self.tabs.setCurrentIndex(index)
        else:
            current_index = self.tabs.indexOf(view)
            if current_index != -1:
                self.tabs.setTabText(current_index, title)
        
        base_url = QUrl.fromLocalFile(base_path + "/") if base_path else QUrl()
        view.setHtml(full_html, base_url)
        view.file_path = file_path
        
        if file_path and os.path.exists(file_path):
            view.last_mtime = os.path.getmtime(file_path)

    def toggle_dark_mode(self):
        self.is_dark_mode = self.dark_mode_act.isChecked()
        js_code = "document.body.classList.toggle('dark-mode');"
        for i in range(self.tabs.count()):
            view = self.tabs.widget(i)
            if isinstance(view, QWebEngineView):
                view.page().runJavaScript(js_code)

    def get_welcome_markdown(self):
        return r"""
# Markdown Viewer Pro - Documentation

## 1. Getting Started
**Markdown Viewer Pro** allows you to view Markdown (`.md`) and Text (`.txt`) files with rich formatting, syntax highlighting, and math support.

### Opening Files
- **File Menu**: Go to `File > Open` (or press `Ctrl+O`).
- **Drag & Drop**: Simply drag files from your file explorer onto the window.
- **Recent Files**: Quickly access previous documents via `File > Open Recent`.
- **Text Files**: `.txt` files are fully supported. Line breaks are preserved automatically.

## 2. Features

### Navigation & Viewing
- **Tabs**: Open multiple documents at once. Use `Ctrl+W` to close the current tab.
- **Zoom**: Adjust text size with `Ctrl +` / `Ctrl -` or use the toolbar buttons.
- **Dark Mode**: Toggle via `View > Dark Mode` (`Ctrl+D`) for comfortable reading at night.
- **Search**: Use the toolbar search box (`Ctrl+F`). Press `F3` for next, `Shift+F3` for previous. The `Aa` button toggles case sensitivity. Click 'X' to clear highlights.

### Automatic Reloading
- **Manual**: Press `F5` to reload the current file.
- **Auto-Reload**: Enable `View > Auto-Reload` to watch files for changes.
    - **Smart Behavior**: If you are editing a file in another tab, it will update quietly in the background (marked with a `*`). When you switch back to it, it reloads instantly without losing your place.

### Exporting
- **PDF**: Go to `File > Export to PDF...` to save your document as a high-quality PDF.
- **Print**: Use `File > Print...` (`Ctrl+P`) to print to a physical printer.

## 3. Syntax Highlighting
Code blocks are automatically highlighted.

**Python Example:**
```python
def hello_world():
    print("Hello, Markdown!")
```

## 4. Math Support
We use MathJax to render LaTeX equations beautifully.

- **Inline**: $E = mc^2$
- **Block**:
$$\int_{a}^{b} x^2 dx$$

## 5. Task Lists
- [x] Read Documentation
- [ ] Try Drag & Drop
- [ ] Export a PDF
"""

if __name__ == "__main__":
    if hasattr(Qt.ApplicationAttribute, "AA_EnableHighDpiScaling"):
        QApplication.setAttribute(Qt.ApplicationAttribute.AA_EnableHighDpiScaling, True)
    if hasattr(Qt.ApplicationAttribute, "AA_UseHighDpiPixmaps"):
        QApplication.setAttribute(Qt.ApplicationAttribute.AA_UseHighDpiPixmaps, True)

    app = QApplication(sys.argv)
    app.setStyle("Fusion") 
    viewer = MarkdownViewer()
    viewer.show()
    sys.exit(app.exec())