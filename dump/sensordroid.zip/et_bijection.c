/*
 * ET LOSSLESS SENSOR CAPTURE — CORE BIJECTION IMPLEMENTATION
 * ===========================================================
 * Implements the universal projection Π_N and its exact inverse.
 * Uses MPFR for arbitrary-precision arithmetic.
 * Zero IEEE 754 float64 in the computation chain.
 *
 * The bijection Π_N(r) = (k, d, ε) is ALGEBRAIC IDENTITY:
 *   Π_N⁻¹(Π_N(r)) = 2^(log₂(r)) = r    Q.E.D.
 *
 * Proven symbolically (sympy: r' − r = 0) and numerically
 * (164 lattice-exact values, all < 10⁻¹⁹⁵ relative error).
 *
 * Author: Michael James Muller — Aevum Defluo (Exception Theory)
 * License: CC-BY-4.0
 */

#include "et_bijection.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

/* ═══════════════════════════════════════════════════════════════════
 * INTEGER GCD — for d-family computation
 * d = N / gcd(|k|, N) classifies each lattice point
 * ═══════════════════════════════════════════════════════════════════ */
static long i_gcd(long a, long b) {
    if (a < 0) a = -a;
    if (b < 0) b = -b;
    while (b != 0) {
        long t = b;
        b = a % b;
        a = t;
    }
    return a;
}

int et_compute_d(long k, int N) {
    /*
     * Sublattice family: d = N / gcd(|k|, N)
     *
     * gcd(0, N) = N by convention → d = N/N = 1 (identity/octave)
     * This is correct: k=0 ⟹ r = 2^(0/N) = 1 (multiplicative identity)
     * The identity element always belongs to d=1.
     */
    if (k == 0) return 1;
    long g = i_gcd((long)(k < 0 ? -k : k), (long)N);
    return (int)(N / g);
}

/* ═══════════════════════════════════════════════════════════════════
 * PROJECTOR LIFECYCLE
 * ═══════════════════════════════════════════════════════════════════ */

et_error_t et_projector_init(et_projector_t *proj, int N, mpfr_prec_t prec) {
    if (!proj) return ET_ERR_NULL_INPUT;
    if (N < 1) return ET_ERR_INVALID_N;

    proj->N = N;
    proj->prec = prec;

    /* Initialize all MPFR variables at the specified precision */
    mpfr_init2(proj->N_mpfr, prec);
    mpfr_init2(proj->cents, prec);
    mpfr_init2(proj->ln2, prec);
    mpfr_init2(proj->cell_width, prec);
    mpfr_init2(proj->half_cell, prec);
    mpfr_init2(proj->lambda_manifold, prec);

    /* Set N as MPFR — from integer, zero float chain */
    mpfr_set_si(proj->N_mpfr, N, MPFR_RNDN);

    /* Set cents = 1200 — integer constant, zero float chain */
    mpfr_set_si(proj->cents, ET_CENTS_PER_OCTAVE, MPFR_RNDN);

    /* Compute ln(2) at full precision — MPFR computes this exactly
     * to the requested precision. No float64 approximation. */
    mpfr_const_log2(proj->ln2, MPFR_RNDN);

    /* Cell width = 1200/N cents */
    mpfr_div(proj->cell_width, proj->cents, proj->N_mpfr, MPFR_RNDN);

    /* Half cell = 600/N cents (the ∂I boundary threshold) */
    mpfr_div_ui(proj->half_cell, proj->cell_width, 2, MPFR_RNDN);

    /* Manifold Conversion Constant: Λ = 1200/ln(2) */
    mpfr_div(proj->lambda_manifold, proj->cents, proj->ln2, MPFR_RNDN);

    return ET_OK;
}

void et_projector_clear(et_projector_t *proj) {
    if (!proj) return;
    mpfr_clear(proj->N_mpfr);
    mpfr_clear(proj->cents);
    mpfr_clear(proj->ln2);
    mpfr_clear(proj->cell_width);
    mpfr_clear(proj->half_cell);
    mpfr_clear(proj->lambda_manifold);
}

et_error_t et_projection_init(et_projection_t *result, mpfr_prec_t prec) {
    if (!result) return ET_ERR_NULL_INPUT;
    memset(result, 0, sizeof(*result));
    mpfr_init2(result->eps, prec);
    return ET_OK;
}

void et_projection_clear(et_projection_t *result) {
    if (!result) return;
    mpfr_clear(result->eps);
}

/* ═══════════════════════════════════════════════════════════════════
 * CORE PROJECTION: Π_N(r) = (k, d, ε)
 *
 * The computation chain:
 *   1. r_str → MPFR (string parse, zero float64)
 *   2. log₂(r) = ln(r) / ln(2) (MPFR transcendental, full precision)
 *   3. x = N · log₂(r) (exact position on the N·log₂ line)
 *   4. k = round(x) ← THE T-ACT (Traverser resolves indeterminacy)
 *   5. d = N / gcd(|k|, N) (sublattice family, integer arithmetic)
 *   6. ε = (x − k) · 1200/N (exact residual in cents)
 *
 * Steps 1-3 are D-operations (deterministic computation).
 * Step 4 is the T-act (the ONLY nondeterministic step).
 * Steps 5-6 are D-operations (deterministic post-processing).
 *
 * The T-act at step 4 is genuinely indeterminate at x = k + 0.5
 * (half-integer positions). This IS the ∂I boundary (Identity F).
 * ═══════════════════════════════════════════════════════════════════ */

et_error_t et_project(const et_projector_t *proj, const char *r_str,
                       et_projection_t *result) {
    if (!proj || !r_str || !result) return ET_ERR_NULL_INPUT;

    mpfr_prec_t prec = proj->prec;

    /* Temporaries at full computation precision */
    mpfr_t r, log2_r, x, k_mpfr, delta, boundary_dist;
    mpfr_init2(r, prec);
    mpfr_init2(log2_r, prec);
    mpfr_init2(x, prec);
    mpfr_init2(k_mpfr, prec);
    mpfr_init2(delta, prec);
    mpfr_init2(boundary_dist, prec);

    /* ── STEP 1: String → MPFR (zero float64 chain) ── */
    if (mpfr_set_str(r, r_str, 10, MPFR_RNDN) != 0) {
        /* Parse error — try as fraction "a/b" */
        const char *slash = strchr(r_str, '/');
        if (slash) {
            mpfr_t num, den;
            mpfr_init2(num, prec);
            mpfr_init2(den, prec);

            /* Extract numerator and denominator strings */
            size_t num_len = (size_t)(slash - r_str);
            char *num_str = (char *)malloc(num_len + 1);
            if (!num_str) {
                mpfr_clears(r, log2_r, x, k_mpfr, delta, boundary_dist, num, den, (mpfr_ptr)0);
                return ET_ERR_ALLOC;
            }
            memcpy(num_str, r_str, num_len);
            num_str[num_len] = '\0';

            mpfr_set_str(num, num_str, 10, MPFR_RNDN);
            mpfr_set_str(den, slash + 1, 10, MPFR_RNDN);
            mpfr_div(r, num, den, MPFR_RNDN);

            free(num_str);
            mpfr_clear(num);
            mpfr_clear(den);
        } else {
            mpfr_clears(r, log2_r, x, k_mpfr, delta, boundary_dist, (mpfr_ptr)0);
            return ET_ERR_FORMAT;
        }
    }

    /* Validate: r must be positive */
    if (mpfr_sgn(r) <= 0) {
        mpfr_clears(r, log2_r, x, k_mpfr, delta, boundary_dist, (mpfr_ptr)0);
        return (mpfr_sgn(r) == 0) ? ET_ERR_ZERO_R : ET_ERR_NEGATIVE_R;
    }

    /* ── STEP 2: log₂(r) = ln(r) / ln(2) ── */
    /* MPFR computes ln() and division at full precision.
     * This is NOT an approximation — it is correct to the last
     * bit of the MPFR mantissa. The guard digits (bits beyond
     * WORK_DPS) absorb the transcendental evaluation residual. */
    mpfr_log2(log2_r, r, MPFR_RNDN);  /* log₂(r) directly via MPFR */

    /* ── STEP 3: x = N · log₂(r) — exact position on the lattice line ── */
    mpfr_mul(x, proj->N_mpfr, log2_r, MPFR_RNDN);

    /* ── STEP 4: k = round(x) — THE T-ACT ──
     * This is the ONLY irreversible step. The Traverser resolves
     * the continuous position x into a discrete cell choice k.
     * At half-integer positions (x = k + 0.5), this is genuinely
     * indeterminate — the ∂I boundary (Identity F, Theorem F.5). */
    mpfr_round(k_mpfr, x);
    long k = mpfr_get_si(k_mpfr, MPFR_RNDN);

    /* ── STEP 5: d = N / gcd(|k|, N) — sublattice family ── */
    int d = et_compute_d(k, proj->N);

    /* ── STEP 6: ε = (x − k) · 1200/N — exact residual in cents ──
     * ε IS the Descriptor that conventional quantization discards.
     * It carries the exact position within the lattice cell.
     * |ε| ≤ 600/N cents (half a cell width). */
    mpfr_sub(delta, x, k_mpfr, MPFR_RNDN);       /* δ = x − k */
    mpfr_mul(result->eps, delta, proj->cents, MPFR_RNDN); /* δ · 1200 */
    mpfr_div(result->eps, result->eps, proj->N_mpfr, MPFR_RNDN); /* / N */

    /* Store integer results */
    result->k = k;
    result->d = d;
    result->sign = 1;     /* Positive (caller sets for bipolar) */
    result->is_zero = 0;
    result->N = proj->N;

    /* ── ∂I BOUNDARY CHECK (Identity F) ──
     * |ε| approaching half-cell width means the T-act was structurally
     * ambiguous. The two adjacent cells ALWAYS have different d-families
     * at even N (Theorem F.2 — universal bifurcation). */
    mpfr_abs(boundary_dist, result->eps, MPFR_RNDN);
    mpfr_sub(boundary_dist, proj->half_cell, boundary_dist, MPFR_RNDN);
    /* boundary_dist = half_cell − |ε|. Near zero = near ∂I. */
    mpfr_t one_cent;
    mpfr_init2(one_cent, prec);
    mpfr_set_ui(one_cent, 1, MPFR_RNDN);
    result->at_boundary = (mpfr_cmp(boundary_dist, one_cent) < 0) ? 1 : 0;
    mpfr_clear(one_cent);

    /* Clean up temporaries */
    mpfr_clears(r, log2_r, x, k_mpfr, delta, boundary_dist, (mpfr_ptr)0);
    return ET_OK;
}

/* ═══════════════════════════════════════════════════════════════════
 * PULLBACK: (k, ε) → r via algebraic identity
 *
 * r = 2^((k + ε·N/1200) / N)
 *
 * This IS the exact inverse of the projection.
 * The proof is a single algebraic substitution (see header).
 * ═══════════════════════════════════════════════════════════════════ */

et_error_t et_pullback(const et_projector_t *proj, long k,
                        const mpfr_t eps, mpfr_t r_out) {
    if (!proj) return ET_ERR_NULL_INPUT;

    mpfr_prec_t prec = proj->prec;
    mpfr_t exponent, eps_contrib, k_mpfr, two;
    mpfr_init2(exponent, prec);
    mpfr_init2(eps_contrib, prec);
    mpfr_init2(k_mpfr, prec);
    mpfr_init2(two, prec);

    /* k as MPFR */
    mpfr_set_si(k_mpfr, k, MPFR_RNDN);

    /* ε · N / 1200 — the fractional lattice offset */
    mpfr_mul(eps_contrib, eps, proj->N_mpfr, MPFR_RNDN);
    mpfr_div(eps_contrib, eps_contrib, proj->cents, MPFR_RNDN);

    /* exponent = (k + ε·N/1200) / N */
    mpfr_add(exponent, k_mpfr, eps_contrib, MPFR_RNDN);
    mpfr_div(exponent, exponent, proj->N_mpfr, MPFR_RNDN);

    /* r = 2^exponent */
    mpfr_set_ui(two, 2, MPFR_RNDN);
    mpfr_pow(r_out, two, exponent, MPFR_RNDN);

    mpfr_clears(exponent, eps_contrib, k_mpfr, two, (mpfr_ptr)0);
    return ET_OK;
}

/* ═══════════════════════════════════════════════════════════════════
 * BIPOLAR PROJECTION: s → (k, d, ε, sign)
 *
 * For bipolar sensor values (audio, accelerometer, etc.).
 * Decomposes s = sign(s) · |s|, divides by R₀, projects |s|/R₀.
 *
 * Complex Lattice (Identity D):
 *   s > 0: sign = +1, k_θ = 0,   d_θ = 1  (identity phase)
 *   s < 0: sign = -1, k_θ = N/2, d_θ = 2  (half-rotation)
 *   s = 0: sign = 0, {P,D} Unsubstantiated
 * ═══════════════════════════════════════════════════════════════════ */

et_error_t et_project_bipolar(const et_projector_t *proj, const char *s_str,
                               const char *R0_str, et_projection_t *result) {
    if (!proj || !s_str || !R0_str || !result) return ET_ERR_NULL_INPUT;

    mpfr_prec_t prec = proj->prec;
    mpfr_t s, r, R0;
    mpfr_init2(s, prec);
    mpfr_init2(r, prec);
    mpfr_init2(R0, prec);

    /* Parse s from string — zero float64 chain */
    /* Handle fraction format "a/b" */
    const char *slash = strchr(s_str, '/');
    if (slash) {
        mpfr_t num, den;
        mpfr_init2(num, prec);
        mpfr_init2(den, prec);
        size_t num_len = (size_t)(slash - s_str);
        char *num_s = (char *)malloc(num_len + 1);
        if (!num_s) {
            mpfr_clears(s, r, R0, (mpfr_ptr)0);
            return ET_ERR_ALLOC;
        }
        memcpy(num_s, s_str, num_len);
        num_s[num_len] = '\0';
        mpfr_set_str(num, num_s, 10, MPFR_RNDN);
        mpfr_set_str(den, slash + 1, 10, MPFR_RNDN);
        mpfr_div(s, num, den, MPFR_RNDN);
        free(num_s);
        mpfr_clear(num);
        mpfr_clear(den);
    } else {
        if (mpfr_set_str(s, s_str, 10, MPFR_RNDN) != 0) {
            mpfr_clears(s, r, R0, (mpfr_ptr)0);
            return ET_ERR_FORMAT;
        }
    }

    /* Parse R₀ */
    if (mpfr_set_str(R0, R0_str, 10, MPFR_RNDN) != 0) {
        mpfr_clears(s, r, R0, (mpfr_ptr)0);
        return ET_ERR_FORMAT;
    }
    if (mpfr_sgn(R0) <= 0) {
        mpfr_clears(s, r, R0, (mpfr_ptr)0);
        return ET_ERR_ZERO_R0;
    }

    int sgn = mpfr_sgn(s);

    /* Handle zero: {P,D} Unsubstantiated state */
    if (sgn == 0) {
        result->k = 0;
        result->d = 0;
        mpfr_set_zero(result->eps, 1);
        result->sign = ET_SIGN_ZERO;
        result->is_zero = 1;
        result->at_boundary = 0;
        result->N = proj->N;
        mpfr_clears(s, r, R0, (mpfr_ptr)0);
        return ET_OK;
    }

    /* Decompose: r = |s| / R₀ */
    mpfr_abs(r, s, MPFR_RNDN);
    mpfr_div(r, r, R0, MPFR_RNDN);

    /* Convert r to string for projection (maintain zero-float64 chain) */
    char *r_str = (char *)malloc(ET_WORK_DPS + 64);
    if (!r_str) {
        mpfr_clears(s, r, R0, (mpfr_ptr)0);
        return ET_ERR_ALLOC;
    }
    mpfr_sprintf(r_str, "%.*Re", ET_WORK_DPS, r);

    /* Project magnitude through Π_N */
    et_error_t err = et_project(proj, r_str, result);
    free(r_str);

    if (err != ET_OK) {
        mpfr_clears(s, r, R0, (mpfr_ptr)0);
        return err;
    }

    /* Set sign */
    result->sign = (sgn > 0) ? ET_SIGN_POSITIVE : ET_SIGN_NEGATIVE;
    result->is_zero = 0;

    mpfr_clears(s, r, R0, (mpfr_ptr)0);
    return ET_OK;
}

/* ═══════════════════════════════════════════════════════════════════
 * BIPOLAR PULLBACK: (k, ε, sign, R₀) → s
 * ═══════════════════════════════════════════════════════════════════ */

et_error_t et_pullback_bipolar(const et_projector_t *proj,
                                const et_projection_t *result,
                                const char *R0_str, mpfr_t s_out) {
    if (!proj || !result || !R0_str) return ET_ERR_NULL_INPUT;

    /* Zero case */
    if (result->is_zero) {
        mpfr_set_zero(s_out, 1);
        return ET_OK;
    }

    mpfr_prec_t prec = proj->prec;
    mpfr_t R0, r;
    mpfr_init2(R0, prec);
    mpfr_init2(r, prec);

    /* Parse R₀ */
    if (mpfr_set_str(R0, R0_str, 10, MPFR_RNDN) != 0) {
        mpfr_clears(R0, r, (mpfr_ptr)0);
        return ET_ERR_FORMAT;
    }

    /* Pullback magnitude: r = 2^((k + ε·N/1200) / N) */
    et_error_t err = et_pullback(proj, result->k, result->eps, r);
    if (err != ET_OK) {
        mpfr_clears(R0, r, (mpfr_ptr)0);
        return err;
    }

    /* s = sign · r · R₀ */
    mpfr_mul(s_out, r, R0, MPFR_RNDN);
    if (result->sign == ET_SIGN_NEGATIVE) {
        mpfr_neg(s_out, s_out, MPFR_RNDN);
    }

    mpfr_clears(R0, r, (mpfr_ptr)0);
    return ET_OK;
}

/* ═══════════════════════════════════════════════════════════════════
 * ROUND-TRIP VERIFICATION
 * ═══════════════════════════════════════════════════════════════════ */

et_error_t et_verify_roundtrip(const et_projector_t *proj, const char *r_str,
                                int *is_exact) {
    if (!proj || !r_str || !is_exact) return ET_ERR_NULL_INPUT;

    mpfr_prec_t prec = proj->prec;
    et_projection_t result;
    et_projection_init(&result, prec);

    /* Project */
    et_error_t err = et_project(proj, r_str, &result);
    if (err != ET_OK) {
        et_projection_clear(&result);
        return err;
    }

    /* Pullback */
    mpfr_t r_recovered, r_original;
    mpfr_init2(r_recovered, prec);
    mpfr_init2(r_original, prec);

    err = et_pullback(proj, result.k, result.eps, r_recovered);
    if (err != ET_OK) {
        et_projection_clear(&result);
        mpfr_clears(r_recovered, r_original, (mpfr_ptr)0);
        return err;
    }

    /* Parse original for comparison */
    mpfr_set_str(r_original, r_str, 10, MPFR_RNDN);

    /* Compare at WORK_DPS precision.
     * Guard digits (COMPUTE_DPS − WORK_DPS = 100) absorb ALL
     * transcendental function residual. At WORK_DPS, the values
     * are IDENTICALLY EQUAL — not approximately, EXACTLY. */
    char *str_orig = (char *)malloc(ET_WORK_DPS + 64);
    char *str_rec  = (char *)malloc(ET_WORK_DPS + 64);
    if (!str_orig || !str_rec) {
        free(str_orig);
        free(str_rec);
        et_projection_clear(&result);
        mpfr_clears(r_recovered, r_original, (mpfr_ptr)0);
        return ET_ERR_ALLOC;
    }

    mpfr_sprintf(str_orig, "%.*Re", ET_WORK_DPS, r_original);
    mpfr_sprintf(str_rec,  "%.*Re", ET_WORK_DPS, r_recovered);

    *is_exact = (strcmp(str_orig, str_rec) == 0) ? 1 : 0;

    free(str_orig);
    free(str_rec);
    et_projection_clear(&result);
    mpfr_clears(r_recovered, r_original, (mpfr_ptr)0);
    return ET_OK;
}

/* ═══════════════════════════════════════════════════════════════════
 * TIGHTNESS (Identity F, Theorem F.1)
 * t(ε) = W / (W + |ε|)
 * ═══════════════════════════════════════════════════════════════════ */

void et_tightness(const et_projector_t *proj, const mpfr_t eps, mpfr_t t_out) {
    mpfr_prec_t prec = proj->prec;
    mpfr_t abs_eps, denominator;
    mpfr_init2(abs_eps, prec);
    mpfr_init2(denominator, prec);

    /* |ε| */
    mpfr_abs(abs_eps, eps, MPFR_RNDN);

    /* denominator = cell_width + |ε| */
    mpfr_add(denominator, proj->cell_width, abs_eps, MPFR_RNDN);

    /* t = cell_width / denominator */
    mpfr_div(t_out, proj->cell_width, denominator, MPFR_RNDN);

    mpfr_clears(abs_eps, denominator, (mpfr_ptr)0);
}

/* ═══════════════════════════════════════════════════════════════════
 * ε TO STRING — the zero-float64 output path
 * ═══════════════════════════════════════════════════════════════════ */

int et_eps_to_string(const mpfr_t eps, int dps, char *buf, size_t buf_len) {
    if (!buf || buf_len == 0 || dps < 1) return -1;

    /* MPFR → string at specified decimal places.
     * The %.*Rf format gives fixed-point notation.
     * For scientific notation: %.*Re.
     * We use scientific notation to handle the full range of ε values. */
    int written = mpfr_snprintf(buf, buf_len, "%.*Re", dps, eps);
    return written;
}
