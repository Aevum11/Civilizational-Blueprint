"""
SYSTEMATIC DSR COMPARISON — Which ratio reveals nuclear stability?
Project ALL candidate DSRs through the Sempaevum at N=12 and compare.
Every DSR uses REAL MEASURED VALUES from AME2020 (string → mpmath, zero float).
"""
import sys
sys.path.insert(0, '/home/claude')
import mpmath
mpmath.mp.dps = 130
from collections import defaultdict

from sempaevum_nz_viewer import (
    build_atomic_particles, sempaevum_project_mp, N
)

print("Loading data...")
particles = build_atomic_particles(measured_only=True)
print(f"Built {len(particles)} isotopes\n")

# Constants
m_p = mpmath.mpf("1.007276466621")
m_n = mpmath.mpf("1.008664915600")
m_e_MeV = mpmath.mpf("0.51099895000")
u_to_MeV = mpmath.mpf("931.494102")

# Build per-isotope data
isotopes = []
for p in particles:
    Z = p.get("Z", 0)
    A = p.get("A", 0)
    N_val = A - Z
    if Z == 0 or A == 0: continue
    
    mass_str = p.get("Ar_str", p.get("mass_str", ""))
    if not mass_str: continue
    
    M = mpmath.mpf(mass_str)
    is_nat = p.get("is_naturally_occurring", False)
    be_str = p.get("binding_energy_per_A_keV", "0")
    
    isotopes.append({
        "sym": p["symbol"], "Z": Z, "A": A, "N": N_val,
        "M": M, "nat": is_nat, "be_str": be_str,
    })

print(f"Prepared {len(isotopes)} isotopes for DSR comparison\n")

# ================================================================
# Define all 5 DSRs
# ================================================================
dsrs = {}

# DSR 1: N/Z (neutron-to-proton ratio)
def dsr_nz(iso):
    if iso["N"] <= 0: return None
    return mpmath.mpf(iso["N"]) / mpmath.mpf(iso["Z"])
dsrs["N/Z"] = dsr_nz

# DSR 2: Binding fraction Δm / M_constituent
def dsr_bf(iso):
    constituent = iso["Z"] * m_p + iso["N"] * m_n
    defect = constituent - iso["M"]
    if defect <= 0: return None
    return defect / constituent
dsrs["Binding_fraction"] = dsr_bf

# DSR 3: BE/A / m_e (binding energy per nucleon in electron mass units)
def dsr_bea(iso):
    be_str = iso["be_str"]
    if not be_str or be_str == "0": return None
    try:
        be_keV = mpmath.mpf(be_str)
    except:
        return None
    if be_keV <= 0: return None
    be_MeV = be_keV / mpmath.mpf(1000)
    return be_MeV / m_e_MeV
dsrs["BE_per_A_over_me"] = dsr_bea

# DSR 4: Mass defect per nucleon |Δm/A| in electron mass units
def dsr_defect_per_A(iso):
    constituent = iso["Z"] * m_p + iso["N"] * m_n
    defect = constituent - iso["M"]
    if defect <= 0: return None
    defect_per_A = defect / mpmath.mpf(iso["A"])
    defect_MeV = defect_per_A * u_to_MeV
    return defect_MeV / m_e_MeV
dsrs["Defect_per_A_over_me"] = dsr_defect_per_A

# DSR 5: Neutron separation energy S_n = M(Z,A-1) + m_n - M(Z,A) in m_e units
# Need lookup by (Z,A)
by_ZA = {(p["Z"], p["A"]): p for p in isotopes}
def dsr_sn(iso):
    parent = by_ZA.get((iso["Z"], iso["A"] - 1))
    if not parent: return None
    Sn_u = parent["M"] + m_n - iso["M"]
    if Sn_u <= 0: return None
    Sn_MeV = Sn_u * u_to_MeV
    return Sn_MeV / m_e_MeV
dsrs["Sn_over_me"] = dsr_sn

# ================================================================
# Project each DSR and measure stability separation
# ================================================================
print("=" * 100)
print("SYSTEMATIC DSR COMPARISON — Stability Separation at N=12")
print("=" * 100)

for dsr_name, dsr_func in dsrs.items():
    print(f"\n{'─' * 100}")
    print(f"DSR: {dsr_name}")
    print(f"{'─' * 100}")
    
    # Project all isotopes
    k_nat = defaultdict(int)
    k_all = defaultdict(int)
    projected = 0
    skipped = 0
    
    for iso in isotopes:
        r = dsr_func(iso)
        if r is None or r <= 0:
            skipped += 1
            continue
        
        r_str = mpmath.nstr(r, 40)
        proj = sempaevum_project_mp(r_str, 12)
        if proj is None:
            skipped += 1
            continue
        
        k, d, eps = proj
        k_all[k] += 1
        if iso["nat"]:
            k_nat[k] += 1
        projected += 1
    
    print(f"  Projected: {projected}, Skipped: {skipped}")
    
    # Compute stability separation metric:
    # For each k, what fraction is natural? Find the SHARPEST boundary.
    all_k = sorted(k_all.keys())
    if not all_k:
        print("  NO DATA")
        continue
    
    # Find the k-range with the highest natural concentration
    best_band_score = 0
    best_band = None
    total_nat = sum(k_nat.values())
    
    # Try all contiguous bands of width 1 to 20
    for width in range(1, min(21, len(all_k))):
        for start_idx in range(len(all_k) - width + 1):
            band_ks = all_k[start_idx:start_idx + width]
            band_nat = sum(k_nat.get(k, 0) for k in band_ks)
            band_all = sum(k_all.get(k, 0) for k in band_ks)
            band_nat_frac = band_nat / total_nat if total_nat > 0 else 0
            band_purity = band_nat / band_all if band_all > 0 else 0
            # Score = fraction of all naturals captured × purity
            score = band_nat_frac * band_purity
            if score > best_band_score:
                best_band_score = score
                best_band = (band_ks[0], band_ks[-1], width, band_nat, band_all, band_nat_frac, band_purity)
    
    if best_band:
        k_lo, k_hi, w, bn, ba, bnf, bp = best_band
        print(f"  Best stability band: k ∈ [{k_lo}, {k_hi}] (width={w})")
        print(f"    Captures {bn}/{total_nat} natural ({bnf*100:.1f}%)")
        print(f"    Band purity: {bn}/{ba} = {bp*100:.1f}% natural")
        print(f"    Score (capture × purity): {best_band_score:.4f}")
    
    # Show k distribution
    print(f"\n  k distribution (top 15 most populated):")
    top_k = sorted(k_all.items(), key=lambda x: -x[1])[:15]
    for k, count in top_k:
        n = k_nat.get(k, 0)
        pct = 100 * n / count if count else 0
        bar = "█" * int(pct / 2) + "░" * (50 - int(pct / 2))
        print(f"    k={k:>5d}: {count:>5d} total, {n:>4d} nat ({pct:>5.1f}%) {bar}")
    
    # Natural isotopes outside the best band
    outside_nat = total_nat - (best_band[3] if best_band else 0)
    print(f"\n  Natural OUTSIDE best band: {outside_nat}")

print(f"\n{'=' * 100}")
print("COMPARISON COMPLETE")
print("=" * 100)
