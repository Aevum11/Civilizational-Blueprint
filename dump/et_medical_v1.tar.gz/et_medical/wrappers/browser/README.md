# libet_med — Browser Wrapper (WebAssembly)

JavaScript facade over an Emscripten-built `et_med.wasm`, usable from
any modern browser or Node.js. API matches the Windows `.NET` and Android
`Kotlin` wrappers one-for-one.

## Directory contents

| File | Purpose |
|------|---------|
| `libet_med.js`   | JS facade — wraps the Emscripten glue, exposes `EtMed` class |
| `index.html`     | Single-page demo UI (input form + findings table) |
| `build_wasm.sh`  | Shell script that invokes Emscripten to build `et_med.{js,wasm}` |
| `README.md`      | This file |

## Build

This wrapper requires the Emscripten SDK (emsdk). The host (Ubuntu, macOS,
Windows with WSL, etc.) builds `et_med.wasm` once; the browser then loads
both `et_med.js` (Emscripten glue) and `libet_med.js` (our facade).

```bash
# 1. Install emsdk (one-time, ~2 GB)
git clone https://github.com/emscripten-core/emsdk.git
cd emsdk
./emsdk install latest
./emsdk activate latest
source ./emsdk_env.sh

# 2. Return to this directory and build
cd /path/to/et_medical/wrappers/browser
./build_wasm.sh
```

Output lands in `./build_wasm/`:
- `et_med.js` — Emscripten-generated glue code
- `et_med.wasm` — the compiled library (~40 KB)

## Run the demo

```bash
# Serve locally (WASM needs a proper MIME type; opening via file:// won't work)
python3 -m http.server 8080
```

Then open <http://localhost:8080/index.html>. Fill in the patient baseline
and current measurements, click **Compute**.

## Integration

### Plain `<script>` usage

```html
<script src="build_wasm/et_med.js"></script>
<script src="libet_med.js"></script>
<script>
  createLibEtMed().then(Module => {
    const api = new EtMed(Module);
    const patient = api.patientBaseline({ hrRestBpm: 60, sex: 1 });
    const signature = api.computeMultifoldSignature(patient);
    console.log(signature.scalar, signature.normalizedVsReference);

    const findings = api.generateFindings(
      [api.measurement({ name: "HR", currentValue: 120,
                         tower: 0 /* Cardiac */, units: "bpm" })],
      patient);
    findings.forEach(f => console.log(f.name, f.state, f.severityPct));
  });
</script>
```

### Node.js / ESM usage

The Emscripten output supports both `MODULARIZE=1` factory style (`createLibEtMed`)
and bundler-friendly import. For Node:

```js
const createLibEtMed = require('./build_wasm/et_med.js');
const { EtMed, Tower } = require('./libet_med.js');

createLibEtMed().then(Module => {
    const api = new EtMed(Module);
    // ... same as in the browser
});
```

## ABI notes

The facade hard-codes struct layout offsets that match the **Linux x86-64
build** (all that was testable when this wrapper was written). The same
offsets apply to the WASM32 build because WASM uses the same ILP32-style
layout rules plus the C11 alignment requirements — `sizeof(double)=8`,
`sizeof(int)=4`, struct members naturally aligned. These are verified by
a small `abi_probe.c` in `libet_med/test/` that prints every `offsetof`.

If a future change to `libet_med.h` alters struct layout, re-run
`abi_probe` on the native build and update the offset tables near the top
of `libet_med.js` accordingly.

## Status note

As of 2026-04-20 this wrapper is **source-complete but not runtime-tested
from the sandbox where it was written** — the sandbox cannot reach
`storage.googleapis.com` to download Emscripten binaries. The `.js` facade,
build script, and HTML demo are all production code and should work when
Mike runs `build_wasm.sh` on a machine with emsdk installed.

The C ABI this wrapper targets is exercised by 180+ unit-test assertions
on the native build. The JNI wrapper, Windows P/Invoke wrapper, and this
browser wrapper all bind to the *same* C entry points; differences among
them are purely in the language-specific marshalling layer.
