# -*- mode: python ; coding: utf-8 -*-
"""
Exception Theory — CDF Compressor PyInstaller Build Specification
=================================================================

Build specification for packaging et_cdf_compressor.py into a standalone
single-file executable (.exe) with optional bundled C pattern engine DLL.

ET Derivation (Three Tools):
  Identification Principle: This spec identifies the complete D-set required
  to build the executable — the Python source (P-substrate), the DLL binary
  (D-constraint on pattern engine availability), and PyInstaller's build
  engine (T-agency that traverses the spec to produce the .exe).

  Descriptor Gap Principle: The DLL is detected dynamically at build time.
  If present, it is bundled; if absent, the .exe auto-compiles from embedded
  C source at runtime. The gap between "DLL available" and "DLL bundled" is
  closed by os.path.isfile detection — no static assumption.

  Subsumption Law: The spec subsumes ALL build configurations without remainder:
  DLL present → bundled; DLL absent → omitted. No manual intervention needed.

P ∘ D ∘ T = E
Author: Michael James Muller — Aevum_Defluo
"""

import os
from PyInstaller.building.build_main import Analysis
from PyInstaller.building.api import PYZ, EXE

# ── Dynamic DLL Detection ──────────────────────────────────────────────
# Descriptor Gap Principle: the gap between "DLL exists on disk" and "DLL
# bundled into .exe" is closed by runtime detection. No static list —
# the DLL is discovered dynamically via os.path.isfile. If the DLL was
# compiled (by build.bat or CMake), it gets bundled. If not, the .exe
# auto-compiles from embedded C source at runtime (zero loss in function).
_dll_name = 'et_pattern_engine.dll'
_binaries = [(_dll_name, '.')] if os.path.isfile(_dll_name) else []

a = Analysis(
    ['et_cdf_compressor.py'],
    pathex=[],
    binaries=_binaries,
    datas=[],
    hiddenimports=[],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name='et_cdf_compressor',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)
