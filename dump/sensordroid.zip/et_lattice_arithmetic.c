/*
 * ET LOSSLESS SENSOR CAPTURE — LATTICE ARITHMETIC IMPLEMENTATION
 * ===============================================================
 * Identity A (Theorems A.1–A.6): arithmetic in lattice coordinates
 * without accessing the underlying real values.
 *
 * κ (kappa) is the rounding correction — the T-act's trace in
 * lattice arithmetic. At N=12: 79% of multiplications have κ=0,
 * 21% have κ=±1. The T-act is MOSTLY invisible but structurally
 * present in every operation.
 *
 * Author: Michael James Muller — Aevum Defluo (Exception Theory)
 * License: CC-BY-4.0
 */

#include "et_lattice_arithmetic.h"
#include <stdlib.h>

static long la_gcd(long a, long b) {
    if (a < 0) a = -a;
    if (b < 0) b = -b;
    while (b != 0) { long t = b; b = a % b; a = t; }
    return a;
}

et_error_t et_arith_result_init(et_arith_result_t *r, mpfr_prec_t prec) {
    if (!r) return ET_ERR_NULL_INPUT;
    r->k = 0; r->d = 0; r->kappa = 0;
    mpfr_init2(r->eps, prec);
    return ET_OK;
}

void et_arith_result_clear(et_arith_result_t *r) {
    if (!r) return;
    mpfr_clear(r->eps);
}

/*
 * Common helper: given δ_sum (the combined fractional offset),
 * compute κ, k_result, d_result, ε_result.
 */
static void finalize_arith(int N, long k_base, const mpfr_t delta_sum,
                            et_arith_result_t *result, mpfr_prec_t prec) {
    mpfr_t kappa_mpfr, delta_rem, cents, N_mpfr;
    mpfr_init2(kappa_mpfr, prec);
    mpfr_init2(delta_rem, prec);
    mpfr_init2(cents, prec);
    mpfr_init2(N_mpfr, prec);

    mpfr_set_si(cents, ET_CENTS_PER_OCTAVE, MPFR_RNDN);
    mpfr_set_si(N_mpfr, N, MPFR_RNDN);

    /* κ = round(δ_sum) — THE T-ACT in lattice arithmetic */
    mpfr_round(kappa_mpfr, delta_sum);
    long kappa = mpfr_get_si(kappa_mpfr, MPFR_RNDN);

    /* k_result = k_base + κ */
    long k_result = k_base + kappa;

    /* d = N / gcd(|k|, N) */
    long g = (k_result == 0) ? (long)N : la_gcd(k_result < 0 ? -k_result : k_result, (long)N);
    int d_result = (int)(N / g);

    /* ε = (δ_sum − κ) · 1200/N */
    mpfr_sub(delta_rem, delta_sum, kappa_mpfr, MPFR_RNDN);
    mpfr_mul(result->eps, delta_rem, cents, MPFR_RNDN);
    mpfr_div(result->eps, result->eps, N_mpfr, MPFR_RNDN);

    result->k = k_result;
    result->d = d_result;
    result->kappa = kappa;

    mpfr_clears(kappa_mpfr, delta_rem, cents, N_mpfr, (mpfr_ptr)0);
}

/* ═══════════════════════════════════════════════════════════════════
 * A.1: MULTIPLICATION — Π_N(r₁ · r₂) in lattice coordinates
 *
 * log₂(r₁·r₂) = log₂(r₁) + log₂(r₂)
 * N·log₂(r₁·r₂) = (k₁ + δ₁) + (k₂ + δ₂)
 * k_× = k₁ + k₂ + round(δ₁ + δ₂)
 * ═══════════════════════════════════════════════════════════════════ */
et_error_t et_lattice_multiply(int N, long k1, const mpfr_t eps1,
                                long k2, const mpfr_t eps2,
                                et_arith_result_t *result, mpfr_prec_t prec) {
    if (!result) return ET_ERR_NULL_INPUT;

    mpfr_t delta1, delta2, delta_sum, cents, N_mpfr;
    mpfr_init2(delta1, prec);
    mpfr_init2(delta2, prec);
    mpfr_init2(delta_sum, prec);
    mpfr_init2(cents, prec);
    mpfr_init2(N_mpfr, prec);

    mpfr_set_si(cents, ET_CENTS_PER_OCTAVE, MPFR_RNDN);
    mpfr_set_si(N_mpfr, N, MPFR_RNDN);

    /* δᵢ = εᵢ · N / 1200 */
    mpfr_mul(delta1, eps1, N_mpfr, MPFR_RNDN);
    mpfr_div(delta1, delta1, cents, MPFR_RNDN);
    mpfr_mul(delta2, eps2, N_mpfr, MPFR_RNDN);
    mpfr_div(delta2, delta2, cents, MPFR_RNDN);

    /* δ_sum = δ₁ + δ₂ */
    mpfr_add(delta_sum, delta1, delta2, MPFR_RNDN);

    finalize_arith(N, k1 + k2, delta_sum, result, prec);

    mpfr_clears(delta1, delta2, delta_sum, cents, N_mpfr, (mpfr_ptr)0);
    return ET_OK;
}

/* ═══════════════════════════════════════════════════════════════════
 * A.2: DIVISION — Π_N(r₁ / r₂) in lattice coordinates
 *
 * log₂(r₁/r₂) = log₂(r₁) − log₂(r₂)
 * ═══════════════════════════════════════════════════════════════════ */
et_error_t et_lattice_divide(int N, long k1, const mpfr_t eps1,
                              long k2, const mpfr_t eps2,
                              et_arith_result_t *result, mpfr_prec_t prec) {
    if (!result) return ET_ERR_NULL_INPUT;

    mpfr_t delta1, delta2, delta_diff, cents, N_mpfr;
    mpfr_init2(delta1, prec);
    mpfr_init2(delta2, prec);
    mpfr_init2(delta_diff, prec);
    mpfr_init2(cents, prec);
    mpfr_init2(N_mpfr, prec);

    mpfr_set_si(cents, ET_CENTS_PER_OCTAVE, MPFR_RNDN);
    mpfr_set_si(N_mpfr, N, MPFR_RNDN);

    mpfr_mul(delta1, eps1, N_mpfr, MPFR_RNDN);
    mpfr_div(delta1, delta1, cents, MPFR_RNDN);
    mpfr_mul(delta2, eps2, N_mpfr, MPFR_RNDN);
    mpfr_div(delta2, delta2, cents, MPFR_RNDN);

    /* δ_diff = δ₁ − δ₂ */
    mpfr_sub(delta_diff, delta1, delta2, MPFR_RNDN);

    finalize_arith(N, k1 - k2, delta_diff, result, prec);

    mpfr_clears(delta1, delta2, delta_diff, cents, N_mpfr, (mpfr_ptr)0);
    return ET_OK;
}

/* ═══════════════════════════════════════════════════════════════════
 * A.3: RECIPROCATION — Π_N(1/r) = mirror symmetry
 *
 * For |ε| < half-cell strictly: (−k, d, −ε), κ=0.
 * At ∂I boundary: mirror symmetry BREAKS (Identity F, Theorem F.4).
 * ═══════════════════════════════════════════════════════════════════ */
et_error_t et_lattice_reciprocal(int N, long k1, const mpfr_t eps1,
                                  et_arith_result_t *result, mpfr_prec_t prec) {
    if (!result) return ET_ERR_NULL_INPUT;

    mpfr_t delta1, neg_delta, cents, N_mpfr;
    mpfr_init2(delta1, prec);
    mpfr_init2(neg_delta, prec);
    mpfr_init2(cents, prec);
    mpfr_init2(N_mpfr, prec);

    mpfr_set_si(cents, ET_CENTS_PER_OCTAVE, MPFR_RNDN);
    mpfr_set_si(N_mpfr, N, MPFR_RNDN);

    mpfr_mul(delta1, eps1, N_mpfr, MPFR_RNDN);
    mpfr_div(delta1, delta1, cents, MPFR_RNDN);

    /* −δ₁ */
    mpfr_neg(neg_delta, delta1, MPFR_RNDN);

    finalize_arith(N, -k1, neg_delta, result, prec);

    mpfr_clears(delta1, neg_delta, cents, N_mpfr, (mpfr_ptr)0);
    return ET_OK;
}

/* ═══════════════════════════════════════════════════════════════════
 * A.4: POWER — Π_N(r^n) from (k, ε) and integer n
 *
 * log₂(r^n) = n · log₂(r)
 * N·log₂(r^n) = n·(k + δ) = n·k + n·δ
 * κ_n = round(n·δ), |κ_n| ≤ ⌈|n|/2⌉
 * ═══════════════════════════════════════════════════════════════════ */
et_error_t et_lattice_power(int N, long k1, const mpfr_t eps1, int n,
                             et_arith_result_t *result, mpfr_prec_t prec) {
    if (!result) return ET_ERR_NULL_INPUT;

    mpfr_t delta1, n_delta, cents, N_mpfr, n_mpfr;
    mpfr_init2(delta1, prec);
    mpfr_init2(n_delta, prec);
    mpfr_init2(cents, prec);
    mpfr_init2(N_mpfr, prec);
    mpfr_init2(n_mpfr, prec);

    mpfr_set_si(cents, ET_CENTS_PER_OCTAVE, MPFR_RNDN);
    mpfr_set_si(N_mpfr, N, MPFR_RNDN);
    mpfr_set_si(n_mpfr, n, MPFR_RNDN);

    mpfr_mul(delta1, eps1, N_mpfr, MPFR_RNDN);
    mpfr_div(delta1, delta1, cents, MPFR_RNDN);

    /* n·δ */
    mpfr_mul(n_delta, n_mpfr, delta1, MPFR_RNDN);

    finalize_arith(N, (long)n * k1, n_delta, result, prec);

    mpfr_clears(delta1, n_delta, cents, N_mpfr, n_mpfr, (mpfr_ptr)0);
    return ET_OK;
}
