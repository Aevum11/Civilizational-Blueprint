// ============================================================================
// EtMedConsoleDemo.cs — Windows console demo for libet_med via P/Invoke
// ----------------------------------------------------------------------------
//  Build:
//      dotnet new console -n EtMedConsoleDemo
//      # copy this file and LibEtMed.cs in
//      dotnet run
//  Requires libet_med.dll on PATH or beside the executable.
// ============================================================================
using System;
using EtMed;

public class EtMedConsoleDemo
{
    public static int Main(string[] args)
    {
        Console.WriteLine("====================================================================");
        Console.WriteLine("  libet_med — .NET / Windows console demo");
        Console.WriteLine("====================================================================");

        // Demo patient matching the C CLI's defaults
        var patient = PatientBaseline.Empty();
        patient.HrRestBpm     = 60.0;
        patient.RrRestPerMin  = 12.0;
        patient.TemperatureC  = 36.8;
        patient.AgeYears      = 45.0;
        patient.SexValue      = Sex.Male;

        Console.WriteLine($"  Baseline: HR={patient.HrRestBpm} bpm  RR={patient.RrRestPerMin}/min  Temp={patient.TemperatureC} C  Sex={patient.SexValue}");

        // Multifold signature
        Console.WriteLine("\n--- Multifold Signature ---");
        var mf = EtMedLib.ComputeMultifoldSignature(patient);
        for (int i = 0; i < EtMed.TowerCount; ++i)
        {
            var t = (Tower)i;
            Console.WriteLine($"  {t,-16} R0 = {mf.R0Seconds[i],14:G6} s   N={EtMedLib.TowerResolution(t),-6}  {(mf.R0Present[i] ? "patient" : "default")}");
        }
        Console.WriteLine($"  Scalar M (geometric mean): {mf.Scalar:F4}");
        Console.WriteLine($"  Normalized vs. reference:  {mf.NormalizedVsReference:F4}  (1.0 = population-baseline)");
        Console.WriteLine($"  Valid pairs counted:       {mf.PairCountValid} / 45");

        // Measurements
        var measurements = new[] {
            new Measurement { Name = "HR",   CurrentValue = 120.0, Units = "bpm",  Tower = Tower.Cardiac },
            new Measurement { Name = "RR",   CurrentValue =  30.0, Units = "/min", Tower = Tower.Respiratory },
            new Measurement { Name = "TEMP", CurrentValue =  38.8, Units = "C",    Tower = Tower.Endocrine },
            new Measurement { Name = "GAIT", CurrentValue =   1.0, Units = "s",    Tower = Tower.Musculoskeletal }
        };

        Console.WriteLine("\n--- Findings (sorted by urgency) ---");
        var findings = EtMedLib.GenerateFindings(measurements, patient);
        Console.WriteLine($"  {"#",-4}  {"Tower",-16}  {"Name",-8}  {"State",-17}  {"Sev%",-7}  Details");
        Console.WriteLine($"  {new string('-',4)}  {new string('-',16)}  {new string('-',8)}  {new string('-',17)}  {new string('-',7)}  -------");
        foreach (var f in findings)
        {
            Console.WriteLine($"  {f.UrgencyRank,-4}  {f.Tower,-16}  {f.Name,-8}  {f.State,-17}  {f.SeverityPct,7:F2}  k={f.Projection.K} d={f.Projection.D} eps={f.Projection.EpsCents:+0.00;-0.00;0.00}¢  ({f.SeverityText})");
        }

        Console.WriteLine($"\n  Fallback paths during run: {EtMedLib.FallbackCount()}");
        Console.WriteLine("====================================================================");
        return 0;
    }
}
