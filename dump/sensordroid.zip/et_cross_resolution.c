/*
 * ET LOSSLESS SENSOR CAPTURE — CROSS-RESOLUTION IMPLEMENTATION
 * =============================================================
 * Finding 11: Three transition map cases.
 * All derived forward from P∘D∘T = E via the bijection.
 *
 * Author: Michael James Muller — Aevum Defluo (Exception Theory)
 * License: CC-BY-4.0
 */

#include "et_cross_resolution.h"
#include <stdlib.h>

static long cr_gcd(long a, long b) {
    if (a < 0) a = -a;
    if (b < 0) b = -b;
    while (b != 0) { long t = b; b = a % b; a = t; }
    return a;
}

/* ═══════════════════════════════════════════════════════════════════
 * CASE 1: CROSS-RESOLUTION (same R₀, N₁ | N₂)
 *
 * THEOREM: Let N₁ | N₂ with M = N₂/N₁. Given Π_N₁(r) = (k₁, d₁, ε₁),
 *   δ₁ = ε₁ · N₁ / 1200
 *   k₂ = round(M · k₁ + M · δ₁)
 *   ε₂ = (M·k₁ + M·δ₁ − k₂) · 1200/N₂
 *   d₂ = N₂/gcd(|k₂|, N₂)
 *
 * PROOF: By losslessness (Theorem 19.4):
 *   N₁·log₂(r) = k₁ + δ₁  (algebraic identity)
 *   N₂·log₂(r) = M·N₁·log₂(r) = M·(k₁ + δ₁)
 *   k₂ = round(N₂·log₂(r)) = round(M·k₁ + M·δ₁)  ∎
 * ═══════════════════════════════════════════════════════════════════ */
et_error_t et_cross_resolution(long k1, int d1, const mpfr_t eps1,
                                int N1, int N2,
                                long *k2_out, int *d2_out, mpfr_t eps2_out,
                                mpfr_prec_t prec) {
    if (!k2_out || !d2_out) return ET_ERR_NULL_INPUT;
    if (N1 < 1 || N2 < 1) return ET_ERR_INVALID_N;
    if (N2 % N1 != 0) return ET_ERR_TRANSITION; /* N₁ must divide N₂ */

    int M = N2 / N1;

    mpfr_t delta1, exact_pos, k2_mpfr, cents, N1_mpfr, N2_mpfr, M_mpfr;
    mpfr_init2(delta1, prec);
    mpfr_init2(exact_pos, prec);
    mpfr_init2(k2_mpfr, prec);
    mpfr_init2(cents, prec);
    mpfr_init2(N1_mpfr, prec);
    mpfr_init2(N2_mpfr, prec);
    mpfr_init2(M_mpfr, prec);

    mpfr_set_si(cents, ET_CENTS_PER_OCTAVE, MPFR_RNDN);
    mpfr_set_si(N1_mpfr, N1, MPFR_RNDN);
    mpfr_set_si(N2_mpfr, N2, MPFR_RNDN);
    mpfr_set_si(M_mpfr, M, MPFR_RNDN);

    /* δ₁ = ε₁ · N₁ / 1200 */
    mpfr_mul(delta1, eps1, N1_mpfr, MPFR_RNDN);
    mpfr_div(delta1, delta1, cents, MPFR_RNDN);

    /* exact_pos = M · k₁ + M · δ₁ */
    mpfr_t k1_mpfr;
    mpfr_init2(k1_mpfr, prec);
    mpfr_set_si(k1_mpfr, k1, MPFR_RNDN);
    mpfr_mul(exact_pos, M_mpfr, k1_mpfr, MPFR_RNDN);
    mpfr_t m_delta;
    mpfr_init2(m_delta, prec);
    mpfr_mul(m_delta, M_mpfr, delta1, MPFR_RNDN);
    mpfr_add(exact_pos, exact_pos, m_delta, MPFR_RNDN);

    /* k₂ = round(exact_pos) — T-ACT at target resolution */
    mpfr_round(k2_mpfr, exact_pos);
    long k2 = mpfr_get_si(k2_mpfr, MPFR_RNDN);

    /* d₂ = N₂ / gcd(|k₂|, N₂) */
    long g2 = (k2 == 0) ? (long)N2 : cr_gcd(k2 < 0 ? -k2 : k2, (long)N2);
    int d2 = (int)(N2 / g2);

    /* ε₂ = (exact_pos − k₂) · 1200/N₂ */
    mpfr_sub(eps2_out, exact_pos, k2_mpfr, MPFR_RNDN);
    mpfr_mul(eps2_out, eps2_out, cents, MPFR_RNDN);
    mpfr_div(eps2_out, eps2_out, N2_mpfr, MPFR_RNDN);

    *k2_out = k2;
    *d2_out = d2;

    mpfr_clears(delta1, exact_pos, k2_mpfr, cents, N1_mpfr, N2_mpfr, M_mpfr,
                k1_mpfr, m_delta, (mpfr_ptr)0);
    return ET_OK;
}

/* ═══════════════════════════════════════════════════════════════════
 * CASE 2: CROSS-SEED (same N, different R₀)
 *
 * THEOREM: Let ρ = R₀/R₀'. Given Π_N(Q/R₀) = (k₁, d₁, ε₁):
 *   Δk_exact = N · log₂(ρ)
 *   k₂ = round(k₁ + δ₁ + Δk_exact)
 *   ε₂ = (k₁ + δ₁ + Δk_exact − k₂) · 1200/N
 *   d₂ = N/gcd(|k₂|, N)
 *
 * PROOF: Q/R₀' = (Q/R₀) · (R₀/R₀') = r · ρ
 *   log₂(r·ρ) = log₂(r) + log₂(ρ)
 *   N·log₂(r·ρ) = (k₁ + δ₁) + Δk_exact  ∎
 * ═══════════════════════════════════════════════════════════════════ */
et_error_t et_cross_seed(long k1, int d1, const mpfr_t eps1,
                          int N, const char *rho_str,
                          long *k2_out, int *d2_out, mpfr_t eps2_out,
                          mpfr_prec_t prec) {
    if (!k2_out || !d2_out || !rho_str) return ET_ERR_NULL_INPUT;

    mpfr_t rho, delta1, delta_k, exact_pos, k2_mpfr, cents, N_mpfr;
    mpfr_init2(rho, prec);
    mpfr_init2(delta1, prec);
    mpfr_init2(delta_k, prec);
    mpfr_init2(exact_pos, prec);
    mpfr_init2(k2_mpfr, prec);
    mpfr_init2(cents, prec);
    mpfr_init2(N_mpfr, prec);

    mpfr_set_str(rho, rho_str, 10, MPFR_RNDN);
    mpfr_set_si(cents, ET_CENTS_PER_OCTAVE, MPFR_RNDN);
    mpfr_set_si(N_mpfr, N, MPFR_RNDN);

    /* δ₁ = ε₁ · N / 1200 */
    mpfr_mul(delta1, eps1, N_mpfr, MPFR_RNDN);
    mpfr_div(delta1, delta1, cents, MPFR_RNDN);

    /* Δk_exact = N · log₂(ρ) */
    mpfr_log2(delta_k, rho, MPFR_RNDN);
    mpfr_mul(delta_k, delta_k, N_mpfr, MPFR_RNDN);

    /* exact_pos = k₁ + δ₁ + Δk_exact */
    mpfr_t k1_mpfr;
    mpfr_init2(k1_mpfr, prec);
    mpfr_set_si(k1_mpfr, k1, MPFR_RNDN);
    mpfr_add(exact_pos, k1_mpfr, delta1, MPFR_RNDN);
    mpfr_add(exact_pos, exact_pos, delta_k, MPFR_RNDN);

    /* k₂ = round(exact_pos) */
    mpfr_round(k2_mpfr, exact_pos);
    long k2 = mpfr_get_si(k2_mpfr, MPFR_RNDN);

    /* d₂, ε₂ */
    long g2 = (k2 == 0) ? (long)N : cr_gcd(k2 < 0 ? -k2 : k2, (long)N);
    *d2_out = (int)(N / g2);
    *k2_out = k2;

    mpfr_sub(eps2_out, exact_pos, k2_mpfr, MPFR_RNDN);
    mpfr_mul(eps2_out, eps2_out, cents, MPFR_RNDN);
    mpfr_div(eps2_out, eps2_out, N_mpfr, MPFR_RNDN);

    mpfr_clears(rho, delta1, delta_k, exact_pos, k2_mpfr, cents, N_mpfr, k1_mpfr, (mpfr_ptr)0);
    return ET_OK;
}

/* ═══════════════════════════════════════════════════════════════════
 * CASE 3: FULL CROSS-TOWER (different N AND R₀)
 *
 * THEOREM: General transition Π_N₂^{R₀'} ∘ (Π_N₁^{R₀})⁻¹:
 *   x = (k₁ + ε₁·N₁/1200) / N₁   (recover log₂(Q/R₀))
 *   x' = x + log₂(R₀/R₀')          (shift to new seed)
 *   k₂ = round(N₂ · x')
 *   ε₂ = (N₂·x' − k₂) · 1200/N₂
 *   d₂ = N₂/gcd(|k₂|, N₂)
 *
 * Factors as: (Seed ∘ Scale) = (Scale ∘ Seed) — COMMUTATIVE
 * ═══════════════════════════════════════════════════════════════════ */
et_error_t et_full_cross_tower(long k1, int d1, const mpfr_t eps1,
                                int N1, int N2, const char *rho_str,
                                long *k2_out, int *d2_out, mpfr_t eps2_out,
                                mpfr_prec_t prec) {
    if (!k2_out || !d2_out || !rho_str) return ET_ERR_NULL_INPUT;

    mpfr_t rho, x, x_prime, delta1, log2_rho, exact_pos, k2_mpfr;
    mpfr_t cents, N1_mpfr, N2_mpfr;
    mpfr_init2(rho, prec);
    mpfr_init2(x, prec);
    mpfr_init2(x_prime, prec);
    mpfr_init2(delta1, prec);
    mpfr_init2(log2_rho, prec);
    mpfr_init2(exact_pos, prec);
    mpfr_init2(k2_mpfr, prec);
    mpfr_init2(cents, prec);
    mpfr_init2(N1_mpfr, prec);
    mpfr_init2(N2_mpfr, prec);

    mpfr_set_str(rho, rho_str, 10, MPFR_RNDN);
    mpfr_set_si(cents, ET_CENTS_PER_OCTAVE, MPFR_RNDN);
    mpfr_set_si(N1_mpfr, N1, MPFR_RNDN);
    mpfr_set_si(N2_mpfr, N2, MPFR_RNDN);

    /* Recover x = (k₁ + ε₁·N₁/1200) / N₁ = log₂(Q/R₀) */
    mpfr_mul(delta1, eps1, N1_mpfr, MPFR_RNDN);
    mpfr_div(delta1, delta1, cents, MPFR_RNDN);
    mpfr_t k1_mpfr;
    mpfr_init2(k1_mpfr, prec);
    mpfr_set_si(k1_mpfr, k1, MPFR_RNDN);
    mpfr_add(x, k1_mpfr, delta1, MPFR_RNDN);
    mpfr_div(x, x, N1_mpfr, MPFR_RNDN);

    /* Shift to new seed: x' = x + log₂(ρ) */
    mpfr_log2(log2_rho, rho, MPFR_RNDN);
    mpfr_add(x_prime, x, log2_rho, MPFR_RNDN);

    /* Project at N₂: k₂ = round(N₂ · x') */
    mpfr_mul(exact_pos, N2_mpfr, x_prime, MPFR_RNDN);
    mpfr_round(k2_mpfr, exact_pos);
    long k2 = mpfr_get_si(k2_mpfr, MPFR_RNDN);

    /* d₂, ε₂ */
    long g2 = (k2 == 0) ? (long)N2 : cr_gcd(k2 < 0 ? -k2 : k2, (long)N2);
    *d2_out = (int)(N2 / g2);
    *k2_out = k2;

    mpfr_sub(eps2_out, exact_pos, k2_mpfr, MPFR_RNDN);
    mpfr_mul(eps2_out, eps2_out, cents, MPFR_RNDN);
    mpfr_div(eps2_out, eps2_out, N2_mpfr, MPFR_RNDN);

    mpfr_clears(rho, x, x_prime, delta1, log2_rho, exact_pos, k2_mpfr,
                cents, N1_mpfr, N2_mpfr, k1_mpfr, (mpfr_ptr)0);
    return ET_OK;
}
